param(
    [Parameter(Mandatory = $false)]
    [string]$RepoRoot = (Get-Location).Path
)

$ErrorActionPreference = "Stop"

$source = Join-Path $PSScriptRoot "AI_HLY\Downstream\ToolActivityTimeline"
$destination = Join-Path $RepoRoot "AI_HLY\Downstream\ToolActivityTimeline"

if (-not (Test-Path (Join-Path $RepoRoot ".git"))) {
    throw "RepoRoot is not a Git repository: $RepoRoot"
}

if (-not (Test-Path $source)) {
    throw "Package source folder is missing: $source"
}

New-Item -ItemType Directory -Force -Path $destination | Out-Null
Copy-Item -Path (Join-Path $source "*") -Destination $destination -Recurse -Force

Write-Host ""
Write-Host "Installed ToolActivityTimeline files to:"
Write-Host "  $destination"
Write-Host ""
Write-Host "Installed files:"
Get-ChildItem -Path $destination -File | Sort-Object Name | ForEach-Object {
    Write-Host "  $($_.FullName.Substring($RepoRoot.Length + 1))"
}
Write-Host ""
Write-Host "No existing upstream-owned files were modified by this installer."
