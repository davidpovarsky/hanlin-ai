import SwiftUI

struct ToolActivitySummaryView: View {
    let timeline: ToolActivityTimeline
    let onLaunchRequest: ((NativeAppLaunchRequest) -> Void)?

    @State private var isInspectorPresented = false

    init(
        timeline: ToolActivityTimeline,
        onLaunchRequest: ((NativeAppLaunchRequest) -> Void)? = nil
    ) {
        self.timeline = timeline
        self.onLaunchRequest = onLaunchRequest
    }

    private var visibleSteps: [ToolActivityStep] {
        let ordered = timeline.orderedSteps
        if ordered.count <= 4 {
            return ordered
        }
        return Array(ordered.suffix(4))
    }

    var body: some View {
        Button {
            isInspectorPresented = true
        } label: {
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 7) {
                    statusIndicator

                    Text(summaryTitle)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)

                    Image(systemName: "chevron.down")
                        .font(.caption2.weight(.semibold))
                        .foregroundStyle(.tertiary)
                }

                ForEach(visibleSteps) { step in
                    HStack(alignment: .firstTextBaseline, spacing: 9) {
                        stepStatusIcon(step)
                            .frame(width: 18)

                        Text(step.title)
                            .font(.subheadline)
                            .foregroundStyle(step.status == .running ? .primary : .secondary)
                            .lineLimit(2)
                    }
                }

                if timeline.steps.count > visibleSteps.count {
                    Text(String(localized: "More steps"))
                        .font(.caption)
                        .foregroundStyle(.tertiary)
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(String(localized: "Open tool activity"))
        .accessibilityValue(accessibilityStatus)
        .sheet(isPresented: $isInspectorPresented) {
            ToolActivityInspectorView(
                timeline: timeline,
                onLaunchRequest: onLaunchRequest
            )
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.visible)
        }
    }

    @ViewBuilder
    private var statusIndicator: some View {
        switch timeline.status {
        case .pending, .running:
            ProgressView()
                .controlSize(.small)
        case .completed:
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.secondary)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.red)
        case .cancelled:
            Image(systemName: "xmark.circle.fill")
                .foregroundStyle(.secondary)
        }
    }

    private var summaryTitle: String {
        let duration = Duration.toolActivityString(seconds: timeline.duration)
        switch timeline.status {
        case .pending, .running:
            return String(localized: "Working…")
        case .completed:
            return String(format: String(localized: "Worked for %@"), duration)
        case .failed:
            return String(format: String(localized: "Stopped after %@"), duration)
        case .cancelled:
            return String(format: String(localized: "Cancelled after %@"), duration)
        }
    }

    private var accessibilityStatus: String {
        switch timeline.status {
        case .pending, .running:
            String(localized: "Working…")
        case .completed:
            String(localized: "Done")
        case .failed:
            String(localized: "Failed")
        case .cancelled:
            String(localized: "Cancelled")
        }
    }

    @ViewBuilder
    private func stepStatusIcon(_ step: ToolActivityStep) -> some View {
        switch step.status {
        case .pending:
            Image(systemName: "circle")
                .foregroundStyle(.tertiary)
        case .running:
            ProgressView()
                .controlSize(.mini)
        case .completed:
            Image(systemName: step.kind.defaultSystemImage)
                .foregroundStyle(.secondary)
        case .failed:
            Image(systemName: "exclamationmark.triangle")
                .foregroundStyle(.red)
        case .cancelled:
            Image(systemName: "xmark.circle")
                .foregroundStyle(.secondary)
        }
    }
}

struct ToolActivityInspectorView: View {
    let timeline: ToolActivityTimeline
    let onLaunchRequest: ((NativeAppLaunchRequest) -> Void)?

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    ForEach(Array(timeline.orderedSteps.enumerated()), id: \.element.id) { index, step in
                        ToolActivityStepView(
                            step: step,
                            isLast: false,
                            onLaunchRequest: onLaunchRequest
                        )
                    }

                    ToolActivityTerminalRow(
                        timeline: timeline,
                        isLast: true
                    )
                }
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
            }
            .navigationTitle(String(localized: "Thinking"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(String(localized: "Done")) {
                        dismiss()
                    }
                }
            }
        }
    }
}

private struct ToolActivityStepView: View {
    let step: ToolActivityStep
    let isLast: Bool
    let onLaunchRequest: ((NativeAppLaunchRequest) -> Void)?

    @State private var isExpanded = true

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            timelineRail

            DisclosureGroup(isExpanded: $isExpanded) {
                ToolActivityDetailView(
                    step: step,
                    onLaunchRequest: onLaunchRequest
                )
                .padding(.top, 9)
            } label: {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text(step.title)
                            .font(.headline)
                            .multilineTextAlignment(.leading)

                        Spacer(minLength: 4)

                        Text(Duration.toolActivityString(seconds: step.duration))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.tertiary)
                    }

                    if let subtitle = nonEmpty(step.subtitle) {
                        Text(subtitle)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.leading)
                    }
                }
            }
            .padding(.bottom, isLast ? 0 : 18)
        }
    }

    private var timelineRail: some View {
        VStack(spacing: 0) {
            statusIcon
                .frame(width: 24, height: 24)

            if !isLast {
                Rectangle()
                    .fill(.separator)
                    .frame(width: 1)
                    .frame(minHeight: 42)
            }
        }
    }

    @ViewBuilder
    private var statusIcon: some View {
        switch step.status {
        case .pending:
            Image(systemName: "circle")
                .foregroundStyle(.tertiary)
        case .running:
            ProgressView()
                .controlSize(.small)
        case .completed:
            Image(systemName: step.kind.defaultSystemImage)
                .foregroundStyle(.secondary)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.red)
        case .cancelled:
            Image(systemName: "xmark.circle.fill")
                .foregroundStyle(.secondary)
        }
    }
}

private struct ToolActivityDetailView: View {
    let step: ToolActivityStep
    let onLaunchRequest: ((NativeAppLaunchRequest) -> Void)?

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !step.queryItems.isEmpty {
                ScrollView(.horizontal) {
                    HStack(spacing: 8) {
                        ForEach(step.queryItems, id: \.self) { query in
                            Text(query)
                                .font(.caption)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 6)
                                .background(.quaternary, in: .capsule)
                        }
                    }
                }
                .scrollIndicators(.hidden)
            }

            if let input = nonEmpty(step.input) {
                detailCard(title: String(localized: "Input"), text: input, monospaced: step.kind == .codeExecution)
            }

            if let output = nonEmpty(step.output) {
                detailCard(title: String(localized: "Output"), text: output, monospaced: step.kind == .codeExecution)
            }

            if let errorDescription = nonEmpty(step.errorDescription) {
                detailCard(title: String(localized: "Failed"), text: errorDescription, monospaced: false)
            }

            let safeBlocks = step.richResultBlocks.filter { $0.type != .activityTimeline }
            if !safeBlocks.isEmpty {
                NativeUIRenderer(
                    blocks: safeBlocks,
                    onLaunchRequest: onLaunchRequest
                )
            }
        }
    }

    @ViewBuilder
    private func detailCard(title: String, text: String, monospaced: Bool) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            if monospaced {
                ScrollView(.horizontal) {
                    Text(text)
                        .font(.system(.footnote, design: .monospaced))
                        .textSelection(.enabled)
                        .fixedSize(horizontal: true, vertical: false)
                }
            } else {
                Text(text)
                    .font(.subheadline)
                    .textSelection(.enabled)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.quaternary, in: .rect(cornerRadius: 12))
    }
}

private struct ToolActivityTerminalRow: View {
    let timeline: ToolActivityTimeline
    let isLast: Bool

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            VStack(spacing: 0) {
                terminalIcon
                    .frame(width: 24, height: 24)
            }

            HStack {
                Text(terminalTitle)
                    .font(.headline)

                Spacer()

                Text(Duration.toolActivityString(seconds: timeline.duration))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.tertiary)
            }
        }
    }

    @ViewBuilder
    private var terminalIcon: some View {
        switch timeline.status {
        case .pending, .running:
            ProgressView()
                .controlSize(.small)
        case .completed:
            Image(systemName: "checkmark.circle.fill")
                .foregroundStyle(.secondary)
        case .failed:
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.red)
        case .cancelled:
            Image(systemName: "xmark.circle.fill")
                .foregroundStyle(.secondary)
        }
    }

    private var terminalTitle: String {
        switch timeline.status {
        case .pending, .running:
            String(localized: "Working…")
        case .completed:
            String(localized: "Done")
        case .failed:
            String(localized: "Failed")
        case .cancelled:
            String(localized: "Cancelled")
        }
    }
}

private func nonEmpty(_ value: String?) -> String? {
    guard let value else { return nil }
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    return trimmed.isEmpty ? nil : trimmed
}
