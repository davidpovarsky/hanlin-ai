import Foundation

enum LegacyToolActivityAdapter {
    static func timeline(
        for message: ChatMessages,
        nativeUIBlocks: [NativeUIBlock]
    ) -> ToolActivityTimeline? {
        guard message.role == "assistant" || message.role == "error" else {
            return nil
        }

        var steps: [ToolActivityStep] = []
        var sequence = 0

        func append(
            kind: ToolActivityKind,
            title: String,
            subtitle: String? = nil,
            status: ToolActivityStatus = .completed,
            input: String? = nil,
            output: String? = nil,
            queryItems: [String] = [],
            richResultBlocks: [NativeUIBlock] = [],
            errorDescription: String? = nil
        ) {
            steps.append(
                ToolActivityStep(
                    sequence: sequence,
                    kind: kind,
                    title: title,
                    subtitle: subtitle,
                    status: status,
                    startedAt: message.timestamp.addingTimeInterval(Double(sequence) * 0.001),
                    completedAt: message.timestamp.addingTimeInterval(Double(sequence + 1) * 0.001),
                    input: input,
                    output: output,
                    queryItems: queryItems,
                    richResultBlocks: richResultBlocks,
                    errorDescription: errorDescription
                )
            )
            sequence += 1
        }

        if let reasoning = normalized(message.reasoning) {
            append(
                kind: .reasoning,
                title: String(localized: "Reasoned through the request"),
                subtitle: normalized(message.reasoningTime),
                output: reasoning
            )
        }

        if let toolContent = normalized(message.toolContent) {
            append(
                kind: .toolCall,
                title: toolTitle(message.toolName),
                output: toolContent
            )
        }

        if let resources = message.resources, !resources.isEmpty {
            let blocks = resources.map { resource in
                NativeUIBlock(
                    type: .source,
                    title: resource.title,
                    subtitle: resource.link,
                    url: resource.link,
                    actions: [
                        NativeUIAction(
                            type: .openURL,
                            title: String(localized: "Open"),
                            systemImage: "safari",
                            url: resource.link
                        )
                    ]
                )
            }

            append(
                kind: .webSearch,
                title: String(localized: "Searched the web"),
                subtitle: normalized(message.searchEngine),
                queryItems: resources.prefix(6).map(\.title),
                richResultBlocks: blocks
            )
        }

        if let document = normalized(message.document_text) {
            append(
                kind: .documentRead,
                title: String(localized: "Read document"),
                output: document
            )
        }

        for code in message.codeBlockData ?? [] {
            append(
                kind: .codeExecution,
                title: code.hasError
                    ? String(localized: "Code execution failed")
                    : String(localized: "Ran code"),
                subtitle: code.codeType,
                status: code.hasError ? .failed : (code.isRunning ? .running : .completed),
                input: code.code,
                output: normalized(code.output),
                errorDescription: code.hasError ? normalized(code.output) : nil
            )
        }

        appendResultSummaries(message: message, append: append)

        if !nativeUIBlocks.isEmpty {
            append(
                kind: .nativeApp,
                title: String(localized: "Used native tools"),
                richResultBlocks: nativeUIBlocks.filter { $0.type != .activityTimeline }
            )
        }

        if message.role == "error" {
            append(
                kind: .error,
                title: String(localized: "Failed"),
                status: .failed,
                output: normalized(message.text),
                errorDescription: normalized(message.text)
            )
        }

        guard !steps.isEmpty else { return nil }

        let status: ToolActivityStatus = message.role == "error"
            ? .failed
            : (steps.contains(where: { $0.status == .running }) ? .running : .completed)

        return ToolActivityTimeline(
            groupID: message.groupID,
            startedAt: message.timestamp,
            completedAt: status.isTerminal ? message.timestamp : nil,
            status: status,
            steps: steps
        )
    }

    private static func appendResultSummaries(
        message: ChatMessages,
        append: (
            ToolActivityKind,
            String,
            String?,
            ToolActivityStatus,
            String?,
            String?,
            [String],
            [NativeUIBlock],
            String?
        ) -> Void
    ) {
        if let locations = message.locationsInfo, !locations.isEmpty {
            append(.map, String(localized: "Found locations"), "\(locations.count)", .completed, nil, nil, [], [], nil)
        }
        if let routes = message.routeInfos, !routes.isEmpty {
            append(.map, String(localized: "Calculated routes"), "\(routes.count)", .completed, nil, nil, [], [], nil)
        }
        if let events = message.events, !events.isEmpty {
            append(.calendar, String(localized: "Prepared calendar items"), "\(events.count)", .completed, nil, nil, [], [], nil)
        }
        if let health = message.healthData, !health.isEmpty {
            append(.health, String(localized: "Prepared health data"), "\(health.count)", .completed, nil, nil, [], [], nil)
        }
        if let cards = message.knowledgeCard, !cards.isEmpty {
            append(.result, String(localized: "Created knowledge cards"), "\(cards.count)", .completed, nil, nil, [], [], nil)
        }
        if normalized(message.htmlContent) != nil {
            append(.result, String(localized: "Generated web content"), nil, .completed, nil, nil, [], [], nil)
        }
        if message.audioAssets?.isEmpty == false {
            append(.audio, String(localized: "Generated audio"), nil, .completed, nil, nil, [], [], nil)
        }
    }

    private static func normalized(_ value: String?) -> String? {
        guard let value else { return nil }
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    private static func toolTitle(_ name: String?) -> String {
        guard let name = normalized(name) else {
            return String(localized: "Used a tool")
        }
        let readable = name
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "-", with: " ")
            .split(separator: " ")
            .map { $0.capitalized }
            .joined(separator: " ")
        return String(localized: "Used \(readable)")
    }
}
