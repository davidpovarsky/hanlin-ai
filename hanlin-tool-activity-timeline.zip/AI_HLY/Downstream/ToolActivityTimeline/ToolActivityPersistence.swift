import Foundation

extension ChatMessages {
    var toolActivityTimeline: ToolActivityTimeline? {
        get {
            guard
                let toolActivityJSON,
                let data = toolActivityJSON.data(using: .utf8)
            else {
                return nil
            }

            return try? Self.toolActivityDecoder.decode(ToolActivityTimeline.self, from: data)
        }
        set {
            guard let newValue else {
                toolActivityJSON = nil
                return
            }

            guard let data = try? Self.toolActivityEncoder.encode(newValue) else {
                return
            }
            toolActivityJSON = String(data: data, encoding: .utf8)
        }
    }

    func persistToolActivity(_ timeline: ToolActivityTimeline) {
        toolActivityTimeline = timeline
    }

    func finishToolActivity(
        status: ToolActivityStatus,
        at date: Date = Date()
    ) {
        guard var timeline = toolActivityTimeline else { return }
        timeline.finish(status: status, at: date)
        toolActivityTimeline = timeline
    }

    private static let toolActivityEncoder: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }()

    private static let toolActivityDecoder: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
}
