import Foundation

struct ToolActivityStreamEvent: Codable, Hashable, Identifiable, Sendable {
    enum Action: String, Codable, Hashable, Sendable {
        case beginTimeline
        case beginStep
        case updateStep
        case completeStep
        case failStep
        case cancelStep
        case completeTimeline
        case failTimeline
        case cancelTimeline
    }

    var id: UUID
    var action: Action
    var timelineID: UUID
    var groupID: UUID
    var stepID: UUID?
    var sequence: Int?
    var kind: ToolActivityKind?
    var status: ToolActivityStatus?
    var title: String?
    var subtitle: String?
    var timestamp: Date
    var input: String?
    var output: String?
    var queryItems: [String]
    var richResultBlocks: [NativeUIBlock]
    var errorDescription: String?

    init(
        id: UUID = UUID(),
        action: Action,
        timelineID: UUID,
        groupID: UUID,
        stepID: UUID? = nil,
        sequence: Int? = nil,
        kind: ToolActivityKind? = nil,
        status: ToolActivityStatus? = nil,
        title: String? = nil,
        subtitle: String? = nil,
        timestamp: Date = Date(),
        input: String? = nil,
        output: String? = nil,
        queryItems: [String] = [],
        richResultBlocks: [NativeUIBlock] = [],
        errorDescription: String? = nil
    ) {
        self.id = id
        self.action = action
        self.timelineID = timelineID
        self.groupID = groupID
        self.stepID = stepID
        self.sequence = sequence
        self.kind = kind
        self.status = status
        self.title = title
        self.subtitle = subtitle
        self.timestamp = timestamp
        self.input = input
        self.output = output
        self.queryItems = queryItems
        self.richResultBlocks = richResultBlocks
        self.errorDescription = errorDescription
    }

    private enum CodingKeys: String, CodingKey {
        case id
        case action
        case timelineID
        case groupID
        case stepID
        case sequence
        case kind
        case status
        case title
        case subtitle
        case timestamp
        case input
        case output
        case queryItems
        case richResultBlocks
        case errorDescription
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        action = try container.decode(Action.self, forKey: .action)
        timelineID = try container.decodeIfPresent(UUID.self, forKey: .timelineID) ?? UUID()
        groupID = try container.decodeIfPresent(UUID.self, forKey: .groupID) ?? UUID()
        stepID = try container.decodeIfPresent(UUID.self, forKey: .stepID)
        sequence = try container.decodeIfPresent(Int.self, forKey: .sequence)
        kind = try container.decodeIfPresent(ToolActivityKind.self, forKey: .kind)
        status = try container.decodeIfPresent(ToolActivityStatus.self, forKey: .status)
        title = try container.decodeIfPresent(String.self, forKey: .title)
        subtitle = try container.decodeIfPresent(String.self, forKey: .subtitle)
        timestamp = try container.decodeIfPresent(Date.self, forKey: .timestamp) ?? Date()
        input = try container.decodeIfPresent(String.self, forKey: .input)
        output = try container.decodeIfPresent(String.self, forKey: .output)
        queryItems = try container.decodeIfPresent([String].self, forKey: .queryItems) ?? []
        richResultBlocks = try container.decodeIfPresent([NativeUIBlock].self, forKey: .richResultBlocks) ?? []
        errorDescription = try container.decodeIfPresent(String.self, forKey: .errorDescription)
    }
}
