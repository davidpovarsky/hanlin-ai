# Tool Activity Timeline

This downstream layer provides a ChatGPT-style activity timeline for Hanlin assistant turns.

## Goals

- Show one chronological activity timeline per assistant group.
- Preserve explicit step order, status, timestamps, inputs, outputs, queries, and rich native results.
- Keep most custom code outside upstream-owned files.
- Preserve old conversations through a display-time legacy adapter.
- Avoid exposing private chain-of-thought. Only visible provider reasoning and operational/tool activity are represented.

## Files

- `ToolActivityTimeline.swift` — core timeline, step, status, and kind models.
- `ToolActivityStreamEvent.swift` — forward-compatible streaming event surface.
- `ToolActivityAccumulator.swift` — `@MainActor` timeline mutation and lifecycle handling.
- `ToolActivityPersistence.swift` — `ChatMessages` JSON encoding/decoding helpers.
- `LegacyToolActivityAdapter.swift` — temporary timeline generation for old messages.
- `ToolActivityViews.swift` — compact summary, inspector sheet, timeline rows, and details.

## Required upstream hooks

The integration requires narrow changes in existing files:

1. `ChatMessages.swift`
   - Add only `var toolActivityJSON: String? = nil`.
   - Add the matching initializer parameter and assignment.

2. `APIManager.StreamData`
   - Add `var activityEvent: ToolActivityStreamEvent?`.

3. `ChatView.swift`
   - Start one accumulator for each assistant group.
   - Apply incoming `activityEvent` values.
   - Convert visible provider reasoning into one updating step.
   - Finalize and persist on success, failure, cancellation, and empty response.
   - Pass one timeline only to the selected assistant message in each group.

4. The file containing `ChatBubbleView`
   - Accept `ToolActivityTimeline?`.
   - Render `ToolActivitySummaryView` before the final answer.
   - Hide the old reasoning/tool/resources/operational blocks when a timeline exists.
   - Keep final text and interactive result cards visible.

5. `NativeToolBridge`
   - Emit begin/complete/fail events through the existing stream pathway.
   - Do not wrap every native tool result in a separate timeline.

6. `NativeUIBlock`
   - Decode arrays using `decodeIfPresent(... ) ?? []` so old JSON remains readable.

7. `Localizable.xcstrings`
   - Add activity UI strings for all languages already present in the project.

## Group ownership

Store the timeline on one assistant message only. Split assistant messages sharing a `groupID` must not each render a summary. Retry attempts require a fresh group/timeline identity so late events cannot update an older attempt.

## Legacy behavior

`LegacyToolActivityAdapter` reads old optional fields at display time and does not write migration data. It preserves reasoning, search/resources, tools, documents, code, native UI, maps, calendar, health, audio, HTML, and error information where present.

## Adding a tool kind

1. Add or reuse a `ToolActivityKind`.
2. Emit `beginStep`.
3. Update the same step ID while streaming.
4. Emit `completeStep`, `failStep`, or `cancelStep`.
5. Put interactive final content in `richResultBlocks` only when the inspector needs it.
6. Keep final result cards outside the timeline when they are the primary user-facing output.

## Merge risk

The downstream files are additive. Remaining merge risk is limited to the narrow hooks in `ChatMessages`, `APIManager`, `ChatView`, `ChatBubbleView`, `NativeToolBridge`, `NativeUIBlock`, and the string catalog.

## Verification status

The package has not been compiled with Xcode or an Apple SDK. Device/simulator verification is still required for SwiftData migration, real streaming order, cancellation/retry ownership, RTL, Dynamic Type, VoiceOver, sheet behavior, and NativeUI actions.
