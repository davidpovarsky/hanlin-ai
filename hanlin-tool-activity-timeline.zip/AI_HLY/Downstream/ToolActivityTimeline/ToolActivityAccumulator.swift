import Foundation
import Observation

@MainActor
@Observable
final class ToolActivityAccumulator {
    private(set) var timeline: ToolActivityTimeline

    init(groupID: UUID, timelineID: UUID = UUID(), startedAt: Date = Date()) {
        timeline = ToolActivityTimeline(id: timelineID, groupID: groupID, startedAt: startedAt)
    }

    init(timeline: ToolActivityTimeline) {
        self.timeline = timeline
    }

    @discardableResult
    func beginStep(
        id: UUID = UUID(),
        kind: ToolActivityKind,
        title: String,
        subtitle: String? = nil,
        input: String? = nil,
        queryItems: [String] = [],
        richResultBlocks: [NativeUIBlock] = [],
        at date: Date = Date()
    ) -> UUID {
        if timeline.status.isTerminal {
            return id
        }

        let nextSequence = (timeline.steps.map(\.sequence).max() ?? -1) + 1
        timeline.upsert(
            ToolActivityStep(
                id: id,
                sequence: nextSequence,
                kind: kind,
                title: title,
                subtitle: subtitle,
                status: .running,
                startedAt: date,
                input: input,
                queryItems: queryItems,
                richResultBlocks: richResultBlocks
            )
        )
        return id
    }

    func updateStep(
        id: UUID,
        title: String? = nil,
        subtitle: String? = nil,
        input: String? = nil,
        output: String? = nil,
        queryItems: [String]? = nil,
        richResultBlocks: [NativeUIBlock]? = nil
    ) {
        guard let index = timeline.steps.firstIndex(where: { $0.id == id }) else { return }

        if let title { timeline.steps[index].title = title }
        if let subtitle { timeline.steps[index].subtitle = subtitle }
        if let input { timeline.steps[index].input = input }
        if let output { timeline.steps[index].output = output }
        if let queryItems { timeline.steps[index].queryItems = queryItems }
        if let richResultBlocks { timeline.steps[index].richResultBlocks = richResultBlocks }
    }

    func completeStep(
        id: UUID,
        output: String? = nil,
        richResultBlocks: [NativeUIBlock]? = nil,
        at date: Date = Date()
    ) {
        finishStep(
            id: id,
            status: .completed,
            output: output,
            richResultBlocks: richResultBlocks,
            errorDescription: nil,
            at: date
        )
    }

    func failStep(id: UUID, errorDescription: String, at date: Date = Date()) {
        finishStep(
            id: id,
            status: .failed,
            output: nil,
            richResultBlocks: nil,
            errorDescription: errorDescription,
            at: date
        )
    }

    func cancelStep(id: UUID, at date: Date = Date()) {
        finishStep(
            id: id,
            status: .cancelled,
            output: nil,
            richResultBlocks: nil,
            errorDescription: nil,
            at: date
        )
    }

    func apply(_ event: ToolActivityStreamEvent) {
        guard event.groupID == timeline.groupID else { return }
        guard event.timelineID == timeline.id else { return }
        guard !timeline.status.isTerminal || event.action == .beginTimeline else { return }

        switch event.action {
        case .beginTimeline:
            if timeline.steps.isEmpty {
                timeline.startedAt = event.timestamp
                timeline.status = .running
            }

        case .beginStep:
            guard let stepID = event.stepID else { return }
            let sequence = event.sequence ?? ((timeline.steps.map(\.sequence).max() ?? -1) + 1)
            timeline.upsert(
                ToolActivityStep(
                    id: stepID,
                    sequence: sequence,
                    kind: event.kind ?? .result,
                    title: event.title ?? "",
                    subtitle: event.subtitle,
                    status: .running,
                    startedAt: event.timestamp,
                    input: event.input,
                    output: event.output,
                    queryItems: event.queryItems,
                    richResultBlocks: event.richResultBlocks,
                    errorDescription: event.errorDescription
                )
            )

        case .updateStep:
            guard let stepID = event.stepID else { return }
            updateStep(
                id: stepID,
                title: event.title,
                subtitle: event.subtitle,
                input: event.input,
                output: event.output,
                queryItems: event.queryItems.isEmpty ? nil : event.queryItems,
                richResultBlocks: event.richResultBlocks.isEmpty ? nil : event.richResultBlocks
            )

        case .completeStep:
            guard let stepID = event.stepID else { return }
            completeStep(
                id: stepID,
                output: event.output,
                richResultBlocks: event.richResultBlocks.isEmpty ? nil : event.richResultBlocks,
                at: event.timestamp
            )

        case .failStep:
            guard let stepID = event.stepID else { return }
            failStep(
                id: stepID,
                errorDescription: event.errorDescription ?? String(localized: "Failed"),
                at: event.timestamp
            )

        case .cancelStep:
            guard let stepID = event.stepID else { return }
            cancelStep(id: stepID, at: event.timestamp)

        case .completeTimeline:
            finish(status: .completed, at: event.timestamp)

        case .failTimeline:
            finish(status: .failed, at: event.timestamp)

        case .cancelTimeline:
            finish(status: .cancelled, at: event.timestamp)
        }
    }

    func finish(status: ToolActivityStatus, at date: Date = Date()) {
        timeline.finish(status: status, at: date)
    }

    private func finishStep(
        id: UUID,
        status: ToolActivityStatus,
        output: String?,
        richResultBlocks: [NativeUIBlock]?,
        errorDescription: String?,
        at date: Date
    ) {
        guard let index = timeline.steps.firstIndex(where: { $0.id == id }) else { return }

        timeline.steps[index].status = status
        timeline.steps[index].completedAt = date
        if let output { timeline.steps[index].output = output }
        if let richResultBlocks { timeline.steps[index].richResultBlocks = richResultBlocks }
        if let errorDescription { timeline.steps[index].errorDescription = errorDescription }
        timeline.deriveStatus()
    }
}
