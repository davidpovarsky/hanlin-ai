import Foundation

enum ToolActivityStatus: String, Codable, Hashable, Sendable {
    case pending
    case running
    case completed
    case failed
    case cancelled

    var isTerminal: Bool {
        switch self {
        case .completed, .failed, .cancelled:
            true
        case .pending, .running:
            false
        }
    }
}

enum ToolActivityKind: String, Codable, Hashable, Sendable {
    case reasoning
    case planning
    case webSearch
    case sourceRead
    case toolCall
    case codeExecution
    case documentRead
    case calendar
    case map
    case health
    case audio
    case nativeApp
    case result
    case error
    case cancellation

    var defaultSystemImage: String {
        switch self {
        case .reasoning, .planning:
            "sparkles"
        case .webSearch:
            "globe"
        case .sourceRead, .documentRead:
            "doc.text.magnifyingglass"
        case .toolCall:
            "gearshape.2"
        case .codeExecution:
            "terminal"
        case .calendar:
            "calendar"
        case .map:
            "map"
        case .health:
            "heart.text.square"
        case .audio:
            "waveform"
        case .nativeApp:
            "app.badge"
        case .result:
            "rectangle.stack"
        case .error:
            "exclamationmark.triangle"
        case .cancellation:
            "xmark.circle"
        }
    }
}

struct ToolActivityStep: Codable, Hashable, Identifiable, Sendable {
    var id: UUID
    var sequence: Int
    var kind: ToolActivityKind
    var title: String
    var subtitle: String?
    var status: ToolActivityStatus
    var startedAt: Date
    var completedAt: Date?
    var input: String?
    var output: String?
    var queryItems: [String]
    var richResultBlocks: [NativeUIBlock]
    var errorDescription: String?

    init(
        id: UUID = UUID(),
        sequence: Int,
        kind: ToolActivityKind,
        title: String,
        subtitle: String? = nil,
        status: ToolActivityStatus = .pending,
        startedAt: Date = Date(),
        completedAt: Date? = nil,
        input: String? = nil,
        output: String? = nil,
        queryItems: [String] = [],
        richResultBlocks: [NativeUIBlock] = [],
        errorDescription: String? = nil
    ) {
        self.id = id
        self.sequence = sequence
        self.kind = kind
        self.title = title
        self.subtitle = subtitle
        self.status = status
        self.startedAt = startedAt
        self.completedAt = completedAt
        self.input = input
        self.output = output
        self.queryItems = queryItems
        self.richResultBlocks = richResultBlocks
        self.errorDescription = errorDescription
    }

    var duration: TimeInterval {
        max(0, (completedAt ?? Date()).timeIntervalSince(startedAt))
    }

    private enum CodingKeys: String, CodingKey {
        case id
        case sequence
        case kind
        case title
        case subtitle
        case status
        case startedAt
        case completedAt
        case input
        case output
        case queryItems
        case richResultBlocks
        case errorDescription
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        sequence = try container.decodeIfPresent(Int.self, forKey: .sequence) ?? 0
        kind = try container.decodeIfPresent(ToolActivityKind.self, forKey: .kind) ?? .result
        title = try container.decodeIfPresent(String.self, forKey: .title) ?? ""
        subtitle = try container.decodeIfPresent(String.self, forKey: .subtitle)
        status = try container.decodeIfPresent(ToolActivityStatus.self, forKey: .status) ?? .completed
        startedAt = try container.decodeIfPresent(Date.self, forKey: .startedAt) ?? Date()
        completedAt = try container.decodeIfPresent(Date.self, forKey: .completedAt)
        input = try container.decodeIfPresent(String.self, forKey: .input)
        output = try container.decodeIfPresent(String.self, forKey: .output)
        queryItems = try container.decodeIfPresent([String].self, forKey: .queryItems) ?? []
        richResultBlocks = try container.decodeIfPresent([NativeUIBlock].self, forKey: .richResultBlocks) ?? []
        errorDescription = try container.decodeIfPresent(String.self, forKey: .errorDescription)
    }
}

struct ToolActivityTimeline: Codable, Hashable, Identifiable, Sendable {
    static let currentSchemaVersion = 1

    var schemaVersion: Int
    var id: UUID
    var groupID: UUID
    var startedAt: Date
    var completedAt: Date?
    var status: ToolActivityStatus
    var steps: [ToolActivityStep]

    init(
        schemaVersion: Int = Self.currentSchemaVersion,
        id: UUID = UUID(),
        groupID: UUID,
        startedAt: Date = Date(),
        completedAt: Date? = nil,
        status: ToolActivityStatus = .running,
        steps: [ToolActivityStep] = []
    ) {
        self.schemaVersion = schemaVersion
        self.id = id
        self.groupID = groupID
        self.startedAt = startedAt
        self.completedAt = completedAt
        self.status = status
        self.steps = steps.sorted(by: Self.stepSort)
    }

    var duration: TimeInterval {
        max(0, (completedAt ?? Date()).timeIntervalSince(startedAt))
    }

    var orderedSteps: [ToolActivityStep] {
        steps.sorted(by: Self.stepSort)
    }

    mutating func upsert(_ step: ToolActivityStep) {
        if let index = steps.firstIndex(where: { $0.id == step.id }) {
            steps[index] = step
        } else {
            steps.append(step)
        }
        steps.sort(by: Self.stepSort)
        deriveStatus()
    }

    mutating func finish(status finalStatus: ToolActivityStatus, at date: Date = Date()) {
        for index in steps.indices where !steps[index].status.isTerminal {
            steps[index].status = finalStatus == .completed ? .completed : finalStatus
            steps[index].completedAt = date
        }
        status = finalStatus
        completedAt = date
    }

    mutating func deriveStatus() {
        if steps.contains(where: { $0.status == .running || $0.status == .pending }) {
            status = .running
        } else if steps.contains(where: { $0.status == .failed }) {
            status = .failed
        } else if steps.contains(where: { $0.status == .cancelled }) {
            status = .cancelled
        } else if !steps.isEmpty {
            status = .completed
        }
    }

    private static func stepSort(_ lhs: ToolActivityStep, _ rhs: ToolActivityStep) -> Bool {
        if lhs.sequence != rhs.sequence {
            return lhs.sequence < rhs.sequence
        }
        if lhs.startedAt != rhs.startedAt {
            return lhs.startedAt < rhs.startedAt
        }
        return lhs.id.uuidString < rhs.id.uuidString
    }

    private enum CodingKeys: String, CodingKey {
        case schemaVersion
        case id
        case groupID
        case startedAt
        case completedAt
        case status
        case steps
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        schemaVersion = try container.decodeIfPresent(Int.self, forKey: .schemaVersion) ?? 0
        id = try container.decodeIfPresent(UUID.self, forKey: .id) ?? UUID()
        groupID = try container.decodeIfPresent(UUID.self, forKey: .groupID) ?? UUID()
        startedAt = try container.decodeIfPresent(Date.self, forKey: .startedAt) ?? Date()
        completedAt = try container.decodeIfPresent(Date.self, forKey: .completedAt)
        status = try container.decodeIfPresent(ToolActivityStatus.self, forKey: .status) ?? .completed
        steps = (try container.decodeIfPresent([ToolActivityStep].self, forKey: .steps) ?? [])
            .sorted(by: Self.stepSort)
    }
}

extension Duration {
    static func toolActivityString(seconds: TimeInterval) -> String {
        let seconds = max(0, seconds)
        if seconds < 1 {
            return String(format: "%.1fs", seconds)
        }
        if seconds < 60 {
            return String(format: "%.0fs", seconds)
        }

        let whole = Int(seconds.rounded())
        return "\(whole / 60)m \(whole % 60)s"
    }
}
