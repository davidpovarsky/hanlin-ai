import { Navigation, Script } from 'scripting'
import { AppProvider } from './src/context/AppContext'
import { ChatScreen } from './src/screens/ChatScreen'

function Root() {
  return (
    <AppProvider>
      <ChatScreen />
    </AppProvider>
  )
}

async function main() {
  await Navigation.present({
    element: <Root />,
  })
  Script.exit()
}

main()
