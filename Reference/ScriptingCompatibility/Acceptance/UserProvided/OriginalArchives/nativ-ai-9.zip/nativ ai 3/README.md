# AI Agent — Scripting App

A Hebrew/English AI agent app for the Scripting iOS platform.

This build enables five internal native tools and runtime-discovered external skills:

- `weather`
- `reminder`
- `cityInfo`
- `nearbyTransitArrivals`
- `transitDirections`

The other native tool folders may remain in `src/tools/`, but they are not registered until their `index.ts` files are adapted to the shared module contract and `src/tools/index.ts` is updated manually or through the in-app sync button.

---

## Tool Architecture

Each enabled tool is self-contained in its own folder and exports one unified module from `src/tools/<toolName>/index.ts`:

```ts
export const AGENT_TOOL_MODULE = {
  spec,
  run,
  Card,
}

export default AGENT_TOOL_MODULE
```

The shared contract lives in:

```txt
src/tools/types.ts
```

The central registry lives in:

```txt
src/tools/index.ts
```

The orchestrator and UI no longer import each tool manually. They use registry helpers instead:

```ts
getAgentToolRunner(toolName)
getAgentToolCard(toolName)
```

This means `agentOrchestrator.ts`, `ToolMessage.tsx`, and `src/types/chat.ts` should not need edits when more tools are enabled later.

---

## Two Ways to Enable Tools

### Option 1 — In-app Sync, no terminal

Scripting has no terminal and no external build step. This project now includes an in-app synchronizer:

```txt
Settings -> Tools -> Sync Tools
```

What it does:

1. Scans `src/tools/*`.
2. Includes only folders that have:
   - `tool.json`
   - `index.ts`
   - an `AGENT_TOOL_MODULE` export in `index.ts`
3. Rewrites only `src/tools/index.ts` with static imports.
4. Shows a native alert with the enabled tools.

Important: after pressing Sync Tools, close/rerun the script so Scripting reloads the new static imports.

The sync implementation lives in:

```txt
src/tools/syncToolsRegistry.ts
```

### Option 2 — Manual edit in one file

You can also update only `src/tools/index.ts` yourself.

Add an import:

```ts
import toolModule4 from './myNewTool'
```

Then add it to the array:

```ts
export const AGENT_TOOL_MODULES = [
  toolModule0,
  toolModule1,
  toolModule2,
  toolModule3,
  toolModule4,
]
```

No changes are needed in the orchestrator, UI renderer, or chat types.

---

## Current Important Files

```txt
src/tools/types.ts                         # Shared AgentToolModule contract
src/tools/index.ts                         # Central enabled-tool registry
src/tools/syncToolsRegistry.ts             # In-app registry sync button logic
src/screens/SettingsScreen.tsx             # Native Settings button for sync
src/logic/agent/agentOrchestrator.ts       # Executes tools through registry
src/components/ToolMessage.tsx             # Renders cards through registry
src/types/chat.ts                          # Generic ToolPayload: { kind, data }
```

---

## Enabled Tools

### Weather

```txt
src/tools/weather/
```

The old weather tool is now wrapped as a registered module. Its wrapper normalizes planner params such as `location` into the old runner shape `locationName/useCurrentLocation`.

### Reminder

```txt
src/tools/reminder/
```

The old reminder tool is now wrapped as a registered module. The wrapper fills safe defaults such as `priority: "none"`, and can still render a failed reminder card when creation fails.

### City Info

```txt
src/tools/cityInfo/
```

The old Wikipedia/city info tool is now wrapped as a registered module. The legacy internal name remains `cityInfo` to avoid breaking prompts and UI history.

### Nearby Transit Arrivals

```txt
src/tools/nearbyTransitArrivals/
```

The public transport tool is registered alongside the old tools and renders through the same `ToolMessage` path.

---

## Adding / Enabling Another Tool Later

To enable another existing tool folder later:

1. Open `src/tools/<toolName>/index.ts`.
2. Import its `tool.json`, runner, and card.
3. Export an `AGENT_TOOL_MODULE` object:

```ts
import toolJson from './tool.json'
import { runSomeTool } from './runSomeTool'
import { SomeToolCard } from './SomeToolCard'
import { AgentToolModule, asAgentToolSpec } from '../types'

export const SOME_TOOL_SPEC = asAgentToolSpec(toolJson)

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: SOME_TOOL_SPEC,
  run: async (params, language) => {
    const result = await runSomeTool(params, language)
    return result.ok
      ? { ok: true, data: result.data }
      : { ok: false, message: result.message }
  },
  Card: SomeToolCard,
}

export default AGENT_TOOL_MODULE
```

4. Either press `Settings -> Tools -> Sync Tools`, or manually add the import and module entry in `src/tools/index.ts`.
5. Restart/rerun the script.

---

## Sample Mode

`src/logic/agent/agentSampleMode.ts` is disabled in this build so real AI planning and real tool manifests are used:

```ts
export const USE_AGENT_SAMPLE_RESPONSES = false
```

## Runtime external skills

This build can discover external Scripting skills at runtime from:

```
iCloud Drive/Scripting/scripting-skills/<skill-name>
```

Each skill folder may include:

```
skill.json or skile.json
SKILL.md, skill.md, or skile.md
scripts/*.ts
```

Discovered skills are exposed to the agent as tools without editing `src/tools/index.ts` or rebuilding the project for every new capability. The agent first sees a compact tool index, then receives the detailed `SKILL.md` documentation only for relevant selected tools. External skill calls are requested from the planner through `paramsJson` to keep the structured schema valid and flexible:


### Multi-step manifest expansion

The agent now supports a more advanced planner loop:

1. The model first receives a compact index of all native tools and discovered external skills.
2. The model receives detailed manifests for the tools that look immediately relevant.
3. The planner also receives the compact index of the remaining tools.
4. If a detailed tool is missing required information that another compact-index tool may provide, the planner can return:

```json
{
  "action": "request_more_tool_manifests",
  "requestedTools": ["ios-location"],
  "reason": "Need current location before checking weather."
}
```

The orchestrator then loads those additional manifests and plans again, without showing a confusing intermediate message to the user. This is generic and not hard-coded for weather: the same pattern can handle cases like finding Apple Music song IDs before setting a queue, or finding calendar event identifiers before removing events.

System/App permissions are handled by the executed tool or the OS runtime. The planner should call the relevant tool instead of asking the user for permission in natural language; if permission is denied, the tool result is returned to the planner and it can ask for an alternative.


```json
{
  "tool": "apple-music",
  "paramsJson": "{\"action\":\"get_songs\",\"artist\":\"Taylor Swift\",\"limit\":10}"
}
```

At runtime this becomes normal tool params:

```json
{
  "action": "get_songs",
  "artist": "Taylor Swift",
  "limit": 10
}
```

If a script itself needs a parameter called `action`, for example `playback_control.ts`, use `scriptParams` inside `paramsJson`:

```json
{
  "tool": "apple-music",
  "paramsJson": "{\"action\":\"playback_control\",\"scriptParams\":{\"action\":\"play\"}}"
}
```

The external skill runner maps `action` to `scripts/<action>.ts` and runs it with:

```
scripting-ts run scripts/<action>.ts --queryparameters '<json>'
```

The model never receives permission to construct arbitrary shell commands. Read-only actions run directly. Actions that look state-changing, such as `create_*`, `remove_*`, `delete_*`, `update_*`, `set_*`, queue/playback/control actions, and similar operations, ask for confirmation before execution.

## Localization

Localization is centralized under `src/l10n`.

- Locale data lives in `src/l10n/locales/*.json`.
- The runtime loader is configured in `src/l10n/index.ts` with `USE_DYNAMIC_LOCALES`.
- `USE_DYNAMIC_LOCALES = true` scans the locale folder at runtime so adding a new JSON file can add a language without additional code changes.
- `USE_DYNAMIC_LOCALES = false` uses static imports from the same locale files for faster/lightweight runs.
- Both modes share the same JSON schema: `code`, `name`, `nativeName`, `direction`, `intlLocale`, and `strings`.
- Missing strings fall back to English, and missing keys fall back to the key name.

## Composer feature toggles

The chat composer now includes a native options menu with three persisted toggles:

- PiP Status: connected to Scripting's PiP view modifier and shows a lightweight chat status PiP view.
- Live Activity: connected to the agent runtime and updates while the assistant thinks, runs tools, streams a response, finishes, fails, or is stopped.
- Background Notifications: UI/state only for now. Notification behavior can be connected later.

The composer also exposes AI provider selection directly from the provider chip, using the same provider settings used by the Settings screen.

## Live Activity integration

This build connects the composer **Live Activity** toggle to the running agent flow.

When the toggle is enabled, the chat runtime starts `AgentChatLiveActivity` from the root `live_activity.tsx` file at the beginning of a reply, updates it during thinking/tool execution/streaming, and ends it on completion, cancellation, or error.

Important files:

```txt
live_activity.tsx                         # Root Live Activity registration scanned by Scripting
src/liveActivity/types.ts                  # JSON-serializable state and UI contracts
src/liveActivity/activityViews.tsx         # Thinking, generic tool, result, error, and cancelled UI
src/liveActivity/liveActivityController.ts # Runtime bridge from ChatScreen agent events to ActivityKit
src/tools/types.ts                         # AgentToolModule now supports optional LiveActivity UI
src/tools/liveActivity/shared.tsx          # Shared helper view for tool-specific Live Activity UI
```

Every native tool may now provide its own compact Live Activity renderer:

```ts
export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec,
  run,
  Card,
  LiveActivity,
}
```

If a tool does not provide `LiveActivity`, including runtime-discovered external skills, the central Live Activity automatically shows the generic animated tool-running UI with the tool name, action/status, and result/error state.

The currently enabled native tools include small Live Activity UI components in their folders:

```txt
src/tools/weather/liveActivity.tsx
src/tools/reminder/liveActivity.tsx
src/tools/cityInfo/liveActivity.tsx
src/tools/nearbyTransitArrivals/liveActivity.tsx
src/tools/transitDirections/liveActivity.tsx
```

All Live Activity text is routed through the existing localization JSON files under `src/l10n/locales/`.
