import { Divider, Text, VStack, Widget } from "scripting"

function WidgetView() {

  return <VStack
    padding
    frame={Widget.displaySize}
    background='accentColor'
    foregroundStyle="white"
  >
    <Text>
      {Widget.family}
    </Text>
    <Divider />
    <Text>{Widget.displaySize.width}*{Widget.displaySize.height}</Text>
  </VStack>
}

Widget.present(<WidgetView />)