// assistant_tool.tsx
// Required entry file for the Scripting AssistantTool system.
// This file registers the execution logic that the Assistant invokes
// when the user interacts with the AI Agent app.
//
// The actual agent logic lives in src/logic/agent/agentOrchestrator.ts.
// This file is the platform bridge required by Scripting to wire up
// Assistant.requestStructuredData and Assistant.requestStreaming.

import { runAgent } from './src/logic/agent/agentOrchestrator'
import { getStrings } from './src/l10n'

type AgentToolParams = {
  userMessage: string
  language: string
  currentLocationLabel?: string
}

const executeTool: AssistantToolExecuteFn<AgentToolParams> = async (params) => {
  let resultText = ''
  let errorText = ''

  await runAgent(
    {
      userMessage: params.userMessage || '',
      language: params.language || 'en',
      currentLocationLabel: params.currentLocationLabel ?? null,
    },
    {
      onTextChunk: (chunk) => {
        resultText += chunk
      },
      onError: (err) => {
        errorText = err instanceof Error ? err.message : String(err)
      },
    }
  )

  if (errorText) {
    return {
      success: false,
      message: errorText,
    }
  }

  return {
    success: true,
    message: resultText || getStrings(params.language || 'en').done,
  }
}

AssistantTool.registerExecuteTool(executeTool)
