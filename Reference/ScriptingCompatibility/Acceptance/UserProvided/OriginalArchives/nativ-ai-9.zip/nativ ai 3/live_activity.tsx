import {
  LiveActivity,
  LiveActivityUI,
  LiveActivityUIBuilder,
  LiveActivityUIExpandedCenter,
} from 'scripting'
import type { AgentChatLiveActivityState } from './src/liveActivity/types'
import {
  renderAgentCompactLeading,
  renderAgentCompactTrailing,
  renderAgentExpanded,
  renderAgentLockScreen,
  renderAgentMinimal,
} from './src/liveActivity/activityViews'

const agentChatLiveActivityBuilder: LiveActivityUIBuilder<AgentChatLiveActivityState> = (state) => {
  const payload = state.payload
  return (
    <LiveActivityUI
      content={renderAgentLockScreen(payload)}
      compactLeading={renderAgentCompactLeading(payload)}
      compactTrailing={renderAgentCompactTrailing(payload)}
      minimal={renderAgentMinimal(payload)}
    >
      <LiveActivityUIExpandedCenter>
        {renderAgentExpanded(payload)}
      </LiveActivityUIExpandedCenter>
    </LiveActivityUI>
  )
}

export const AgentChatLiveActivity = LiveActivity.register(
  'AgentChatLiveActivity',
  agentChatLiveActivityBuilder
)
