import enLocale from './locales/en.json'
import heLocale from './locales/he.json'

export type LocaleFile = {
  code: string
  name: string
  nativeName: string
  direction: 'ltr' | 'rtl'
  intlLocale: string
  strings: Record<string, string>
}

/**
 * Locale loading mode.
 *
 * true  -> scan src/l10n/locales/*.json at runtime, so new language files are
 *          picked up without editing code.
 * false -> use the static imports below. This is faster and safer for lightweight
 *          runs where runtime directory scanning is not desired.
 *
 * Both modes read the same locale files and return the same normalized shape.
 */
export const USE_DYNAMIC_LOCALES = true

const staticallyImportedLocales = [enLocale, heLocale]
const builtInFallbackLocale = normalizeLocaleFile(enLocale)
const fallbackLocale = builtInFallbackLocale

export type Locale = string
export type Strings = typeof fallbackLocale.strings

export type LocaleOption = {
  locale: Locale
  code: Locale
  name: string
  nativeName: string
  direction: 'ltr' | 'rtl'
  intlLocale: string
  isRTL: boolean
}

const localeFiles = loadLocaleFiles()
const localeMap = buildLocaleMap(localeFiles)

export const supportedLocales: ReadonlyArray<LocaleOption> = Array.from(localeMap.values()).map(file => ({
  locale: file.code,
  code: file.code,
  name: file.name,
  nativeName: file.nativeName,
  direction: file.direction,
  intlLocale: file.intlLocale,
  isRTL: file.direction === 'rtl',
}))

export function getStrings(locale: Locale): Strings {
  const file = localeMap.get(locale) ?? fallbackLocale
  return {
    ...fallbackLocale.strings,
    ...file.strings,
  }
}

export function getString(locale: Locale, key: keyof Strings | string, values?: Record<string, string | number>): string {
  const strings = getStrings(locale)
  const template = String((strings as Record<string, string>)[String(key)] ?? String(key))
  return values ? formatString(template, values) : template
}

export function getLocaleInfo(locale: Locale): LocaleOption {
  return supportedLocales.find(item => item.code === locale) ?? supportedLocales[0]
}

export function getIntlLocale(locale: Locale): string {
  return getLocaleInfo(locale).intlLocale
}

export function getLanguageName(locale: Locale): string {
  const info = getLocaleInfo(locale)
  return info.name || info.nativeName || info.code || fallbackLocale.name
}

export function formatString(template: string, values: Record<string, string | number>): string {
  return template.replace(/\{(\w+)\}/g, (_match, key) => String(values[key] ?? ''))
}

export function isRTL(locale: Locale): boolean {
  return getLocaleInfo(locale).direction === 'rtl'
}

export function isSupportedLocale(locale: string | null | undefined): locale is Locale {
  return typeof locale === 'string' && localeMap.has(locale)
}

export function detectDefaultLocale(systemLocale: string | null | undefined): Locale {
  if (!systemLocale) return fallbackLocale.code
  const lower = String(systemLocale).toLowerCase()
  const exact = supportedLocales.find(item => item.intlLocale.toLowerCase() === lower || item.code.toLowerCase() === lower)
  if (exact) return exact.code
  const base = lower.split(/[-_]/)[0]
  const byBase = supportedLocales.find(item => item.code.toLowerCase() === base || item.intlLocale.toLowerCase().startsWith(`${base}-`))
  return byBase?.code ?? fallbackLocale.code
}

function buildLocaleMap(files: LocaleFile[]): Map<string, LocaleFile> {
  const map = new Map<string, LocaleFile>()
  for (const file of files) {
    if (!file.code) continue
    map.set(file.code, mergeWithFallback(file))
  }
  if (!map.has(fallbackLocale.code)) {
    map.set(fallbackLocale.code, fallbackLocale)
  }
  return map
}

function loadLocaleFiles(): LocaleFile[] {
  if (USE_DYNAMIC_LOCALES) {
    const dynamicFiles = readLocaleFilesFromProject()
    if (dynamicFiles.length > 0) return dynamicFiles
  }
  return readLocaleFilesFromImports()
}

function readLocaleFilesFromImports(): LocaleFile[] {
  return staticallyImportedLocales
    .map(item => safeNormalizeLocale(item))
    .filter((file): file is LocaleFile => file != null)
}

function readLocaleFilesFromProject(): LocaleFile[] {
  try {
    const directories = getLocaleDirectoryCandidates()
    for (const directory of directories) {
      if (!safeExists(directory)) continue
      const names = FileManager.readDirectorySync(directory, false)
      const files = names
        .filter(name => name.endsWith('.json'))
        .map(name => safeReadLocale(`${directory}/${name}`))
        .filter((file): file is LocaleFile => file != null)
      if (files.length > 0) return files
    }
  } catch {
    // Fall back to static imports.
  }
  return []
}

function getLocaleDirectoryCandidates(): string[] {
  const relative = 'src/l10n/locales'
  const candidates = [relative]
  try {
    candidates.push(`${Script.directory}/${relative}`)
  } catch {
    // Ignore unavailable Script directory.
  }
  try {
    const root = FileManager.scriptsDirectory
    candidates.push(`${root}/${Script.name}/${relative}`)
    candidates.push(`${root}/${relative}`)
  } catch {
    // Ignore unavailable FileManager roots.
  }
  return Array.from(new Set(candidates.filter(Boolean)))
}

function safeExists(path: string): boolean {
  try {
    return FileManager.existsSync(path)
  } catch {
    return false
  }
}

function safeReadLocale(path: string): LocaleFile | null {
  try {
    return safeNormalizeLocale(JSON.parse(FileManager.readAsStringSync(path)))
  } catch {
    return null
  }
}

function safeNormalizeLocale(value: unknown): LocaleFile | null {
  try {
    return normalizeLocaleFile(value)
  } catch {
    return null
  }
}

function mergeWithFallback(file: LocaleFile): LocaleFile {
  if (file.code === fallbackLocale.code) return file
  return {
    ...file,
    strings: {
      ...fallbackLocale.strings,
      ...file.strings,
    },
  }
}

function normalizeLocaleFile(value: unknown): LocaleFile {
  const raw = value as Partial<LocaleFile>
  const code = String(raw.code || 'en')
  const direction = raw.direction === 'rtl' ? 'rtl' : 'ltr'
  return {
    code,
    name: String(raw.name || code),
    nativeName: String(raw.nativeName || raw.name || code),
    direction,
    intlLocale: String(raw.intlLocale || code),
    strings: typeof raw.strings === 'object' && raw.strings != null
      ? raw.strings as Record<string, string>
      : {},
  }
}
