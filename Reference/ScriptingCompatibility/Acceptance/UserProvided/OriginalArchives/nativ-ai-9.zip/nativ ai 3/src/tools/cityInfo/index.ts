import toolJson from './tool.json'
import { buildCityInfoDisplay } from './buildCityInfoDisplay'
import { runCityInfoTool } from './runCityInfoTool'
import { CityInfoCard } from './CityInfoCard'
import {
  AgentToolModule,
  AgentToolRunResult,
  asAgentToolSpec,
} from '../types'
import { CityInfoIntentParams } from '../../types/intents'

import { CityInfoLiveActivity } from './liveActivity'
export * from './buildCityInfoDisplay'
export * from './runCityInfoTool'
export * from './CityInfoCard'
export * from './liveActivity'

export const CITY_INFO_TOOL_SPEC = asAgentToolSpec(toolJson)

async function runRegisteredCityInfoTool(
  params: Record<string, unknown>,
  language: string
): Promise<AgentToolRunResult> {
  const normalized = normalizeCityInfoParams(params, language)
  const result = await runCityInfoTool(normalized, language)

  if (result.ok) {
    return { ok: true, data: result.data }
  }

  const failure = result as { message: string }
  return { ok: false, message: failure.message }
}

function normalizeCityInfoParams(
  params: Record<string, unknown>,
  language: string
): CityInfoIntentParams {
  return {
    query: firstString(params.query, params.topic, params.title) || '',
    language: firstString(params.language) || language || 'en',
  }
}

function firstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim()
    }
  }
  return null
}

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: CITY_INFO_TOOL_SPEC,
  run: runRegisteredCityInfoTool,
  Card: CityInfoCard,
  LiveActivity: CityInfoLiveActivity,
}

export default AGENT_TOOL_MODULE
