// src/tools/nearbyTransitArrivals/runNearbyTransitArrivalsTool.ts
// Scripting-aware runner for nearby public transport arrivals.
// Debug build: emits detailed console logs and also returns a compact debugLog in display data.

import {
  NearbyTransitArrivalsDisplayData,
  NearbyTransitRawData,
  NearbyTransitRawStop,
  buildNearbyTransitArrivalsDisplay,
} from './buildNearbyTransitArrivalsDisplay'

export type NearbyTransitArrivalsIntentParams = {
  latitude?: number | string | null
  longitude?: number | string | null
  radiusMeters?: number | string | null
  maxStops?: number | string | null
  lookaheadMinutes?: number | string | null
  forceLocationRequest?: boolean | string | null
  debug?: boolean | string | null
}

export type NearbyTransitArrivalsToolResult =
  | { ok: true; data: NearbyTransitArrivalsDisplayData }
  | { ok: false; message: string; debugLog?: string[] }

type LocationPoint = {
  latitude: number
  longitude: number
  source: 'params' | 'device'
}

type NearbyStop = {
  name: string
  stopCode: string
  distance: number
}

type FetchJSONRequest = {
  url: string
  method?: 'GET' | 'POST'
  headers?: Record<string, string>
  body?: string
  logUrl?: string
  timeout?: number
}

type KavNavAdapter = {
  fetchJSON: (request: string | FetchJSONRequest, label?: string) => Promise<any | null>
  getLocation: (forceRequest?: boolean) => Promise<LocationPoint | null>
}

type DebugLogger = {
  enabled: boolean
  entries: string[]
  log: (message: string, details?: unknown) => void
  warn: (message: string, details?: unknown) => void
  error: (message: string, details?: unknown) => void
}

const BASE_URL = 'https://kavnav.com/api'
const DEFAULT_RADIUS_METERS = 500
const DEFAULT_MAX_STOPS = 5
const DEFAULT_LOOKAHEAD_MINUTES = 60
const SUMMARY_CACHE_TTL_MS = 60 * 60 * 1000
const SCHEDULE_CACHE_TTL_MS = 2 * 60 * 1000
const REQUEST_TIMEOUT_SECONDS = 12
const OVERPASS_TIMEOUT_SECONDS = 8
const OVERPASS_USER_AGENT = 'ScriptingNearbyTransitArrivals/1.0 (OpenStreetMap Overpass client; contact: local-scripting-app)'
const LOG_PREFIX = '[nearbyTransitArrivals]'

const summaryCache = new Map<string, { ts: number; data: any }>()
const scheduleCache = new Map<string, { ts: number; data: any }>()
const realtimeCache = new Map<string, any>()

export async function runNearbyTransitArrivalsTool(
  params: NearbyTransitArrivalsIntentParams = {}
): Promise<NearbyTransitArrivalsToolResult> {
  const debug = createDebugLogger(toBoolean(params.debug, true))

  try {
    debug.log('tool_start', { params: safeParamsForLog(params) })

    const radiusMeters = clampInt(params.radiusMeters, DEFAULT_RADIUS_METERS, 100, 2000)
    const maxStops = clampInt(params.maxStops, DEFAULT_MAX_STOPS, 1, 12)
    const lookaheadMinutes = clampInt(params.lookaheadMinutes, DEFAULT_LOOKAHEAD_MINUTES, 5, 180)
    const forceLocationRequest = toBoolean(params.forceLocationRequest, false)

    debug.log('normalized_params', {
      radiusMeters,
      maxStops,
      lookaheadMinutes,
      forceLocationRequest,
    })

    const adapter = createScriptingKavNavAdapter(debug)
    const location = await resolveLocation(params, adapter, forceLocationRequest, debug)

    if (!location) {
      debug.error('location_missing')
      return {
        ok: false,
        message: 'Missing location. Provide latitude/longitude or allow the script to request current location.',
        debugLog: debug.entries,
      }
    }

    debug.log('location_resolved', {
      latitude: roundCoord(location.latitude),
      longitude: roundCoord(location.longitude),
      source: location.source,
    })

    const warnings: string[] = []
    const nearbyStops = await findNearbyStops(
      adapter,
      location.latitude,
      location.longitude,
      maxStops,
      radiusMeters,
      debug
    )

    debug.log('nearby_stops_result', {
      count: nearbyStops.length,
      stops: nearbyStops.map(stop => ({ code: stop.stopCode, name: stop.name, distance: stop.distance })),
    })

    if (nearbyStops.length === 0) {
      warnings.push('No nearby stops were found through OpenStreetMap/Overpass in the requested radius.')
    }

    const stops: NearbyTransitRawStop[] = []

    for (const nearbyStop of nearbyStops) {
      if (AssistantToolMaybeCancelled()) {
        debug.warn('cancelled_before_stop_fetch', { stopCode: nearbyStop.stopCode })
        break
      }

      debug.log('stop_fetch_start', { stopCode: nearbyStop.stopCode, name: nearbyStop.name })
      const stopData = await getStopData(adapter, nearbyStop.stopCode, lookaheadMinutes, debug)
      debug.log('stop_fetch_done', {
        stopCode: nearbyStop.stopCode,
        fetchedName: stopData.name,
        groups: stopData.groups.length,
        arrivals: stopData.groups.reduce((sum, group) => sum + group.arrivals.length, 0),
      })

      stops.push({
        stopCode: nearbyStop.stopCode,
        name: stopData.name || nearbyStop.name,
        distance: nearbyStop.distance,
        groups: stopData.groups,
      })
    }

    if (stops.length > 0 && stops.every(stop => (stop.groups || []).length === 0)) {
      warnings.push(`No arrivals were found within ${lookaheadMinutes} minutes.`)
    }

    const raw: NearbyTransitRawData = {
      generatedAt: new Date().toISOString(),
      location,
      radiusMeters,
      lookaheadMinutes,
      stops,
      warnings,
      debugLog: debug.entries,
    }

    debug.log('build_display_start', {
      rawStops: raw.stops.length,
      warnings: raw.warnings?.length ?? 0,
    })

    const display = buildNearbyTransitArrivalsDisplay(raw)
    if (!display) {
      debug.error('build_display_failed')
      return { ok: false, message: 'Could not build nearby transit arrivals display.', debugLog: debug.entries }
    }

    debug.log('tool_success', {
      displayStops: display.stops.length,
      displayGroups: display.stops.reduce((sum, stop) => sum + stop.groups.length, 0),
    })

    display.debugLog = debug.entries
    return { ok: true, data: display }
  } catch (error) {
    debug.error('tool_unhandled_error', stringifyError(error))
    return {
      ok: false,
      message: `Nearby transit arrivals failed: ${stringifyError(error)}`,
      debugLog: debug.entries,
    }
  }
}

function createScriptingKavNavAdapter(debug: DebugLogger): KavNavAdapter {
  return {
    fetchJSON: async (requestInput: string | FetchJSONRequest, label = 'request') => {
      const startedAt = Date.now()
      const request = typeof requestInput === 'string'
        ? { url: requestInput, method: 'GET' as const }
        : requestInput
      const method = request.method ?? 'GET'
      const timeout = request.timeout ?? REQUEST_TIMEOUT_SECONDS
      const headers = request.headers ?? { Accept: 'application/json' }

      debug.log('fetch_start', {
        label,
        method,
        url: request.logUrl || stripQueryForLog(request.url),
      })

      try {
        const init: Record<string, unknown> = {
          method,
          timeout,
          headers,
          debugLabel: `nearbyTransitArrivals:${label}`,
        }

        if (method !== 'GET' && request.body != null) {
          init.body = request.body
        }

        const response = await fetch(request.url, init as any)
        const status = Number((response as any)?.status)
        const ok = Boolean((response as any)?.ok)

        debug.log('fetch_response', {
          label,
          status: Number.isFinite(status) ? status : 'unknown',
          ok,
          ms: Date.now() - startedAt,
        })

        if (!response || !ok) {
          let bodyPreview = ''
          try {
            bodyPreview = typeof (response as any)?.text === 'function'
              ? String(await (response as any).text()).slice(0, 500)
              : ''
          } catch {
            bodyPreview = ''
          }
          debug.warn('fetch_not_ok', { label, status, bodyPreview })
          return null
        }

        try {
          const json = await response.json()
          debug.log('fetch_json_done', { label, shape: describeJsonShape(json) })
          return json
        } catch (jsonError) {
          let bodyPreview = ''
          try {
            bodyPreview = typeof (response as any)?.text === 'function'
              ? String(await (response as any).text()).slice(0, 500)
              : ''
          } catch {
            bodyPreview = ''
          }
          debug.error('fetch_json_failed', { label, error: stringifyError(jsonError), bodyPreview })
          return null
        }
      } catch (error) {
        debug.error('fetch_failed', { label, error: stringifyError(error) })
        return null
      }
    },

    getLocation: async (forceRequest = false) => {
      debug.log('location_request_start', { forceRequest })

      try {
        const LocationAPI = (globalThis as any).Location
        if (!LocationAPI) {
          debug.error('location_api_missing')
          return null
        }
        if (typeof LocationAPI.requestCurrent !== 'function') {
          debug.error('location_requestCurrent_missing')
          return null
        }

        if (typeof LocationAPI.setAccuracy === 'function') {
          debug.log('location_set_accuracy_start', { accuracy: 'hundredMeters' })
          await LocationAPI.setAccuracy('hundredMeters')
          debug.log('location_set_accuracy_done')
        } else {
          debug.warn('location_setAccuracy_missing')
        }

        const location = await LocationAPI.requestCurrent({ forceRequest })
        debug.log('location_request_done', {
          hasLocation: Boolean(location),
          keys: location && typeof location === 'object' ? Object.keys(location) : [],
        })

        const latitude = Number(location?.latitude)
        const longitude = Number(location?.longitude)

        if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
          debug.error('location_invalid_coordinates', { latitude: location?.latitude, longitude: location?.longitude })
          return null
        }

        return { latitude, longitude, source: 'device' }
      } catch (error) {
        debug.error('location_request_failed', stringifyError(error))
        return null
      }
    },
  }
}

async function resolveLocation(
  params: NearbyTransitArrivalsIntentParams,
  adapter: KavNavAdapter,
  forceLocationRequest: boolean,
  debug: DebugLogger
): Promise<LocationPoint | null> {
  const latitude = Number(params.latitude)
  const longitude = Number(params.longitude)

  debug.log('resolve_location_start', {
    hasLatitudeParam: params.latitude != null && params.latitude !== '',
    hasLongitudeParam: params.longitude != null && params.longitude !== '',
  })

  if (Number.isFinite(latitude) && Number.isFinite(longitude)) {
    debug.log('resolve_location_from_params')
    return { latitude, longitude, source: 'params' }
  }

  debug.log('resolve_location_from_device')
  return await adapter.getLocation(forceLocationRequest)
}

async function findNearbyStops(
  adapter: KavNavAdapter,
  latitude: number,
  longitude: number,
  limit: number,
  radiusMeters: number,
  debug: DebugLogger
): Promise<NearbyStop[]> {
  const query = [
    '[out:json][timeout:20];',
    '(',
    `node["highway"="bus_stop"](around:${radiusMeters},${latitude},${longitude});`,
    `node["public_transport"="platform"](around:${radiusMeters},${latitude},${longitude});`,
    `node["railway"="tram_stop"](around:${radiusMeters},${latitude},${longitude});`,
    `node["railway"="station"](around:${radiusMeters},${latitude},${longitude});`,
    ');',
    'out body;',
  ].join('')

  debug.log('overpass_query_built', { radiusMeters, limit, queryLength: query.length })

  const data = await fetchOverpassJSON(adapter, query, debug)

  if (!data?.elements || !Array.isArray(data.elements)) {
    debug.warn('overpass_no_elements', { shape: describeJsonShape(data) })
    return []
  }

  debug.log('overpass_elements_received', { count: data.elements.length })

  const byStopCode = new Map<string, NearbyStop>()
  let elementsWithStopCode = 0
  let elementsWithoutCoordinates = 0

  for (const element of data.elements) {
    const lat = Number(element?.lat)
    const lon = Number(element?.lon)
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      elementsWithoutCoordinates++
      continue
    }

    const refs = extractStopCodesFromTags(element?.tags)
    if (refs.length === 0) continue
    elementsWithStopCode++

    for (const stopCode of refs) {
      const distance = Math.round(getDistance(latitude, longitude, lat, lon))
      if (!Number.isFinite(distance)) continue

      const stop: NearbyStop = {
        name: cleanText(element?.tags?.['name:he']) || cleanText(element?.tags?.name) || 'Stop',
        stopCode,
        distance,
      }

      const existing = byStopCode.get(stopCode)
      if (!existing || stop.distance < existing.distance) {
        byStopCode.set(stopCode, stop)
      }
    }
  }

  const stops = [...byStopCode.values()]
    .sort((a, b) => a.distance - b.distance)
    .slice(0, limit)

  debug.log('overpass_stops_parsed', {
    elementsWithStopCode,
    elementsWithoutCoordinates,
    uniqueStopCodes: byStopCode.size,
    returned: stops.length,
  })

  return stops
}

async function fetchOverpassJSON(
  adapter: KavNavAdapter,
  query: string,
  debug: DebugLogger
): Promise<any | null> {
  // overpass-api.de recently rejects unidentified/default HTTP clients with 406.
  // Use a stable, non-browser User-Agent and try the two official request shapes:
  // 1. GET /api/interpreter?data=<encoded query> for short queries.
  // 2. POST /api/interpreter with the raw Overpass QL body.
  // A form-encoded POST is kept as a final compatibility fallback.
  const baseHeaders = buildOverpassHeaders()
  const attempts: Array<{
    endpoint: string
    label: string
    request: FetchJSONRequest
  }> = [
    {
      endpoint: 'https://overpass-api.de/api/interpreter',
      label: 'overpass_nearby_stops_get',
      request: {
        url: `https://overpass-api.de/api/interpreter?data=${encodeURIComponent(query)}`,
        method: 'GET',
        headers: baseHeaders,
        logUrl: 'https://overpass-api.de/api/interpreter?data=<encoded-query>',
        timeout: OVERPASS_TIMEOUT_SECONDS,
      },
    },
    {
      endpoint: 'https://overpass-api.de/api/interpreter',
      label: 'overpass_nearby_stops_post_raw',
      request: {
        url: 'https://overpass-api.de/api/interpreter',
        method: 'POST',
        headers: { ...baseHeaders, 'Content-Type': 'text/plain; charset=UTF-8' },
        body: query,
        logUrl: 'https://overpass-api.de/api/interpreter',
        timeout: OVERPASS_TIMEOUT_SECONDS,
      },
    },
    {
      endpoint: 'https://overpass-api.de/api/interpreter',
      label: 'overpass_nearby_stops_post_form',
      request: {
        url: 'https://overpass-api.de/api/interpreter',
        method: 'POST',
        headers: { ...baseHeaders, 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: `data=${encodeURIComponent(query)}`,
        logUrl: 'https://overpass-api.de/api/interpreter',
        timeout: OVERPASS_TIMEOUT_SECONDS,
      },
    },
    {
      endpoint: 'https://overpass.private.coffee/api/interpreter',
      label: 'overpass_nearby_stops_private_coffee_get',
      request: {
        url: `https://overpass.private.coffee/api/interpreter?data=${encodeURIComponent(query)}`,
        method: 'GET',
        headers: baseHeaders,
        logUrl: 'https://overpass.private.coffee/api/interpreter?data=<encoded-query>',
        timeout: OVERPASS_TIMEOUT_SECONDS,
      },
    },
    {
      endpoint: 'https://overpass.kumi.systems/api/interpreter',
      label: 'overpass_nearby_stops_kumi_get',
      request: {
        url: `https://overpass.kumi.systems/api/interpreter?data=${encodeURIComponent(query)}`,
        method: 'GET',
        headers: baseHeaders,
        logUrl: 'https://overpass.kumi.systems/api/interpreter?data=<encoded-query>',
        timeout: OVERPASS_TIMEOUT_SECONDS,
      },
    },
  ]

  for (const attempt of attempts) {
    const data = await adapter.fetchJSON(attempt.request, attempt.label)

    if (data?.elements && Array.isArray(data.elements)) {
      debug.log('overpass_endpoint_success', {
        endpoint: attempt.endpoint,
        label: attempt.label,
        elements: data.elements.length,
      })
      return data
    }

    debug.warn('overpass_endpoint_no_usable_elements', {
      endpoint: attempt.endpoint,
      label: attempt.label,
      shape: describeJsonShape(data),
    })
  }

  return null
}

function buildOverpassHeaders(): Record<string, string> {
  return {
    'Accept': '*/*',
    'User-Agent': OVERPASS_USER_AGENT,
  }
}

async function getStopData(
  adapter: KavNavAdapter,
  stopCode: string,
  lookaheadMinutes: number,
  debug: DebugLogger
): Promise<{
  stopCode: string
  name: string | null
  groups: Array<{
    line: string
    headsign: string
    arrivals: Array<{
      line: string
      headsign: string
      minutes: number
      realtime: boolean
      stale?: boolean
    }>
  }>
}> {
  const today = new Date()
  const todayStr = formatDate(today)

  debug.log('kavnav_stop_requests_start', { stopCode, todayStr })

  let [summary, schedule, realtime] = await Promise.all([
    getStopSummaryCached(adapter, stopCode, debug),
    getStopScheduleCached(adapter, stopCode, todayStr, debug),
    adapter.fetchJSON(`${BASE_URL}/realtime?stopCode=${encodeURIComponent(stopCode)}`, `realtime_${stopCode}`),
  ])

  debug.log('kavnav_stop_requests_done', {
    stopCode,
    summaryShape: describeJsonShape(summary),
    scheduleShape: describeJsonShape(schedule),
    realtimeShape: describeJsonShape(realtime),
  })

  let isRealtimeStale = false
  if (realtime) {
    realtimeCache.set(String(stopCode), realtime)
  } else {
    const cachedRealtime = realtimeCache.get(String(stopCode))
    if (cachedRealtime) {
      realtime = cachedRealtime
      isRealtimeStale = true
      debug.warn('using_stale_realtime_cache', { stopCode })
    }
  }

  const fetchedName = extractStopName(summary)
  const routeMap = buildRouteMap(summary)
  debug.log('kavnav_route_map_built', { stopCode, routes: Object.keys(routeMap).length, fetchedName })

  const trips: Array<{
    line: string
    headsign: string
    minutes: number
    realtime: boolean
    stale?: boolean
    tripId?: string
  }> = []
  const realtimeTrips = new Set<string>()

  let realtimeVehicles = 0
  let realtimeMatchedCalls = 0
  if (realtime?.vehicles && Array.isArray(realtime.vehicles)) {
    realtimeVehicles = realtime.vehicles.length
    for (const bus of realtime.vehicles) {
      const call = bus?.trip?.onwardCalls?.calls?.find((c: any) => String(c.stopCode) === String(stopCode))
      if (!call) continue
      realtimeMatchedCalls++

      const eta = new Date(call.eta)
      const minutes = getMinutesDiff(eta)
      if (!Number.isFinite(minutes) || minutes < 0 || minutes > lookaheadMinutes) continue

      const tripId = cleanText(bus?.trip?.gtfsInfo?.tripId)
      if (tripId) realtimeTrips.add(tripId)

      trips.push({
        line: cleanText(bus?.trip?.gtfsInfo?.routeNumber) || cleanText(routeMap[bus?.trip?.routeId]) || '?',
        headsign: cleanText(bus?.trip?.gtfsInfo?.headsign),
        minutes,
        realtime: true,
        stale: isRealtimeStale,
        tripId,
      })
    }
  }

  debug.log('realtime_parsed', {
    stopCode,
    realtimeVehicles,
    realtimeMatchedCalls,
    realtimeTripsInWindow: realtimeTrips.size,
    tripsSoFar: trips.length,
  })

  const scheduleList = normalizeArray(schedule?.stopSchedule)
  let scheduledTripCount = 0
  let scheduledTripInWindowCount = 0

  for (const scheduleStop of scheduleList) {
    const scheduledTrips = normalizeArray(scheduleStop?.trips)
    scheduledTripCount += scheduledTrips.length

    for (const trip of scheduledTrips) {
      if (trip?.tripId && realtimeTrips.has(String(trip.tripId))) continue
      if (!trip?.departureTime) continue

      const departure = parseTimeStr(String(trip.departureTime), today)
      const minutes = getMinutesDiff(departure)
      if (!Number.isFinite(minutes) || minutes < 0 || minutes > lookaheadMinutes) continue
      scheduledTripInWindowCount++

      trips.push({
        line: cleanText(routeMap[trip.routeId]) || cleanText(trip.routeNumber) || cleanText(trip.routeId) || '?',
        headsign: cleanText(trip.headsign),
        minutes,
        realtime: false,
        tripId: cleanText(trip.tripId),
      })
    }
  }

  debug.log('schedule_parsed', {
    stopCode,
    scheduleStops: scheduleList.length,
    scheduledTripCount,
    scheduledTripInWindowCount,
    totalTrips: trips.length,
  })

  const grouped: Record<string, {
    line: string
    headsign: string
    arrivals: Array<{
      line: string
      headsign: string
      minutes: number
      realtime: boolean
      stale?: boolean
    }>
  }> = {}

  for (const trip of trips) {
    const key = `${trip.line}_${trip.headsign}`
    grouped[key] ??= { line: trip.line, headsign: trip.headsign, arrivals: [] }
    grouped[key].arrivals.push({
      line: trip.line,
      headsign: trip.headsign,
      minutes: trip.minutes,
      realtime: trip.realtime,
      stale: trip.stale,
    })
  }

  const groups = Object.values(grouped).map(group => ({
    line: group.line,
    headsign: group.headsign,
    arrivals: group.arrivals
      .sort((a, b) => a.minutes - b.minutes)
      .slice(0, 4),
  }))

  debug.log('stop_grouped', { stopCode, groups: groups.length })

  return {
    stopCode,
    name: fetchedName,
    groups,
  }
}

async function getStopSummaryCached(adapter: KavNavAdapter, stopCode: string, debug: DebugLogger): Promise<any | null> {
  const key = String(stopCode)
  const entry = summaryCache.get(key)
  if (isFresh(entry, SUMMARY_CACHE_TTL_MS)) {
    debug.log('summary_cache_hit', { stopCode })
    return entry?.data ?? null
  }

  const data = await adapter.fetchJSON(`${BASE_URL}/stopSummary?stopCode=${encodeURIComponent(stopCode)}`, `summary_${stopCode}`)
  if (data == null && entry) {
    debug.warn('summary_fetch_failed_using_cache', { stopCode })
    return entry.data
  }
  if (data) summaryCache.set(key, { ts: Date.now(), data })
  return data || null
}

async function getStopScheduleCached(adapter: KavNavAdapter, stopCode: string, dateStr: string, debug: DebugLogger): Promise<any | null> {
  const key = `${String(stopCode)}|${String(dateStr)}`
  const entry = scheduleCache.get(key)
  if (isFresh(entry, SCHEDULE_CACHE_TTL_MS)) {
    debug.log('schedule_cache_hit', { stopCode, dateStr })
    return entry?.data ?? null
  }

  const data = await adapter.fetchJSON(
    `${BASE_URL}/stopSchedule?stopCode=${encodeURIComponent(stopCode)}&date=${encodeURIComponent(dateStr)}`,
    `schedule_${stopCode}`
  )
  if (data == null && entry) {
    debug.warn('schedule_fetch_failed_using_cache', { stopCode, dateStr })
    return entry.data
  }
  if (data) scheduleCache.set(key, { ts: Date.now(), data })
  return data || null
}

function isFresh(entry: { ts: number; data: any } | undefined, ttlMs: number): boolean {
  if (!entry) return false
  return Date.now() - entry.ts < ttlMs
}

function extractStopName(summary: any): string | null {
  if (Array.isArray(summary) && summary.length > 0) return cleanText(summary[0]?.name) || null
  return cleanText(summary?.name) || null
}

function buildRouteMap(summary: any): Record<string, string> {
  const routeMap: Record<string, string> = {}
  for (const group of normalizeArray(summary)) {
    for (const route of normalizeArray(group?.routes)) {
      const routeId = cleanText(route?.routeId)
      const routeNumber = cleanText(route?.routeNumber)
      if (routeId && routeNumber) routeMap[routeId] = routeNumber
    }
  }
  return routeMap
}

function normalizeArray<T = any>(value: T | T[] | null | undefined): T[] {
  if (value == null) return []
  return Array.isArray(value) ? value : [value]
}

function extractStopCodesFromTags(tags: Record<string, unknown> | null | undefined): string[] {
  if (!tags || typeof tags !== 'object') return []

  const candidates = [
    tags.ref,
    tags.local_ref,
    tags['gtfs:stop_id'],
    tags['gtfs:stop_code'],
    tags['public_transport:ref'],
    tags['ref:IL:mot'],
    tags['ref:il:mot'],
  ]

  const codes: string[] = []
  for (const candidate of candidates) {
    for (const code of splitStopCodes(candidate)) {
      if (!codes.includes(code)) codes.push(code)
    }
  }
  return codes
}

function splitStopCodes(value: unknown): string[] {
  if (value == null) return []
  return String(value)
    .split(/[;,/|]/)
    .map(item => item.trim())
    .filter(Boolean)
    .map(item => item.replace(/^IL:/i, '').trim())
    .filter(Boolean)
}

function formatDate(date: Date): string {
  const offset = date.getTimezoneOffset() * 60000
  return new Date(date.getTime() - offset).toISOString().slice(0, 10)
}

function getMinutesDiff(targetDate: Date): number {
  return Math.round((targetDate.getTime() - Date.now()) / 60000)
}

function parseTimeStr(timeStr: string, dateRef: Date): Date {
  const [hours, minutes, seconds] = timeStr.split(':').map(Number)
  const date = new Date(dateRef)
  date.setHours(hours || 0, minutes || 0, seconds || 0, 0)
  return date
}

function getDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371000
  const dLat = degreesToRadians(lat2 - lat1)
  const dLon = degreesToRadians(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(degreesToRadians(lat1)) *
    Math.cos(degreesToRadians(lat2)) *
    Math.sin(dLon / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

function degreesToRadians(value: number): number {
  return value * Math.PI / 180
}

function clampInt(value: unknown, fallback: number, min: number, max: number): number {
  const n = Math.round(Number(value))
  if (!Number.isFinite(n)) return fallback
  return Math.min(max, Math.max(min, n))
}

function toBoolean(value: unknown, fallback: boolean): boolean {
  if (value == null || value === '') return fallback
  if (typeof value === 'boolean') return value
  const text = String(value).trim().toLowerCase()
  return ['1', 'true', 'yes', 'y', 'yes'].includes(text)
}

function cleanText(value: unknown): string {
  if (value == null) return ''
  return String(value).trim()
}

function createDebugLogger(enabled: boolean): DebugLogger {
  const entries: string[] = []

  const add = (level: 'log' | 'warn' | 'error', message: string, details?: unknown) => {
    const line = details === undefined
      ? `${message}`
      : `${message} ${safeJson(details)}`
    entries.push(line)

    if (!enabled) return
    const output = `${LOG_PREFIX} ${line}`
    if (level === 'error') console.error(output)
    else if (level === 'warn') console.warn(output)
    else console.log(output)
  }

  return {
    enabled,
    entries,
    log: (message, details) => add('log', message, details),
    warn: (message, details) => add('warn', message, details),
    error: (message, details) => add('error', message, details),
  }
}

function safeJson(value: unknown): string {
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}

function stringifyError(error: unknown): string {
  if (error instanceof Error) return `${error.name}: ${error.message}`
  return safeJson(error)
}

function describeJsonShape(value: any): any {
  if (value == null) return 'null'
  if (Array.isArray(value)) return { type: 'array', length: value.length }
  if (typeof value === 'object') {
    const keys = Object.keys(value)
    const shape: Record<string, unknown> = { type: 'object', keys: keys.slice(0, 12) }
    if (Array.isArray(value.elements)) shape.elements = value.elements.length
    if (Array.isArray(value.vehicles)) shape.vehicles = value.vehicles.length
    if (Array.isArray(value.stopSchedule)) shape.stopSchedule = value.stopSchedule.length
    return shape
  }
  return typeof value
}

function stripQueryForLog(url: string): string {
  if (url.includes('/api/interpreter')) return url.split('?')[0]
  return url
}

function safeParamsForLog(params: NearbyTransitArrivalsIntentParams): Record<string, unknown> {
  return {
    hasLatitude: params.latitude != null && params.latitude !== '',
    hasLongitude: params.longitude != null && params.longitude !== '',
    radiusMeters: params.radiusMeters,
    maxStops: params.maxStops,
    lookaheadMinutes: params.lookaheadMinutes,
    forceLocationRequest: params.forceLocationRequest,
    debug: params.debug,
  }
}

function roundCoord(value: number): number {
  return Math.round(value * 1000000) / 1000000
}

function AssistantToolMaybeCancelled(): boolean {
  try {
    return Boolean((globalThis as any).AssistantTool?.isCancelled)
  } catch {
    return false
  }
}
