import toolJson from './tool.json'
import { buildNearbyTransitArrivalsDisplay } from './buildNearbyTransitArrivalsDisplay'
import { runNearbyTransitArrivalsTool } from './runNearbyTransitArrivalsTool'
import { NearbyTransitArrivalsCard } from './NearbyTransitArrivalsCard'
import {
  AgentToolModule,
  AgentToolRunResult,
  asAgentToolSpec,
} from '../types'

import { NearbyTransitArrivalsLiveActivity } from './liveActivity'
export * from './buildNearbyTransitArrivalsDisplay'
export * from './runNearbyTransitArrivalsTool'
export * from './NearbyTransitArrivalsCard'
export * from './liveActivity'

export const NEARBY_TRANSIT_ARRIVALS_TOOL_SPEC = asAgentToolSpec(toolJson)

async function runRegisteredNearbyTransitArrivalsTool(
  params: Record<string, unknown>
): Promise<AgentToolRunResult> {
  const result = await runNearbyTransitArrivalsTool(params)

  if (result.ok) {
    return { ok: true, data: result.data }
  }

  const failure = result as { message: string; debugLog?: string[] }
  return {
    ok: false,
    message: failure.message,
    data: failure.debugLog
      ? {
          title: 'Public transit arrival times',
          subtitle: failure.message,
          generatedAtLabel: '',
          warnings: [failure.message],
          stops: [],
          debugLog: failure.debugLog,
        }
      : undefined,
  }
}

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: NEARBY_TRANSIT_ARRIVALS_TOOL_SPEC,
  run: runRegisteredNearbyTransitArrivalsTool,
  Card: NearbyTransitArrivalsCard,
  LiveActivity: NearbyTransitArrivalsLiveActivity,
}

export default AGENT_TOOL_MODULE
