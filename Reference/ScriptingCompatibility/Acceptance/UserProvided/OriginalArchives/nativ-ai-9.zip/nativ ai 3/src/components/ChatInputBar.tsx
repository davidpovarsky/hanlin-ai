import {
  Button,
  Capsule,
  Image,
  HStack,
  List,
  Menu,
  NavigationStack,
  Section,
  Spacer,
  Text,
  TextField,
  Toggle,
  VStack,
  useEffect,
  useState,
} from 'scripting'
import type { AIProvider } from '../context/AppContext'
import { Strings } from '../l10n'
import { ChatAttachment, ChatMessage } from '../types/chat'

export type ComposerFeatureKey = 'pip' | 'liveActivity' | 'backgroundNotifications'

export type ComposerFeatureSettings = {
  pip: boolean
  liveActivity: boolean
  backgroundNotifications: boolean
}

type Props = {
  strings: Strings
  locale: string
  isBusy: boolean
  editingMessage: ChatMessage | null
  attachments: ChatAttachment[]
  aiProvider: AIProvider
  featureSettings: ComposerFeatureSettings
  onSend: (text: string) => void
  onSaveEdit: (text: string) => void
  onCancelEdit: () => void
  onStop: () => void
  onPickFiles: () => void
  onPickPhotos: () => void
  onTakePhoto: () => void
  onRemoveAttachment: (id: string) => void
  onAIProviderChange: (provider: AIProvider) => void
  onToggleFeature: (key: ComposerFeatureKey, enabled: boolean) => void
}

const AI_PROVIDER_VALUES: AIProvider[] = [
  'app_default',
  'openai',
  'gemini',
  'anthropic',
  'deepseek',
  'openrouter',
]

export function ChatInputBar({
  strings,
  locale,
  isBusy,
  editingMessage,
  attachments,
  aiProvider,
  featureSettings,
  onSend,
  onSaveEdit,
  onCancelEdit,
  onStop,
  onPickFiles,
  onPickPhotos,
  onTakePhoto,
  onRemoveAttachment,
  onAIProviderChange,
  onToggleFeature,
}: Props) {
  const [draft, setDraft] = useState('')
  const [featureSheetPresented, setFeatureSheetPresented] = useState(false)
  const [isListening, setIsListening] = useState(false)
  const [voiceLevel, setVoiceLevel] = useState(0)
  const isEditing = editingMessage != null
  const canSubmit = draft.trim().length > 0 || attachments.length > 0
  const providerLabel = getAIProviderLabel(strings, aiProvider)

  useEffect(() => {
    stopSpeechRecognition(setIsListening, setVoiceLevel)

    if (editingMessage) {
      setDraft(editingMessage.text)
    } else {
      setDraft('')
    }
  }, [editingMessage?.id])

  const toggleSpeechRecognition = async () => {
    if (isBusy) return

    if (isListening || SpeechRecognition.isRecognizing) {
      await stopSpeechRecognition(setIsListening, setVoiceLevel)
      return
    }

    setVoiceLevel(0)

    const baseText = draft.trimEnd()
    const prefix = baseText.length > 0 ? `${baseText} ` : ''

    try {
      const started = await SpeechRecognition.start({
        locale: normalizeSpeechLocale(locale),
        partialResults: true,
        addsPunctuation: true,
        taskHint: 'dictation',
        onResult: (result) => {
          setDraft(`${prefix}${result.text}`.trimStart())
          if (result.isFinal) {
            setIsListening(false)
            setVoiceLevel(0)
          }
        },
        onSoundLevelChanged: (level) => {
          setVoiceLevel(normalizeSoundLevel(level))
        },
      })

      setIsListening(started)
      if (!started) {
        setVoiceLevel(0)
        await Dialog.alert({
          title: strings.voiceInputUnavailable,
          message: strings.voiceInputStartFailed,
          buttonLabel: strings.ok,
        })
      }
    } catch (error) {
      setIsListening(false)
      setVoiceLevel(0)
      await Dialog.alert({
        title: strings.voiceInputUnavailable,
        message: error instanceof Error ? error.message : strings.voiceInputStartFailed,
        buttonLabel: strings.ok,
      })
    }
  }

  const submit = () => {
    const trimmed = draft.trim()
    if ((!trimmed && attachments.length === 0) || isBusy) return

    stopSpeechRecognition(setIsListening, setVoiceLevel)

    if (isEditing) {
      if (!trimmed) return
      onSaveEdit(trimmed)
      setDraft('')
    } else {
      onSend(trimmed)
      setDraft('')
    }
  }

  const cancelEdit = () => {
    stopSpeechRecognition(setIsListening, setVoiceLevel)
    setDraft('')
    onCancelEdit()
  }

  return (
    <VStack
      spacing={0}
      padding={{ horizontal: 12, vertical: 8 }}
    >
      <VStack
        spacing={8}
        padding={{ horizontal: 12, vertical: 10 }}
        background="ultraThinMaterial"
        clipShape={{ type: 'rect', cornerRadius: isEditing ? 24 : 30 }}
        shadow={{ color: 'systemGray4', radius: 18, x: 0, y: 8 }}
      >
        {!isEditing && attachments.length > 0 ? (
          <HStack
            spacing={7}
            frame={{ maxWidth: 'infinity', alignment: isRTLLocale(locale) ? 'trailing' : 'leading' }}
          >
            {attachments.map(item => (
              <AttachmentChip
                key={item.id}
                attachment={item}
                onRemove={() => onRemoveAttachment(item.id)}
              />
            ))}
          </HStack>
        ) : null}

        {isEditing ? (
          <HStack spacing={8} frame={{ maxWidth: 'infinity' }}>
            <Text
              font="caption"
              foregroundStyle="secondaryLabel"
            >
              {strings.editMessageTitle}
            </Text>
            <Spacer />
            <Button
              title=""
              systemImage="xmark"
              action={cancelEdit}
              disabled={isBusy}
              buttonStyle="borderless"
              foregroundStyle="secondaryLabel"
            />
          </HStack>
        ) : null}

        {isListening ? (
          <ListeningComposer
            level={voiceLevel}
            onStop={toggleSpeechRecognition}
          />
        ) : (
          <VStack spacing={8} frame={{ maxWidth: 'infinity' }}>
            <TextField
              title={isEditing ? strings.editMessageTitle : strings.chatPlaceholder}
              value={draft}
              onChanged={setDraft}
              prompt={isEditing ? strings.editMessagePlaceholder : strings.chatPlaceholder}
              axis="vertical"
              autofocus={isEditing}
              lineLimit={{ min: 1, max: 6 }}
              submitLabel="send"
              font="body"
              multilineTextAlignment={isRTLLocale(locale) ? 'trailing' : 'leading'}
              textFieldStyle="plain"
            />

            <HStack
              spacing={8}
              frame={{ maxWidth: 'infinity', alignment: 'center' }}
              buttonStyle="bordered"
              buttonBorderShape="circle"
              controlSize="regular"
            >
              {!isEditing ? (
                <Menu
                  title=""
                  systemImage="plus"
                >
                  <Button
                    title={strings.chooseFiles}
                    systemImage="doc.badge.plus"
                    action={onPickFiles}
                    disabled={isBusy}
                  />
                  <Button
                    title={strings.choosePhotos}
                    systemImage="photo.on.rectangle"
                    action={onPickPhotos}
                    disabled={isBusy}
                  />
                  <Button
                    title={strings.takePhoto}
                    systemImage="camera"
                    action={onTakePhoto}
                    disabled={isBusy}
                  />
                </Menu>
              ) : null}

              <Button
                title=""
                systemImage="slider.horizontal.3"
                action={() => setFeatureSheetPresented(true)}
                disabled={isBusy}
                sheet={{
                  isPresented: featureSheetPresented,
                  onChanged: setFeatureSheetPresented,
                  content: (
                    <ComposerFeatureSettingsSheet
                      strings={strings}
                      featureSettings={featureSettings}
                      onToggleFeature={onToggleFeature}
                      onClose={() => setFeatureSheetPresented(false)}
                    />
                  ),
                }}
              />

              <Menu
                title={providerLabel}
                systemImage="cpu"
                buttonStyle="bordered"
                buttonBorderShape="capsule"
              >
                {AI_PROVIDER_VALUES.map(provider => (
                  <Button
                    key={provider}
                    title={getAIProviderLabel(strings, provider)}
                    systemImage={aiProvider === provider ? 'checkmark.circle.fill' : 'circle'}
                    action={() => onAIProviderChange(provider)}
                  />
                ))}
              </Menu>

              <Spacer />

              <Button
                title=""
                systemImage="mic"
                action={toggleSpeechRecognition}
                disabled={isBusy}
                buttonStyle="bordered"
                buttonBorderShape="circle"
                foregroundStyle="label"
              />

              <Button
                title=""
                systemImage={isBusy ? 'stop.fill' : (isEditing ? 'checkmark' : 'arrow.up')}
                buttonStyle="borderedProminent"
                buttonBorderShape="circle"
                tint={isBusy ? 'systemRed' : 'systemBlue'}
                action={isBusy ? onStop : submit}
                disabled={!isBusy && !canSubmit}
              />
            </HStack>
          </VStack>
        )}
      </VStack>
    </VStack>
  )

}


function AttachmentChip({
  attachment,
  onRemove,
}: {
  attachment: ChatAttachment
  onRemove: () => void
}) {
  return (
    <HStack
      spacing={6}
      padding={{ horizontal: 9, vertical: 6 }}
      background="tertiarySystemFill"
      clipShape={{ type: 'capsule' }}
    >
      <Image
        systemName={attachment.kind === 'image' ? 'photo' : 'doc'}
        foregroundStyle="secondaryLabel"
        imageScale="small"
      />
      <Text
        font="subheadline"
        foregroundStyle="label"
        lineLimit={1}
      >
        {attachment.name}
      </Text>
      <Button
        title=""
        systemImage="xmark"
        action={onRemove}
        buttonStyle="borderless"
        foregroundStyle="secondaryLabel"
        controlSize="small"
      />
    </HStack>
  )
}


function isRTLLocale(locale: string): boolean {
  const normalized = String(locale || '').toLowerCase()
  return normalized === 'he' || normalized.startsWith('he-') || normalized === 'ar' || normalized.startsWith('ar-')
}


function ComposerFeatureSettingsSheet({
  strings,
  featureSettings,
  onToggleFeature,
  onClose,
}: {
  strings: Strings
  featureSettings: ComposerFeatureSettings
  onToggleFeature: (key: ComposerFeatureKey, enabled: boolean) => void
  onClose: () => void
}) {
  return (
    <NavigationStack
      presentationDragIndicator="visible"
      presentationDetents={[260, 'medium']}
      presentationCornerRadius={28}
    >
      <List
        navigationTitle={strings.composerOptions}
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          topBarTrailing: (
            <Button
              title=""
              systemImage="xmark"
              action={onClose}
              buttonStyle="borderless"
            />
          ),
        }}
      >
        <Section>
          <Toggle
            title={strings.pipStatus}
            systemImage="pip"
            value={featureSettings.pip}
            onChanged={(enabled: boolean) => onToggleFeature('pip', enabled)}
            toggleStyle="switch"
          />
          <Toggle
            title={strings.liveActivity}
            systemImage="livephoto"
            value={featureSettings.liveActivity}
            onChanged={(enabled: boolean) => onToggleFeature('liveActivity', enabled)}
            toggleStyle="switch"
          />
          <Toggle
            title={strings.backgroundNotifications}
            systemImage="bell.badge"
            value={featureSettings.backgroundNotifications}
            onChanged={(enabled: boolean) => onToggleFeature('backgroundNotifications', enabled)}
            toggleStyle="switch"
          />
        </Section>
      </List>
    </NavigationStack>
  )
}


function ListeningComposer({
  level,
  onStop,
}: {
  level: number
  onStop: () => void
}) {
  const [pulse, setPulse] = useState(0)
  const bars = new Array(42).fill(0)

  useEffect(() => {
    let nextPulse = 0
    const timer = setInterval(() => {
      nextPulse += 1
      setPulse(nextPulse)
    }, 95)

    return () => clearInterval(timer)
  }, [])

  return (
    <HStack spacing={10} frame={{ maxWidth: 'infinity' }}>
      <Button
        title=""
        systemImage="stop.fill"
        action={onStop}
        buttonStyle="borderedProminent"
      />

      <HStack
        spacing={2}
        frame={{ maxWidth: 'infinity', alignment: 'center' }}
        padding={{ horizontal: 10, vertical: 8 }}
        background="tertiarySystemFill"
        clipShape={{ type: 'rect', cornerRadius: 18 }}
      >
        {bars.map((_, index) => (
          <Capsule
            key={`voice-bar-${index}`}
            fill={waveformBarFill(index, bars.length)}
            frame={{
              width: 3,
              height: waveformBarHeight(index, pulse, level),
            }}
          />
        ))}
      </HStack>
    </HStack>
  )
}

async function stopSpeechRecognition(
  setIsListening: (value: boolean) => void,
  setVoiceLevel?: (value: number) => void,
): Promise<void> {
  try {
    if (SpeechRecognition.isRecognizing) {
      await SpeechRecognition.stop()
    }
  } catch {
    /* ignore */
  }
  setIsListening(false)
  setVoiceLevel?.(0)
}

function normalizeSpeechLocale(locale: string): string {
  const normalized = String(locale || '').trim()
  const lower = normalized.toLowerCase()

  if (lower === 'he' || lower.startsWith('he-')) return 'he-IL'
  if (lower === 'en' || lower.startsWith('en-')) return 'en-US'
  if (normalized.includes('-')) return normalized

  return 'en-US'
}

function normalizeSoundLevel(level: number): number {
  const value = Number(level)
  if (!Number.isFinite(value)) return 0

  if (value >= 0 && value <= 1) return value
  if (value <= 0) return Math.max(0, Math.min(1, (value + 60) / 60))

  return Math.max(0, Math.min(1, value / 100))
}

function waveformBarHeight(index: number, pulse: number, level: number): number {
  const phase = (index + pulse) * 0.62
  const motion = (Math.sin(phase) + 1) / 2
  const breathing = (Math.sin(phase * 0.43 + pulse * 0.18) + 1) / 2
  const energy = Math.max(0.1, Math.min(1, level))

  return 5 + Math.round((motion * 14 + breathing * 8) * (0.35 + energy * 0.85))
}

function waveformBarFill(index: number, count: number): string {
  return index >= count - 5 ? 'label' : 'secondaryLabel'
}

function getAIProviderLabel(strings: Strings, provider: AIProvider): string {
  switch (provider) {
    case 'openai':
      return strings.aiProviderOpenAI
    case 'gemini':
      return strings.aiProviderGemini
    case 'anthropic':
      return strings.aiProviderAnthropic
    case 'deepseek':
      return strings.aiProviderDeepSeek
    case 'openrouter':
      return strings.aiProviderOpenRouter
    case 'app_default':
    default:
      return strings.aiProviderDefault
  }
}
