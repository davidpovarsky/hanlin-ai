// Pure JS - date formatting helpers
// Receives a project locale code and resolves it through the central l10n registry.

import { getIntlLocale } from '../l10n'

export function formatTime(timestamp: number, locale: string): string {
  try {
    const localeTag = getIntlLocale(locale)
    return new Date(timestamp).toLocaleTimeString(localeTag, {
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return new Date(timestamp).toISOString()
  }
}

export function formatDate(timestamp: number, locale: string): string {
  try {
    const localeTag = getIntlLocale(locale)
    return new Date(timestamp).toLocaleDateString(localeTag, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  } catch {
    return new Date(timestamp).toISOString()
  }
}

export function formatDateTime(isoString: string | null, locale: string): string {
  if (!isoString) return ''
  try {
    const date = new Date(isoString)
    if (isNaN(date.getTime())) return isoString
    const localeTag = getIntlLocale(locale)
    return date.toLocaleString(localeTag, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return isoString
  }
}

export function parseISOToParts(isoString: string): {
  year: number
  month: number
  day: number
  hour: number
  minute: number
} | null {
  try {
    const date = new Date(isoString)
    if (isNaN(date.getTime())) return null
    return {
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate(),
      hour: date.getHours(),
      minute: date.getMinutes(),
    }
  } catch {
    return null
  }
}
