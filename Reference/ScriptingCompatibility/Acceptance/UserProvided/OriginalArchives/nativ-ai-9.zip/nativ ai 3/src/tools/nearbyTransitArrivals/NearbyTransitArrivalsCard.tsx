import { DisclosureGroup, HStack, Label, Text, VStack } from 'scripting'
import { isRTL } from '../../l10n'
import { NearbyTransitArrivalsDisplayData, NearbyTransitStopDisplayItem } from './buildNearbyTransitArrivalsDisplay'
import { ToolCardFrame, ToolHeader, SoftPanel, ToolPill, NativeDivider } from '../nativeToolUI'

type Props = {
  data: NearbyTransitArrivalsDisplayData
  strings?: Record<string, string>
  locale?: string
}

export function NearbyTransitArrivalsCard({ data, locale }: Props) {
  const hasStops = data.stops.length > 0
  const rtl = isRTL(locale || '')
  const align = rtl ? 'trailing' : 'leading'

  return (
    <ToolCardFrame alignment={align}>
      <ToolHeader
        title={data.title}
        subtitle={data.generatedAtLabel ? `Updated at ${data.generatedAtLabel}` : 'Arrival times'}
        icon="bus.fill"
        accent="systemTeal"
        alignment={align}
      />

      <SoftPanel alignment={align} spacing={8} fill="secondarySystemGroupedBackground">
        <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment={align}>
          {data.subtitle}
        </Text>
        <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment: align }}>
          <ToolPill icon="location.circle" text={`${data.radiusMeters}m`} color="secondaryLabel" />
          <ToolPill icon="clock" text={`${data.lookaheadMinutes} min`} color="secondaryLabel" />
          {data.location ? (
            <ToolPill icon="scope" text={data.location.source === 'device' ? 'Device location' : 'Provided location'} color="systemBlue" />
          ) : null}
        </HStack>
      </SoftPanel>

      {data.warnings.length > 0 ? (
        <Warnings warnings={data.warnings} alignment={align} />
      ) : null}

      {data.debugLog && data.debugLog.length > 0 ? (
        <DebugLog lines={data.debugLog} alignment={align} />
      ) : null}

      {hasStops ? (
        <VStack alignment={align} spacing={10} frame={{ maxWidth: 'infinity', alignment: align }}>
          {data.stops.map(stop => (
            <StopGroup key={stop.id} stop={stop} alignment={align} />
          ))}
        </VStack>
      ) : (
        <SoftPanel alignment={align}>
          <Label
            title="No nearby stops found."
            systemImage="location.slash"
            foregroundStyle="secondaryLabel"
          />
        </SoftPanel>
      )}
    </ToolCardFrame>
  )
}

function StopGroup({
  stop,
  alignment,
}: {
  stop: NearbyTransitStopDisplayItem
  alignment: 'leading' | 'trailing'
  key?: string
}) {
  const hasGroups = stop.groups.length > 0

  return (
    <SoftPanel alignment={alignment} spacing={10} padding={12}>
      <DisclosureGroup title={stop.name}>
        <VStack alignment={alignment} spacing={10}>
          <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment }}>
            <ToolPill icon="number" text={`Stop ${stop.stopCode}`} color="secondaryLabel" />
            {stop.distanceLabel ? <ToolPill icon="figure.walk" text={stop.distanceLabel} color="secondaryLabel" /> : null}
            {stop.hasRealtime ? <ToolPill icon="dot.radiowaves.left.and.right" text="Real time" color="systemGreen" /> : null}
          </HStack>

          {hasGroups ? (
            <VStack alignment={alignment} spacing={10}>
              {stop.groups.map(group => (
                <VStack key={group.id} alignment={alignment} spacing={6} frame={{ maxWidth: 'infinity', alignment }}>
                  <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment }}>
                    <ToolPill icon="bus.fill" text={`Line ${group.line}`} color="systemTeal" />
                    {group.firstArrivalMinutes != null ? (
                      <ToolPill icon="clock.fill" text={`${group.firstArrivalMinutes} min`} color="systemOrange" />
                    ) : null}
                  </HStack>

                  {group.headsign ? (
                    <Text font="caption" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
                      {group.headsign}
                    </Text>
                  ) : null}

                  <Text font="subheadline" fontWeight="medium" multilineTextAlignment={alignment}>
                    {group.arrivals
                      .map(arrival => `${arrival.label}${arrival.stale ? ' *' : ''}${arrival.realtime ? ' · real time' : ''}`)
                      .join('  •  ')}
                  </Text>
                </VStack>
              ))}
            </VStack>
          ) : (
            <Text font="caption" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
              No arrivals in the selected time range.
            </Text>
          )}

          {stop.hasStaleRealtime ? (
            <>
              <NativeDivider />
              <Text font="caption2" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
                * Real-time data came from cache and may not be current.
              </Text>
            </>
          ) : null}
        </VStack>
      </DisclosureGroup>
    </SoftPanel>
  )
}

function Warnings({ warnings, alignment }: { warnings: string[]; alignment: 'leading' | 'trailing' }) {
  return (
    <SoftPanel alignment={alignment} spacing={6} fill="tertiarySystemFill">
      {warnings.map((warning, index) => (
        <Label
          key={`warning_${index}`}
          title={warning}
          systemImage="exclamationmark.triangle.fill"
          font="caption"
          foregroundStyle="systemOrange"
        />
      ))}
    </SoftPanel>
  )
}

function DebugLog({ lines, alignment }: { lines: string[]; alignment: 'leading' | 'trailing' }) {
  return (
    <SoftPanel alignment={alignment} spacing={6}>
      <DisclosureGroup title="Debug log">
        <VStack alignment={alignment} spacing={4}>
          {lines.slice(-14).map((line, index) => (
            <Text
              key={`debug_${index}`}
              font="caption2"
              foregroundStyle="secondaryLabel"
              multilineTextAlignment={alignment}
            >
              {line}
            </Text>
          ))}
        </VStack>
      </DisclosureGroup>
    </SoftPanel>
  )
}
