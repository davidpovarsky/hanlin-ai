// src/tools/externalSkills.ts
//
// Runtime loader for external Scripting skills.
//
// External skills live outside this project, normally in:
//   iCloud Drive/Scripting/scripting-skills/<skill-name>
//
// Each skill folder may contain:
//   skill.json or skile.json
//   SKILL.md, skill.md, or skile.md
//   scripts/*.ts
//
// The agent exposes every discovered skill as one tool. The model selects the
// skill and an action. This runner maps that action to a script file and runs it
// with scripting-ts. The model never receives permission to create arbitrary
// shell commands.

import type {
  AgentToolModule,
  AgentToolRunResult,
  AgentToolSpec,
  CompactAgentToolSpec,
} from './types'
import { formatString, getStrings } from '../l10n'

export type ExternalSkillScript = {
  action: string
  fileName: string
  relativePath: string
}

export type ExternalSkillDefinition = {
  id: string
  folderName: string
  directory: string
  displayName: string
  description: string
  icon?: string
  color?: string
  version?: string
  skillMarkdown: string
  scripts: ExternalSkillScript[]
  spec: AgentToolSpec
}

type SkillJsonLike = {
  name?: string
  displayName?: string
  display_name?: string
  description?: string
  icon?: string
  color?: string
  version?: string
  metadata?: {
    display_name?: string
    displayName?: string
    [key: string]: unknown
  }
  [key: string]: unknown
}

type FrontMatter = {
  values: Record<string, string>
  body: string
}

const SKILLS_ROOT_RELATIVE = 'scripting-skills'
const SKILL_JSON_NAMES = ['skill.json', 'skile.json']
const SKILL_MD_NAMES = ['SKILL.md', 'skill.md', 'skile.md']
const MAX_DETAILED_MD_CHARS = 9000

let cachedModules: AgentToolModule[] = []
let cachedDefinitions: ExternalSkillDefinition[] = []
let cacheLoaded = false

export async function refreshExternalSkillModules(): Promise<AgentToolModule[]> {
  const definitions = await discoverExternalSkills()
  cachedDefinitions = definitions
  cachedModules = definitions.map(definition => buildExternalSkillModule(definition))
  cacheLoaded = true
  logExternalSkillDiscovery(definitions)
  return cachedModules
}

export async function ensureExternalSkillModulesLoaded(): Promise<AgentToolModule[]> {
  if (cacheLoaded) return cachedModules
  return refreshExternalSkillModules()
}

export function getExternalSkillModulesSnapshot(): AgentToolModule[] {
  return cachedModules
}

export function getExternalSkillDefinitionsSnapshot(): ExternalSkillDefinition[] {
  return cachedDefinitions
}

export async function discoverExternalSkills(): Promise<ExternalSkillDefinition[]> {
  const FileManager = getGlobal('FileManager')
  if (!FileManager) return []

  const roots = await getSkillRootCandidates(FileManager)
  console.log('[External skills] root candidates:', roots)
  const seenRoots = new Set<string>()
  const found: ExternalSkillDefinition[] = []

  for (const root of roots) {
    const normalizedRoot = normalizePath(root)
    if (!normalizedRoot || seenRoots.has(normalizedRoot)) continue
    seenRoots.add(normalizedRoot)

    if (!(await exists(FileManager, normalizedRoot))) {
      console.log('[External skills] root not found:', normalizedRoot)
      continue
    }

    const entries = await readDirectory(FileManager, normalizedRoot)
    console.log('[External skills] scanning root:', normalizedRoot, 'entries:', entries.length)
    for (const rawEntry of entries) {
      const entry = String(rawEntry || '').trim()
      if (!entry || entry.startsWith('.')) continue

      const folderName = basename(entry)
      const directory = isAbsolutePath(entry) ? entry : joinPath(normalizedRoot, entry)
      if (!(await isDirectoryPath(FileManager, directory))) continue

      const definition = await readExternalSkillDefinition(FileManager, directory, folderName)
      if (definition) found.push(definition)
    }
  }

  const byId: Record<string, ExternalSkillDefinition> = {}
  for (const definition of found) {
    byId[definition.id] = definition
  }

  return Object.values(byId).sort((a, b) => a.id.localeCompare(b.id))
}

async function readExternalSkillDefinition(
  FileManager: any,
  directory: string,
  folderName: string
): Promise<ExternalSkillDefinition | null> {
  const scriptsDir = joinPath(directory, 'scripts')
  if (!(await exists(FileManager, scriptsDir))) return null

  const scripts = await discoverSkillScripts(FileManager, scriptsDir)
  if (scripts.length === 0) return null

  const skillJson = await readFirstJson<SkillJsonLike>(FileManager, directory, SKILL_JSON_NAMES)
  const skillMarkdown = await readFirstText(FileManager, directory, SKILL_MD_NAMES)
  const frontMatter = parseFrontMatter(skillMarkdown)

  const rawId = firstNonEmpty(
    frontMatter.values.name,
    stringValue(skillJson?.name),
    folderName
  )
  const id = toToolName(rawId || folderName)
  if (!id) return null

  const displayName = firstNonEmpty(
    frontMatter.values.display_name,
    frontMatter.values.displayName,
    stringValue(skillJson?.metadata?.display_name),
    stringValue(skillJson?.metadata?.displayName),
    stringValue(skillJson?.displayName),
    stringValue(skillJson?.display_name),
    prettifyName(id)
  ) || prettifyName(id)

  const description = firstNonEmpty(
    frontMatter.values.description,
    stringValue(skillJson?.description),
    extractPurposeOrFirstParagraph(frontMatter.body),
    `External Scripting skill: ${displayName}.`
  ) || `External Scripting skill: ${displayName}.`

  const definitionWithoutSpec = {
    id,
    folderName,
    directory,
    displayName,
    description,
    icon: stringValue(skillJson?.icon),
    color: stringValue(skillJson?.color),
    version: stringValue(skillJson?.version),
    skillMarkdown,
    scripts,
  }

  const definition: ExternalSkillDefinition = {
    ...definitionWithoutSpec,
    spec: buildExternalSkillSpec(definitionWithoutSpec),
  }

  return definition
}

function buildExternalSkillSpec(definition: Omit<ExternalSkillDefinition, 'spec'>): AgentToolSpec {
  const actions = definition.scripts.map(script => script.action)
  const aliases = uniqueStrings([
    definition.folderName,
    camelCase(definition.id),
    definition.displayName,
  ]).filter(item => item !== definition.id)

  return {
    name: definition.id,
    publicName: definition.displayName,
    shortDescription: definition.description,
    aliases,
    description: buildExternalSkillDescription(definition, actions),
    whenToUse: [
      `Use this external skill when the user asks for capabilities described by ${definition.displayName}.`,
      'Use it when the request requires data or actions from the local Scripting runtime, iOS apps, media library, calendar, files, or another script-backed capability exposed by this skill.',
    ],
    whenNotToUse: [
      'Do not use this skill for ordinary conversation, explanations, or tasks that do not require its scripts.',
      'Do not invent action names. Use only the action names listed for this skill.',
      'Do not claim that a device/app action completed until a successful tool result is available.',
    ],
    params: {
      action: {
        required: true,
        description: `Script action to run. Allowed actions: ${actions.join(', ')}. Use the script file name without .ts.`,
      },
      paramsJson: {
        required: false,
        description: 'Optional JSON object string for script parameters that cannot be represented as flat fields. Use this especially when the selected script itself needs a parameter named action. In that case, include script parameters under scriptParams.',
      },
    },
    resultPolicy: [
      'The tool result is the JSON/text returned by the external Scripting skill script.',
      'Read-only/query actions may run directly.',
      'State-changing actions such as create, remove, delete, update, set, playback, play, pause, stop, start, or queue operations may ask the user for confirmation before execution.',
    ].join(' '),
    examples: [
      {
        user: `Use ${definition.displayName} to list available data.`,
        call: {
          tool: definition.id,
          params: {
            action: actions[0] || 'list',
          },
        },
      },
    ],
  }
}

function buildExternalSkillDescription(
  definition: Omit<ExternalSkillDefinition, 'spec'>,
  actions: string[]
): string {
  const docs = compactMarkdownForPrompt(definition.skillMarkdown)
  const lines: string[] = []

  lines.push(`${definition.description}`)
  lines.push('')
  lines.push('This is an external Scripting skill discovered at runtime from the scripting-skills directory.')
  lines.push(`Available actions: ${actions.join(', ') || '(none)'}.`)
  lines.push('Call shape: { "action": "action_name", ...scriptParameters }. If the selected script itself needs a parameter named action, put script parameters under scriptParams inside paramsJson.')
  lines.push('Use the SKILL.md documentation below to choose the action and exact script parameters.')

  if (docs) {
    lines.push('')
    lines.push('Skill documentation:')
    lines.push(docs)
  }

  return lines.join('\n')
}

function buildExternalSkillModule(definition: ExternalSkillDefinition): AgentToolModule {
  return {
    spec: definition.spec,
    run: async (params, language) => runExternalSkill(definition, params, language),
  }
}

async function runExternalSkill(
  definition: ExternalSkillDefinition,
  rawParams: Record<string, unknown>,
  language: string
): Promise<AgentToolRunResult> {
  const normalized = normalizeExternalSkillParams(definition, rawParams)
  if (!normalized.ok) {
    const failure = normalized as { ok: false; action?: string; message: string }
    return {
      ok: false,
      message: failure.message,
      data: buildExternalSkillDisplayData(definition, {
        action: failure.action || '',
        params: {},
        ok: false,
        errorMessage: failure.message,
      }),
    }
  }

  const { script, action, params } = normalized

  if (requiresConfirmationForAction(action, params)) {
    const confirmed = await confirmExternalSkillAction(definition, action, params, language)
    if (!confirmed) {
      const message = getStrings(language).actionCancelledBeforeTool
      return {
        ok: false,
        message,
        data: buildExternalSkillDisplayData(definition, {
          action,
          params,
          ok: false,
          errorMessage: message,
        }),
      }
    }
  }

  try {
    const result = await runSkillScript(definition, script, params)
    const parsed = parseScriptingTsOutput(result.output)
    const scriptReportedFailure = parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? (parsed as any).success === false || (parsed as any).ok === false
      : false

    const ok = result.exitCode === 0 && !result.timedOut && !result.cancelled && !scriptReportedFailure
    const message = ok
      ? ''
      : extractFailureMessage(parsed, result.output, result.exitCode, result.timedOut, result.cancelled)

    const data = buildExternalSkillDisplayData(definition, {
      action,
      params,
      ok,
      parsed,
      rawOutput: result.output,
      exitCode: result.exitCode,
      timedOut: result.timedOut,
      cancelled: result.cancelled,
      errorMessage: ok ? null : message,
    })

    return ok
      ? { ok: true, data }
      : { ok: false, message, data }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return {
      ok: false,
      message,
      data: buildExternalSkillDisplayData(definition, {
        action,
        params,
        ok: false,
        errorMessage: message,
      }),
    }
  }
}

type NormalizedExternalSkillParams =
  | { ok: true; action: string; script: ExternalSkillScript; params: Record<string, unknown> }
  | { ok: false; action?: string; message: string }

function normalizeExternalSkillParams(
  definition: ExternalSkillDefinition,
  rawParams: Record<string, unknown>
): NormalizedExternalSkillParams {
  const paramsJsonObject = parseJsonObject(rawParams.paramsJson)
  const nestedScriptParams = paramsJsonObject.scriptParams && typeof paramsJsonObject.scriptParams === 'object' && !Array.isArray(paramsJsonObject.scriptParams)
    ? paramsJsonObject.scriptParams as Record<string, unknown>
    : {}
  if (Object.keys(nestedScriptParams).length > 0) {
    delete (paramsJsonObject as any).scriptParams
  }
  const nestedParams = rawParams.params && typeof rawParams.params === 'object' && !Array.isArray(rawParams.params)
    ? rawParams.params as Record<string, unknown>
    : {}

  const actionCandidates = [
    { source: 'top', value: stringValue(rawParams.action) },
    { source: 'top', value: stringValue(rawParams.operation) },
    { source: 'top', value: stringValue(rawParams.script) },
    { source: 'top', value: stringValue(rawParams.name) },
    { source: 'nested', value: stringValue(nestedParams.action) },
    { source: 'json', value: stringValue(paramsJsonObject.action) },
  ]
  const actionCandidate = actionCandidates.find(item => item.value)
  const actionRaw = actionCandidate?.value || ''
  const actionSource = actionCandidate?.source || 'top'
  const hasNestedScriptAction = Object.prototype.hasOwnProperty.call(nestedScriptParams, 'action')

  const action = normalizeActionName(actionRaw || '')
  if (!action) {
    return {
      ok: false,
      message: `Missing action. Allowed actions: ${definition.scripts.map(item => item.action).join(', ')}`,
    }
  }

  const script = findScriptForAction(definition, action)
  if (!script) {
    return {
      ok: false,
      action,
      message: `Unsupported action "${action}" for ${definition.id}. Allowed actions: ${definition.scripts.map(item => item.action).join(', ')}`,
    }
  }

  const directParams: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(rawParams || {})) {
    if (['action', 'operation', 'script', 'name', 'params', 'paramsJson', 'confirmed'].includes(key)) continue
    directParams[key] = value
  }

  const merged = {
    ...paramsJsonObject,
    ...nestedParams,
    ...directParams,
    ...nestedScriptParams,
  }

  // Remove routing-only aliases from top-level/direct params. Keep nested
  // params.action when the selected script itself needs an action parameter
  // (for example apple-music/playback_control.ts uses { action: 'play' }).
  delete merged.operation
  delete merged.script
  delete merged.name
  if (hasNestedScriptAction) {
    // Keep scriptParams.action for scripts whose own parameter is named
    // action, for example apple-music/playback_control.ts.
  } else if (actionSource !== 'top') {
    delete merged.action
  } else if (Object.prototype.hasOwnProperty.call(directParams, 'action')) {
    delete merged.action
  }

  return {
    ok: true,
    action: script.action,
    script,
    params: merged,
  }
}

function findScriptForAction(
  definition: ExternalSkillDefinition,
  rawAction: string
): ExternalSkillScript | null {
  const normalized = normalizeActionName(rawAction)

  for (const script of definition.scripts) {
    if (normalizeActionName(script.action) === normalized) return script
    if (normalizeActionName(script.fileName) === normalized) return script
    if (normalizeActionName(script.relativePath) === normalized) return script
  }

  return null
}

async function runSkillScript(
  definition: ExternalSkillDefinition,
  script: ExternalSkillScript,
  params: Record<string, unknown>
): Promise<{
  output: string
  exitCode: number
  timedOut: boolean
  cancelled: boolean
}> {
  const Shell = getGlobal('Shell')
  if (!Shell?.run) {
    throw new Error('Shell.run is not available. External skills require Scripting Shell support.')
  }

  const hasParams = Object.keys(params || {}).length > 0
  const command = hasParams
    ? `scripting-ts run ${script.relativePath} --queryparameters ${shellSingleQuote(JSON.stringify(params))}`
    : `scripting-ts run ${script.relativePath}`

  return await Shell.run(command, {
    cwd: definition.directory,
    timeout: 120,
  })
}

function parseScriptingTsOutput(output: string): unknown {
  const text = String(output || '').trim()
  if (!text) return null

  const marker = 'Script result:'
  const markerIndex = text.lastIndexOf(marker)
  const candidate = markerIndex >= 0
    ? text.slice(markerIndex + marker.length).trim()
    : text

  const jsonCandidate = extractLikelyJson(candidate)
  if (jsonCandidate) {
    try {
      return JSON.parse(jsonCandidate)
    } catch {
      // Fall through to raw text.
    }
  }

  return candidate
}

function extractLikelyJson(value: string): string | null {
  const text = String(value || '').trim()
  if (!text) return null

  if ((text.startsWith('{') && text.endsWith('}')) || (text.startsWith('[') && text.endsWith(']'))) {
    return text
  }

  const objectStart = text.indexOf('{')
  const objectEnd = text.lastIndexOf('}')
  if (objectStart >= 0 && objectEnd > objectStart) {
    return text.slice(objectStart, objectEnd + 1)
  }

  const arrayStart = text.indexOf('[')
  const arrayEnd = text.lastIndexOf(']')
  if (arrayStart >= 0 && arrayEnd > arrayStart) {
    return text.slice(arrayStart, arrayEnd + 1)
  }

  return null
}

function buildExternalSkillDisplayData(
  definition: ExternalSkillDefinition,
  options: {
    action: string
    params: Record<string, unknown>
    ok: boolean
    parsed?: unknown
    rawOutput?: string
    exitCode?: number
    timedOut?: boolean
    cancelled?: boolean
    errorMessage?: string | null
  }
): Record<string, unknown> {
  return {
    externalSkill: true,
    kind: 'externalSkillResult',
    skillId: definition.id,
    skillName: definition.displayName,
    action: options.action,
    params: options.params,
    ok: options.ok,
    result: options.parsed ?? null,
    rawOutput: options.rawOutput || null,
    exitCode: options.exitCode ?? null,
    timedOut: options.timedOut ?? false,
    cancelled: options.cancelled ?? false,
    errorMessage: options.errorMessage ?? null,
  }
}

function requiresConfirmationForAction(action: string, params: Record<string, unknown>): boolean {
  if ((params as any).confirmed === true) return false

  const normalized = normalizeActionName(action)
  if (/^(get|list|read|query|search|find|fetch|lookup|describe|summarize)_?/.test(normalized)) {
    return false
  }

  if (/(create|remove|delete|update|set|write|save|send|post|queue|playback|control|play|pause|stop|skip|seek|start|resume|cancel|clear)/.test(normalized)) {
    return true
  }

  return false
}

async function confirmExternalSkillAction(
  definition: ExternalSkillDefinition,
  action: string,
  params: Record<string, unknown>,
  language: string
): Promise<boolean> {
  const Dialog = getGlobal('Dialog')
  if (!Dialog?.confirm) return false

  const strings = getStrings(language)
  const title = formatString(strings.confirmToolActionTitle, { tool: definition.displayName })
  const message = [
    formatString(strings.confirmToolActionMessage, { action }),
    '',
    formatParamsForConfirmation(params),
  ].join('\n')

  return !!(await Dialog.confirm({
    title,
    message,
    cancelLabel: strings.cancel,
    confirmLabel: strings.confirm,
  }))
}

function formatParamsForConfirmation(params: Record<string, unknown>): string {
  try {
    const json = JSON.stringify(params || {}, null, 2)
    return json.length > 1200 ? json.slice(0, 1200) + '\n…' : json
  } catch {
    return String(params)
  }
}

function extractFailureMessage(
  parsed: unknown,
  rawOutput: string,
  exitCode: number,
  timedOut: boolean,
  cancelled: boolean
): string {
  if (timedOut) return 'External skill timed out.'
  if (cancelled) return 'External skill was cancelled.'

  if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
    const obj = parsed as Record<string, unknown>
    const message = firstNonEmpty(
      stringValue(obj.message),
      stringValue(obj.error),
      stringValue(obj.reason)
    )
    if (message) return message
  }

  const text = String(rawOutput || '').trim()
  if (text) return text.length > 1000 ? text.slice(0, 1000) + '…' : text
  return `External skill failed with exit code ${exitCode}.`
}

async function discoverSkillScripts(FileManager: any, scriptsDir: string): Promise<ExternalSkillScript[]> {
  const entries = await readDirectory(FileManager, scriptsDir)
  const scripts: ExternalSkillScript[] = []

  for (const rawEntry of entries) {
    const entry = String(rawEntry || '').trim()
    if (!entry || entry.startsWith('.')) continue

    const fileName = basename(entry)
    if (!fileName.endsWith('.ts') && !fileName.endsWith('.tsx')) continue
    if (fileName.endsWith('.d.ts')) continue

    const action = fileName.replace(/\.tsx?$/i, '')
    scripts.push({
      action,
      fileName,
      relativePath: joinPath('scripts', fileName),
    })
  }

  scripts.sort((a, b) => a.action.localeCompare(b.action))
  return scripts
}

async function getSkillRootCandidates(FileManager: any): Promise<string[]> {
  const candidates: string[] = []

  const directICloudPath = '/private/var/mobile/Library/Mobile Documents/iCloud~com~thomfang~Scripting/Documents/scripting-skills'
  candidates.push(directICloudPath)

  for (const base of [
    FileManager.documentsDirectory,
    FileManager.iCloudDocumentsDirectory,
    FileManager.icloudDocumentsDirectory,
    FileManager.iCloudDirectory,
    FileManager.iCloudDriveDirectory,
    FileManager.scriptsDirectory,
  ]) {
    const path = normalizeOptionalPath(base)
    if (!path) continue
    candidates.push(joinPath(path, SKILLS_ROOT_RELATIVE))

    // Some roots point at the Scripting documents directory, while others point
    // one level above it. Include both shapes to avoid hard-coding one runtime.
    candidates.push(joinPath(path, 'Scripting', SKILLS_ROOT_RELATIVE))
  }

  const Script = getGlobal('Script')
  const scriptDirectory = normalizeOptionalPath(Script?.directory)
  if (scriptDirectory) {
    candidates.push(joinPath(dirname(scriptDirectory), SKILLS_ROOT_RELATIVE))
    candidates.push(joinPath(dirname(dirname(scriptDirectory)), SKILLS_ROOT_RELATIVE))
  }

  return uniqueStrings(candidates.map(normalizePath))
}

async function readFirstJson<T>(FileManager: any, directory: string, names: string[]): Promise<T | null> {
  for (const name of names) {
    const path = joinPath(directory, name)
    if (!(await exists(FileManager, path))) continue

    try {
      const text = await readText(FileManager, path)
      return JSON.parse(text) as T
    } catch {
      // Try the next variant.
    }
  }
  return null
}

async function readFirstText(FileManager: any, directory: string, names: string[]): Promise<string> {
  for (const name of names) {
    const path = joinPath(directory, name)
    if (!(await exists(FileManager, path))) continue

    try {
      return await readText(FileManager, path)
    } catch {
      // Try the next variant.
    }
  }
  return ''
}

function parseFrontMatter(markdown: string): FrontMatter {
  const text = String(markdown || '')
  if (!text.startsWith('---')) {
    return { values: {}, body: text }
  }

  const end = text.indexOf('\n---', 3)
  if (end < 0) return { values: {}, body: text }

  const front = text.slice(3, end).trim()
  const body = text.slice(end + 4).trim()
  const values: Record<string, string> = {}

  for (const line of front.split(/\r?\n/)) {
    const match = /^([A-Za-z0-9_.-]+)\s*:\s*(.*)$/.exec(line.trim())
    if (!match) continue
    values[match[1]] = match[2].replace(/^['"]|['"]$/g, '').trim()
  }

  return { values, body }
}

function extractPurposeOrFirstParagraph(markdown: string): string {
  const text = String(markdown || '')
  const purposeMatch = /#\s*Purpose\s+([\s\S]*?)(?:\n#|$)/i.exec(text)
  const source = purposeMatch?.[1] || text

  const paragraph = source
    .split(/\n\s*\n/)
    .map(part => part.replace(/\s+/g, ' ').trim())
    .find(Boolean)

  return paragraph || ''
}

function compactMarkdownForPrompt(markdown: string): string {
  const text = String(markdown || '').trim()
  if (!text) return ''

  const withoutFrontMatter = parseFrontMatter(text).body
  const compact = withoutFrontMatter
    .replace(/```[\s\S]*?```/g, match => {
      // Keep command examples short enough to remain useful, but avoid huge code blocks.
      return match.length > 600 ? match.slice(0, 600) + '\n```' : match
    })
    .trim()

  return compact.length > MAX_DETAILED_MD_CHARS
    ? compact.slice(0, MAX_DETAILED_MD_CHARS) + '\n…'
    : compact
}

async function exists(FileManager: any, path: string): Promise<boolean> {
  try {
    if (FileManager.exists) return !!(await FileManager.exists(path))
    if (FileManager.existsSync) return !!FileManager.existsSync(path)
  } catch {
    return false
  }
  return false
}

async function readDirectory(FileManager: any, path: string): Promise<string[]> {
  try {
    if (FileManager.readDirectory) return (await FileManager.readDirectory(path, false)) || []
    if (FileManager.readDirectorySync) return FileManager.readDirectorySync(path, false) || []
  } catch {
    return []
  }
  return []
}

async function readText(FileManager: any, path: string): Promise<string> {
  if (FileManager.readAsString) return String(await FileManager.readAsString(path))
  if (FileManager.readAsStringSync) return String(FileManager.readAsStringSync(path))
  throw new Error('FileManager.readAsString is not available.')
}

async function isDirectoryPath(FileManager: any, path: string): Promise<boolean> {
  try {
    if (FileManager.isDirectory) return !!(await FileManager.isDirectory(path))
    if (FileManager.isDirectorySync) return !!FileManager.isDirectorySync(path)
    const stat = FileManager.stat ? await FileManager.stat(path) : FileManager.statSync?.(path)
    return stat?.type === 'directory'
  } catch {
    return false
  }
}

function parseJsonObject(value: unknown): Record<string, unknown> {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as Record<string, unknown>
  }

  const raw = String(value || '').trim()
  if (!raw) return {}

  try {
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? parsed as Record<string, unknown>
      : {}
  } catch {
    return {}
  }
}

function shellSingleQuote(value: string): string {
  return `'${String(value).replace(/'/g, `'\\''`)}'`
}

function toToolName(value: string): string {
  return String(value || '')
    .trim()
    .replace(/[^A-Za-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
}

function normalizeActionName(value: string): string {
  return String(value || '')
    .trim()
    .replace(/\.tsx?$/i, '')
    .replace(/^scripts\//i, '')
    .replace(/[^A-Za-z0-9_-]+/g, '_')
}

function prettifyName(value: string): string {
  return String(value || '')
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase())
}

function camelCase(value: string): string {
  return String(value || '')
    .split(/[-_\s]+/g)
    .filter(Boolean)
    .map((part, index) => index === 0
      ? part.toLowerCase()
      : part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()
    )
    .join('')
}

function stringValue(value: unknown): string {
  return typeof value === 'string' ? value.trim() : ''
}

function firstNonEmpty(...values: unknown[]): string {
  for (const value of values) {
    const text = String(value || '').trim()
    if (text) return text
  }
  return ''
}

function joinPath(...parts: string[]): string {
  const cleaned = parts
    .filter(Boolean)
    .map((part, index) => {
      const value = String(part)
      if (index === 0) return value.replace(/\/+$/g, '')
      return value.replace(/^\/+|\/+$/g, '')
    })
    .filter(Boolean)

  return cleaned.join('/')
}

function basename(path: string): string {
  const normalized = String(path || '').replace(/\/+$/g, '')
  const index = normalized.lastIndexOf('/')
  return index >= 0 ? normalized.slice(index + 1) : normalized
}

function dirname(path: string): string {
  const normalized = String(path || '').replace(/\/+$/g, '')
  const index = normalized.lastIndexOf('/')
  return index >= 0 ? normalized.slice(0, index) : ''
}

function isAbsolutePath(path: string): boolean {
  return path.startsWith('/') || /^[A-Za-z]:[\\/]/.test(path)
}

function normalizeOptionalPath(value: unknown): string {
  const path = String(value || '').trim()
  return path && path !== 'undefined' && path !== 'null' ? path : ''
}

function normalizePath(value: string): string {
  return String(value || '').replace(/\/+$/g, '')
}

function uniqueStrings(values: string[]): string[] {
  return Array.from(new Set(values.map(value => String(value || '').trim()).filter(Boolean)))
}

function logExternalSkillDiscovery(definitions: ExternalSkillDefinition[]): void {
  try {
    const summary = definitions.map(definition => ({
      id: definition.id,
      displayName: definition.displayName,
      scriptCount: definition.scripts.length,
      actions: definition.scripts.map(script => script.action),
      directory: definition.directory,
    }))
    console.log('[External skills] discovered:', summary.length, summary)
  } catch (err) {
    console.log('[External skills] discovery logging failed:', err)
  }
}

function getGlobal(name: string): any {
  return (globalThis as any)[name]
}
