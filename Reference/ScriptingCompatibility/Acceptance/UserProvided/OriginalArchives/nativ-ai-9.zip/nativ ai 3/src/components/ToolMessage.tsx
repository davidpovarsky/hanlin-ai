import {
  Button,
  HStack,
  Image,
  Spacer,
  Text,
  VStack,
  useObservable,
} from 'scripting'
import { ToolPayload } from '../types/chat'
import { Strings, isRTL } from '../l10n'
import { getAgentToolCard } from '../tools'

type Props = {
  payload: ToolPayload
  strings: Strings
  locale: string
}

export function ToolMessage({ payload, strings, locale }: Props) {
  const Card = getAgentToolCard(payload.kind)
  const expanded = useObservable(true)
  const rtl = isRTL(locale)
  const align = rtl ? 'trailing' : 'leading'
  const title = getToolCardTitle(payload.kind, strings)
  const chevron = expanded.value ? 'chevron.down' : (rtl ? 'chevron.left' : 'chevron.right')

  if (!Card) {
    return <VStack />
  }

  return (
    <VStack
      alignment={align}
      spacing={8}
      frame={{ maxWidth: 'infinity', alignment: align }}
      padding={{ horizontal: 12, vertical: 10 }}
      background="secondarySystemBackground"
      clipShape={{ type: 'rect', cornerRadius: 12 }}
    >
      <Button
        action={() => expanded.setValue(!expanded.value)}
        buttonStyle="plain"
      >
        <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment: align }}>
          <Image
            systemName="rectangle.on.rectangle.angled"
            foregroundStyle="secondaryLabel"
            imageScale="small"
          />
          <Text font="caption" foregroundStyle="label" multilineTextAlignment={align}>
            {title}
          </Text>
          <Spacer />
          <Image
            systemName={chevron}
            foregroundStyle="tertiaryLabel"
            imageScale="small"
          />
        </HStack>
      </Button>

      {expanded.value ? (
        <Card data={payload.data as any} strings={strings} locale={locale} />
      ) : null}
    </VStack>
  )
}

function getToolCardTitle(kind: string, strings: Strings): string {
  const key = String(kind || '').trim()
  const localized = (strings as any)[key]
  if (typeof localized === 'string' && localized.trim()) return localized
  return key
    .replace(/[-_]/g, ' ')
    .replace(/\b\w/g, letter => letter.toUpperCase())
}
