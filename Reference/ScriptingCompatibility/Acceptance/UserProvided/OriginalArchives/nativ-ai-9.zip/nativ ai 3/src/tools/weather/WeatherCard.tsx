import { HStack, Image, Spacer, Text, VStack } from 'scripting'
import { WeatherDisplayData } from '../../types/chat'
import { Strings, isRTL } from '../../l10n'
import { ToolCardFrame, ToolHeader, SoftPanel, ToolPill } from '../nativeToolUI'

type Props = {
  data: WeatherDisplayData
  strings: Strings
  locale?: string
}

export function WeatherCard({ data, strings, locale }: Props) {
  const rtl = isRTL(locale || '')
  const align = rtl ? 'trailing' : 'leading'

  return (
    <ToolCardFrame alignment={align}>
      <ToolHeader
        title={data.locationName || strings.currentWeather}
        subtitle={data.condition}
        icon={data.symbolName || 'cloud.sun'}
        accent="systemBlue"
        alignment={align}
      />

      <SoftPanel alignment={align} spacing={12} padding={14} fill="secondarySystemGroupedBackground">
        <HStack spacing={12} frame={{ maxWidth: 'infinity', alignment: align }}>
          <VStack alignment={align} spacing={2}>
            <Text font={{ size: 46, weight: 'bold' }} foregroundStyle="label" lineLimit={1}>
              {data.temperature}
            </Text>
            <Text font="subheadline" foregroundStyle="secondaryLabel" multilineTextAlignment={align}>
              {data.condition}
            </Text>
          </VStack>
          <Spacer />
          <Image
            systemName={data.symbolName || 'cloud.sun'}
            foregroundStyle="systemBlue"
            font={{ size: 42, weight: 'semibold' }}
          />
        </HStack>

        <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment: align }}>
          <ToolPill icon="thermometer.medium" text={`${strings.feelsLike}: ${data.feelsLike}`} color="systemOrange" />
          <ToolPill icon="humidity" text={`${strings.humidity}: ${data.humidity}%`} color="systemBlue" />
          <ToolPill icon="wind" text={`${strings.wind}: ${data.windSpeed}`} color="secondaryLabel" />
        </HStack>
      </SoftPanel>
    </ToolCardFrame>
  )
}
