// Pure JS - shapes reminder data into display model.
// No platform imports.

import { ReminderIntentParams } from '../../types/intents'
import { ReminderDisplayData } from '../../types/chat'

export function buildPendingReminderDisplay(
  params: ReminderIntentParams
): ReminderDisplayData {
  return {
    title: params.title,
    notes: params.notes,
    dueDateISO: params.dueDateISO,
    priority: params.priority,
    status: 'pending',
    errorMessage: null,
  }
}

export function markReminderCreated(
  current: ReminderDisplayData
): ReminderDisplayData {
  return { ...current, status: 'created', errorMessage: null }
}

export function markReminderFailed(
  current: ReminderDisplayData,
  message: string
): ReminderDisplayData {
  return { ...current, status: 'failed', errorMessage: message }
}
