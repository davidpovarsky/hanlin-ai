export type ChatBackgroundId =
  | 'default'
  | 'mist'
  | 'dawn'
  | 'sage'
  | 'lilac'
  | 'night'
  | 'customPhoto'

export const CHAT_BACKGROUND_STORAGE_KEY = 'app.chatBackground'
export const CHAT_BACKGROUND_PHOTO_PATH_STORAGE_KEY = 'app.chatBackground.photoPath'
export const DEFAULT_CHAT_BACKGROUND_ID: ChatBackgroundId = 'default'

export type ChatBackgroundOption = {
  id: ChatBackgroundId
  labelKey: string
}

export const CHAT_BACKGROUND_OPTIONS: ChatBackgroundOption[] = [
  { id: 'default', labelKey: 'chatBackgroundDefault' },
  { id: 'mist', labelKey: 'chatBackgroundMist' },
  { id: 'dawn', labelKey: 'chatBackgroundDawn' },
  { id: 'sage', labelKey: 'chatBackgroundSage' },
  { id: 'lilac', labelKey: 'chatBackgroundLilac' },
  { id: 'night', labelKey: 'chatBackgroundNight' },
]

const CHAT_BACKGROUND_IDS: ChatBackgroundId[] = [
  ...CHAT_BACKGROUND_OPTIONS.map(option => option.id),
  'customPhoto',
]

export function isChatBackgroundId(value: string | null | undefined): value is ChatBackgroundId {
  return typeof value === 'string' && (CHAT_BACKGROUND_IDS as string[]).includes(value)
}

export function shouldHideChatScrollBackground(id: ChatBackgroundId): boolean {
  return id !== 'default'
}

export function getChatBackgroundStyle(id: ChatBackgroundId) {
  switch (id) {
    case 'mist':
      return dynamicLinearGradient(
        ['#F8FAFD', '#EEF3F8', '#F8FAFD'],
        ['#111821', '#172232', '#10151D']
      )
    case 'dawn':
      return dynamicLinearGradient(
        ['#FFF9F2', '#F7EEE6', '#FDF8F2'],
        ['#1D1715', '#281F1A', '#161311']
      )
    case 'sage':
      return dynamicLinearGradient(
        ['#F6FAF6', '#EDF5EF', '#F9FBF8'],
        ['#111A16', '#18251D', '#101610']
      )
    case 'lilac':
      return dynamicLinearGradient(
        ['#FAF8FF', '#F1EEFA', '#FAF9FD'],
        ['#171421', '#221D31', '#121018']
      )
    case 'night':
      return dynamicLinearGradient(
        ['#F8FAFD', '#EEF3F8', '#F7F9FC'],
        ['#090D14', '#101827', '#070A10']
      )
    case 'customPhoto':
      return 'clear'
    case 'default':
    default:
      return 'systemBackground'
  }
}

function dynamicLinearGradient(lightColors: string[], darkColors: string[]) {
  return {
    light: linearGradient(lightColors),
    dark: linearGradient(darkColors),
  }
}

function linearGradient(colors: string[]) {
  const lastIndex = Math.max(1, colors.length - 1)

  return {
    gradient: colors.map((color, index) => ({
      color,
      location: index / lastIndex,
    })),
    startPoint: { x: 0, y: 0 },
    endPoint: { x: 1, y: 1 },
  }
}
