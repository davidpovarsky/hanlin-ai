import { fetch } from 'scripting'

export type WikiSummary = {
  title: string
  extract: string
  pageUrl: string | null
  thumbnailUrl: string | null
}

const USER_AGENT = 'AIAgentApp/1.0 (scripting)'

function getWikiBase(language: string): string {
  // Wikipedia provides language-specific REST endpoints.
  const lang = (language || 'en').toLowerCase()
  const safeLang = /^[a-z\-]{2,10}$/.test(lang) ? lang : 'en'
  return `https://${safeLang}.wikipedia.org/api/rest_v1`
}

export async function fetchWikiSummary(
  query: string,
  language: string
): Promise<WikiSummary | null> {
  if (!query || !query.trim()) return null

  const base = getWikiBase(language)
  const encoded = encodeURIComponent(query.trim().replace(/\s+/g, '_'))
  const url = `${base}/page/summary/${encoded}`

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'User-Agent': USER_AGENT,
      },
    })

    if (!response.ok) {
      return null
    }

    const data = await response.json() as Record<string, unknown>

    // Some pages return a "disambiguation" or "no extract" type; we treat those as no result.
    if (data && typeof data === 'object' && (data as { type?: string }).type === 'disambiguation') {
      return {
        title: String((data as { title?: string }).title ?? query),
        extract: String((data as { extract?: string }).extract ?? ''),
        pageUrl: extractPageUrl(data),
        thumbnailUrl: extractThumbnail(data),
      }
    }

    const extract = String((data as { extract?: string }).extract ?? '').trim()
    if (!extract) return null

    return {
      title: String((data as { title?: string }).title ?? query),
      extract,
      pageUrl: extractPageUrl(data),
      thumbnailUrl: extractThumbnail(data),
    }
  } catch {
    return null
  }
}

function extractPageUrl(data: Record<string, unknown>): string | null {
  const contentUrls = data['content_urls'] as Record<string, unknown> | undefined
  if (!contentUrls) return null
  const desktop = contentUrls['desktop'] as Record<string, unknown> | undefined
  if (desktop && typeof desktop['page'] === 'string') return desktop['page'] as string
  const mobile = contentUrls['mobile'] as Record<string, unknown> | undefined
  if (mobile && typeof mobile['page'] === 'string') return mobile['page'] as string
  return null
}

function extractThumbnail(data: Record<string, unknown>): string | null {
  const thumb = data['thumbnail'] as Record<string, unknown> | undefined
  if (thumb && typeof thumb['source'] === 'string') return thumb['source'] as string
  return null
}
