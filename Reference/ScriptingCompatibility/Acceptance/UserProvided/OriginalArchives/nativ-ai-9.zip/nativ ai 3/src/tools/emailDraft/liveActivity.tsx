import type { AgentToolLiveActivityComponent } from '../types'
import { ToolMiniLiveActivityView, firstString } from '../liveActivity/shared'

export const EmailDraftLiveActivity: AgentToolLiveActivityComponent = ({ payload, tool, region, data }) => {
  const recipient = firstString(data?.recipientName, data?.toEmail, tool.params?.recipientName, tool.params?.toEmail)
  const subject = firstString(data?.subject, tool.params?.subject)
  const detail = subject || firstString(data?.body, tool.params?.request) || tool.action || null

  return (
    <ToolMiniLiveActivityView
      payload={payload}
      tool={tool}
      region={region}
      icon="envelope.badge.fill"
      accent="systemBlue"
      title={recipient || tool.displayName}
      subtitle={payload.subtitle}
      detail={detail}
    />
  )
}
