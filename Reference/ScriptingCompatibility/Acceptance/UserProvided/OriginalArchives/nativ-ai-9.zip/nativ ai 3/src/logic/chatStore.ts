import { Path } from 'scripting'
import { ChatMessage, ChatSession } from '../types/chat'

const CHAT_DATABASE_FILE = 'ai-agent-chat-history.sqlite'
const CHAT_SESSIONS_TABLE = 'chat_sessions'

export const CHAT_HISTORY_PAGE_SIZE = 15

export type ChatHistoryPageOptions = {
  query?: string
  limit?: number
  offset?: number
}

type ChatSessionRow = {
  id: string
  title: string
  created_at: number
  updated_at: number
  is_favorite: number
  title_manually_edited: number
  messages_json: string
}

type DatabaseLike = {
  execute: (sql: string, args?: unknown[] | Record<string, unknown>) => Promise<void>
  fetchAll: <T>(sql: string, args?: unknown[] | Record<string, unknown>) => Promise<T[]>
}

let databasePromise: Promise<DatabaseLike> | null = null

export async function saveChatSessionToDatabase(session: ChatSession): Promise<void> {
  const db = await getDatabase()
  const updatedAt = session.updatedAt ?? Date.now()
  const titleManuallyEdited = session.titleManuallyEdited === true ? 1 : 0
  const isFavorite = typeof session.isFavorite === 'boolean'
    ? session.isFavorite ? 1 : 0
    : null

  await db.execute(
    `INSERT INTO ${CHAT_SESSIONS_TABLE} (
      id,
      title,
      created_at,
      updated_at,
      is_favorite,
      title_manually_edited,
      messages_json,
      search_text
    ) VALUES (
      :id,
      :title,
      :createdAt,
      :updatedAt,
      COALESCE(:isFavorite, 0),
      :titleManuallyEdited,
      :messagesJson,
      :searchText
    )
    ON CONFLICT(id) DO UPDATE SET
      title = CASE
        WHEN ${CHAT_SESSIONS_TABLE}.title_manually_edited = 1 THEN ${CHAT_SESSIONS_TABLE}.title
        ELSE excluded.title
      END,
      updated_at = excluded.updated_at,
      is_favorite = COALESCE(:isFavorite, ${CHAT_SESSIONS_TABLE}.is_favorite),
      title_manually_edited = CASE
        WHEN ${CHAT_SESSIONS_TABLE}.title_manually_edited = 1 THEN 1
        ELSE excluded.title_manually_edited
      END,
      messages_json = excluded.messages_json,
      search_text = excluded.search_text`,
    {
      id: session.id,
      title: session.title,
      createdAt: session.createdAt,
      updatedAt,
      isFavorite,
      titleManuallyEdited,
      messagesJson: JSON.stringify(session.messages || []),
      searchText: buildSessionSearchText(session),
    }
  )
}

export async function saveManyChatSessionsToDatabase(sessions: ChatSession[]): Promise<void> {
  for (const session of sessions) {
    await saveChatSessionToDatabase({
      ...session,
      updatedAt: session.updatedAt ?? session.createdAt,
      isFavorite: session.isFavorite ?? false,
    })
  }
}

export async function fetchFavoriteChatSessions(query: string = ''): Promise<ChatSession[]> {
  const db = await getDatabase()
  const args: unknown[] = []
  const searchClause = buildSearchClause(query, args)
  const rows = await db.fetchAll<ChatSessionRow>(
    `SELECT id, title, created_at, updated_at, is_favorite, title_manually_edited, messages_json
     FROM ${CHAT_SESSIONS_TABLE}
     WHERE is_favorite = 1${searchClause}
     ORDER BY updated_at DESC, created_at DESC`,
    args
  )
  return rows.map(rowToSession)
}

export async function fetchRecentChatSessions({
  query = '',
  limit = CHAT_HISTORY_PAGE_SIZE,
  offset = 0,
}: ChatHistoryPageOptions = {}): Promise<ChatSession[]> {
  const db = await getDatabase()
  const args: unknown[] = []
  const searchClause = buildSearchClause(query, args)
  args.push(limit, offset)

  const rows = await db.fetchAll<ChatSessionRow>(
    `SELECT id, title, created_at, updated_at, is_favorite, title_manually_edited, messages_json
     FROM ${CHAT_SESSIONS_TABLE}
     WHERE is_favorite = 0${searchClause}
     ORDER BY updated_at DESC, created_at DESC
     LIMIT ? OFFSET ?`,
    args
  )
  return rows.map(rowToSession)
}

export async function fetchChatSessionById(sessionId: string): Promise<ChatSession | null> {
  const db = await getDatabase()
  const rows = await db.fetchAll<ChatSessionRow>(
    `SELECT id, title, created_at, updated_at, is_favorite, title_manually_edited, messages_json
     FROM ${CHAT_SESSIONS_TABLE}
     WHERE id = ?
     LIMIT 1`,
    [sessionId]
  )
  return rows[0] ? rowToSession(rows[0]) : null
}

export async function deleteChatSessionFromDatabase(sessionId: string): Promise<void> {
  const db = await getDatabase()
  await db.execute(`DELETE FROM ${CHAT_SESSIONS_TABLE} WHERE id = ?`, [sessionId])
}

export async function setChatSessionFavoriteInDatabase(sessionId: string, isFavorite: boolean): Promise<void> {
  const db = await getDatabase()
  await db.execute(
    `UPDATE ${CHAT_SESSIONS_TABLE}
     SET is_favorite = ?, updated_at = ?
     WHERE id = ?`,
    [isFavorite ? 1 : 0, Date.now(), sessionId]
  )
}

export async function renameChatSessionInDatabase(sessionId: string, title: string): Promise<void> {
  const db = await getDatabase()
  await db.execute(
    `UPDATE ${CHAT_SESSIONS_TABLE}
     SET title = ?, title_manually_edited = 1, updated_at = ?, search_text = ? || ' ' || search_text
     WHERE id = ?`,
    [title, Date.now(), title, sessionId]
  )
}

async function getDatabase(): Promise<DatabaseLike> {
  if (!databasePromise) {
    databasePromise = openAndPrepareDatabase()
  }
  return databasePromise
}

async function openAndPrepareDatabase(): Promise<DatabaseLike> {
  const dbPath = Path.join(FileManager.appGroupDocumentsDirectory, CHAT_DATABASE_FILE)
  const db = SQLite.open(dbPath, {
    foreignKeysEnabled: true,
    journalMode: 'wal',
    busyMode: 5,
    maximumReaderCount: 4,
    label: 'ai-agent-chat-history',
  }) as DatabaseLike

  await db.execute(
    `CREATE TABLE IF NOT EXISTS ${CHAT_SESSIONS_TABLE} (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      is_favorite INTEGER NOT NULL DEFAULT 0,
      title_manually_edited INTEGER NOT NULL DEFAULT 0,
      messages_json TEXT NOT NULL,
      search_text TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_chat_sessions_updated
      ON ${CHAT_SESSIONS_TABLE}(updated_at DESC, created_at DESC);

    CREATE INDEX IF NOT EXISTS idx_chat_sessions_favorite
      ON ${CHAT_SESSIONS_TABLE}(is_favorite, updated_at DESC, created_at DESC);`
  )

  return db
}

function buildSearchClause(query: string, args: unknown[]): string {
  const normalized = query.trim().toLowerCase()
  if (!normalized) return ''
  args.push(`%${normalized}%`)
  return ' AND lower(search_text) LIKE ?'
}

function rowToSession(row: ChatSessionRow): ChatSession {
  return {
    id: row.id,
    title: row.title,
    createdAt: Number(row.created_at),
    updatedAt: Number(row.updated_at),
    isFavorite: Number(row.is_favorite) === 1,
    titleManuallyEdited: Number(row.title_manually_edited) === 1,
    messages: safeParseMessages(row.messages_json),
  }
}

function safeParseMessages(value: string): ChatMessage[] {
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed as ChatMessage[] : []
  } catch {
    return []
  }
}

function buildSessionSearchText(session: ChatSession): string {
  const parts: string[] = [session.title]
  for (const message of session.messages || []) {
    collectMessageSearchText(message, parts)
  }
  return parts.join(' ').replace(/\s+/g, ' ').trim()
}

function collectMessageSearchText(message: ChatMessage, parts: string[]): void {
  if (message.text) parts.push(message.text)
  if (message.toolStatusText) parts.push(message.toolStatusText)
  for (const attachment of message.attachments || []) {
    parts.push(attachment.name)
  }
  for (const option of message.branchOptions || []) {
    parts.push(option.title)
    for (const branchMessage of option.messages || []) {
      collectMessageSearchText(branchMessage, parts)
    }
  }
}
