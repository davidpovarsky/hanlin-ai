import { LiveActivity } from 'scripting'
import { AgentChatLiveActivity } from '../../live_activity'
import { getAgentToolSpec } from '../tools'
import { getStrings } from '../l10n'
import { ToolPayload, ToolRunRecord } from '../types/chat'
import {
  AgentChatLiveActivityState,
  AgentLiveActivityPayload,
  AgentLiveActivityRunControl,
  AgentLiveActivitySessionHandle,
  AgentLiveActivitySessionOptions,
  AgentLiveActivityToolState,
} from './types'

const THINKING_STATUS_MARKER = '__agent_thinking__'
const MIN_UPDATE_INTERVAL_MS = 700
const FINAL_DISMISS_SECONDS = 12
const ERROR_DISMISS_SECONDS = 18

export async function createAgentLiveActivitySession(
  options: AgentLiveActivitySessionOptions
): Promise<AgentLiveActivitySessionHandle | null> {
  if (!options.enabled) return null

  try {
    const enabled = await LiveActivity.areActivitiesEnabled()
    if (!enabled) return null
  } catch {
    // Older/broken runtimes may throw while checking. Try to start anyway.
  }

  const session = new AgentLiveActivitySession(options)
  await session.start()
  return session
}

export function cancelRunLiveActivity(runControl: AgentLiveActivityRunControl | null | undefined): void {
  try {
    runControl?.liveActivity?.cancel()
  } catch {
    // Ignore Live Activity cleanup failures.
  }
}

class AgentLiveActivitySession implements AgentLiveActivitySessionHandle {
  private activity: any | null = null
  private payload: AgentLiveActivityPayload
  private started = false
  private closed = false
  private lastUpdateAt = 0
  private latestToolId: string | null = null
  private toolsUsed: string[] = []

  constructor(private readonly options: AgentLiveActivitySessionOptions) {
    const strings = getStrings(options.locale)
    this.payload = {
      phase: 'thinking',
      locale: options.locale,
      query: trimText(options.userText, 120),
      title: strings.appName,
      subtitle: strings.liveActivityAgentThinking || strings.thinking,
      detail: null,
      answerPreview: null,
      tool: null,
      toolPayload: null,
      toolsUsed: [],
      updatedAt: Date.now(),
    }
  }

  async start(): Promise<void> {
    if (this.started || this.closed) return

    try {
      this.activity = AgentChatLiveActivity()
      const ok = await this.activity.start(this.toState(), {
        staleDate: Date.now() + 10 * 60 * 1000,
        relevanceScore: 1,
      })
      this.started = ok !== false
      this.lastUpdateAt = Date.now()
    } catch (error) {
      this.closed = true
      this.started = false
      console.log('[Live Activity] failed to start:', String(error))
    }
  }

  setThinking(statusText?: string | null): void {
    if (this.closed) return
    const strings = getStrings(this.options.locale)
    const status = normalizeStatusText(statusText, strings.liveActivityAgentThinking || strings.thinking)

    this.payload = {
      ...this.payload,
      phase: 'thinking',
      title: strings.appName,
      subtitle: status,
      detail: null,
      tool: null,
      updatedAt: Date.now(),
    }
    this.update(false)
  }

  setToolStart(run: ToolRunRecord): void {
    if (this.closed) return
    const strings = getStrings(this.options.locale)
    const toolState = buildToolState(run)
    this.latestToolId = run.id
    this.addToolUsed(toolState.displayName || toolState.name)

    this.payload = {
      ...this.payload,
      phase: 'tool',
      title: toolState.displayName,
      subtitle: strings.liveActivityRunningTool,
      detail: toolState.action || null,
      tool: toolState,
      updatedAt: Date.now(),
    }
    this.update(true)
  }

  setToolFinish(runId: string, patch: Partial<ToolRunRecord>): void {
    if (this.closed) return
    const current = this.payload.tool
    if (!current || current.id !== runId) return
    const strings = getStrings(this.options.locale)
    const nextTool: AgentLiveActivityToolState = {
      ...current,
      status: patch.status || current.status,
      finishedAt: patch.finishedAt ?? current.finishedAt ?? Date.now(),
      response: patch.response !== undefined ? patch.response : current.response,
      errorMessage: patch.errorMessage ?? current.errorMessage ?? null,
      payloadKind: patch.payloadKind ?? current.payloadKind ?? null,
    }

    this.payload = {
      ...this.payload,
      phase: 'tool',
      title: nextTool.displayName,
      subtitle: nextTool.status === 'success'
        ? strings.liveActivityToolCompleted
        : nextTool.status === 'error'
          ? (nextTool.errorMessage || strings.liveActivityToolFailed)
          : strings.liveActivityRunningTool,
      detail: nextTool.action || null,
      tool: nextTool,
      updatedAt: Date.now(),
    }
    this.update(true)
  }

  setToolPayload(payload: ToolPayload | null): void {
    if (this.closed || !payload) return
    const current = this.payload.tool
    const nextTool = current
      ? {
          ...current,
          payloadKind: payload.kind,
          data: payload.data,
        }
      : null

    this.payload = {
      ...this.payload,
      tool: nextTool,
      toolPayload: payload,
      updatedAt: Date.now(),
    }
    this.update(true)
  }

  setAnswerPreview(text: string): void {
    if (this.closed) return
    const preview = trimText(text, 180)
    if (!preview) return

    this.payload = {
      ...this.payload,
      answerPreview: preview,
      updatedAt: Date.now(),
    }
    this.update(false)
  }

  finish(answer: string): void {
    if (this.closed) return
    const strings = getStrings(this.options.locale)
    const preview = trimText(answer, 180)
    this.payload = {
      ...this.payload,
      phase: 'result',
      title: strings.liveActivityResponseReady || strings.done,
      subtitle: preview || strings.actionCompleted,
      detail: this.toolsUsed.length > 0 ? this.toolsUsed.slice(0, 3).join(' · ') : null,
      answerPreview: preview,
      tool: null,
      toolsUsed: [...this.toolsUsed],
      updatedAt: Date.now(),
    }
    this.end(FINAL_DISMISS_SECONDS)
  }

  fail(message: string): void {
    if (this.closed) return
    const strings = getStrings(this.options.locale)
    this.payload = {
      ...this.payload,
      phase: 'error',
      title: strings.error,
      subtitle: trimText(message, 180) || strings.unknownError,
      detail: null,
      updatedAt: Date.now(),
    }
    this.end(ERROR_DISMISS_SECONDS)
  }

  cancel(): void {
    if (this.closed) return
    const strings = getStrings(this.options.locale)
    this.payload = {
      ...this.payload,
      phase: 'cancelled',
      title: strings.stopResponse,
      subtitle: strings.actionCancelledBeforeTool,
      detail: null,
      updatedAt: Date.now(),
    }
    this.end(0)
  }

  private update(force: boolean): void {
    if (!this.started || this.closed || !this.activity) return
    const now = Date.now()
    if (!force && now - this.lastUpdateAt < MIN_UPDATE_INTERVAL_MS) return
    this.lastUpdateAt = now

    try {
      this.activity.update(this.toState(), {
        staleDate: Date.now() + 10 * 60 * 1000,
        relevanceScore: 1,
      })
    } catch (error) {
      console.log('[Live Activity] update failed:', String(error))
    }
  }

  private end(dismissTimeInterval: number): void {
    if (!this.started || this.closed || !this.activity) {
      this.closed = true
      return
    }

    this.closed = true
    try {
      this.activity.end(this.toState(), {
        dismissTimeInterval,
        relevanceScore: 1,
      })
    } catch (error) {
      console.log('[Live Activity] end failed:', String(error))
    }
  }

  private toState(): AgentChatLiveActivityState {
    return {
      payload: this.payload,
      updatedAt: Date.now(),
    }
  }

  private addToolUsed(name: string): void {
    const clean = name.trim()
    if (!clean || this.toolsUsed.includes(clean)) return
    this.toolsUsed.push(clean)
  }
}

function buildToolState(run: ToolRunRecord): AgentLiveActivityToolState {
  const spec = getAgentToolSpec(run.tool)
  const displayName = spec?.publicName || readableToolName(run.tool)
  return {
    id: run.id,
    name: run.tool,
    displayName,
    action: run.action || null,
    status: run.status,
    startedAt: run.startedAt,
    finishedAt: run.finishedAt || null,
    params: run.params,
    response: run.response,
    errorMessage: run.errorMessage || null,
    payloadKind: run.payloadKind || null,
  }
}

function readableToolName(value: string): string {
  const text = String(value || '').trim()
  if (!text) return 'Tool'
  return text
    .replace(/[-_]+/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase())
}

function normalizeStatusText(text: string | null | undefined, fallback: string): string {
  const clean = String(text || '').trim()
  if (!clean || clean === THINKING_STATUS_MARKER) return fallback
  return trimText(clean, 140)
}

function trimText(text: string, maxLength: number): string {
  const normalized = String(text || '').replace(/\s+/g, ' ').trim()
  if (normalized.length <= maxLength) return normalized
  return `${normalized.slice(0, Math.max(0, maxLength - 3))}...`
}
