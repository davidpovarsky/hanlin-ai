import type { AgentToolLiveActivityComponent } from '../types'
import { ToolMiniLiveActivityView, firstString } from '../liveActivity/shared'

export const ReminderLiveActivity: AgentToolLiveActivityComponent = ({ payload, tool, region, data }) => {
  const title = firstString(data?.title, tool.params?.title) || tool.displayName
  const due = firstString(data?.dueDateISO, tool.params?.dueDateISO)
  const notes = firstString(data?.notes, tool.params?.notes)
  const detail = due || notes || tool.action || null

  return (
    <ToolMiniLiveActivityView
      payload={payload}
      tool={tool}
      region={region}
      icon="bell.badge.fill"
      accent="systemPink"
      title={title}
      subtitle={payload.subtitle}
      detail={detail}
    />
  )
}
