// src/tools/cityInfo/buildCityInfoDisplay.ts
// Pure JS - shapes Wikipedia data into the display model.
// No platform imports.

import { CityInfoDisplayData } from '../../types/chat'
import { WikiSummary } from '../../logic/apiClients/wikiClient'

export function buildCityInfoDisplay(
  query: string,
  summary: WikiSummary | null
): CityInfoDisplayData | null {
  if (!summary) return null

  return {
    title: summary.title || query,
    summary: truncateExtract(summary.extract, 700),
    pageUrl: summary.pageUrl,
    thumbnailUrl: summary.thumbnailUrl,
  }
}

function truncateExtract(text: string, maxLen: number): string {
  if (!text) return ''
  if (text.length <= maxLen) return text

  const slice = text.slice(0, maxLen)

  // Try common sentence boundaries across English/Hebrew and similar scripts.
  const boundaries = ['.', '!', '?', ':', '۔', '。']
  let best = -1
  for (const boundary of boundaries) {
    best = Math.max(best, slice.lastIndexOf(boundary))
  }

  if (best > maxLen * 0.55) {
    return slice.slice(0, best + 1)
  }

  return slice.trimEnd() + '…'
}
