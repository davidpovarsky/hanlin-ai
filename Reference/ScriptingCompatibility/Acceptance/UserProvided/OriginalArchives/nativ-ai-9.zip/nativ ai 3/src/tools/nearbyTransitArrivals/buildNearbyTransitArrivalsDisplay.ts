// src/tools/nearbyTransitArrivals/buildNearbyTransitArrivalsDisplay.ts
// Pure JS/TS - shapes nearby public transport arrival data into a compact display model.
// No platform imports.

export type NearbyTransitArrivalSource = 'realtime' | 'schedule'

export type NearbyTransitArrivalDisplayItem = {
  id: string
  minutes: number
  label: string
  source: NearbyTransitArrivalSource
  realtime: boolean
  stale: boolean
}

export type NearbyTransitLineDisplayGroup = {
  id: string
  line: string
  headsign: string
  firstArrivalMinutes: number | null
  arrivals: NearbyTransitArrivalDisplayItem[]
}

export type NearbyTransitStopDisplayItem = {
  id: string
  name: string
  stopCode: string
  distanceMeters: number | null
  distanceLabel: string
  groups: NearbyTransitLineDisplayGroup[]
  hasRealtime: boolean
  hasStaleRealtime: boolean
}

export type NearbyTransitArrivalsDisplayData = {
  title: string
  subtitle: string
  generatedAt: string
  generatedAtLabel: string
  location: {
    latitude: number
    longitude: number
    source: 'params' | 'device'
  } | null
  radiusMeters: number
  lookaheadMinutes: number
  stops: NearbyTransitStopDisplayItem[]
  warnings: string[]
  debugLog?: string[]
}

export type NearbyTransitRawArrival = {
  line: string | number
  headsign?: string | null
  minutes: number
  realtime?: boolean
  stale?: boolean
}

export type NearbyTransitRawLineGroup = {
  line: string | number
  headsign?: string | null
  arrivals?: NearbyTransitRawArrival[]
}

export type NearbyTransitRawStop = {
  stopCode: string | number
  name?: string | null
  distance?: number | null
  groups?: NearbyTransitRawLineGroup[]
}

export type NearbyTransitRawData = {
  generatedAt?: string
  location?: {
    latitude: number
    longitude: number
    source: 'params' | 'device'
  } | null
  radiusMeters: number
  lookaheadMinutes: number
  stops: NearbyTransitRawStop[]
  warnings?: string[]
  debugLog?: string[]
}

export function buildNearbyTransitArrivalsDisplay(
  raw: NearbyTransitRawData | null
): NearbyTransitArrivalsDisplayData | null {
  if (!raw) return null

  const generatedAt = raw.generatedAt || new Date().toISOString()
  const stops = (raw.stops || [])
    .map((stop, stopIndex) => buildStop(stop, stopIndex))
    .filter((stop): stop is NearbyTransitStopDisplayItem => stop != null)

  const warnings = Array.isArray(raw.warnings) ? raw.warnings.filter(Boolean) : []
  const radiusMeters = Math.max(1, Math.round(Number(raw.radiusMeters || 0)))
  const lookaheadMinutes = Math.max(1, Math.round(Number(raw.lookaheadMinutes || 0)))

  return {
    title: 'Nearby transit',
    subtitle: buildSubtitle(stops.length, radiusMeters, lookaheadMinutes),
    generatedAt,
    generatedAtLabel: formatGeneratedAt(generatedAt),
    location: raw.location || null,
    radiusMeters,
    lookaheadMinutes,
    stops,
    warnings,
    debugLog: Array.isArray(raw.debugLog) ? raw.debugLog.filter(Boolean) : [],
  }
}

function buildStop(
  stop: NearbyTransitRawStop,
  stopIndex: number
): NearbyTransitStopDisplayItem | null {
  const stopCode = cleanText(stop.stopCode)
  if (!stopCode) return null

  const groups = (stop.groups || [])
    .map((group, groupIndex) => buildGroup(group, stopCode, groupIndex))
    .filter((group): group is NearbyTransitLineDisplayGroup => group != null)
    .sort((a, b) => {
      const aMin = a.firstArrivalMinutes ?? Number.MAX_SAFE_INTEGER
      const bMin = b.firstArrivalMinutes ?? Number.MAX_SAFE_INTEGER
      if (aMin !== bMin) return aMin - bMin
      return compareLineNumbers(a.line, b.line)
    })

  const arrivals = groups.flatMap(group => group.arrivals)
  const hasRealtime = arrivals.some(arrival => arrival.realtime)
  const hasStaleRealtime = arrivals.some(arrival => arrival.stale)
  const distanceMeters = normalizeDistance(stop.distance)

  return {
    id: `stop_${stopCode}_${stopIndex}`,
    name: cleanText(stop.name) || 'Stop',
    stopCode,
    distanceMeters,
    distanceLabel: formatDistance(distanceMeters),
    groups,
    hasRealtime,
    hasStaleRealtime,
  }
}

function buildGroup(
  group: NearbyTransitRawLineGroup,
  stopCode: string,
  groupIndex: number
): NearbyTransitLineDisplayGroup | null {
  const line = cleanText(group.line)
  if (!line) return null

  const headsign = cleanText(group.headsign)
  const arrivals = (group.arrivals || [])
    .map((arrival, arrivalIndex) => buildArrival(arrival, stopCode, line, groupIndex, arrivalIndex))
    .filter((arrival): arrival is NearbyTransitArrivalDisplayItem => arrival != null)
    .sort((a, b) => a.minutes - b.minutes)
    .slice(0, 4)

  if (arrivals.length === 0) return null

  return {
    id: `line_${stopCode}_${line}_${hashText(headsign)}_${groupIndex}`,
    line,
    headsign,
    firstArrivalMinutes: arrivals[0]?.minutes ?? null,
    arrivals,
  }
}

function buildArrival(
  arrival: NearbyTransitRawArrival,
  stopCode: string,
  line: string,
  groupIndex: number,
  arrivalIndex: number
): NearbyTransitArrivalDisplayItem | null {
  const minutes = Math.round(Number(arrival.minutes))
  if (!Number.isFinite(minutes) || minutes < 0) return null

  const realtime = Boolean(arrival.realtime)
  const stale = Boolean(arrival.stale)

  return {
    id: `arrival_${stopCode}_${line}_${groupIndex}_${arrivalIndex}_${minutes}_${realtime ? 'rt' : 'sch'}`,
    minutes,
    label: formatMinutes(minutes),
    source: realtime ? 'realtime' : 'schedule',
    realtime,
    stale,
  }
}

function buildSubtitle(stopCount: number, radiusMeters: number, lookaheadMinutes: number): string {
  if (stopCount === 0) {
    return `No stops found within ${formatDistance(radiusMeters)}`
  }

  const stopWord = stopCount === 1 ? 'One stop' : `${stopCount} stops`
  return `${stopWord} within ${formatDistance(radiusMeters)} · ${lookaheadMinutes} min ahead`
}

function formatGeneratedAt(value: string): string {
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return ''

  return date.toLocaleTimeString('he-IL', {
    hour: '2-digit',
    minute: '2-digit',
  })
}

function formatMinutes(minutes: number): string {
  if (minutes <= 0) return 'Now'
  if (minutes === 1) return '1 min'
  return `${minutes} min`
}

function formatDistance(distanceMeters: number | null): string {
  if (distanceMeters == null) return ''
  if (distanceMeters < 1000) return `${Math.round(distanceMeters)} m`
  return `${(distanceMeters / 1000).toFixed(1)} km`
}

function normalizeDistance(value: unknown): number | null {
  const n = Math.round(Number(value))
  return Number.isFinite(n) && n >= 0 ? n : null
}

function compareLineNumbers(a: string, b: string): number {
  const an = Number(a)
  const bn = Number(b)
  if (Number.isFinite(an) && Number.isFinite(bn) && an !== bn) return an - bn
  return a.localeCompare(b, 'he')
}

function hashText(value: string): string {
  let hash = 0
  for (let i = 0; i < value.length; i++) {
    hash = ((hash << 5) - hash + value.charCodeAt(i)) | 0
  }
  return String(Math.abs(hash))
}

function cleanText(value: unknown): string {
  if (value == null) return ''
  return String(value).trim()
}
