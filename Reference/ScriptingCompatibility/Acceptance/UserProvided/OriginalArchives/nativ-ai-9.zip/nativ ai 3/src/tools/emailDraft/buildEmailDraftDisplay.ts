import { EmailDraftDisplayData } from '../../types/chat'

export type EmailDraftInput = {
  recipientName?: string | null
  toEmail?: string | null
  subject?: string | null
  body?: string | null
  request?: string | null
  tone?: string | null
}

export function buildEmailDraftDisplay(input: EmailDraftInput): EmailDraftDisplayData {
  return {
    recipientName: clean(input.recipientName),
    toEmail: clean(input.toEmail),
    subject: clean(input.subject),
    body: clean(input.body),
    request: clean(input.request),
    tone: clean(input.tone),
    status: 'draft',
    lastEditInstruction: null,
    errorMessage: null,
  }
}

export function markEmailDraftFailed(
  current: EmailDraftDisplayData,
  message: string
): EmailDraftDisplayData {
  return {
    ...current,
    status: 'failed',
    errorMessage: message,
  }
}

function clean(value: unknown): string {
  return typeof value === 'string' ? value.trim() : ''
}
