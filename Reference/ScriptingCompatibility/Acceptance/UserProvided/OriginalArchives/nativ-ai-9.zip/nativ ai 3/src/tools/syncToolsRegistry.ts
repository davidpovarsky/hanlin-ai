// src/tools/syncToolsRegistry.ts
//
// In-app registry synchronizer for Scripting.
//
// Scripting does not have a terminal/build step. This utility is intentionally
// callable from the Settings screen. It scans src/tools/* and rewrites only
// src/tools/index.ts with static imports for tool folders that follow the shared
// contract:
//   export const AGENT_TOOL_MODULE = { spec, run, Card }
//   export default AGENT_TOOL_MODULE
//
// After syncing, restart/rerun the script so Scripting reloads the new imports.

export type SyncToolsRegistrySkippedTool = {
  name: string
  reason: string
}

export type SyncToolsRegistryOptions = {
  /**
   * Absolute path of the currently running script project.
   * Passing Script.directory from the UI is the safest way to avoid matching
   * older imported copies of the same project in FileManager.scriptsDirectory.
   */
  projectRoot?: string | null
}

export type SyncToolsRegistryResult = {
  ok: true
  indexPath: string
  enabledTools: string[]
  skippedTools: SyncToolsRegistrySkippedTool[]
  message: string
}

export async function syncToolsRegistry(options: SyncToolsRegistryOptions = {}): Promise<SyncToolsRegistryResult> {
  const FileManager = getGlobal('FileManager')

  if (!FileManager?.readDirectory || !FileManager?.writeAsString) {
    throw new Error('FileManager.readDirectory/writeAsString is not available.')
  }

  const projectRoot = await resolveProjectRoot(FileManager, options.projectRoot)
  const toolsDir = joinPath(projectRoot, 'src/tools')
  const indexPath = joinPath(toolsDir, 'index.ts')

  const entries = await FileManager.readDirectory(toolsDir, false)
  const folders = await collectToolFolders(FileManager, toolsDir, entries)

  const enabledTools: string[] = []
  const skippedTools: SyncToolsRegistrySkippedTool[] = []

  for (const folder of folders) {
    const indexFile = joinPath(folder.path, 'index.ts')
    const toolJsonFile = joinPath(folder.path, 'tool.json')

    if (!(await exists(FileManager, toolJsonFile))) {
      skippedTools.push({ name: folder.name, reason: 'Missing tool.json.' })
      continue
    }

    if (!(await exists(FileManager, indexFile))) {
      skippedTools.push({ name: folder.name, reason: 'Missing index.ts.' })
      continue
    }

    const indexContent = await readText(FileManager, indexFile)
    if (!/AGENT_TOOL_MODULE/.test(indexContent)) {
      skippedTools.push({
        name: folder.name,
        reason: 'index.ts does not export AGENT_TOOL_MODULE yet.',
      })
      continue
    }

    if (!/export\s+default\s+AGENT_TOOL_MODULE/.test(indexContent)) {
      skippedTools.push({
        name: folder.name,
        reason: 'index.ts must also default-export AGENT_TOOL_MODULE.',
      })
      continue
    }

    enabledTools.push(folder.name)
  }

  enabledTools.sort((a, b) => a.localeCompare(b))

  const content = buildRegistrySource(enabledTools)
  await FileManager.writeAsString(indexPath, content)

  return {
    ok: true,
    indexPath,
    enabledTools,
    skippedTools,
    message: `Synced ${enabledTools.length} tool(s). Restart the script to load new imports.`,
  }
}

async function resolveProjectRoot(FileManager: any, projectRootHint?: string | null): Promise<string> {
  const hintedDirectory = normalizeOptionalPath(projectRootHint)
  if (hintedDirectory) {
    if (await looksLikeThisProject(FileManager, hintedDirectory)) {
      return hintedDirectory
    }

    // In a few environments a file path can be passed instead of the root folder.
    // Try its parent as a defensive fallback before giving up.
    const hintedParent = dirname(hintedDirectory)
    if (hintedParent && hintedParent !== hintedDirectory && await looksLikeThisProject(FileManager, hintedParent)) {
      return hintedParent
    }

    throw new Error(`Could not sync tools because the provided project path does not look like this script project: ${hintedDirectory}`)
  }

  const Script = getGlobal('Script')

  // Some Scripting versions/environments expose Script.directory, but it is not
  // guaranteed. Keep it as a fast path only; never require it.
  const directDirectory = normalizeOptionalPath(Script?.directory)
  if (directDirectory && await looksLikeThisProject(FileManager, directDirectory)) {
    return directDirectory
  }

  const scriptsDirectory = normalizeOptionalPath(FileManager?.scriptsDirectory)
  if (!scriptsDirectory) {
    throw new Error('FileManager.scriptsDirectory is not available.')
  }

  // Prefer an explicit script name when the runtime exposes one.
  for (const scriptName of getScriptNameCandidates(Script)) {
    const candidate = joinPath(scriptsDirectory, scriptName)
    if (await looksLikeThisProject(FileManager, candidate)) {
      return candidate
    }
  }

  // Final fallback: scan the scripts directory and pick the project that contains
  // this tool-sync file. This keeps the button usable even when Script.directory
  // and Script.name are unavailable.
  const entries = await FileManager.readDirectory(scriptsDirectory, false)
  const matches: string[] = []

  for (const rawEntry of entries || []) {
    const entry = String(rawEntry || '')
    if (!entry) continue

    const entryPath = isAbsolutePath(entry) ? entry : joinPath(scriptsDirectory, entry)
    if (!(await isDirectoryPath(FileManager, entryPath))) continue

    if (await looksLikeThisProject(FileManager, entryPath)) {
      matches.push(entryPath)
    }
  }

  if (matches.length === 1) {
    return matches[0]
  }

  if (matches.length > 1) {
    throw new Error(
      'Found more than one matching script project and could not determine the currently running project. Open Settings from the running app so Script.directory can be passed to syncToolsRegistry.'
    )
  }

  throw new Error(
    'Could not find the current script project under FileManager.scriptsDirectory.'
  )
}

async function looksLikeThisProject(FileManager: any, projectRoot: string): Promise<boolean> {
  if (!projectRoot) return false

  const requiredPaths = [
    joinPath(projectRoot, 'script.json'),
    joinPath(projectRoot, 'src/tools/index.ts'),
    joinPath(projectRoot, 'src/tools/syncToolsRegistry.ts'),
  ]

  for (const path of requiredPaths) {
    if (!(await exists(FileManager, path))) {
      return false
    }
  }

  return true
}

function getScriptNameCandidates(Script: any): string[] {
  const candidates = [
    Script?.name,
    Script?.scriptName,
    Script?.projectName,
    Script?.currentScriptName,
    Script?.current?.name,
    Script?.current?.scriptName,
  ]
    .map(value => String(value || '').trim())
    .filter(Boolean)

  return Array.from(new Set(candidates))
}

async function collectToolFolders(
  FileManager: any,
  toolsDir: string,
  entries: unknown[]
): Promise<Array<{ name: string; path: string }>> {
  const folders: Array<{ name: string; path: string }> = []

  for (const rawEntry of entries || []) {
    const entry = String(rawEntry || '')
    if (!entry) continue

    const name = basename(entry)
    if (!name || name.startsWith('.') || name === 'types.ts' || name === 'index.ts' || name === 'liveActivity') {
      continue
    }

    const entryPath = isAbsolutePath(entry) ? entry : joinPath(toolsDir, entry)
    const isDirectory = await isDirectoryPath(FileManager, entryPath)
    if (!isDirectory) continue

    folders.push({ name, path: entryPath })
  }

  folders.sort((a, b) => a.name.localeCompare(b.name))
  return folders
}

function buildRegistrySource(toolFolders: string[]): string {
  const importLines = toolFolders.map((folder, index) => {
    return `import toolModule${index} from ${JSON.stringify('./' + folder)}`
  })

  const moduleLines = toolFolders.map((_, index) => `  toolModule${index},`)

  return `// src/tools/index.ts
//
// Central registry for enabled agent tools.
//
// Native tools remain statically imported because they can provide rich in-app
// TSX cards and app-specific UI. External skills are discovered dynamically at
// runtime from iCloud Drive/Scripting/scripting-skills/* and exposed through the
// same AgentToolModule contract without requiring a project rebuild.

${importLines.join('\n')}
import {
  ensureExternalSkillModulesLoaded,
  refreshExternalSkillModules,
  getExternalSkillDefinitionsSnapshot,
} from './externalSkills'

export type {
  AgentToolCardComponent,
  AgentToolLiveActivityComponent,
  AgentToolExample,
  AgentToolModule,
  AgentToolParamSpec,
  AgentToolRunFailure,
  AgentToolRunResult,
  AgentToolRunSuccess,
  AgentToolRunner,
  AgentToolSpec,
  CompactAgentToolSpec,
} from './types'

export {
  ensureExternalSkillModulesLoaded,
  refreshExternalSkillModules,
  getExternalSkillDefinitionsSnapshot,
} from './externalSkills'

import type {
  AgentToolCardComponent,
  AgentToolLiveActivityComponent,
  AgentToolModule,
  AgentToolRunner,
  AgentToolSpec,
  CompactAgentToolSpec,
} from './types'

export const NATIVE_AGENT_TOOL_MODULES: AgentToolModule[] = [
${moduleLines.join('\n')}
]

export const AGENT_TOOL_MODULES: AgentToolModule[] = NATIVE_AGENT_TOOL_MODULES

export type AgentToolName = string

let runtimeToolModules: AgentToolModule[] = [...NATIVE_AGENT_TOOL_MODULES]
let toolModuleByName: Record<string, AgentToolModule> = buildToolModuleMap(runtimeToolModules)

export async function refreshAgentToolRegistry(): Promise<AgentToolModule[]> {
  const externalModules = await refreshExternalSkillModules()
  runtimeToolModules = mergeToolModules(NATIVE_AGENT_TOOL_MODULES, externalModules)
  toolModuleByName = buildToolModuleMap(runtimeToolModules)
  return runtimeToolModules
}

export async function ensureAgentToolRegistryLoaded(): Promise<AgentToolModule[]> {
  const externalModules = await ensureExternalSkillModulesLoaded()
  runtimeToolModules = mergeToolModules(NATIVE_AGENT_TOOL_MODULES, externalModules)
  toolModuleByName = buildToolModuleMap(runtimeToolModules)
  return runtimeToolModules
}

export function getAllAgentToolModules(): AgentToolModule[] {
  return runtimeToolModules
}

export function getAllAgentToolSpecs(): AgentToolSpec[] {
  return runtimeToolModules.map(module => module.spec)
}

export function getCompactAgentToolIndex(): CompactAgentToolSpec[] {
  return getAllAgentToolSpecs().map(tool => ({
    name: tool.name,
    publicName: tool.publicName,
    shortDescription: tool.shortDescription || tool.description,
    aliases: tool.aliases || [],
  }))
}

export function getAgentToolNames(): AgentToolName[] {
  return getAllAgentToolSpecs().map(tool => tool.name)
}

export const AGENT_TOOL_SPECS: AgentToolSpec[] =
  NATIVE_AGENT_TOOL_MODULES.map(module => module.spec)

export const COMPACT_AGENT_TOOL_INDEX: CompactAgentToolSpec[] =
  AGENT_TOOL_SPECS.map(tool => ({
    name: tool.name,
    publicName: tool.publicName,
    shortDescription: tool.shortDescription || tool.description,
    aliases: tool.aliases || [],
  }))

export const AGENT_TOOL_NAMES: AgentToolName[] =
  AGENT_TOOL_SPECS.map(tool => tool.name)

export function getAgentToolModule(name: string): AgentToolModule | null {
  return toolModuleByName[name] || null
}

export function getAgentToolSpec(name: string): AgentToolSpec | null {
  return getAgentToolModule(name)?.spec || null
}

export function getAgentToolRunner(name: string): AgentToolRunner | null {
  return getAgentToolModule(name)?.run || null
}

export function getAgentToolCard(name: string): AgentToolCardComponent | null {
  return getAgentToolModule(name)?.Card || null
}

export function getAgentToolLiveActivity(name: string): AgentToolLiveActivityComponent | null {
  return getAgentToolModule(name)?.LiveActivity || null
}

function mergeToolModules(
  nativeModules: AgentToolModule[],
  externalModules: AgentToolModule[]
): AgentToolModule[] {
  const merged: AgentToolModule[] = []
  const seen = new Set<string>()

  for (const module of [...nativeModules, ...externalModules]) {
    const name = module?.spec?.name
    if (!name || seen.has(name)) continue
    seen.add(name)
    merged.push(module)
  }

  return merged
}

function buildToolModuleMap(modules: AgentToolModule[]): Record<string, AgentToolModule> {
  return modules.reduce<Record<string, AgentToolModule>>((acc, module) => {
    if (module?.spec?.name) acc[module.spec.name] = module
    return acc
  }, {})
}
`
}

async function exists(FileManager: any, path: string): Promise<boolean> {
  if (FileManager.exists) return !!(await FileManager.exists(path))
  if (FileManager.existsSync) return !!FileManager.existsSync(path)
  return false
}

async function isDirectoryPath(FileManager: any, path: string): Promise<boolean> {
  if (FileManager.isDirectory) return !!(await FileManager.isDirectory(path))
  if (FileManager.isDirectorySync) return !!FileManager.isDirectorySync(path)

  try {
    const stat = FileManager.stat ? await FileManager.stat(path) : FileManager.statSync?.(path)
    return stat?.type === 'directory'
  } catch {
    return false
  }
}

async function readText(FileManager: any, path: string): Promise<string> {
  if (FileManager.readAsString) return String(await FileManager.readAsString(path))
  if (FileManager.readAsStringSync) return String(FileManager.readAsStringSync(path))
  throw new Error('FileManager.readAsString is not available.')
}

function joinPath(...parts: string[]): string {
  const cleaned = parts
    .filter(Boolean)
    .map((part, index) => {
      const value = String(part)
      if (index === 0) return value.replace(/\/+$/g, '')
      return value.replace(/^\/+|\/+$/g, '')
    })
    .filter(Boolean)

  return cleaned.join('/')
}

function basename(path: string): string {
  const normalized = String(path || '').replace(/\/+$/g, '')
  const index = normalized.lastIndexOf('/')
  return index >= 0 ? normalized.slice(index + 1) : normalized
}

function dirname(path: string): string {
  const normalized = String(path || '').replace(/\/+$/g, '')
  const index = normalized.lastIndexOf('/')
  return index > 0 ? normalized.slice(0, index) : normalized
}

function isAbsolutePath(path: string): boolean {
  return path.startsWith('/') || /^[A-Za-z]:[\\/]/.test(path)
}

function normalizeOptionalPath(value: unknown): string {
  const path = String(value || '').trim()
  return path && path !== 'undefined' && path !== 'null' ? path : ''
}

function getGlobal(name: string): any {
  return (globalThis as any)[name]
}
