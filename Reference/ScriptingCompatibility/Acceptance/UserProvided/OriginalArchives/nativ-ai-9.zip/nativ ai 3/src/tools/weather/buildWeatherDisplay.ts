// Pure JS - shapes raw weather data into a display-ready model.
// No platform imports. The platform-specific fetching lives in `runWeatherTool.ts`.

import { WeatherDisplayData } from '../../types/chat'

// Loose shape for what the platform returns - we keep this independent so the
// pure logic stays portable.
export type WeatherInput = {
  locationName: string
  temperatureFormatted: string
  apparentTemperatureFormatted: string
  conditionRaw: string
  humidity01: number // 0..1
  windSpeedFormatted: string
  symbolName: string
}

export function buildWeatherDisplay(input: WeatherInput): WeatherDisplayData {
  return {
    locationName: input.locationName || '',
    temperature: input.temperatureFormatted || '—',
    feelsLike: input.apparentTemperatureFormatted || '—',
    condition: prettifyCondition(input.conditionRaw),
    humidity: clampPercent(input.humidity01),
    windSpeed: input.windSpeedFormatted || '—',
    symbolName: input.symbolName || 'cloud.sun',
  }
}

function prettifyCondition(raw: string): string {
  if (!raw) return ''
  // The Weather API returns lower-camel/snake-ish strings ("clear", "partlyCloudy", "thunderstorms").
  // We split camelCase, capitalize words, and replace underscores with spaces.
  const spaced = String(raw)
    .replace(/_/g, ' ')
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .toLowerCase()
  return spaced.charAt(0).toUpperCase() + spaced.slice(1)
}

function clampPercent(value: number): number {
  if (!Number.isFinite(value)) return 0
  if (value <= 0) return 0
  if (value >= 1) return 100
  return Math.round(value * 100)
}
