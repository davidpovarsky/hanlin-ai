import { createContext, useContext, useReducer, useState, useMemo, useCallback, useEffect, useRef, VirtualNode, Device } from 'scripting'
import { Locale, getStrings, Strings, isRTL, detectDefaultLocale, isSupportedLocale } from '../l10n'
import { chatReducer, initialChatState, ChatState, ChatAction } from '../logic/chatReducer'
import { ChatMessage, ChatSession } from '../types/chat'
import { generateId } from '../utils/id'
import {
  CHAT_BACKGROUND_STORAGE_KEY,
  CHAT_BACKGROUND_PHOTO_PATH_STORAGE_KEY,
  ChatBackgroundId,
  DEFAULT_CHAT_BACKGROUND_ID,
  isChatBackgroundId,
} from '../theme/chatBackgrounds'
import {
  CHAT_HISTORY_PAGE_SIZE,
  deleteChatSessionFromDatabase,
  fetchChatSessionById,
  fetchFavoriteChatSessions,
  fetchRecentChatSessions,
  renameChatSessionInDatabase,
  saveChatSessionToDatabase,
  saveManyChatSessionsToDatabase,
  setChatSessionFavoriteInDatabase,
} from '../logic/chatStore'

const LOCALE_STORAGE_KEY = 'app.locale'
const AI_PROVIDER_STORAGE_KEY = 'app.aiProvider'
const CHAT_SESSIONS_STORAGE_KEY = 'app.chatSessions'
const CHAT_SESSIONS_MIGRATED_STORAGE_KEY = 'app.chatSessions.sqliteMigrated.v1'
const CHAT_SESSIONS_CACHE_LIMIT = 15

export type AIProvider = 'app_default' | 'openai' | 'gemini' | 'anthropic' | 'deepseek' | 'openrouter'

const AI_PROVIDER_VALUES: AIProvider[] = ['app_default', 'openai', 'gemini', 'anthropic', 'deepseek', 'openrouter']

type AppContextValue = {
  // Locale
  locale: Locale
  strings: Strings
  isRTLLayout: boolean
  setLocale: (next: Locale) => void

  // AI
  aiProvider: AIProvider
  setAIProvider: (next: AIProvider) => void

  // Appearance
  chatBackground: ChatBackgroundId
  chatBackgroundPhotoPath: string | null
  setChatBackground: (next: ChatBackgroundId) => void
  setChatBackgroundPhotoPath: (next: string | null) => void

  // Chat
  chat: ChatState
  dispatchChat: (action: ChatAction) => void

  // Chat History
  chatSessions: ChatSession[]
  currentSessionId: string
  chatHistorySearchQuery: string
  hasMoreChatSessions: boolean
  startNewChat: () => void
  loadChatSession: (sessionId: string) => Promise<void>
  deleteSession: (sessionId: string) => void
  renameSession: (sessionId: string, title: string) => void
  toggleFavoriteSession: (sessionId: string) => void
  setChatHistorySearchQuery: (query: string) => void
  loadMoreChatSessions: () => void
  saveCurrentSession: () => void

  // Re-reads locale and aiProvider from Storage (used after settings modal closes)
  refreshSettings: () => void
}

const AppContext = createContext<AppContextValue>()

export function useApp(): AppContextValue {
  return useContext(AppContext)
}

type Props = {
  children: VirtualNode
}

export function AppProvider({ children }: Props) {
  const [locale, setLocaleState] = useState<Locale>(() => readInitialLocale())
  const [aiProvider, setAIProviderState] = useState<AIProvider>(() => readInitialAIProvider())
  const [chatBackground, setChatBackgroundState] = useState<ChatBackgroundId>(() => readInitialChatBackground())
  const [chatBackgroundPhotoPath, setChatBackgroundPhotoPathState] = useState<string | null>(() => readInitialChatBackgroundPhotoPath())
  const [chat, dispatchChat] = useReducer(chatReducer, initialChatState)
  const [chatSessions, setChatSessions] = useState<ChatSession[]>(() => readInitialSessions().slice(0, CHAT_SESSIONS_CACHE_LIMIT))
  const [currentSessionId, setCurrentSessionId] = useState<string>(() => generateId('session'))
  const [chatHistorySearchQuery, setChatHistorySearchQueryState] = useState('')
  const [historyOffset, setHistoryOffset] = useState(CHAT_HISTORY_PAGE_SIZE)
  const [hasMoreChatSessions, setHasMoreChatSessions] = useState(false)
  const historyLoadRequestRef = useRef(0)
  const historyLoadingRef = useRef(false)

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next)
    try {
      Storage.set(LOCALE_STORAGE_KEY, next)
    } catch {
      /* ignore */
    }
  }, [])

  const setAIProvider = useCallback((next: AIProvider) => {
    setAIProviderState(next)
    try {
      Storage.set(AI_PROVIDER_STORAGE_KEY, next)
    } catch {
      /* ignore */
    }
  }, [])

  const setChatBackground = useCallback((next: ChatBackgroundId) => {
    setChatBackgroundState(next)
    try {
      Storage.set(CHAT_BACKGROUND_STORAGE_KEY, next)
    } catch {
      /* ignore */
    }
  }, [])

  const setChatBackgroundPhotoPath = useCallback((next: string | null) => {
    setChatBackgroundPhotoPathState(next)
    try {
      if (next) {
        Storage.set(CHAT_BACKGROUND_PHOTO_PATH_STORAGE_KEY, next)
      } else {
        Storage.remove(CHAT_BACKGROUND_PHOTO_PATH_STORAGE_KEY)
      }
    } catch {
      /* ignore */
    }
  }, [])

  const refreshSettings = useCallback(() => {
    setLocaleState(readInitialLocale())
    setAIProviderState(readInitialAIProvider())
    setChatBackgroundState(readInitialChatBackground())
    setChatBackgroundPhotoPathState(readInitialChatBackgroundPhotoPath())
  }, [])

  const persistSessionCache = useCallback((sessions: ChatSession[]) => {
    try {
      const cache = sortSessionsByRecency(sessions).slice(0, CHAT_SESSIONS_CACHE_LIMIT)
      Storage.set(CHAT_SESSIONS_STORAGE_KEY, JSON.stringify(cache))
    } catch {
      /* ignore */
    }
  }, [])

  const loadChatHistoryPage = useCallback(async (query: string, offset: number, append: boolean) => {
    if (append && historyLoadingRef.current) return

    const requestId = historyLoadRequestRef.current + 1
    historyLoadRequestRef.current = requestId
    historyLoadingRef.current = true

    try {
      const [favorites, history] = await Promise.all([
        fetchFavoriteChatSessions(query),
        fetchRecentChatSessions({ query, limit: CHAT_HISTORY_PAGE_SIZE, offset }),
      ])
      const merged = mergeSessionLists(favorites, history)
      if (historyLoadRequestRef.current !== requestId) return

      setHistoryOffset(offset + history.length)
      setHasMoreChatSessions(history.length === CHAT_HISTORY_PAGE_SIZE)
      setChatSessions(prev => {
        const next = append ? mergeSessionLists(prev, history) : merged
        if (!query.trim()) persistSessionCache(next)
        return sortVisibleSessions(next)
      })
    } catch (error) {
      console.log('Failed to load chat history:', String(error))
    } finally {
      if (historyLoadRequestRef.current === requestId) {
        historyLoadingRef.current = false
      }
    }
  }, [persistSessionCache])

  useEffect(() => {
    void (async () => {
      await migrateLegacyStorageSessions()
      await loadChatHistoryPage('', 0, false)
    })()
  }, [loadChatHistoryPage])

  const setChatHistorySearchQuery = useCallback((query: string) => {
    setChatHistorySearchQueryState(query)
    void loadChatHistoryPage(query, 0, false)
  }, [loadChatHistoryPage])

  const loadMoreChatSessions = useCallback(() => {
    if (!hasMoreChatSessions) return
    void loadChatHistoryPage(chatHistorySearchQuery, historyOffset, true)
  }, [chatHistorySearchQuery, hasMoreChatSessions, historyOffset, loadChatHistoryPage])

  const saveSessionData = useCallback((messages: ChatMessage[], sessionId: string) => {
    const userMessages = messages.filter(m => m.role === 'user')
    if (userMessages.length === 0) return

    const rawTitle = userMessages[0].text.trim() || getStrings(locale).newChat
    const generatedTitle = rawTitle.length > 40 ? rawTitle.substring(0, 37) + '...' : rawTitle
    const normalized = normalizeMessagesForStorage(refreshActiveBranchOptions(messages))

    setChatSessions(prev => {
      const idx = prev.findIndex(s => s.id === sessionId)
      const existing = idx >= 0 ? prev[idx] : null
      const session: ChatSession = {
        id: sessionId,
        title: existing?.titleManuallyEdited ? existing.title : generatedTitle,
        createdAt: existing?.createdAt ?? Date.now(),
        updatedAt: Date.now(),
        isFavorite: existing?.isFavorite ?? false,
        titleManuallyEdited: existing?.titleManuallyEdited ?? false,
        messages: normalized,
      }

      void saveChatSessionToDatabase(session).catch(error => {
        console.log('Failed to save chat session:', String(error))
      })

      const shouldShow = !chatHistorySearchQuery.trim() || sessionMatchesQuery(session, chatHistorySearchQuery)
      if (!shouldShow && idx < 0) return prev

      const updated = idx >= 0
        ? prev.map((s, i) => (i === idx ? session : s))
        : [session, ...prev]
      const sorted = sortVisibleSessions(updated)
      if (!chatHistorySearchQuery.trim()) persistSessionCache(sorted)
      return sorted
    })
  }, [chatHistorySearchQuery, locale, persistSessionCache])

  const saveCurrentSession = useCallback(() => {
    if (chat.messages.length === 0) return
    saveSessionData(chat.messages, currentSessionId)
  }, [chat.messages, currentSessionId, saveSessionData])

  const startNewChat = useCallback(() => {
    saveSessionData(chat.messages, currentSessionId)
    setCurrentSessionId(generateId('session'))
    dispatchChat({ type: 'clear' })
  }, [chat.messages, currentSessionId, saveSessionData, dispatchChat])

  const loadChatSession = useCallback(async (sessionId: string) => {
    try {
      saveSessionData(chat.messages, currentSessionId)
      const visibleSession = chatSessions.find(s => s.id === sessionId)
      const session = visibleSession ?? await fetchChatSessionById(sessionId)
      if (session) {
        setCurrentSessionId(sessionId)
        dispatchChat({ type: 'loadSession', messages: session.messages })
        setChatSessions(prev => sortVisibleSessions(mergeSessionLists(prev, [session])))
      }
    } catch (error) {
      console.log('Failed to load chat session:', String(error))
    }
  }, [chat.messages, currentSessionId, chatSessions, saveSessionData, dispatchChat])

  const deleteSession = useCallback((sessionId: string) => {
    void deleteChatSessionFromDatabase(sessionId).catch(error => {
      console.log('Failed to delete chat session:', String(error))
    })
    setChatSessions(prev => {
      const updated = prev.filter(s => s.id !== sessionId)
      if (!chatHistorySearchQuery.trim()) persistSessionCache(updated)
      return updated
    })
    if (sessionId === currentSessionId) {
      setCurrentSessionId(generateId('session'))
      dispatchChat({ type: 'clear' })
    }
  }, [chatHistorySearchQuery, currentSessionId, dispatchChat, persistSessionCache])

  const renameSession = useCallback((sessionId: string, title: string) => {
    const trimmed = title.trim()
    if (!trimmed) return

    void renameChatSessionInDatabase(sessionId, trimmed).catch(error => {
      console.log('Failed to rename chat session:', String(error))
    })
    setChatSessions(prev => {
      const updated = prev.map(session => session.id === sessionId
        ? {
            ...session,
            title: trimmed,
            titleManuallyEdited: true,
            updatedAt: Date.now(),
          }
        : session
      )
      if (!chatHistorySearchQuery.trim()) persistSessionCache(updated)
      return sortVisibleSessions(updated)
    })
  }, [chatHistorySearchQuery, persistSessionCache])

  const toggleFavoriteSession = useCallback((sessionId: string) => {
    setChatSessions(prev => {
      const target = prev.find(session => session.id === sessionId)
      if (!target) return prev
      const nextFavorite = !target.isFavorite
      void setChatSessionFavoriteInDatabase(sessionId, nextFavorite).catch(error => {
        console.log('Failed to update chat favorite:', String(error))
      })
      const updated = prev.map(session => session.id === sessionId
        ? {
            ...session,
            isFavorite: nextFavorite,
            updatedAt: Date.now(),
          }
        : session
      )
      if (!chatHistorySearchQuery.trim()) persistSessionCache(updated)
      return sortVisibleSessions(updated)
    })
  }, [chatHistorySearchQuery, persistSessionCache])

  const value = useMemo<AppContextValue>(() => ({
    locale,
    strings: getStrings(locale),
    isRTLLayout: isRTL(locale),
    setLocale,
    aiProvider,
    setAIProvider,
    chatBackground,
    chatBackgroundPhotoPath,
    setChatBackground,
    setChatBackgroundPhotoPath,
    chat,
    dispatchChat,
    chatSessions,
    currentSessionId,
    chatHistorySearchQuery,
    hasMoreChatSessions,
    startNewChat,
    loadChatSession,
    deleteSession,
    renameSession,
    toggleFavoriteSession,
    setChatHistorySearchQuery,
    loadMoreChatSessions,
    saveCurrentSession,
    refreshSettings,
  }), [
    locale, setLocale, aiProvider, setAIProvider, chatBackground, chatBackgroundPhotoPath, setChatBackground, setChatBackgroundPhotoPath, chat, dispatchChat,
    chatSessions, currentSessionId, chatHistorySearchQuery, hasMoreChatSessions, startNewChat, loadChatSession,
    deleteSession, renameSession, toggleFavoriteSession, setChatHistorySearchQuery, loadMoreChatSessions, saveCurrentSession, refreshSettings,
  ])

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  )
}

async function migrateLegacyStorageSessions(): Promise<void> {
  try {
    const migrated = Storage.get<string>(CHAT_SESSIONS_MIGRATED_STORAGE_KEY)
    if (migrated === '1') return

    const sessions = readInitialSessions()
    if (sessions.length > 0) {
      await saveManyChatSessionsToDatabase(sessions)
    }
    Storage.set(CHAT_SESSIONS_MIGRATED_STORAGE_KEY, '1')
  } catch (error) {
    console.log('Failed to migrate chat history to SQLite:', String(error))
  }
}

function refreshActiveBranchOptions(messages: ChatMessage[]): ChatMessage[] {
  return messages.map((message, index) => {
    const options = message.branchOptions || []
    const activeBranchId = message.activeBranchId
    if (!options.length || !activeBranchId) return message

    const branchMessages = messages.slice(index).map(stripBranchNavigationForBranchSnapshot)
    const refreshedOptions = options.map(option =>
      option.id === activeBranchId
        ? {
            ...option,
            title: message.text.length > 40 ? message.text.substring(0, 37) + '...' : message.text,
            createdAt: message.createdAt,
            messages: branchMessages,
          }
        : option
    )

    return {
      ...message,
      branchOptions: refreshedOptions,
    }
  })
}

function stripBranchNavigationForBranchSnapshot(message: ChatMessage): ChatMessage {
  const {
    branchOptions,
    activeBranchId,
    ...rest
  } = message

  return {
    ...rest,
    isStreaming: false,
    branchOptions: null,
    activeBranchId: null,
  }
}

function normalizeMessagesForStorage(messages: ChatMessage[]): ChatMessage[] {
  return messages.map(message => ({
    ...message,
    isStreaming: false,
    branchOptions: message.branchOptions
      ? message.branchOptions.map(option => ({
          ...option,
          messages: normalizeMessagesForStorage(option.messages).map(stripBranchNavigation),
        }))
      : message.branchOptions,
  }))
}

function stripBranchNavigation(message: ChatMessage): ChatMessage {
  const {
    branchOptions,
    activeBranchId,
    ...rest
  } = message

  return {
    ...rest,
    isStreaming: false,
    branchOptions: null,
    activeBranchId: null,
  }
}

function sortVisibleSessions(sessions: ChatSession[]): ChatSession[] {
  return [...sessions].sort((a, b) => {
    const favoriteDelta = Number(!!b.isFavorite) - Number(!!a.isFavorite)
    if (favoriteDelta !== 0) return favoriteDelta
    return sessionSortTime(b) - sessionSortTime(a)
  })
}


function sortSessionsByRecency(sessions: ChatSession[]): ChatSession[] {
  return [...sessions].sort((a, b) => sessionSortTime(b) - sessionSortTime(a))
}

function mergeSessionLists(...lists: ChatSession[][]): ChatSession[] {
  const map = new Map<string, ChatSession>()
  for (const list of lists) {
    for (const session of list) {
      map.set(session.id, {
        ...map.get(session.id),
        ...session,
      })
    }
  }
  return sortVisibleSessions(Array.from(map.values()))
}

function sessionSortTime(session: ChatSession): number {
  return session.updatedAt ?? session.createdAt
}

function sessionMatchesQuery(session: ChatSession, query: string): boolean {
  const normalized = query.trim().toLowerCase()
  if (!normalized) return true
  const text = [
    session.title,
    ...(session.messages || []).map(message => message.text),
  ].join(' ').toLowerCase()
  return text.includes(normalized)
}

function normalizeStoredSession(session: ChatSession): ChatSession {
  return {
    ...session,
    updatedAt: session.updatedAt ?? session.createdAt,
    isFavorite: session.isFavorite ?? false,
    titleManuallyEdited: session.titleManuallyEdited ?? false,
    messages: normalizeMessagesForStorage(session.messages || []),
  }
}

function readInitialChatBackground(): ChatBackgroundId {
  try {
    const saved = Storage.get<string>(CHAT_BACKGROUND_STORAGE_KEY)
    if (isChatBackgroundId(saved)) return saved
  } catch {
    /* ignore */
  }
  return DEFAULT_CHAT_BACKGROUND_ID
}

function readInitialChatBackgroundPhotoPath(): string | null {
  try {
    const saved = Storage.get<string>(CHAT_BACKGROUND_PHOTO_PATH_STORAGE_KEY)
    if (typeof saved === 'string' && saved.length > 0) return saved
  } catch {
    /* ignore */
  }
  return null
}

function readInitialAIProvider(): AIProvider {
  try {
    const saved = Storage.get<string>(AI_PROVIDER_STORAGE_KEY)
    if (saved && (AI_PROVIDER_VALUES as string[]).includes(saved)) {
      return saved as AIProvider
    }
  } catch {
    /* ignore */
  }
  return 'app_default'
}

function readInitialLocale(): Locale {
  try {
    const saved = Storage.get<Locale>(LOCALE_STORAGE_KEY)
    if (isSupportedLocale(saved)) return saved
  } catch {
    /* ignore */
  }
  try {
    return detectDefaultLocale(Device.systemLocale)
  } catch {
    return 'en'
  }
}

function readInitialSessions(): ChatSession[] {
  try {
    const saved = Storage.get<string>(CHAT_SESSIONS_STORAGE_KEY)
    if (saved) {
      const parsed = JSON.parse(saved)
      if (Array.isArray(parsed)) return parsed.map(item => normalizeStoredSession(item as ChatSession))
    }
  } catch {
    /* ignore */
  }
  return []
}
