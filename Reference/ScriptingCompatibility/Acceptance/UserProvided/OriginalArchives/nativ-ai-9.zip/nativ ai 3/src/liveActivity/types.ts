import type { ToolPayload, ToolRunRecord, ToolRunStatus } from '../types/chat'

export type AgentLiveActivityRegion =
  | 'lockScreen'
  | 'expanded'
  | 'compactLeading'
  | 'compactTrailing'
  | 'minimal'

export type AgentLiveActivityPhase =
  | 'thinking'
  | 'tool'
  | 'result'
  | 'error'
  | 'cancelled'

export type AgentLiveActivityToolState = {
  id: string
  name: string
  displayName: string
  action?: string | null
  status: ToolRunStatus
  startedAt: number
  finishedAt?: number | null
  params?: Record<string, unknown>
  response?: unknown
  errorMessage?: string | null
  payloadKind?: string | null
  data?: unknown
}

export type AgentLiveActivityPayload = {
  phase: AgentLiveActivityPhase
  locale: string
  query: string
  title: string
  subtitle: string
  detail?: string | null
  answerPreview?: string | null
  tool?: AgentLiveActivityToolState | null
  toolPayload?: ToolPayload | null
  toolsUsed?: string[]
  updatedAt: number
}

export type AgentChatLiveActivityState = {
  payload: AgentLiveActivityPayload
  updatedAt: number
}

export type AgentToolLiveActivityComponent = (props: {
  payload: AgentLiveActivityPayload
  tool: AgentLiveActivityToolState
  region: AgentLiveActivityRegion
  data?: any
  strings?: any
  locale?: string
}) => any

export type AgentLiveActivitySessionOptions = {
  enabled: boolean
  userText: string
  locale: string
}

export type AgentLiveActivityRunControl = {
  cancelled: boolean
  liveActivity?: AgentLiveActivitySessionHandle | null
}

export type AgentLiveActivitySessionHandle = {
  setThinking(statusText?: string | null): void
  setToolStart(run: ToolRunRecord): void
  setToolFinish(runId: string, patch: Partial<ToolRunRecord>): void
  setToolPayload(payload: ToolPayload | null): void
  setAnswerPreview(text: string): void
  finish(answer: string): void
  fail(message: string): void
  cancel(): void
}
