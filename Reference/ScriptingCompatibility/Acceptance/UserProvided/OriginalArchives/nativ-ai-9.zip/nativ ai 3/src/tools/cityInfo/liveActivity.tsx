import type { AgentToolLiveActivityComponent } from '../types'
import { ToolMiniLiveActivityView, firstString } from '../liveActivity/shared'

export const CityInfoLiveActivity: AgentToolLiveActivityComponent = ({ payload, tool, region, data }) => {
  const title = firstString(data?.title, tool.params?.query, tool.params?.topic, tool.params?.title) || tool.displayName
  const summary = firstString(data?.summary)

  return (
    <ToolMiniLiveActivityView
      payload={payload}
      tool={tool}
      region={region}
      icon="building.2.crop.circle.fill"
      accent="systemTeal"
      title={title}
      subtitle={payload.subtitle}
      detail={summary}
    />
  )
}
