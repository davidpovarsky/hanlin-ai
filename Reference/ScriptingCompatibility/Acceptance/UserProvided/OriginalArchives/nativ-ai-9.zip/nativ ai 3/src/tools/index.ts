// src/tools/index.ts
//
// Central registry for enabled agent tools.
//
// Native tools remain statically imported because they can provide rich in-app
// TSX cards and app-specific UI. External skills are discovered dynamically at
// runtime from iCloud Drive/Scripting/scripting-skills/* and exposed through the
// same AgentToolModule contract without requiring a project rebuild.

import toolModule0 from "./cityInfo"
import toolModule1 from "./emailDraft"
import toolModule2 from "./nearbyTransitArrivals"
import toolModule3 from "./reminder"
import toolModule4 from "./transitDirections"
import toolModule5 from "./weather"
import {
  ensureExternalSkillModulesLoaded,
  refreshExternalSkillModules,
  getExternalSkillDefinitionsSnapshot,
} from './externalSkills'

export type {
  AgentToolCardComponent,
  AgentToolLiveActivityComponent,
  AgentToolExample,
  AgentToolModule,
  AgentToolParamSpec,
  AgentToolRunFailure,
  AgentToolRunResult,
  AgentToolRunSuccess,
  AgentToolRunner,
  AgentToolSpec,
  CompactAgentToolSpec,
} from './types'

export {
  ensureExternalSkillModulesLoaded,
  refreshExternalSkillModules,
  getExternalSkillDefinitionsSnapshot,
} from './externalSkills'

import type {
  AgentToolCardComponent,
  AgentToolLiveActivityComponent,
  AgentToolModule,
  AgentToolRunner,
  AgentToolSpec,
  CompactAgentToolSpec,
} from './types'

export const NATIVE_AGENT_TOOL_MODULES: AgentToolModule[] = [
  toolModule0,
  toolModule1,
  toolModule2,
  toolModule3,
  toolModule4,
  toolModule5,
]

export const AGENT_TOOL_MODULES: AgentToolModule[] = NATIVE_AGENT_TOOL_MODULES

export type AgentToolName = string

let runtimeToolModules: AgentToolModule[] = [...NATIVE_AGENT_TOOL_MODULES]
let toolModuleByName: Record<string, AgentToolModule> = buildToolModuleMap(runtimeToolModules)

export async function refreshAgentToolRegistry(): Promise<AgentToolModule[]> {
  const externalModules = await refreshExternalSkillModules()
  runtimeToolModules = mergeToolModules(NATIVE_AGENT_TOOL_MODULES, externalModules)
  toolModuleByName = buildToolModuleMap(runtimeToolModules)
  return runtimeToolModules
}

export async function ensureAgentToolRegistryLoaded(): Promise<AgentToolModule[]> {
  const externalModules = await ensureExternalSkillModulesLoaded()
  runtimeToolModules = mergeToolModules(NATIVE_AGENT_TOOL_MODULES, externalModules)
  toolModuleByName = buildToolModuleMap(runtimeToolModules)
  return runtimeToolModules
}

export function getAllAgentToolModules(): AgentToolModule[] {
  return runtimeToolModules
}

export function getAllAgentToolSpecs(): AgentToolSpec[] {
  return runtimeToolModules.map(module => module.spec)
}

export function getCompactAgentToolIndex(): CompactAgentToolSpec[] {
  return getAllAgentToolSpecs().map(tool => ({
    name: tool.name,
    publicName: tool.publicName,
    shortDescription: tool.shortDescription || tool.description,
    aliases: tool.aliases || [],
  }))
}

export function getAgentToolNames(): AgentToolName[] {
  return getAllAgentToolSpecs().map(tool => tool.name)
}

export const AGENT_TOOL_SPECS: AgentToolSpec[] =
  NATIVE_AGENT_TOOL_MODULES.map(module => module.spec)

export const COMPACT_AGENT_TOOL_INDEX: CompactAgentToolSpec[] =
  AGENT_TOOL_SPECS.map(tool => ({
    name: tool.name,
    publicName: tool.publicName,
    shortDescription: tool.shortDescription || tool.description,
    aliases: tool.aliases || [],
  }))

export const AGENT_TOOL_NAMES: AgentToolName[] =
  AGENT_TOOL_SPECS.map(tool => tool.name)

export function getAgentToolModule(name: string): AgentToolModule | null {
  return toolModuleByName[name] || null
}

export function getAgentToolSpec(name: string): AgentToolSpec | null {
  return getAgentToolModule(name)?.spec || null
}

export function getAgentToolRunner(name: string): AgentToolRunner | null {
  return getAgentToolModule(name)?.run || null
}

export function getAgentToolCard(name: string): AgentToolCardComponent | null {
  return getAgentToolModule(name)?.Card || null
}

export function getAgentToolLiveActivity(name: string): AgentToolLiveActivityComponent | null {
  return getAgentToolModule(name)?.LiveActivity || null
}

function mergeToolModules(
  nativeModules: AgentToolModule[],
  externalModules: AgentToolModule[]
): AgentToolModule[] {
  const merged: AgentToolModule[] = []
  const seen = new Set<string>()

  for (const module of [...nativeModules, ...externalModules]) {
    const name = module?.spec?.name
    if (!name || seen.has(name)) continue
    seen.add(name)
    merged.push(module)
  }

  return merged
}

function buildToolModuleMap(modules: AgentToolModule[]): Record<string, AgentToolModule> {
  return modules.reduce<Record<string, AgentToolModule>>((acc, module) => {
    if (module?.spec?.name) acc[module.spec.name] = module
    return acc
  }, {})
}
