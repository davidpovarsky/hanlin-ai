// src/logic/agent/sampleAgentResponses.ts
//
// Local planner responses for testing the custom agent without calling an AI model.
// This file intentionally covers only the tools currently enabled in the central
// registry: weather, reminder, cityInfo, nearbyTransitArrivals, and transitDirections.

import type { ChatMessage } from '../../types/chat'
import type { AgentToolCall } from './agentToolManifest'
import type {
  PlannedAgentAction,
  ToolResultForPlanning,
} from './agentActionPlanner'
import {
  AGENT_SAMPLE_RESPONSE_SET,
  LOG_AGENT_SAMPLE_MODE,
} from './agentSampleMode'
import { getStrings, formatString } from '../../l10n'

export type SampleAgentActionInput = {
  userMessage: string
  language: string
  currentDateTimeISO: string
  currentLocationLabel: string | null
  chatHistory?: ChatMessage[]
  toolResults?: ToolResultForPlanning[]
  round: number
}

export type SampleAgentScenario = {
  id: string
  responseSet?: string
  match: string[]
  rounds: PlannedAgentAction[]
}

const TEST_PREFIX = '[REAL TOOL DEMO]'

export const SAMPLE_AGENT_SCENARIOS: SampleAgentScenario[] = [
  {
    id: '01-weather',
    responseSet: 'enabled-tools-demo',
    match: ['weather', 'weather', 'rain', 'temperature', 'forecast'],
    rounds: [
      action('respond_and_call_tools', `${TEST_PREFIX} Checking real weather now.`, [
        call('weather', { location: 'Jerusalem', dateText: 'today' }, 'Run the registered weather tool.'),
      ], 'Weather sample.'),
      action('respond', 'Weather demo finished. Send another message to move to the next tool.', [], 'Final weather sample response.'),
    ],
  },
  {
    id: '02-reminder',
    responseSet: 'enabled-tools-demo',
    match: ['reminder', 'reminder', 'remind', 'remind'],
    rounds: [
      action('respond_and_call_tools', `${TEST_PREFIX} Creating a real sample reminder now.`, [
        call('reminder', {
          title: 'Scripting agent demo reminder',
          notes: 'Created from sample planner mode',
          priority: 'none',
        }, 'Run the registered reminder tool.'),
      ], 'Reminder sample.'),
      action('respond', 'Reminder demo finished. Send another message to move to the next tool.', [], 'Final reminder sample response.'),
    ],
  },
  {
    id: '03-city-info',
    responseSet: 'enabled-tools-demo',
    match: ['cityinfo', 'wikipedia', 'wiki', 'wikipedia', 'tell me about'],
    rounds: [
      action('respond_and_call_tools', `${TEST_PREFIX} Searching encyclopedic information on Wikipedia now.`, [
        call('cityInfo', { query: 'Jerusalem', language: 'he' }, 'Run the registered cityInfo tool.'),
      ], 'City info sample.'),
      action('respond', 'Wikipedia demo finished. Send another message to move to the next tool.', [], 'Final cityInfo sample response.'),
    ],
  },

  {
    id: '04-transit-directions',
    responseSet: 'enabled-tools-demo',
    match: [
      'transitdirections',
      'transit directions',
      'get_transit_directions',
      'public transport directions',
      'bus directions',
      'directions transit',
      'how to get',
      'how to get',
      'how do I get',
      'route',
      'public transit route',
      'public transit route',
      'bus to',
      'light rail to',
      'public transit to',
    ],
    rounds: [
      action(
        'respond_and_call_tools',
        `${TEST_PREFIX} Running the public transit route planner now.`,
        [
          call('transitDirections', {
            fromQuery: 'Amatsya 3 Jerusalem',
            toQuery: 'Jerusalem Central Station',
            locale: 'he',
            numItineraries: 3,
            maxWalkDistance: 1200,
          }, 'Run the registered transitDirections tool.'),
        ],
        'Transit directions sample.'
      ),
      action('respond', 'Public transit route-planning demo finished. You can test another route or tool now.', [], 'Final transitDirections sample response.'),
    ],
  },

  {
    id: '05-nearby-transit-arrivals',
    responseSet: 'enabled-tools-demo',
    match: [
      'nearbytransitarrivals',
      'nearby_transit_arrivals',
      'transit',
      'public transport',
      'public transit',
      'buses',
      'nearby stops',
      'Arrival times',
      'nearby lines',
    ],
    rounds: [
      action(
        'respond_and_call_tools',
        `${TEST_PREFIX} Running the nearby transit tool. If no location was sent, the tool will request real system location.`,
        [
          call('nearbyTransitArrivals', {
            radiusMeters: 500,
            maxStops: 5,
            lookaheadMinutes: 60,
          }, 'Run the registered nearbyTransitArrivals tool.'),
        ],
        'Nearby transit sample.'
      ),
      action('respond', 'Nearby transit demo finished. Send another message to start again from the first tool.', [], 'Final nearby transit sample response.'),
    ],
  },
]

export async function getNextSampleAgentAction(
  input: SampleAgentActionInput
): Promise<PlannedAgentAction> {
  const scenario = findScenarioForInput(input)

  if (!scenario) {
    return {
      action: 'respond',
      text: getStrings(input.language).sampleModeNoTools,
      toolCalls: [],
      requestedTools: [],
      reason: 'No sample scenarios configured.',
      confidence: 1,
    }
  }

  const planned = scenario.rounds[input.round]

  if (!planned) {
    return {
      action: 'respond',
      text: formatString(getStrings(input.language).sampleScenarioFinished, { id: scenario.id }),
      toolCalls: [],
      requestedTools: [],
      reason: `Sample scenario ${scenario.id} has no round ${input.round}.`,
      confidence: 1,
    }
  }

  if (LOG_AGENT_SAMPLE_MODE) {
    console.log('[Agent sample mode] selected planned action:', {
      responseSet: AGENT_SAMPLE_RESPONSE_SET,
      scenario: scenario.id,
      round: input.round,
      action: planned.action,
      toolCalls: planned.toolCalls.map(item => item.tool),
      realToolsWillRun: true,
    })
  }

  return clonePlannedAction(planned)
}

let fallbackScenarioCursor = 0
let fallbackRunKey = ''
let fallbackRunScenarioIndex = 0

function findScenarioForInput(input: SampleAgentActionInput): SampleAgentScenario | null {
  const scenarios = SAMPLE_AGENT_SCENARIOS.filter(scenario => {
    return !scenario.responseSet || scenario.responseSet === AGENT_SAMPLE_RESPONSE_SET
  })

  if (!scenarios.length) return null

  const normalizedMessage = normalize(input.userMessage)
  const keywordIndex = scenarios.findIndex(scenario => {
    return scenario.match.some(term => {
      const normalizedTerm = normalize(term)
      return normalizedTerm.length > 0 && normalizedMessage.includes(normalizedTerm)
    })
  })

  if (keywordIndex >= 0) return scenarios[keywordIndex]

  const historyIndex = getScenarioIndexFromHistory(input, scenarios.length)
  if (historyIndex != null) return scenarios[historyIndex]

  const fallbackIndex = getFallbackScenarioIndex(input, scenarios.length)
  return scenarios[fallbackIndex]
}

function getScenarioIndexFromHistory(input: SampleAgentActionInput, scenarioCount: number): number | null {
  const history = input.chatHistory || []
  if (!history.length) return null

  const userMessages = history
    .filter(message => message.role === 'user' && !message.isStreaming)
    .map(message => String(message.text || '').trim())
    .filter(Boolean)

  if (!userMessages.length) return null

  const lastUserMessage = normalize(userMessages[userMessages.length - 1])
  const currentMessage = normalize(input.userMessage)
  const historyAlreadyIncludesCurrent = lastUserMessage.length > 0 && lastUserMessage === currentMessage

  const zeroBasedTurnIndex = historyAlreadyIncludesCurrent
    ? userMessages.length - 1
    : userMessages.length

  return positiveModulo(zeroBasedTurnIndex, scenarioCount)
}

function getFallbackScenarioIndex(input: SampleAgentActionInput, scenarioCount: number): number {
  const key = `${input.userMessage}::${input.chatHistory?.length || 0}`

  if (input.round === 0 || key !== fallbackRunKey) {
    fallbackRunKey = key
    fallbackRunScenarioIndex = positiveModulo(fallbackScenarioCursor, scenarioCount)
    fallbackScenarioCursor++
  }

  return fallbackRunScenarioIndex
}

function action(
  actionType: PlannedAgentAction['action'],
  text: string,
  toolCalls: AgentToolCall[],
  reason: string
): PlannedAgentAction {
  return {
    action: actionType,
    text,
    toolCalls,
    requestedTools: [],
    reason,
    confidence: 1,
  }
}

function call(tool: string, params: Record<string, unknown>, reason: string): AgentToolCall {
  return {
    tool: tool as AgentToolCall['tool'],
    params,
    reason,
  }
}

function clonePlannedAction(planned: PlannedAgentAction): PlannedAgentAction {
  return {
    action: planned.action,
    text: planned.text,
    reason: planned.reason,
    confidence: planned.confidence,
    requestedTools: [...(planned.requestedTools || [])],
    toolCalls: planned.toolCalls.map(toolCall => ({
      tool: toolCall.tool,
      params: { ...toolCall.params },
      reason: toolCall.reason,
    })),
  }
}

function normalize(value: string): string {
  return String(value || '').trim().toLowerCase()
}

function positiveModulo(value: number, divisor: number): number {
  return ((value % divisor) + divisor) % divisor
}
