import type { AgentToolLiveActivityComponent } from '../types'
import { ToolMiniLiveActivityView, firstString } from '../liveActivity/shared'

export const TransitDirectionsLiveActivity: AgentToolLiveActivityComponent = ({ payload, tool, region, data }) => {
  const destination = firstString(data?.destinationLabel, tool.params?.destination, tool.params?.destinationAddress)
  const origin = firstString(data?.originLabel, tool.params?.origin, tool.params?.originAddress)
  const title = destination ? `${tool.displayName}: ${destination}` : tool.displayName
  const detail = firstString(data?.summary, data?.subtitle) || (origin ? `${origin} → ${destination || ''}` : tool.action || null)

  return (
    <ToolMiniLiveActivityView
      payload={payload}
      tool={tool}
      region={region}
      icon="point.topleft.down.curvedto.point.bottomright.up.fill"
      accent="systemBlue"
      title={title}
      subtitle={payload.subtitle}
      detail={detail}
    />
  )
}
