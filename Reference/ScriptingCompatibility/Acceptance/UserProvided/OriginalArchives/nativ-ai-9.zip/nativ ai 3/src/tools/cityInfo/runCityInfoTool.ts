// src/tools/cityInfo/runCityInfoTool.ts
// Thin platform-agnostic adapter for the Wikipedia encyclopedic lookup tool.
// The legacy internal name is still cityInfo to avoid breaking existing UI/types.

import { CityInfoIntentParams } from '../../types/intents'
import { CityInfoDisplayData } from '../../types/chat'
import { fetchWikiSummary } from '../../logic/apiClients/wikiClient'
import { buildCityInfoDisplay } from './buildCityInfoDisplay'

export type CityInfoToolResult =
  | { ok: true; data: CityInfoDisplayData }
  | { ok: false; message: string }

export async function runCityInfoTool(
  params: CityInfoIntentParams,
  language: string
): Promise<CityInfoToolResult> {
  const query = String(params.query || '').trim()
  if (!query) {
    return { ok: false, message: 'Missing Wikipedia topic/query.' }
  }

  const preferredLanguage = String((params as { language?: string }).language || language || 'en')

  // Try the user's/preferred language first; if no result, fall back to English.
  let summary = await fetchWikiSummary(query, preferredLanguage)
  if (!summary && preferredLanguage !== 'en') {
    summary = await fetchWikiSummary(query, 'en')
  }

  const display = buildCityInfoDisplay(query, summary)
  if (!display) {
    return { ok: false, message: 'No matching Wikipedia article found.' }
  }

  return { ok: true, data: display }
}
