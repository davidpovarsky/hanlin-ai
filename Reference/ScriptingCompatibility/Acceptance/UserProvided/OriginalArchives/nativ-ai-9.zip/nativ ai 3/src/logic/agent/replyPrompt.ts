// src/logic/agent/replyPrompt.ts
// Pure JS - builds prompts for fallback/final assistant replies.
// Kept compatible with the previous buildAssistantUserMessage API.

import { ParsedIntent } from '../../types/intents'
import { ToolPayload } from '../../types/chat'
import { ToolResultForPlanning } from './agentActionPlanner'
import { getLanguageName, getStrings } from '../../l10n'

export type ReplyPromptInput = {
  language: string
  userMessage: string
  intent: ParsedIntent
  toolPayload: ToolPayload | null
  toolErrorMessage: string | null
}

export type FallbackStreamingPromptInput = {
  language: string
  userMessage: string
  toolResults?: ToolResultForPlanning[]
}

export function buildAssistantSystemPrompt(language: string): string {
  const langName = getStrings(language).modelLanguageName || getLanguageName(language)
  return [
    `You are a friendly, helpful personal assistant.`,
    `Always reply in ${langName}.`,
    `Keep replies concise, natural, and conversational.`,
    `You can have free conversations, answer general questions, brainstorm, tell stories, give opinions, and help with tasks.`,
    `If tool results are provided, use them as factual context and summarize naturally; do not repeat every field.`,
    `If a tool failed, apologize briefly and suggest a useful next step.`,
    `Do not claim that you used a tool unless tool results were actually provided.`,
    `If the user asks for live/current/device/app data and no tool result is provided, do not guess; say you could not access the tool result and ask them to try again or provide more details.`,
  ].join(' ')
}

export function buildFallbackStreamingUserMessage(input: FallbackStreamingPromptInput): string {
  const lines: string[] = []

  lines.push(`User said: "${input.userMessage}"`)

  if (input.toolResults && input.toolResults.length > 0) {
    lines.push('')
    lines.push('Tool results from the current agent run:')
    lines.push(JSON.stringify(input.toolResults, null, 2))
    lines.push('')
    lines.push('Write a short natural-language answer using these results. Do not list every field.')
  } else {
    lines.push('')
    lines.push('Reply naturally and helpfully. If this request needs live/current/device/app data and no tool result is present, do not invent the data; say that the tool result was not available and ask the user to try again.')
  }

  return lines.join('\n')
}

// Backward-compatible helper for the old intent -> single tool -> final reply flow.
// The new orchestrator no longer depends on this, but keeping it makes this file
// safe for any older imports elsewhere in the project.
export function buildAssistantUserMessage(input: ReplyPromptInput): string {
  if (input.intent.type === 'chat') {
    return input.userMessage
  }

  const lines: string[] = []

  lines.push(`User said: "${input.userMessage}"`)
  lines.push('')
  lines.push(`Detected intent: ${input.intent.type}`)

  if (input.toolErrorMessage) {
    lines.push(`Tool error: ${input.toolErrorMessage}`)
    lines.push('')
    lines.push('Reply with a short apology and a brief suggestion, such as checking spelling or enabling permission.')
    return lines.join('\n')
  }

  if (input.toolPayload) {
    lines.push('')
    lines.push('Tool result, possibly already shown to user as a UI card:')
    lines.push(JSON.stringify(input.toolPayload, null, 2))
    lines.push('')
    lines.push('Write a short natural-language summary that complements the card. Do not list every field.')
    return lines.join('\n')
  }

  if (input.intent.type === 'unknown') {
    return input.userMessage
  }

  lines.push('')
  lines.push('No tool result was produced. Reply briefly and ask a clarifying question if needed.')
  return lines.join('\n')
}
