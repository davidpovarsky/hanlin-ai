// Platform adapter for the weather tool.
// Uses Scripting's Weather and Location APIs.

import { WeatherIntentParams } from '../../types/intents'
import { WeatherDisplayData } from '../../types/chat'
import { buildWeatherDisplay } from './buildWeatherDisplay'
import { getIntlLocale } from '../../l10n'

export type WeatherToolResult =
  | { ok: true; data: WeatherDisplayData }
  | { ok: false; reason: 'noLocation' | 'permissionDenied' | 'failed'; message: string }

export async function runWeatherTool(
  params: WeatherIntentParams,
  language: string
): Promise<WeatherToolResult> {
  // 1. Resolve coordinates and a display name.
  let coords: { latitude: number; longitude: number } | null = null
  let displayName = ''

  try {
    if (!params.useCurrentLocation && params.locationName) {
      const placemarks = await Location.geocodeAddress({
        address: params.locationName,
        locale: getIntlLocale(language),
      })
      const first = placemarks?.[0]
      if (first?.location) {
        coords = {
          latitude: first.location.latitude,
          longitude: first.location.longitude,
        }
        displayName = composePlaceLabel(first) || params.locationName
      } else {
        return {
          ok: false,
          reason: 'failed',
          message: `Could not find location: ${params.locationName}`,
        }
      }
    } else {
      const current = await Location.requestCurrent()
      if (!current) {
        return {
          ok: false,
          reason: 'noLocation',
          message: 'Current location is not available.',
        }
      }
      coords = {
        latitude: current.latitude,
        longitude: current.longitude,
      }
      // Try to reverse-geocode for a friendly label, but don't fail if it doesn't work.
      try {
        const placemarks = await Location.reverseGeocode({
          latitude: current.latitude,
          longitude: current.longitude,
          locale: getIntlLocale(language),
        })
        const first = placemarks?.[0]
        if (first) displayName = composePlaceLabel(first)
      } catch {
        /* ignore */
      }
    }
  } catch (err) {
    return {
      ok: false,
      reason: 'permissionDenied',
      message: extractMessage(err),
    }
  }

  if (!coords) {
    return { ok: false, reason: 'failed', message: 'No coordinates resolved.' }
  }

  // 2. Fetch current weather.
  try {
    const weather = await Weather.requestCurrent(coords)

    const display = buildWeatherDisplay({
      locationName: displayName,
      temperatureFormatted: weather.temperature?.formatted ?? '—',
      apparentTemperatureFormatted: weather.apparentTemperature?.formatted ?? '—',
      conditionRaw: String(weather.condition ?? ''),
      humidity01: typeof weather.humidity === 'number' ? weather.humidity : 0,
      windSpeedFormatted: weather.wind?.speed?.formatted ?? '—',
      symbolName: weather.symbolName || 'cloud.sun',
    })

    return { ok: true, data: display }
  } catch (err) {
    return { ok: false, reason: 'failed', message: extractMessage(err) }
  }
}

function composePlaceLabel(placemark: {
  locality?: string
  subAdministrativeArea?: string
  administrativeArea?: string
  country?: string
  name?: string
}): string {
  const parts: string[] = []
  if (placemark.locality) parts.push(placemark.locality)
  else if (placemark.subAdministrativeArea) parts.push(placemark.subAdministrativeArea)
  if (placemark.country && !parts.includes(placemark.country)) parts.push(placemark.country)
  if (parts.length === 0 && placemark.name) parts.push(placemark.name)
  return parts.join(', ')
}

function extractMessage(err: unknown): string {
  if (err instanceof Error) return err.message
  if (typeof err === 'string') return err
  try {
    return JSON.stringify(err)
  } catch {
    return 'Unknown error'
  }
}
