import toolJson from './tool.json'
import { buildWeatherDisplay } from './buildWeatherDisplay'
import { runWeatherTool } from './runWeatherTool'
import { WeatherCard } from './WeatherCard'
import {
  AgentToolModule,
  AgentToolRunResult,
  asAgentToolSpec,
} from '../types'
import { WeatherIntentParams } from '../../types/intents'

import { WeatherLiveActivity } from './liveActivity'
export * from './buildWeatherDisplay'
export * from './runWeatherTool'
export * from './WeatherCard'
export * from './liveActivity'

export const WEATHER_TOOL_SPEC = asAgentToolSpec(toolJson)

async function runRegisteredWeatherTool(
  params: Record<string, unknown>,
  language: string
): Promise<AgentToolRunResult> {
  const normalized = normalizeWeatherParams(params)
  const result = await runWeatherTool(normalized, language)

  if (result.ok) {
    return { ok: true, data: result.data }
  }

  const failure = result as { message: string; reason?: string }
  return {
    ok: false,
    message: failure.message,
    reason: failure.reason,
  }
}

function normalizeWeatherParams(params: Record<string, unknown>): WeatherIntentParams {
  const locationValue = firstString(
    params.location,
    params.locationName,
    params.city,
    params.place
  )

  const useCurrentLocation = typeof params.useCurrentLocation === 'boolean'
    ? params.useCurrentLocation
    : !locationValue

  return {
    locationName: locationValue,
    useCurrentLocation,
  }
}

function firstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim()
    }
  }
  return null
}

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: WEATHER_TOOL_SPEC,
  run: runRegisteredWeatherTool,
  Card: WeatherCard,
  LiveActivity: WeatherLiveActivity,
}

export default AGENT_TOOL_MODULE
