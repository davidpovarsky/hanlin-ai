import { GroupBox, Label, VStack, HStack, Text } from 'scripting'
import { Strings, formatString, isRTL } from '../l10n'

type Props = {
  kind: string
  data: any
  locale?: string
  strings: Strings
}

export function GenericToolResultCard({ kind, data, locale, strings }: Props) {
  const summary = summarizeToolData(kind, data, locale, strings)
  const isOk = data?.ok !== false && !data?.errorMessage

  return (
    <GroupBox
      label={
        <Label
          title={summary.title}
          systemImage={isOk ? 'checkmark.circle' : 'exclamationmark.triangle'}
          foregroundStyle={isOk ? 'systemGreen' : 'systemOrange'}
        />
      }
    >
      <VStack alignment="leading" spacing={8}>
        <HStack spacing={8}>
          <Text font="caption" foregroundStyle="secondaryLabel">
            {summary.subtitle}
          </Text>
        </HStack>

        {summary.message ? (
          <Text font="subheadline">
            {summary.message}
          </Text>
        ) : null}

        {summary.preview ? (
          <Text font="caption" foregroundStyle="secondaryLabel">
            {summary.preview}
          </Text>
        ) : null}
      </VStack>
    </GroupBox>
  )
}

function summarizeToolData(kind: string, data: any, locale: string | undefined, strings: Strings): {
  title: string
  subtitle: string
  message: string
  preview: string
} {
  const _rtl = isRTL(locale || 'en')

  if (data?.externalSkill) {
    const result = data.result
    const count = countResultItems(result)
    const action = data.action ? String(data.action) : kind
    const title = data.skillName || data.skillId || kind
    const subtitle = data.ok === false
      ? strings.externalSkillError
      : formatString(strings.externalSkill, { action })
    const message = data.errorMessage
      ? String(data.errorMessage)
      : count != null
        ? formatString(strings.returnedItems, { count })
        : strings.actionCompleted

    return {
      title: String(title),
      subtitle,
      message,
      preview: previewValue(result ?? data.rawOutput),
    }
  }

  const title = data?.tool
    ? String(data.tool)
    : data?.skillName
      ? String(data.skillName)
      : kind

  return {
    title,
    subtitle: data?.ok === false
      ? strings.toolError
      : strings.toolResult,
    message: data?.errorMessage ? String(data.errorMessage) : '',
    preview: previewValue(data?.data ?? data),
  }
}

function countResultItems(value: unknown): number | null {
  if (Array.isArray(value)) return value.length

  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>
    if (typeof obj.count === 'number') return obj.count

    for (const key of ['items', 'events', 'calendars', 'songs', 'albums', 'playlists', 'results']) {
      const candidate = obj[key]
      if (Array.isArray(candidate)) return candidate.length
    }
  }

  return null
}

function previewValue(value: unknown): string {
  if (value == null) return ''

  if (typeof value === 'string') {
    return truncate(value.replace(/\s+/g, ' ').trim(), 700)
  }

  try {
    return truncate(JSON.stringify(value, null, 2), 900)
  } catch {
    return truncate(String(value), 700)
  }
}

function truncate(value: string, max: number): string {
  const text = String(value || '').trim()
  if (text.length <= max) return text
  return text.slice(0, max) + '\n…'
}
