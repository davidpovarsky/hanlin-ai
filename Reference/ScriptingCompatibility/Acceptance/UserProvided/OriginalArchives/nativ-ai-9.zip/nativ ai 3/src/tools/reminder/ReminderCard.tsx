import { HStack, Text, type Color } from 'scripting'
import { ReminderDisplayData } from '../../types/chat'
import { Strings, isRTL } from '../../l10n'
import { formatDateTime } from '../../utils/dateFormat'
import { ToolCardFrame, ToolHeader, SoftPanel, ToolPill, NativeDivider } from '../nativeToolUI'

type Props = {
  data: ReminderDisplayData
  strings: Strings
  locale: string
}

export function ReminderCard({ data, strings, locale }: Props) {
  const { iconName, iconColor, statusLabel } = describeStatus(data, strings)
  const rtl = isRTL(locale || '')
  const align = rtl ? 'trailing' : 'leading'

  return (
    <ToolCardFrame alignment={align}>
      <ToolHeader
        title={data.title}
        subtitle={`${strings.reminder} · ${statusLabel}`}
        icon={iconName}
        accent={iconColor}
        alignment={align}
      />

      <SoftPanel alignment={align} spacing={10} fill="secondarySystemGroupedBackground">
        {data.notes ? (
          <Text font="subheadline" foregroundStyle="secondaryLabel" multilineTextAlignment={align}>
            {data.notes}
          </Text>
        ) : null}

        {(data.dueDateISO || data.priority !== 'none') && data.notes ? <NativeDivider /> : null}

        {(data.dueDateISO || data.priority !== 'none') ? (
          <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment: align }}>
            {data.dueDateISO ? (
              <ToolPill
                icon="calendar"
                color="systemBlue"
                text={`${strings.reminderDueDate}: ${formatDateTime(data.dueDateISO, locale)}`}
              />
            ) : null}
            {data.priority !== 'none' ? (
              <ToolPill
                icon="flag.fill"
                color={priorityColor(data.priority)}
                text={`${strings.reminderPriority}: ${priorityLabel(data.priority, strings)}`}
              />
            ) : null}
          </HStack>
        ) : null}

        {data.status === 'failed' && data.errorMessage ? (
          <Text font="caption" foregroundStyle="systemRed" multilineTextAlignment={align}>
            {data.errorMessage}
          </Text>
        ) : null}
      </SoftPanel>
    </ToolCardFrame>
  )
}

function priorityLabel(
  priority: 'none' | 'low' | 'medium' | 'high',
  strings: Strings
): string {
  switch (priority) {
    case 'high': return strings.priorityHigh
    case 'medium': return strings.priorityMedium
    case 'low': return strings.priorityLow
    default: return strings.priorityNone
  }
}

function priorityColor(priority: 'none' | 'low' | 'medium' | 'high'): Color {
  switch (priority) {
    case 'high': return 'systemRed'
    case 'medium': return 'systemOrange'
    case 'low': return 'systemBlue'
    default: return 'secondaryLabel'
  }
}

function describeStatus(data: ReminderDisplayData, strings: Strings): {
  iconName: string
  iconColor: Color
  statusLabel: string
} {
  switch (data.status) {
    case 'created':
      return {
        iconName: 'checkmark.circle.fill',
        iconColor: 'systemGreen',
        statusLabel: strings.reminderCreated,
      }
    case 'failed':
      return {
        iconName: 'exclamationmark.triangle.fill',
        iconColor: 'systemRed',
        statusLabel: strings.reminderFailed,
      }
    case 'pending':
    default:
      return {
        iconName: 'bell.fill',
        iconColor: 'systemBlue',
        statusLabel: strings.loading,
      }
  }
}
