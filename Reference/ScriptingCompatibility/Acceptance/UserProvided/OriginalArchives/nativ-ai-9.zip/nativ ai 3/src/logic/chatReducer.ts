// Pure JS - chat state reducer. No platform imports.
// Easily testable and portable.

import { ChatMessage, ToolPayload, ToolRunRecord } from '../types/chat'
import { ParsedIntent } from '../types/intents'

export type ChatState = {
  messages: ChatMessage[]
}

export type ChatAction =
  | { type: 'add'; message: ChatMessage }
  | { type: 'appendText'; id: string; chunk: string }
  | { type: 'setIntent'; id: string; intent: ParsedIntent }
  | { type: 'setToolPayload'; id: string; payload: ToolPayload | null }
  | { type: 'setToolStatusText'; id: string; text: string | null }
  | { type: 'addToolRun'; id: string; run: ToolRunRecord }
  | { type: 'updateToolRun'; id: string; runId: string; patch: Partial<ToolRunRecord> }
  | { type: 'finishStreaming'; id: string }
  | { type: 'replaceText'; id: string; text: string }
  | { type: 'updateMessageText'; id: string; text: string }
  | { type: 'clear' }
  | { type: 'replaceAll'; messages: ChatMessage[] }
  | { type: 'loadSession'; messages: ChatMessage[] }

export const initialChatState: ChatState = {
  messages: [],
}

export function chatReducer(state: ChatState, action: ChatAction): ChatState {
  switch (action.type) {
    case 'add':
      return { ...state, messages: [...state.messages, action.message] }

    case 'appendText':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, text: m.text + action.chunk } : m
        ),
      }

    case 'replaceText':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, text: action.text } : m
        ),
      }

    case 'updateMessageText':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, text: action.text } : m
        ),
      }

    case 'setIntent':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, intent: action.intent } : m
        ),
      }

    case 'setToolPayload':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, toolPayload: action.payload } : m
        ),
      }

    case 'setToolStatusText':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, toolStatusText: action.text } : m
        ),
      }

    case 'addToolRun':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id
            ? { ...m, toolRuns: [...(m.toolRuns || []), action.run] }
            : m
        ),
      }

    case 'updateToolRun':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id
            ? {
                ...m,
                toolRuns: (m.toolRuns || []).map(run =>
                  run.id === action.runId ? { ...run, ...action.patch } : run
                ),
              }
            : m
        ),
      }

    case 'finishStreaming':
      return {
        ...state,
        messages: state.messages.map(m =>
          m.id === action.id ? { ...m, isStreaming: false } : m
        ),
      }

    case 'clear':
      return { ...state, messages: [] }

    case 'replaceAll':
      return { messages: action.messages }

    case 'loadSession':
      return { messages: action.messages.map(m => ({ ...m, isStreaming: false })) }

    default:
      return state
  }
}
