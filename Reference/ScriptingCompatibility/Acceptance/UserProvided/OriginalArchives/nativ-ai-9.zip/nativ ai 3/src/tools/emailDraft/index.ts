import toolJson from './tool.json'
import { buildEmailDraftDisplay } from './buildEmailDraftDisplay'
import { runEmailDraftTool, EmailDraftToolParams } from './runEmailDraftTool'
import { EmailDraftCard } from './EmailDraftCard'
import {
  AgentToolModule,
  AgentToolRunResult,
  asAgentToolSpec,
} from '../types'
import { EmailDraftLiveActivity } from './liveActivity'

export * from './buildEmailDraftDisplay'
export * from './runEmailDraftTool'
export * from './EmailDraftCard'
export * from './liveActivity'

export const EMAIL_DRAFT_TOOL_SPEC = asAgentToolSpec(toolJson)

async function runRegisteredEmailDraftTool(
  params: Record<string, unknown>,
  language: string
): Promise<AgentToolRunResult> {
  const normalized = normalizeEmailDraftParams(params)
  const result = await runEmailDraftTool(normalized, language)

  if (result.ok) {
    return { ok: true, data: result.data }
  }

  const failure = result as { message: string; data: unknown }
  return {
    ok: false,
    message: failure.message,
    data: failure.data,
  }
}

function normalizeEmailDraftParams(params: Record<string, unknown>): EmailDraftToolParams {
  const explicitEmail = firstString(params.toEmail, params.email, params.recipientEmail, params.toAddress)
  const toAsRecipientName = firstString(params.to)
  const toValue = explicitEmail || (looksLikeEmail(toAsRecipientName) ? toAsRecipientName : null)
  const recipientName = firstString(params.recipientName, params.recipient, params.toName)
    || (looksLikeEmail(toAsRecipientName) ? null : toAsRecipientName)

  return {
    request: firstString(params.request, params.userRequest, params.context, params.message),
    recipientName,
    toEmail: toValue,
    subject: firstString(params.subject, params.title),
    body: firstString(params.body, params.content, params.messageBody),
    tone: firstString(params.tone, params.style),
  }
}


function looksLikeEmail(value: string | null): boolean {
  return !!value && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value.trim())
}

function firstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) {
      return value.trim()
    }
  }
  return null
}

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: EMAIL_DRAFT_TOOL_SPEC,
  run: runRegisteredEmailDraftTool,
  Card: EmailDraftCard,
  LiveActivity: EmailDraftLiveActivity,
}

export default AGENT_TOOL_MODULE
