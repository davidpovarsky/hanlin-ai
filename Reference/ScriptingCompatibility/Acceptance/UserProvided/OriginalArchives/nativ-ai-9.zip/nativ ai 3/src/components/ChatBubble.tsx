import {
  Button,
  Group,
  HStack,
  Image,
  Label,
  ProgressView,
  Spacer,
  Text,
  VStack,
} from 'scripting'
import { ChatMessage, ToolRunRecord } from '../types/chat'
import { Strings } from '../l10n'
import { ToolRunStatusPanel } from './ToolRunStatusPanel'

type Props = {
  message: ChatMessage
  strings: Strings
  locale: string
  isRTL: boolean
  onEdit?: (message: ChatMessage) => void
  onActivateBranch?: (message: ChatMessage, branchId: string) => void
  onRegenerate?: (message: ChatMessage) => void
  branchSourceMessage?: ChatMessage | null
}

export function ChatBubble({
  message,
  strings,
  locale,
  isRTL,
  onEdit,
  onActivateBranch,
  onRegenerate,
  branchSourceMessage,
}: Props) {
  const isUser = message.role === 'user'
  const userBubbleAlignment = isRTL ? 'trailing' : 'leading'
  const assistantAlignment = isRTL ? 'leading' : 'trailing'
  const runs = message.toolRuns || []
  const runningRun = [...runs].reverse().find(run => run.status === 'running') || null
  const hasToolRuns = runs.length > 0
  const text = message.text || ''
  const cleanToolStatusText = String(message.toolStatusText || '').trim()
  const isThinkingStatus = cleanToolStatusText === '__agent_thinking__'
  const showThinkingIndicator = !isUser && message.isStreaming && (isThinkingStatus || (!hasToolRuns && !text.trim() && !cleanToolStatusText))
  const showToolActivity = !isUser && message.isStreaming && !isThinkingStatus && (runningRun != null || cleanToolStatusText.length > 0)
  const branchMessage = branchSourceMessage || message
  const branchOptions = branchMessage.branchOptions || []
  const activeBranchId = branchMessage.activeBranchId || branchOptions[0]?.id || null
  const activeBranchIndex = Math.max(
    0,
    branchOptions.findIndex(option => option.id === activeBranchId)
  )
  const canSwitchBranches = branchOptions.length > 1 && activeBranchId != null && !message.isStreaming
  const canRegenerate = !isUser && !message.isStreaming && onRegenerate != null

  const copyMessage = async () => {
    if (!text.trim()) return

    try {
      await Pasteboard.setString(text)
      await Dialog.alert({
        title: strings.messageCopied,
        message: strings.messageCopiedDescription,
        buttonLabel: strings.ok,
      })
    } catch {
      await Dialog.alert({
        title: strings.error,
        message: strings.messageCopyFailed,
        buttonLabel: strings.ok,
      })
    }
  }

  const requestEdit = () => {
    if (!isUser || message.isStreaming) return
    onEdit?.(message)
  }

  const activateRelativeBranch = (offset: number) => {
    if (!canSwitchBranches || !onActivateBranch) return
    const nextIndex = activeBranchIndex + offset
    const nextOption = branchOptions[nextIndex]
    if (!nextOption || nextOption.id === activeBranchId) return
    onActivateBranch(branchMessage, nextOption.id)
  }

  const renderUserBubbleSurface = (preview = false) => {
    const cornerRadius = preview ? 18 : 10

    return (
    <VStack
      alignment={userBubbleAlignment}
      spacing={6}
      padding={{ horizontal: 14, vertical: 10 }}
      frame={preview ? { maxWidth: 320, alignment: userBubbleAlignment } : undefined}
      fixedSize={preview ? { horizontal: false, vertical: true } : undefined}
      background="secondarySystemBackground"
      clipShape={{ type: 'rect', cornerRadius }}
      contentShape={{
        kind: 'contextMenuPreview',
        shape: {
          type: 'rect',
          cornerRadius,
        },
      }}
    >
      <Label
        title={strings.you}
        systemImage="person.crop.circle"
        font="caption"
        foregroundStyle="secondaryLabel"
      />
      {text.trim() ? (
        <Text
          font="body"
          foregroundStyle="label"
          multilineTextAlignment={isRTL ? 'trailing' : 'leading'}
          fixedSize={preview ? { horizontal: false, vertical: true } : undefined}
        >
          {text}
        </Text>
      ) : null}
      {(message.attachments || []).length > 0 ? (
        <VStack alignment={userBubbleAlignment} spacing={4}>
          {(message.attachments || []).map(item => (
            <Label
              key={item.id}
              title={item.name}
              systemImage={item.kind === 'image' ? 'photo' : 'doc'}
              font="caption"
              foregroundStyle="secondaryLabel"
            />
          ))}
        </VStack>
      ) : null}
    </VStack>
    )
  }

  const renderUserBubblePreview = () => (
    <VStack
      alignment={userBubbleAlignment}
      spacing={0}
      padding={{ horizontal: 2, vertical: 2 }}
      fixedSize={{ horizontal: false, vertical: true }}
      contentShape={{
        kind: 'contextMenuPreview',
        shape: {
          type: 'rect',
          cornerRadius: 20,
        },
      }}
    >
      {renderUserBubbleSurface(true)}
    </VStack>
  )

  const renderUserBubble = () => (
    <VStack
      alignment={userBubbleAlignment}
      spacing={6}
      frame={{ maxWidth: 'infinity', alignment: userBubbleAlignment }}
    >
      <Button
        action={() => {}}
        contentShape={{
          kind: 'interaction',
          shape: {
            type: 'rect',
            cornerRadius: 10,
          },
        }}
        contextMenu={{
          menuItems: (
            <Group>
              <Button
                title={strings.copyMessage}
                systemImage="doc.on.doc"
                action={copyMessage}
                disabled={!text.trim()}
              />
              {!message.isStreaming ? (
                <Button
                  title={strings.editMessage}
                  systemImage="pencil"
                  action={requestEdit}
                />
              ) : null}
            </Group>
          ),
          preview: renderUserBubblePreview(),
        }}
      >
        {renderUserBubbleSurface(false)}
      </Button>
    </VStack>
  )

  const renderAssistantActions = () => {
    if (!text.trim() && !canSwitchBranches && !canRegenerate) return null

    return (
      <HStack spacing={8}>
        {text.trim() ? (
          <Button
            title=""
            systemImage="doc.on.doc"
            buttonStyle="borderless"
            foregroundStyle="secondaryLabel"
            action={copyMessage}
            disabled={!text.trim()}
          />
        ) : null}

        {canRegenerate ? (
          <Button
            title=""
            systemImage="arrow.clockwise"
            buttonStyle="borderless"
            foregroundStyle="secondaryLabel"
            action={() => onRegenerate?.(message)}
          />
        ) : null}

        {canSwitchBranches ? (
          <HStack spacing={6}>
            <Button
              title=""
              systemImage={isRTL ? 'chevron.right' : 'chevron.left'}
              buttonStyle="borderless"
              foregroundStyle="secondaryLabel"
              action={() => activateRelativeBranch(-1)}
              disabled={activeBranchIndex <= 0}
            />
            <Text font="caption" foregroundStyle="secondaryLabel">
              {`${activeBranchIndex + 1} / ${branchOptions.length}`}
            </Text>
            <Button
              title=""
              systemImage={isRTL ? 'chevron.left' : 'chevron.right'}
              buttonStyle="borderless"
              foregroundStyle="secondaryLabel"
              action={() => activateRelativeBranch(1)}
              disabled={activeBranchIndex >= branchOptions.length - 1}
            />
          </HStack>
        ) : null}
        <Spacer />
      </HStack>
    )
  }

  const renderAssistantContent = () => (
    <VStack
      alignment={assistantAlignment}
      spacing={10}
      frame={{ maxWidth: 'infinity', alignment: assistantAlignment }}
    >
      {showThinkingIndicator ? (
        <AssistantActivityIndicator
          mode="thinking"
          text={strings.thinking.replace(/…|\.\.\./g, '')}
        />
      ) : null}

      {showToolActivity ? (
        <AssistantActivityIndicator
          mode="tool"
          text={cleanToolStatusText || formatToolRunName(runningRun, strings)}
        />
      ) : null}

      {hasToolRuns ? (
        <ToolRunStatusPanel
          runs={runs}
          statusText={null}
          locale={locale}
          strings={strings}
        />
      ) : null}

      {text.trim() ? (
        <Text
          attributedString={text}
          font="body"
          foregroundStyle="label"
          multilineTextAlignment={isRTL ? 'trailing' : 'leading'}
          contextMenu={{
            menuItems: (
              <Button
                title={strings.copyMessage}
                systemImage="doc.on.doc"
                action={copyMessage}
              />
            ),
          }}
        />
      ) : null}

      {renderAssistantActions()}
    </VStack>
  )

  return (
    <VStack
      alignment={isUser ? userBubbleAlignment : assistantAlignment}
      spacing={6}
      frame={{ maxWidth: 'infinity', alignment: isUser ? userBubbleAlignment : assistantAlignment }}
    >
      {isUser ? renderUserBubble() : renderAssistantContent()}
    </VStack>
  )
}

function AssistantActivityIndicator({
  mode,
  text,
}: {
  mode: 'thinking' | 'tool'
  text: string
}) {
  return (
    <HStack spacing={8}>
      <ProgressView progressViewStyle="circular" />
      <Image
        systemName={mode === 'tool' ? 'gearshape.2' : 'brain.head.profile'}
        foregroundStyle="secondaryLabel"
        imageScale="medium"
        symbolEffect={mode === 'tool' ? 'rotate' : 'pulse'}
      />
      <Text font="subheadline" foregroundStyle="secondaryLabel">
        {text}
      </Text>
    </HStack>
  )
}

function formatToolRunName(run: ToolRunRecord | null, strings: Strings): string {
  if (!run) return strings.toolActivityFallback || 'Using tool'
  const action = String(run.action || '').replace(/_/g, ' ').trim()
  const tool = String(run.tool || '').replace(/^ios-/, 'iOS ').replace(/-/g, ' ').trim()
  const name = action ? `${tool} · ${action}` : tool
  return name || strings.toolActivityFallback || 'Using tool'
}
