// Pure type definitions - no runtime code, no platform dependencies

export type IntentType =
  | 'weather'
  | 'reminder'
  | 'emailDraft'
  | 'cityInfo'
  | 'nearbyTransitArrivals'
  | 'chat'
  | 'unknown'
  | string

export type WeatherIntentParams = {
  locationName: string | null
  useCurrentLocation: boolean
}

export type ReminderIntentParams = {
  title: string
  notes: string | null
  dueDateISO: string | null
  priority: 'none' | 'low' | 'medium' | 'high'
}


export type EmailDraftIntentParams = {
  request: string
  recipientName?: string | null
  toEmail?: string | null
  subject?: string | null
  body?: string | null
  tone?: string | null
}

export type CityInfoIntentParams = {
  query: string
  language: string
}

export type NearbyTransitArrivalsIntentParams = {
  latitude?: number | string | null
  longitude?: number | string | null
  radiusMeters?: number | string | null
  maxStops?: number | string | null
  lookaheadMinutes?: number | string | null
  forceLocationRequest?: boolean | string | null
  debug?: boolean | string | null
}

export type ParsedIntent =
  | { type: 'weather'; params: WeatherIntentParams; confidence: number }
  | { type: 'reminder'; params: ReminderIntentParams; confidence: number }
  | { type: 'emailDraft'; params: EmailDraftIntentParams; confidence: number }
  | { type: 'cityInfo'; params: CityInfoIntentParams; confidence: number }
  | { type: 'nearbyTransitArrivals'; params: NearbyTransitArrivalsIntentParams; confidence: number }
  | { type: 'chat'; params: {}; confidence: number }
  | { type: 'unknown'; params: {}; confidence: number }
  | { type: string; params: Record<string, unknown>; confidence: number }
