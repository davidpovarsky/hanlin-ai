import toolJson from './tool.json'
import { runTransitDirectionsTool } from './runTransitDirectionsTool'
import { TransitDirectionsCard } from './TransitDirectionsCard'
import {
  AgentToolModule,
  AgentToolRunResult,
  asAgentToolSpec,
} from '../types'

import { TransitDirectionsLiveActivity } from './liveActivity'
export * from './buildTransitDirectionsDisplay'
export * from './runTransitDirectionsTool'
export * from './TransitDirectionsCard'
export * from './liveActivity'

export const TRANSIT_DIRECTIONS_TOOL_SPEC = asAgentToolSpec(toolJson)

async function runRegisteredTransitDirectionsTool(
  params: Record<string, unknown>,
  language: string
): Promise<AgentToolRunResult> {
  const result = await runTransitDirectionsTool(params, language)

  if (result.ok === true) {
    return { ok: true, data: result.data }
  }

  const failure = result as { message: string; reason?: string; data?: unknown }
  return {
    ok: false,
    message: failure.message,
    reason: failure.reason,
    data: failure.data,
  }
}

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: TRANSIT_DIRECTIONS_TOOL_SPEC,
  run: runRegisteredTransitDirectionsTool,
  Card: TransitDirectionsCard,
  LiveActivity: TransitDirectionsLiveActivity,
}

export default AGENT_TOOL_MODULE
