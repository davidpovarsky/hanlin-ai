// src/tools/types.ts
// Shared contract for every internal agent tool.

import type { AgentToolLiveActivityComponent } from '../liveActivity/types'

export type { AgentToolLiveActivityComponent }
//
// A tool folder should expose an AgentToolModule from its index.ts file:
//   export const AGENT_TOOL_MODULE = { spec, run, Card? }
//   export default AGENT_TOOL_MODULE
//
// External runtime skills may provide only spec + run. The UI falls back to a
// generic result card when no custom Card is supplied.
//
// The central registry imports these modules and the rest of the app talks only
// to this contract. That keeps the orchestrator and UI independent of individual
// tool implementation files.

export type AgentToolParamSpec = {
  description: string
  required?: boolean
}

export type AgentToolExample = {
  user: string
  call: {
    tool: string
    params: Record<string, unknown>
  }
}

export type AgentToolSpec = {
  name: string
  publicName: string
  shortDescription: string
  aliases?: string[]
  description: string
  whenToUse: string[]
  whenNotToUse: string[]
  params: Record<string, AgentToolParamSpec>
  resultPolicy: string
  examples: AgentToolExample[]
}

export type CompactAgentToolSpec = {
  name: string
  publicName: string
  shortDescription: string
  aliases?: string[]
}

export type AgentToolRunSuccess = {
  ok: true
  data: unknown
}

export type AgentToolRunFailure = {
  ok: false
  message: string
  reason?: string
  /**
   * Optional display data for failures that should still render a card.
   * Example: reminder creation can fail after we already built a pending card.
   */
  data?: unknown
}

export type AgentToolRunResult = AgentToolRunSuccess | AgentToolRunFailure

export type AgentToolRunner = (
  params: Record<string, unknown>,
  language: string
) => Promise<AgentToolRunResult>

export type AgentToolCardComponent = (props: {
  data: any
  strings?: any
  locale?: string
}) => any

export type AgentToolModule = {
  spec: AgentToolSpec
  run: AgentToolRunner
  Card?: AgentToolCardComponent
  /**
   * Optional compact Live Activity UI for this tool.
   * When absent, the central Live Activity falls back to the generic tool-running view.
   */
  LiveActivity?: AgentToolLiveActivityComponent
}

export function asAgentToolSpec(tool: unknown): AgentToolSpec {
  return tool as AgentToolSpec
}
