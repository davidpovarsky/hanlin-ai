// src/logic/agent/agentActionPlanner.ts
//
// General structured planner for the custom agent loop.
// On every round, the model receives:
// - the latest user message
// - recent conversation history
// - previous tool results from the current run
// - the full internal tool manifest
//
// It must choose exactly one of:
// 1. respond                 -> return only text to the user
// 2. respond_and_call_tools  -> return text and one/multiple tool calls
// 3. call_tools              -> only run one/multiple tool calls
// 4. none                    -> do nothing
//
// This planner is intentionally general. It does not hard-code a special flow
// for one specific tool. The core rule is: reason over the whole context and
// choose the next action that best satisfies the user's request.

import { ChatMessage } from '../../types/chat'
import {
  AgentToolCall,
  AgentToolName,
  getKnownToolNamesAndAliases,
  normalizeAgentToolName,
} from './agentToolManifest'
import { buildPlannerToolManifestPrompt } from './agentToolManifestStrategy'
import { getLanguageName, getStrings } from '../../l10n'

export type AgentActionKind =
  | 'respond'
  | 'respond_and_call_tools'
  | 'call_tools'
  | 'request_more_tool_manifests'
  | 'none'

export type ToolResultForPlanning = {
  tool: string
  params: Record<string, unknown>
  ok: boolean
  payload?: unknown
  errorMessage?: string | null
}

export type AgentActionRaw = {
  action?: string
  text?: string
  toolCalls?: Array<{
    tool?: string
    reason?: string
    params?: Record<string, unknown>
    paramsJson?: string
  }>
  requestedTools?: Array<string | { tool?: string; reason?: string }>
  reason?: string
  confidence?: number
}

export type PlannedAgentAction = {
  action: AgentActionKind
  text: string
  toolCalls: AgentToolCall[]
  requestedTools: AgentToolName[]
  reason: string
  confidence: number
}

export type AgentPlannerInput = {
  userMessage: string
  language: string
  currentDateTimeISO: string
  currentLocationLabel: string | null
  chatHistory?: ChatMessage[]
  toolResults?: ToolResultForPlanning[]
  extraDetailedTools?: AgentToolName[]
}

const agentActionSchema = {
  type: 'object',
  description: 'The next action for the AI agent.',
  properties: {
    action: {
      type: 'string',
      description: 'Exactly one of: respond, respond_and_call_tools, call_tools, request_more_tool_manifests, none.',
    },
    text: {
      type: 'string',
      description: [
        'User-visible text only.',
        'Never include internal tool-call syntax here.',
        'Never write CALL, function_name(...), JSON tool calls, or markdown/code tool calls in this field.',
        'If a tool is needed, put the tool request only in toolCalls.',
        'When action includes toolCalls, this text must be only a short acknowledgement, not the tool result.',
      ].join(' '),
    },
    reason: {
      type: 'string',
      description: 'Brief internal reason for the selected action, based on the full conversation context.',
    },
    confidence: {
      type: 'number',
      description: 'Confidence from 0 to 1.',
    },
    toolCalls: {
      type: 'array',
      description: [
        'Zero or more tool calls to execute now. Use at most 3 per round.',
        'Every real tool request must appear here, never inside text.',
      ].join(' '),
      items: {
        type: 'object',
        description: 'A single internal tool call.',
        properties: {
          tool: {
            type: 'string',
            description: 'Tool name exactly as listed in the manifest, for example weather, reminder, cityInfo, nearbyTransitArrivals, or an external skill name such as apple-music / ios-calendar. Do not use aliases or function-style names.',
          },
          reason: {
            type: 'string',
            description: 'Brief reason for this specific tool call.',
          },
          paramsJson: {
            type: 'string',
            description: 'JSON object string containing all parameters for the selected tool. Example for weather: {\"location\":\"Jerusalem\",\"dateText\":\"today\"}. Example for external skill: {\"action\":\"get_songs\",\"artist\":\"Taylor Swift\",\"limit\":10}.',
          },
        },
      },
    },
    requestedTools: {
      type: 'array',
      description: [
        'Only for action=request_more_tool_manifests.',
        'Tool names from the compact tool index whose full manifests are needed before planning tool calls.',
        'Use this when a selected detailed tool needs missing information that another available tool may provide.',
        'Example: weather needs a location, and ios-location may provide current location.',
      ].join(' '),
      items: {
        type: 'string',
        description: 'Tool name exactly as shown in the compact index.',
      },
    },
  },
}

export async function planNextAgentAction(
  input: AgentPlannerInput,
  aiProvider?: string
): Promise<PlannedAgentAction> {
  if (!Assistant || typeof Assistant.requestStructuredData !== 'function') {
    throw new Error('Assistant.requestStructuredData is not available')
  }

  const prompt = await buildAgentPlannerPrompt(input, aiProvider)

  try {
    console.log('[Agent planner] requestStructuredData start', {
      userMessage: input.userMessage,
      historyCount: input.chatHistory?.length || 0,
      toolResultCount: input.toolResults?.length || 0,
      promptLength: prompt.length,
    })

    const raw = await Assistant.requestStructuredData<AgentActionRaw>(
      prompt,
      agentActionSchema as never,
      aiProvider ? { provider: aiProvider as Assistant.Provider } : undefined
    )

    const normalized = normalizePlannedAction(raw)
    console.log('[Agent planner] structured action', {
      action: normalized.action,
      textLength: normalized.text.length,
      toolCalls: normalized.toolCalls.map(call => ({ tool: call.tool, params: call.params })),
      requestedTools: normalized.requestedTools,
      confidence: normalized.confidence,
    })

    return normalized
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    const fullErrorText = String(err instanceof Error ? err.stack || err.message : err)

    const recoveredRaw = extractStructuredJsonFromError<AgentActionRaw>(message)
      || extractStructuredJsonFromError<AgentActionRaw>(fullErrorText)

    if (recoveredRaw) {
      const normalized = normalizePlannedAction(recoveredRaw)
      console.warn('[Agent planner] recovered structured action from parse error:', {
        action: normalized.action,
        textLength: normalized.text.length,
        toolCalls: normalized.toolCalls.map(call => ({ tool: call.tool, params: call.params })),
        requestedTools: normalized.requestedTools,
        confidence: normalized.confidence,
      })
      return normalized
    }

    if (/insufficient balance|unauthorized|invalid.*key|quota/i.test(message)) {
      throw err
    }

    console.error('planNextAgentAction failed:', err)
    console.error('[Agent planner debug] Could not recover JSON from planner error. The agent will not use normal streaming fallback because that can hallucinate live/tool data.')
    return {
      action: 'respond',
      text: getStrings(input.language).plannerInternalError,
      toolCalls: [],
      requestedTools: [],
      reason: 'Planner failed and no structured JSON could be recovered.',
      confidence: 0,
    }
  }
}

async function buildAgentPlannerPrompt(input: AgentPlannerInput, aiProvider?: string): Promise<string> {
  const langName = getStrings(input.language).modelLanguageName || getLanguageName(input.language)
  const history = formatHistory(input.chatHistory || [])
  const toolResults = formatToolResults(input.toolResults || [])

  return [
    'You are the decision layer of a custom AI agent.',
    `Always reason and write user-visible text in ${langName}.`,
    '',
    'You do NOT execute tools yourself. The script will execute any tool calls you return in toolCalls, then call you again with the tool results.',
    '',
    'Your task on EVERY round:',
    '1. Read the latest user message carefully.',
    '2. Read the recent conversation history, especially the previous assistant message.',
    '3. Read previous tool results from this agent run.',
    '4. Read the detailed tool manifests and the compact index of other available tools.',
    '5. Decide the next action based on the whole context, not only on keywords in the latest message.',
    '',
    'Allowed actions:',
    '- respond: return only text to the user. Use when no tool is needed, or when existing tool results are sufficient to answer.',
    '- respond_and_call_tools: return a short acknowledgement AND one or more tool calls. The text must not contain the result, because the tool has not run yet.',
    '- call_tools: return only one or more tool calls, with no user-visible text yet.',
    '- request_more_tool_manifests: request full definitions for additional tools from the compact index before calling tools or asking the user. Use this when a current detailed tool needs missing data and another available tool may provide it.',
    '- none: do nothing. Use only for empty input or when absolutely no action is appropriate.',
    '',
    'Decision checklist you MUST follow silently:',
    '- Is the latest user message a new request, a continuation, or an answer to a previous assistant clarification?',
    '- If it is a short answer like a place, time, name, topic, option, or confirmation, use the previous assistant message to infer which tool/request it completes.',
    '- Does the user want live/current data, external data, device/app data, or a real action? If yes, use the appropriate tool instead of guessing.',
    '- Does the user want multiple independent things? If yes, return multiple toolCalls when possible.',
    '- Are all required parameters available from the latest message, history, currentDateTimeISO, currentLocationLabel, or previous tool results?',
    '- If required parameters are missing, first check the compact index of other available tools. If another tool may obtain the missing data, choose request_more_tool_manifests instead of asking the user.',
    '- Do not ask the user for app/system permissions before using tools. If a tool needs OS permission, call the tool; the tool/runtime will ask the user and return success or failure.',
    '- Ask the user a clarification only when the missing information cannot reasonably be obtained by another available tool or previous results.',
    '- If previous tool results are sufficient, choose respond and answer using those results.',
    '- A helper/intermediate result is NOT a final answer unless it directly satisfies the user request. Coordinates, identifiers, playlist IDs, calendar IDs, file IDs, or raw search candidates usually must be used in a follow-up tool call before responding.',
    '- If you gathered missing data with a helper tool, continue with the original target tool instead of responding with only the helper result.',
    '- If the latest user message is only punctuation or otherwise ambiguous, do not invent new tool parameters. Continue an unfinished tool workflow only if the existing history/tool results make the next action unambiguous; otherwise ask a short clarification.',
    '- If a previous tool failed, either ask for corrected information or call a corrected tool request; do not repeat the same failed call unchanged.',
    '',
    'CRITICAL separation rules:',
    '- text is only for user-visible natural language.',
    '- toolCalls is the only place for tool calls.',
    '- NEVER put CALL, function_name(...), JSON tool calls, markdown code tool calls, or internal tool syntax in text.',
    '- NEVER claim you checked, found, created, updated, deleted, or fetched something unless a successful tool result is already present.',
    '- NEVER invent tool results. If the answer depends on a tool, call the tool first.',
    '- If you choose respond_and_call_tools, the text must be only a brief acknowledgement such as “Checking now...” or “I will check that.”',
    '',
    'Tool-call rules:',
    '- Use only detailed tools listed in the detailed manifest for toolCalls.',
    '- For tools that appear only in the compact index, do not call them yet. Choose request_more_tool_manifests and put their names in requestedTools.',
    '- Use internal tool names exactly as listed in the manifest.',
    '- Use at most 3 tool calls in one round.',
    '- Normalize aliases to the tool name listed in the manifest. For example, Wikipedia lookup must use cityInfo, not wikiLookup.',
    '- Fill paramsJson from the whole conversation context, not only the latest message.',
    '- Never call a tool with placeholder values such as unknown, unspecified, not provided, missing, or לא צוין. If a required parameter is missing, request more tool manifests for a helper tool or ask a concise clarification only when no tool can obtain it.',
    '- Return ALL tool parameters in paramsJson as a valid JSON object string. Do not output a params object; the schema intentionally uses paramsJson only.',
    '- For runtime-discovered external skills, paramsJson must include action plus script parameters as flat fields. If the selected script itself has a parameter named action, put that script parameter inside a nested object field named scriptParams.',
    '',
    await buildPlannerToolManifestPrompt({
      userMessage: input.userMessage,
      language: input.language,
      currentDateTimeISO: input.currentDateTimeISO,
      currentLocationLabel: input.currentLocationLabel,
      chatHistory: input.chatHistory,
      toolResults: input.toolResults,
      extraDetailedTools: input.extraDetailedTools,
    }, aiProvider),
    '',
    `Current date/time ISO: ${input.currentDateTimeISO}`,
    '',
    'Recent conversation history:',
    history || '(none)',
    '',
    'Previous tool results in this agent run:',
    toolResults || '(none)',
    '',
    'Latest user message:',
    input.userMessage || '(empty)',
    '',
    'Return ONLY structured data matching the schema. Do not include markdown, prose outside the schema, or any hidden reasoning.',
  ].join('\n')
}


function extractStructuredJsonFromError<T>(value: unknown): T | null {
  const text = String(value || '').trim()
  if (!text) return null

  const candidates: string[] = []

  const outputMatch = text.match(/<output>\s*([\s\S]*?)\s*<\/output>/i)
  if (outputMatch?.[1]) candidates.push(outputMatch[1])

  const fencePattern = /```(?:json)?\s*([\s\S]*?)\s*```/gi
  let fenceMatch: RegExpExecArray | null
  while ((fenceMatch = fencePattern.exec(text)) !== null) {
    if (fenceMatch[1]) candidates.push(fenceMatch[1])
  }

  candidates.push(text)

  for (const candidate of candidates) {
    const jsonText = extractBalancedJson(candidate)
    if (!jsonText) continue

    try {
      const parsed = JSON.parse(jsonText)
      if (parsed && typeof parsed === 'object') return parsed as T
    } catch {
      // Try the next candidate.
    }
  }

  return null
}

function extractBalancedJson(value: string): string | null {
  const text = String(value || '').trim()
  if (!text) return null

  const direct = stripCodeFence(text)
  if ((direct.startsWith('{') && direct.endsWith('}')) || (direct.startsWith('[') && direct.endsWith(']'))) {
    return direct
  }

  const object = extractBalancedJsonFrom(text, '{', '}')
  if (object) return object

  return extractBalancedJsonFrom(text, '[', ']')
}

function stripCodeFence(value: string): string {
  return String(value || '')
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim()
}

function extractBalancedJsonFrom(value: string, open: string, close: string): string | null {
  const text = stripCodeFence(value)
  const start = text.indexOf(open)
  if (start < 0) return null

  let depth = 0
  let inString = false
  let escaped = false

  for (let i = start; i < text.length; i++) {
    const ch = text[i]

    if (inString) {
      if (escaped) {
        escaped = false
      } else if (ch === '\\') {
        escaped = true
      } else if (ch === '"') {
        inString = false
      }
      continue
    }

    if (ch === '"') {
      inString = true
      continue
    }

    if (ch === open) depth++
    if (ch === close) depth--

    if (depth === 0) {
      return text.slice(start, i + 1)
    }
  }

  return null
}

function normalizePlannedAction(raw: AgentActionRaw | null | undefined): PlannedAgentAction {
  const initialText = String(raw?.text || '').trim()
  const explicitToolCalls = normalizeToolCalls(raw?.toolCalls || [])
  const recoveredToolCalls = recoverPseudoToolCallsFromText(initialText)
  const toolCalls = dedupeToolCalls([...explicitToolCalls, ...recoveredToolCalls])
  const requestedTools = normalizeRequestedTools(raw?.requestedTools || [])

  // If the model accidentally wrote fake tool syntax in text, strip it before
  // it can be displayed to the user. This is a safety net; the prompt should
  // prevent it, but user-facing text must stay clean even when the model slips.
  const text = stripPseudoToolCallText(initialText).trim()

  const action = normalizeActionKind(raw?.action, text, toolCalls.length, requestedTools.length)
  const confidence = clampNumber(raw?.confidence, 0, 1, toolCalls.length > 0 || requestedTools.length > 0 || text ? 0.8 : 0.4)

  return {
    action,
    text,
    toolCalls,
    requestedTools,
    reason: String(raw?.reason || '').trim(),
    confidence,
  }
}

function normalizeActionKind(
  rawAction: unknown,
  text: string,
  toolCallCount: number,
  requestedToolCount: number
): AgentActionKind {
  const raw = String(rawAction || '').trim()

  if (raw === 'request_more_tool_manifests' || raw === 'request_more_tools' || raw === 'request_tool_manifests' || raw === 'load_more_tool_manifests') {
    if (requestedToolCount > 0) return 'request_more_tool_manifests'
    if (toolCallCount > 0) return text ? 'respond_and_call_tools' : 'call_tools'
    return text ? 'respond' : 'none'
  }
  if (raw === 'respond') return toolCallCount > 0 ? (text ? 'respond_and_call_tools' : 'call_tools') : 'respond'
  if (raw === 'respond_and_call_tools') return toolCallCount > 0 ? 'respond_and_call_tools' : 'respond'
  if (raw === 'call_tools') return toolCallCount > 0 ? 'call_tools' : (requestedToolCount > 0 ? 'request_more_tool_manifests' : (text ? 'respond' : 'none'))
  if (raw === 'none') return text || toolCallCount > 0 || requestedToolCount > 0
    ? (requestedToolCount > 0 ? 'request_more_tool_manifests' : (toolCallCount > 0 ? (text ? 'respond_and_call_tools' : 'call_tools') : 'respond'))
    : 'none'

  // Robust fallback when the model emits a near-valid shape but not the exact action string.
  if (requestedToolCount > 0) return 'request_more_tool_manifests'
  if (text && toolCallCount > 0) return 'respond_and_call_tools'
  if (toolCallCount > 0) return 'call_tools'
  if (text) return 'respond'
  return 'none'
}

function normalizeRequestedTools(rawTools: Array<string | { tool?: string; reason?: string }>): AgentToolName[] {
  const output: AgentToolName[] = []
  const seen = new Set<AgentToolName>()

  for (const item of rawTools.slice(0, 5)) {
    const rawName = typeof item === 'string' ? item : item?.tool
    const tool = normalizeAgentToolName(rawName)
    if (!tool || seen.has(tool)) continue
    seen.add(tool)
    output.push(tool)
  }

  return output
}

function normalizeToolCalls(rawCalls: Array<{
  tool?: string
  reason?: string
  params?: Record<string, unknown>
  paramsJson?: string
}>): AgentToolCall[] {
  const calls: AgentToolCall[] = []

  for (const raw of rawCalls.slice(0, 3)) {
    const tool = normalizeAgentToolName(raw?.tool)
    if (!tool) continue

    const paramsFromObject = raw?.params && typeof raw.params === 'object'
      ? raw.params
      : {}
    const paramsFromJson = parseParamsJson(raw?.paramsJson)

    calls.push({
      tool,
      params: {
        ...paramsFromJson,
        ...paramsFromObject,
      },
      reason: String(raw?.reason || '').trim(),
    })
  }

  return calls
}

function parseParamsJson(value: unknown): Record<string, unknown> {
  const raw = String(value || '').trim()
  if (!raw) return {}

  try {
    const parsed = JSON.parse(raw)
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
      ? parsed as Record<string, unknown>
      : {}
  } catch {
    return {}
  }
}

function recoverPseudoToolCallsFromText(text: string): AgentToolCall[] {
  if (!text) return []

  const calls: AgentToolCall[] = []
  const knownNames = getKnownToolNamesAndAliases()
    .map(escapeRegExp)
    .join('|')

  if (!knownNames) return []

  // Recover common accidental forms such as:
  // CALL: weather(location="Jerusalem")
  // **CALL**: `cityInfo(query='Einstein')`
  // reminder({"title":"Call Daniel","dueDateText":"tomorrow"})
  const fnPattern = new RegExp(`(?:CALL\\s*:?\\s*)?(${knownNames})\\s*\\(([^)]*)\\)`, 'gi')
  let match: RegExpExecArray | null

  while ((match = fnPattern.exec(text)) !== null && calls.length < 3) {
    const tool = normalizeAgentToolName(match[1])
    if (!tool) continue

    const rawArgs = match[2] || ''
    const params = parseFunctionLikeArgs(rawArgs)

    calls.push({
      tool,
      params,
      reason: 'Recovered structured tool call from accidental tool-call text.',
    })
  }

  return calls
}

function parseFunctionLikeArgs(rawArgs: string): Record<string, unknown> {
  const args = rawArgs.trim()
  if (!args) return {}

  // JSON object inside parentheses.
  if (args.startsWith('{') && args.endsWith('}')) {
    try {
      const parsed = JSON.parse(args)
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed)
        ? parsed as Record<string, unknown>
        : {}
    } catch {
      // Continue to named argument parsing.
    }
  }

  const params: Record<string, unknown> = {}
  const pairPattern = /([a-zA-Z_][a-zA-Z0-9_]*)\s*[:=]\s*("[^"]*"|'[^']*'|[^,]+)/g
  let match: RegExpExecArray | null

  while ((match = pairPattern.exec(args)) !== null) {
    const key = match[1]
    let value = (match[2] || '').trim()
    value = value.replace(/^['"]|['"]$/g, '')
    if (key) params[key] = value
  }

  return params
}

function stripPseudoToolCallText(text: string): string {
  if (!text) return ''

  const knownNames = getKnownToolNamesAndAliases()
    .map(escapeRegExp)
    .join('|')

  if (!knownNames) return text.trim()

  let cleaned = text

  // Remove lines that expose internal tool call syntax.
  const fullLinePattern = new RegExp('^\\s*(?:\\*\\*\\s*)?CALL(?:\\s*\\*\\*)?\\s*:?`?[^\\n]*`?\\s*$', 'gim')
  cleaned = cleaned.replace(fullLinePattern, '')

  const fnLinePattern = new RegExp('^\\s*`?(?:' + knownNames + ')\\s*\\([^\\n]*\\)`?\\s*$', 'gim')
  cleaned = cleaned.replace(fnLinePattern, '')

  // If a function-like tool call is embedded in a sentence, remove just that call.
  const embeddedFnPattern = new RegExp('`?(?:' + knownNames + ')\\s*\\([^)]*\\)`?', 'gi')
  cleaned = cleaned.replace(embeddedFnPattern, '')

  return cleaned
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

function dedupeToolCalls(calls: AgentToolCall[]): AgentToolCall[] {
  const seen = new Set<string>()
  const deduped: AgentToolCall[] = []

  for (const call of calls) {
    const key = `${call.tool}:${JSON.stringify(call.params || {})}`
    if (seen.has(key)) continue
    seen.add(key)
    deduped.push(call)
    if (deduped.length >= 3) break
  }

  return deduped
}

function formatHistory(history: ChatMessage[]): string {
  return history
    .filter(m => (m.role === 'user' || m.role === 'assistant') && !m.isStreaming && String(m.text || '').trim().length > 0)
    .slice(-12)
    .map(m => `${m.role}: ${m.text}`)
    .join('\n')
}

function formatToolResults(results: ToolResultForPlanning[]): string {
  if (!results.length) return ''
  return JSON.stringify(results.slice(-10), null, 2)
}

function clampNumber(
  value: unknown,
  min: number,
  max: number,
  fallback: number
): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  return Math.max(min, Math.min(max, n))
}

function escapeRegExp(value: string): string {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}
