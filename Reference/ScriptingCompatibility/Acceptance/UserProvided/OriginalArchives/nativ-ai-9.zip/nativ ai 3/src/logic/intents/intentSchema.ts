// Pure JS - JSON schema definition for intent classification
// This schema is consumed by the Scripting Assistant's `requestStructuredData` API.
// The shape mirrors Scripting's JSONSchemaObject (a structural type), so this file
// remains pure JS/TS without importing any platform-specific modules.

export const intentClassificationSchema = {
  type: 'object',
  description: 'Classified intent with extracted parameters from a free-form user message.',
  properties: {
    intent: {
      type: 'string',
      required: true,
      description:
        'One of: "weather" (user asks about current/forecast weather), ' +
        '"reminder" (user wants to create a reminder/task), ' +
        '"cityInfo" (user asks for general info about a place, city, or landmark), ' +
        '"chat" (user is making small talk, greeting, or asking a general question), ' +
        '"unknown" (none of the above).',
    },
    confidence: {
      type: 'number',
      required: true,
      description: 'Confidence in the classification, between 0 and 1.',
    },
    weatherLocationName: {
      type: 'string',
      description:
        'If intent is "weather": the location name mentioned by the user, ' +
        'or empty string if no specific location was mentioned (then use current location).',
    },
    weatherUseCurrentLocation: {
      type: 'boolean',
      description:
        'If intent is "weather": true if the user wants weather for their current location, ' +
        'false if they specified a different location.',
    },
    reminderTitle: {
      type: 'string',
      description: 'If intent is "reminder": the short title of the reminder.',
    },
    reminderNotes: {
      type: 'string',
      description: 'If intent is "reminder": optional longer notes, or empty string.',
    },
    reminderDueDateISO: {
      type: 'string',
      description:
        'If intent is "reminder": the due date/time in ISO-8601 format if the user specified one, ' +
        'or empty string if none. Use the provided "currentDateTime" context to resolve relative ' +
        'expressions like "tomorrow at 8" into a concrete ISO timestamp.',
    },
    reminderPriority: {
      type: 'string',
      description:
        'If intent is "reminder": one of "none", "low", "medium", "high" based on user wording. ' +
        'Default to "none" if not specified.',
    },
    cityQuery: {
      type: 'string',
      description:
        'If intent is "cityInfo": the place/city/landmark name to search for ' +
        '(extracted as a clean search term, no extra wording).',
    },
  },
} as const

// The flat shape we receive from the model
export type IntentClassificationRaw = {
  intent: string
  confidence: number
  weatherLocationName?: string
  weatherUseCurrentLocation?: boolean
  reminderTitle?: string
  reminderNotes?: string
  reminderDueDateISO?: string
  reminderPriority?: string
  cityQuery?: string
}
