// src/screens/ChatScreen.tsx

import {
  NavigationSplitView,
  NavigationSplitViewColumn,
  NavigationStack,
  List,
  Section,
  ContentUnavailableView,
  Button,
  Menu,
  Navigation,
  ScrollView,
  VStack,
  ZStack,
  Group,
  HStack,
  Image,
  Text,
  Device,
  useObservable,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'scripting'
import { useApp } from '../context/AppContext'
import { ChatBubble } from '../components/ChatBubble'
import { ToolMessage } from '../components/ToolMessage'
import { SuggestionsList } from '../components/SuggestionsList'
import { ChatInputBar, ComposerFeatureKey, ComposerFeatureSettings } from '../components/ChatInputBar'
import { ChatHistorySidebar } from '../components/ChatHistorySidebar'
import { ChatAttachment, ChatBranchOption, ChatMessage } from '../types/chat'
import { generateId } from '../utils/id'
import { runAgent } from '../logic/agent/agentOrchestrator'
import { getAgentToolCard } from '../tools'
import {
  createAgentLiveActivitySession,
  cancelRunLiveActivity,
} from '../liveActivity'
import type { AgentLiveActivityRunControl } from '../liveActivity'
import { ChatBackgroundId, getChatBackgroundStyle, shouldHideChatScrollBackground } from '../theme/chatBackgrounds'

export function ChatScreen() {
  const dismiss = Navigation.useDismiss()
  const {
    strings,
    locale,
    isRTLLayout,
    chat,
    dispatchChat,
    aiProvider,
    setAIProvider,
    chatBackground,
    chatBackgroundPhotoPath,
    chatSessions,
    currentSessionId,
    chatHistorySearchQuery,
    hasMoreChatSessions,
    startNewChat,
    loadChatSession,
    deleteSession,
    renameSession,
    toggleFavoriteSession,
    setChatHistorySearchQuery,
    loadMoreChatSessions,
    saveCurrentSession,
  } = useApp()

  const isBusy = useObservable(false)
  const [preferredCompactColumn, setPreferredCompactColumn] =
    useState<NavigationSplitViewColumn>('detail')
  const [saveVersion, setSaveVersion] = useState(0)
  const [editingMessage, setEditingMessage] = useState<ChatMessage | null>(null)
  const [pendingAttachments, setPendingAttachments] = useState<ChatAttachment[]>([])
  const pipPresented = useObservable(false)
  const pipStatusText = useObservable(strings.chatEmptyTitle)
  const pipBusyState = useObservable(false)
  const [pipEnabled, setPipEnabled] = useState(() => readComposerFeatureToggle('pip'))
  const [pipDismissedForSession, setPipDismissedForSession] = useState(false)
  const [liveActivityEnabled, setLiveActivityEnabled] = useState(() => readComposerFeatureToggle('liveActivity'))
  const [backgroundNotificationsEnabled, setBackgroundNotificationsEnabled] = useState(() => readComposerFeatureToggle('backgroundNotifications'))
  const activeRunRef = useRef<AgentLiveActivityRunControl | null>(null)

  const requestSessionSave = useCallback(() => {
    setSaveVersion(version => version + 1)
  }, [])


  const composerFeatureSettings: ComposerFeatureSettings = {
    pip: pipEnabled,
    liveActivity: liveActivityEnabled,
    backgroundNotifications: backgroundNotificationsEnabled,
  }

  const hasMessages = chat.messages.length > 0
  const customChatBackground = shouldHideChatScrollBackground(chatBackground)
  const chatBackgroundStyle = getChatBackgroundStyle(chatBackground)
  const chatScrollContentBackground = customChatBackground ? 'hidden' : 'automatic'
  const chatToolbarBackgroundVisibility = customChatBackground
    ? { visibility: 'hidden' as const, bars: ['navigationBar' as const] }
    : 'automatic'

  const updateComposerFeature = useCallback((key: ComposerFeatureKey, enabled: boolean) => {
    writeComposerFeatureToggle(key, enabled)

    switch (key) {
      case 'pip':
        setPipEnabled(enabled)
        setPipDismissedForSession(false)
        if (!enabled) {
          pipPresented.setValue(false)
        }
        break
      case 'liveActivity':
        setLiveActivityEnabled(enabled)
        if (!enabled) {
          cancelRunLiveActivity(activeRunRef.current)
          if (activeRunRef.current) {
            activeRunRef.current.liveActivity = null
          }
        }
        break
      case 'backgroundNotifications':
        setBackgroundNotificationsEnabled(enabled)
        break
    }
  }, [pipPresented])

  const handlePipStopped = useCallback(() => {
    setPipDismissedForSession(true)
    pipPresented.setValue(false)
  }, [pipPresented])

  useEffect(() => {
    const shouldPresentPip = pipEnabled && hasMessages && !pipDismissedForSession
    pipPresented.setValue(shouldPresentPip)
  }, [pipEnabled, hasMessages, pipDismissedForSession, pipPresented])

  useEffect(() => {
    setPipDismissedForSession(false)
  }, [currentSessionId])

  useEffect(() => {
    return () => {
      pipPresented.setValue(false)
    }
  }, [pipPresented])

  useEffect(() => {
    if (saveVersion === 0) return
    saveCurrentSession()
  }, [saveVersion])

  useEffect(() => {
    const nextBusy = isBusy.value
    pipBusyState.setValue(nextBusy)
    pipStatusText.setValue(buildPipStatusText(chat.messages, nextBusy, strings.thinking, strings.chatEmptyTitle))
  }, [chat.messages, isBusy.value, strings.thinking, strings.chatEmptyTitle])

  const runAssistantReply = useCallback(async (
    userText: string,
    assistantId: string,
    historyMessages: ChatMessage[],
    attachments: ChatAttachment[] = []
  ) => {
    const runControl: AgentLiveActivityRunControl = { cancelled: false, liveActivity: null }
    let streamedText = ''
    let liveActivityFinished = false
    activeRunRef.current = runControl
    isBusy.setValue(true)
    pipBusyState.setValue(true)
    pipStatusText.setValue(strings.thinking)

    try {
      runControl.liveActivity = await createAgentLiveActivitySession({
        enabled: liveActivityEnabled,
        userText,
        locale,
      })

      await runAgent(
        {
          userMessage: userText,
          language: locale,
          currentLocationLabel: null,
          aiProvider: aiProvider !== 'app_default' ? aiProvider : undefined,
          chatHistory: historyMessages,
          attachments,
          shouldCancel: () => runControl.cancelled,
        },
        {
          onIntent: (intent) => {
            if (runControl.cancelled) return
            dispatchChat({ type: 'setIntent', id: assistantId, intent })
          },
          onToolPayload: (payload) => {
            if (runControl.cancelled) return
            runControl.liveActivity?.setToolPayload(payload)
            dispatchChat({ type: 'setToolPayload', id: assistantId, payload })
          },
          onToolStart: (run) => {
            if (runControl.cancelled) return
            runControl.liveActivity?.setToolStart(run)
            pipStatusText.setValue(formatToolRunPipStatus(run))
            dispatchChat({ type: 'addToolRun', id: assistantId, run })
          },
          onToolFinish: (runId, patch) => {
            if (runControl.cancelled) return
            runControl.liveActivity?.setToolFinish(runId, patch)
            pipStatusText.setValue(strings.thinking)
            dispatchChat({ type: 'updateToolRun', id: assistantId, runId, patch })
          },
          onToolStatusText: (text) => {
            if (runControl.cancelled) return
            const statusText = normalizeAgentStatusText(text, strings.thinking)
            if (text != null) {
              runControl.liveActivity?.setThinking(statusText)
            }
            pipStatusText.setValue(trimPipText(statusText))
            dispatchChat({ type: 'setToolStatusText', id: assistantId, text: text == null ? null : statusText })
          },
          onTextChunk: (chunk) => {
            if (runControl.cancelled) return
            streamedText += chunk
            runControl.liveActivity?.setAnswerPreview(streamedText)
            pipStatusText.setValue(trimPipText(streamedText))
            dispatchChat({ type: 'appendText', id: assistantId, chunk })
          },
          onDone: () => {
            if (runControl.cancelled) return
            liveActivityFinished = true
            runControl.liveActivity?.finish(streamedText)
            pipBusyState.setValue(false)
            if (streamedText.trim()) {
              pipStatusText.setValue(trimPipText(streamedText))
            }
            dispatchChat({ type: 'finishStreaming', id: assistantId })
            requestSessionSave()
          },
          onError: (err) => {
            if (runControl.cancelled) return
            const errMsg = err instanceof Error ? err.message : strings.unknownError
            liveActivityFinished = true
            runControl.liveActivity?.fail(errMsg)
            pipStatusText.setValue(trimPipText(`${strings.error}: ${errMsg}`))
            dispatchChat({
              type: 'replaceText',
              id: assistantId,
              text: `${strings.error}: ${errMsg}`,
            })
            dispatchChat({ type: 'finishStreaming', id: assistantId })
            requestSessionSave()
          },
        }
      )
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : strings.unknownError
      liveActivityFinished = true
      runControl.liveActivity?.fail(errMsg)
      pipStatusText.setValue(trimPipText(`${strings.error}: ${errMsg}`))
      dispatchChat({
        type: 'replaceText',
        id: assistantId,
        text: `${strings.error}: ${errMsg}`,
      })
      dispatchChat({ type: 'finishStreaming', id: assistantId })
    } finally {
      if (runControl.cancelled) {
        runControl.liveActivity?.cancel()
      } else if (!liveActivityFinished && streamedText.trim()) {
        runControl.liveActivity?.finish(streamedText)
      }

      if (activeRunRef.current === runControl) {
        activeRunRef.current = null
      }
      isBusy.setValue(false)
      pipBusyState.setValue(false)
      if (!runControl.cancelled && streamedText.trim()) {
        pipStatusText.setValue(trimPipText(streamedText))
      }
      requestSessionSave()
    }
  }, [isBusy, locale, strings, dispatchChat, requestSessionSave, aiProvider, pipBusyState, pipStatusText, liveActivityEnabled])

  const sendMessage = useCallback(async (userText: string) => {
    const trimmedText = userText.trim()
    if ((!trimmedText && pendingAttachments.length === 0) || isBusy.value) return

    const attachments = pendingAttachments
    const userTextForModel = trimmedText || strings.analyzeAttachments
    const userMsg: ChatMessage = createUserMessage(trimmedText, attachments)
    const assistantId = generateId('msg')
    const assistantMsg = createAssistantMessage(assistantId)
    const historyMessages = chat.messages

    dispatchChat({ type: 'add', message: userMsg })
    dispatchChat({ type: 'add', message: assistantMsg })
    setPendingAttachments([])
    requestSessionSave()

    await runAssistantReply(userTextForModel, assistantId, historyMessages, attachments)
  }, [isBusy, pendingAttachments, locale, chat.messages, dispatchChat, requestSessionSave, runAssistantReply])


  const stopActiveResponse = useCallback(() => {
    const active = activeRunRef.current
    if (!active) return
    active.cancelled = true
    active.liveActivity?.cancel()
    active.liveActivity = null
    const lastStreamingAssistant = [...chat.messages]
      .reverse()
      .find(message => message.role === 'assistant' && message.isStreaming)
    if (lastStreamingAssistant) {
      dispatchChat({ type: 'finishStreaming', id: lastStreamingAssistant.id })
    }
    isBusy.setValue(false)
    pipBusyState.setValue(false)
    pipStatusText.setValue(latestAssistantText(chat.messages, strings.chatEmptyTitle))
    requestSessionSave()
  }, [chat.messages, dispatchChat, isBusy, requestSessionSave, pipBusyState, pipStatusText, strings.chatEmptyTitle])

  const addAttachments = useCallback((items: ChatAttachment[]) => {
    if (items.length === 0) return
    setPendingAttachments(current => [...current, ...items])
  }, [])

  const pickFilesForMessage = useCallback(async () => {
    if (isBusy.value) return
    try {
      const paths = await DocumentPicker.pickFiles({ allowsMultipleSelection: true })
      const items = (paths || [])
        .map(path => buildAttachmentFromFile(path))
        .filter((item): item is ChatAttachment => item != null)
      addAttachments(items)
    } catch (error) {
      console.log('Failed to pick files:', String(error))
    }
  }, [isBusy, addAttachments])

  const pickPhotosForMessage = useCallback(async () => {
    if (isBusy.value) return
    try {
      const photos = await Photos.pickPhotos(8)
      const items = (photos || [])
        .map((image, index) => buildAttachmentFromImage(image, `Photo ${index + 1}.jpg`))
        .filter((item): item is ChatAttachment => item != null)
      addAttachments(items)
    } catch (error) {
      console.log('Failed to pick photos:', String(error))
    }
  }, [isBusy, addAttachments])

  const takePhotoForMessage = useCallback(async () => {
    if (isBusy.value) return
    try {
      const image = await Photos.takePhoto()
      const item = image ? buildAttachmentFromImage(image, 'Camera photo.jpg') : null
      if (item) addAttachments([item])
    } catch (error) {
      console.log('Failed to take photo:', String(error))
    }
  }, [isBusy, addAttachments])

  const removePendingAttachment = useCallback((id: string) => {
    setPendingAttachments(current => current.filter(item => item.id !== id))
  }, [])

  const clearChat = useCallback(async () => {
    const confirmed = await Dialog.confirm({
      title: strings.clearChatConfirmationTitle,
      message: strings.clearChatConfirmationMessage,
      cancelLabel: strings.cancel,
      confirmLabel: strings.clearChat,
    })

    if (!confirmed) return

    setEditingMessage(null)
    dispatchChat({ type: 'clear' })
    requestSessionSave()
  }, [dispatchChat, requestSessionSave, strings])

  const handleNewChat = useCallback(() => {
    setEditingMessage(null)
    startNewChat()
    setPreferredCompactColumn('detail')
  }, [startNewChat])

  const handleLoadSession = useCallback((sessionId: string) => {
    setEditingMessage(null)
    loadChatSession(sessionId)
    setPreferredCompactColumn('detail')
  }, [loadChatSession])

  const beginMessageEdit = useCallback((message: ChatMessage) => {
    if (isBusy.value || message.role !== 'user' || message.isStreaming) return
    setEditingMessage(message)
  }, [isBusy])

  const cancelMessageEdit = useCallback(() => {
    setEditingMessage(null)
  }, [])

  const saveEditedMessage = useCallback(async (nextText: string) => {
    const target = editingMessage
    const trimmedText = nextText.trim()
    if (!target || !trimmedText || isBusy.value) return

    const currentMessages = chat.messages
    const editIndex = currentMessages.findIndex(message => message.id === target.id)
    if (editIndex < 0) {
      setEditingMessage(null)
      return
    }

    const currentMessage = currentMessages[editIndex]
    if (currentMessage.role !== 'user' || currentMessage.isStreaming) {
      setEditingMessage(null)
      return
    }

    if (trimmedText === currentMessage.text.trim()) {
      setEditingMessage(null)
      return
    }

    const prefix = currentMessages.slice(0, editIndex)
    const branchGroupId = currentMessage.branchGroupId || currentMessage.id
    const previousActiveBranchId =
      currentMessage.activeBranchId || currentMessage.branchOptions?.[0]?.id || generateId('branch')
    const previousBranchMessages = stripBranchNavigationFromMessages(currentMessages.slice(editIndex))

    const existingBranchOptions = currentMessage.branchOptions && currentMessage.branchOptions.length > 0
      ? currentMessage.branchOptions
      : [
          createBranchOption(
            previousActiveBranchId,
            currentMessage.text,
            currentMessage.createdAt,
            previousBranchMessages
          ),
        ]

    let refreshedBranchOptions = existingBranchOptions.map(option =>
      option.id === previousActiveBranchId
        ? createBranchOption(
            option.id,
            currentMessage.text,
            currentMessage.createdAt,
            previousBranchMessages
          )
        : option
    )

    if (!refreshedBranchOptions.some(option => option.id === previousActiveBranchId)) {
      refreshedBranchOptions = [
        createBranchOption(
          previousActiveBranchId,
          currentMessage.text,
          currentMessage.createdAt,
          previousBranchMessages
        ),
        ...refreshedBranchOptions,
      ]
    }

    const editedBranchId = generateId('branch')
    const assistantId = generateId('msg')
    const editedUserMessage: ChatMessage = {
      ...createUserMessage(trimmedText),
      editedFromId: currentMessage.id,
      branchGroupId,
      activeBranchId: editedBranchId,
      branchOptions: null,
    }
    const assistantMessage = createAssistantMessage(assistantId)
    const editedBranchMessages = stripBranchNavigationFromMessages([
      editedUserMessage,
      assistantMessage,
    ])

    const branchOptions = [
      ...refreshedBranchOptions,
      createBranchOption(
        editedBranchId,
        trimmedText,
        editedUserMessage.createdAt,
        editedBranchMessages
      ),
    ]

    const nextMessages = [
      ...prefix,
      {
        ...editedUserMessage,
        branchOptions,
        activeBranchId: editedBranchId,
      },
      assistantMessage,
    ]

    setEditingMessage(null)
    dispatchChat({ type: 'replaceAll', messages: nextMessages })
    requestSessionSave()

    await runAssistantReply(trimmedText, assistantId, prefix)
  }, [editingMessage, isBusy, chat.messages, dispatchChat, requestSessionSave, runAssistantReply])

  const regenerateAssistantResponse = useCallback(async (assistantMessage: ChatMessage) => {
    if (isBusy.value || assistantMessage.role !== 'assistant' || assistantMessage.isStreaming) return

    const currentMessages = chat.messages
    const assistantIndex = currentMessages.findIndex(message => message.id === assistantMessage.id)
    if (assistantIndex <= 0) return

    const userIndex = findPreviousUserMessageIndex(currentMessages, assistantIndex)
    if (userIndex < 0) return

    const currentMessage = currentMessages[userIndex]
    if (currentMessage.role !== 'user' || currentMessage.isStreaming) return

    const prefix = currentMessages.slice(0, userIndex)
    const attachments = currentMessage.attachments || []
    const userTextForModel = currentMessage.text.trim() || strings.analyzeAttachments
    const branchGroupId = currentMessage.branchGroupId || currentMessage.id
    const previousActiveBranchId =
      currentMessage.activeBranchId || currentMessage.branchOptions?.[0]?.id || generateId('branch')
    const previousBranchMessages = stripBranchNavigationFromMessages(currentMessages.slice(userIndex))

    const existingBranchOptions = currentMessage.branchOptions && currentMessage.branchOptions.length > 0
      ? currentMessage.branchOptions
      : [
          createBranchOption(
            previousActiveBranchId,
            currentMessage.text,
            currentMessage.createdAt,
            previousBranchMessages
          ),
        ]

    let refreshedBranchOptions = existingBranchOptions.map(option =>
      option.id === previousActiveBranchId
        ? createBranchOption(
            option.id,
            currentMessage.text,
            currentMessage.createdAt,
            previousBranchMessages
          )
        : option
    )

    if (!refreshedBranchOptions.some(option => option.id === previousActiveBranchId)) {
      refreshedBranchOptions = [
        createBranchOption(
          previousActiveBranchId,
          currentMessage.text,
          currentMessage.createdAt,
          previousBranchMessages
        ),
        ...refreshedBranchOptions,
      ]
    }

    const regeneratedBranchId = generateId('branch')
    const assistantId = generateId('msg')
    const regeneratedUserMessage: ChatMessage = {
      ...createUserMessage(currentMessage.text, attachments),
      branchGroupId,
      activeBranchId: regeneratedBranchId,
      branchOptions: null,
    }
    const assistantReply = createAssistantMessage(assistantId)
    const regeneratedBranchMessages = stripBranchNavigationFromMessages([
      regeneratedUserMessage,
      assistantReply,
    ])

    const branchOptions = [
      ...refreshedBranchOptions,
      createBranchOption(
        regeneratedBranchId,
        currentMessage.text,
        regeneratedUserMessage.createdAt,
        regeneratedBranchMessages
      ),
    ]

    const nextMessages = [
      ...prefix,
      {
        ...regeneratedUserMessage,
        branchOptions,
        activeBranchId: regeneratedBranchId,
      },
      assistantReply,
    ]

    setEditingMessage(null)
    dispatchChat({ type: 'replaceAll', messages: nextMessages })
    requestSessionSave()

    await runAssistantReply(userTextForModel, assistantId, prefix, attachments)
  }, [isBusy, chat.messages, dispatchChat, requestSessionSave, runAssistantReply, strings.analyzeAttachments])

  const activateBranch = useCallback((message: ChatMessage, branchId: string) => {
    if (isBusy.value) return

    const currentMessages = chat.messages
    const branchIndex = currentMessages.findIndex(item => item.id === message.id)
    if (branchIndex < 0) return

    const branchPoint = currentMessages[branchIndex]
    const options = branchPoint.branchOptions || []
    if (options.length <= 1) return

    const activeBranchId = branchPoint.activeBranchId || options[0]?.id
    const currentBranchMessages = stripBranchNavigationFromMessages(currentMessages.slice(branchIndex))
    const currentBranchOption = createBranchOption(
      activeBranchId || generateId('branch'),
      branchPoint.text,
      branchPoint.createdAt,
      currentBranchMessages
    )

    let refreshedOptions = options.map(option =>
      option.id === currentBranchOption.id ? currentBranchOption : option
    )

    if (!refreshedOptions.some(option => option.id === currentBranchOption.id)) {
      refreshedOptions = [currentBranchOption, ...refreshedOptions]
    }

    const selectedOption = refreshedOptions.find(option => option.id === branchId)
    if (!selectedOption) return

    const selectedMessages = stripBranchNavigationFromMessages(selectedOption.messages)
    if (selectedMessages.length === 0) return

    const branchGroupId = branchPoint.branchGroupId || branchPoint.id
    const activatedMessages = [
      {
        ...selectedMessages[0],
        branchGroupId,
        activeBranchId: selectedOption.id,
        branchOptions: refreshedOptions,
      },
      ...selectedMessages.slice(1),
    ]

    setEditingMessage(null)
    dispatchChat({
      type: 'replaceAll',
      messages: [
        ...currentMessages.slice(0, branchIndex),
        ...activatedMessages,
      ],
    })
    requestSessionSave()
  }, [isBusy, chat.messages, dispatchChat, requestSessionSave])

  const emptyStateKey = `${currentSessionId}:${locale}:empty`

  const trailingToolbarItems = hasMessages
    ? [
        <Button
          title={strings.newChat}
          systemImage="square.and.pencil"
          action={handleNewChat}
          disabled={isBusy.value}
        />,
        <Menu
          title={strings.messageActions}
          systemImage="ellipsis.circle"
        >
          <Button
            title={strings.clearChat}
            systemImage="trash"
            role="destructive"
            action={clearChat}
            disabled={isBusy.value}
          />
        </Menu>,
      ]
    : [
        <Button
          title={strings.newChat}
          systemImage="square.and.pencil"
          action={handleNewChat}
          disabled={isBusy.value}
        />,
      ]

  const pipContent = (
    <ChatPipView
      title={strings.appName}
      status={pipStatusText}
      isBusy={pipBusyState}
      onStop={handlePipStopped}
    />
  )

  return (
    <NavigationSplitView
      preferredCompactColumn={{
        value: preferredCompactColumn,
        onChanged: setPreferredCompactColumn,
      }}
      sidebar={
        <ChatHistorySidebar
          sessions={chatSessions}
          currentSessionId={currentSessionId}
          searchQuery={chatHistorySearchQuery}
          hasMoreSessions={hasMoreChatSessions}
          onSearchChange={setChatHistorySearchQuery}
          onLoadMore={loadMoreChatSessions}
          onSelect={handleLoadSession}
          onDelete={deleteSession}
          onRename={renameSession}
          onToggleFavorite={toggleFavoriteSession}
          onNewChat={handleNewChat}
          onClose={dismiss}
          strings={strings}
          locale={locale}
          isBusy={isBusy.value}
        />
      }
    >
      <NavigationStack>
        <ZStack
          frame={{
            maxWidth: 'infinity',
            maxHeight: 'infinity',
          }}
          background={
            <ChatBackgroundLayer
              background={chatBackground}
              photoPath={chatBackgroundPhotoPath}
              fallbackStyle={chatBackgroundStyle}
            />
          }
        >
          {!hasMessages ? (
          <List
            navigationTitle={strings.appName}
            background={chatBackgroundStyle}
            scrollContentBackground={chatScrollContentBackground}
            toolbarBackgroundVisibility={chatToolbarBackgroundVisibility}
            pip={{
              isPresented: pipPresented,
              maximumUpdatesPerSecond: 4,
              content: pipContent,
            }}
            toolbar={{
              topBarTrailing: trailingToolbarItems,
            }}
            safeAreaInset={{
              bottom: {
                content: (
                  <ChatInputBar
                    strings={strings}
                    locale={locale}
                    isBusy={isBusy.value}
                    editingMessage={editingMessage}
                    attachments={pendingAttachments}
                    aiProvider={aiProvider}
                    featureSettings={composerFeatureSettings}
                    onSend={sendMessage}
                    onSaveEdit={saveEditedMessage}
                    onCancelEdit={cancelMessageEdit}
                    onStop={stopActiveResponse}
                    onPickFiles={pickFilesForMessage}
                    onPickPhotos={pickPhotosForMessage}
                    onTakePhoto={takePhotoForMessage}
                    onRemoveAttachment={removePendingAttachment}
                    onAIProviderChange={setAIProvider}
                    onToggleFeature={updateComposerFeature}
                  />
                ),
              },
            }}
          >
            <Section key={`${emptyStateKey}:content`}>
              <ContentUnavailableView
                title={strings.chatEmptyTitle}
                systemImage="sparkles"
                description={strings.chatEmptySubtitle}
              />
            </Section>

            <Section
              key={`${emptyStateKey}:suggestions`}
              title={strings.suggestionsTitle}
            >
              <SuggestionsList
                key={`${emptyStateKey}:list`}
                strings={strings}
                isBusy={isBusy.value}
                sessionId={currentSessionId}
                onPick={sendMessage}
              />
            </Section>
          </List>
        ) : (
          <ScrollView
            navigationTitle={strings.appName}
            background={chatBackgroundStyle}
            scrollContentBackground={chatScrollContentBackground}
            toolbarBackgroundVisibility={chatToolbarBackgroundVisibility}
            pip={{
              isPresented: pipPresented,
              maximumUpdatesPerSecond: 4,
              content: pipContent,
            }}
            toolbar={{
              topBarTrailing: trailingToolbarItems,
            }}
            safeAreaInset={{
              bottom: {
                content: (
                  <ChatInputBar
                    strings={strings}
                    locale={locale}
                    isBusy={isBusy.value}
                    editingMessage={editingMessage}
                    attachments={pendingAttachments}
                    aiProvider={aiProvider}
                    featureSettings={composerFeatureSettings}
                    onSend={sendMessage}
                    onSaveEdit={saveEditedMessage}
                    onCancelEdit={cancelMessageEdit}
                    onStop={stopActiveResponse}
                    onPickFiles={pickFilesForMessage}
                    onPickPhotos={pickPhotosForMessage}
                    onTakePhoto={takePhotoForMessage}
                    onRemoveAttachment={removePendingAttachment}
                    onAIProviderChange={setAIProvider}
                    onToggleFeature={updateComposerFeature}
                  />
                ),
              },
            }}
          >
            <VStack spacing={14} padding={{ horizontal: 16, vertical: 12 }}>
              {chat.messages.map((msg, index) => {
                const branchSourceMessage = msg.role === 'assistant'
                  ? findBranchSourceForAssistant(chat.messages, index)
                  : null

                return (
                  <VStack
                    key={msg.id}
                    alignment={msg.role === 'user'
                      ? (isRTLLayout ? 'trailing' : 'leading')
                      : (isRTLLayout ? 'leading' : 'trailing')}
                    frame={{
                      maxWidth: 'infinity',
                      alignment: msg.role === 'user'
                        ? (isRTLLayout ? 'trailing' : 'leading')
                        : (isRTLLayout ? 'leading' : 'trailing'),
                    }}
                    spacing={8}
                  >
                    <ChatBubble
                      message={msg}
                      strings={strings}
                      locale={locale}
                      isRTL={isRTLLayout}
                      onEdit={beginMessageEdit}
                      onActivateBranch={activateBranch}
                      onRegenerate={regenerateAssistantResponse}
                      branchSourceMessage={branchSourceMessage}
                    />

                    {msg.toolPayload && getAgentToolCard(msg.toolPayload.kind) ? (
                      <ToolMessage
                        payload={msg.toolPayload}
                        strings={strings}
                        locale={locale}
                      />
                    ) : (
                      <Group />
                    )}
                  </VStack>
                )
              })}
            </VStack>
          </ScrollView>
          )}
        </ZStack>
      </NavigationStack>
    </NavigationSplitView>
  )
}


type StoredComposerFeatureKey = ComposerFeatureKey

const COMPOSER_FEATURE_STORAGE_KEYS: Record<StoredComposerFeatureKey, string> = {
  pip: 'composer.feature.pip',
  liveActivity: 'composer.feature.liveActivity',
  backgroundNotifications: 'composer.feature.backgroundNotifications',
}

function readComposerFeatureToggle(key: StoredComposerFeatureKey): boolean {
  try {
    return Storage.get<boolean>(COMPOSER_FEATURE_STORAGE_KEYS[key]) === true
  } catch {
    return false
  }
}

function writeComposerFeatureToggle(key: StoredComposerFeatureKey, enabled: boolean): void {
  try {
    Storage.set(COMPOSER_FEATURE_STORAGE_KEYS[key], enabled)
  } catch {
    /* ignore */
  }
}

function normalizeAgentStatusText(text: string | null | undefined, fallback: string): string {
  const clean = String(text || '').trim()
  if (!clean || clean === '__agent_thinking__') return fallback
  return clean
}

function latestAssistantText(messages: ChatMessage[], fallback: string): string {
  const latest = [...messages]
    .reverse()
    .find(message => message.role === 'assistant' && message.text.trim().length > 0)

  return trimPipText(latest?.text.trim() || fallback)
}

function buildPipStatusText(
  messages: ChatMessage[],
  isBusy: boolean,
  thinkingText: string,
  fallback: string
): string {
  const latestAssistant = [...messages]
    .reverse()
    .find(message => message.role === 'assistant')

  if (isBusy) {
    const latestText = latestAssistant?.text?.trim()
    if (latestText) return trimPipText(latestText)

    const toolStatusText = latestAssistant?.toolStatusText?.trim()
    if (toolStatusText) return trimPipText(toolStatusText)

    const runningTool = latestAssistant?.toolRuns
      ?.slice()
      .reverse()
      .find(run => run.status === 'running')
    if (runningTool) return formatToolRunPipStatus(runningTool)

    return thinkingText
  }

  return latestAssistantText(messages, fallback)
}

function trimPipText(text: string): string {
  const normalized = text.replace(/\s+/g, ' ').trim()
  return normalized.length > 140 ? `${normalized.substring(0, 137)}...` : normalized
}

function formatToolRunPipStatus(run: { tool: string; action?: string | null }): string {
  const action = typeof run.action === 'string' && run.action.trim().length > 0
    ? ` · ${run.action.trim()}`
    : ''
  return trimPipText(`${run.tool}${action}`)
}

type ObservableValue<T> = {
  readonly value: T
}

function ChatBackgroundLayer({
  background,
  photoPath,
  fallbackStyle,
}: {
  background: ChatBackgroundId
  photoPath: string | null
  fallbackStyle: any
}) {
  const hasPhoto = background === 'customPhoto' && !!photoPath && safeFileExists(photoPath)

  return (
    <VStack
      frame={{
        maxWidth: 'infinity',
        maxHeight: 'infinity',
      }}
      background={hasPhoto && photoPath
        ? {
            content: (
              <Image
                filePath={photoPath}
                resizable={true}
                scaleToFill={true}
                frame={{
                  maxWidth: 'infinity',
                  maxHeight: 'infinity',
                }}
                clipped={true}
              />
            ),
            alignment: 'center',
          }
        : fallbackStyle
      }
      clipped={true}
      ignoresSafeArea={{
        regions: 'container',
        edges: 'all',
      }}
    />
  )
}


function safeFileExists(path: string): boolean {
  try {
    return FileManager.existsSync(path)
  } catch {
    return false
  }
}

function ChatPipView({
  title,
  status,
  isBusy,
  onStop,
}: {
  title: string
  status: ObservableValue<string>
  isBusy: ObservableValue<boolean>
  onStop: () => void
}) {
  return (
    <HStack
      spacing={10}
      frame={{
        width: Device.screen.width,
        height: 64,
      }}
      padding={{ horizontal: 14, vertical: 8 }}
      background="systemBlue"
      onPipStop={onStop}
      pipShowOnBackground
      pipHideOnForeground={false}
    >
      <Image
        systemName={isBusy.value ? 'sparkles' : 'message.fill'}
        foregroundStyle="white"
        font="headline"
      />
      <VStack alignment="leading" spacing={2}>
        <Text
          font="caption"
          foregroundStyle="white"
          opacity={0.82}
        >
          {title}
        </Text>
        <Text
          font="footnote"
          foregroundStyle="white"
          lineLimit={1}
        >
          {status.value}
        </Text>
      </VStack>
    </HStack>
  )
}


function findPreviousUserMessageIndex(messages: ChatMessage[], beforeIndex: number): number {
  for (let index = beforeIndex - 1; index >= 0; index -= 1) {
    if (messages[index]?.role === 'user') return index
  }

  return -1
}


function findBranchSourceForAssistant(messages: ChatMessage[], assistantIndex: number): ChatMessage | null {
  const previous = messages[assistantIndex - 1]
  if (!previous || previous.role !== 'user') return null
  const options = previous.branchOptions || []
  return options.length > 1 ? previous : null
}

function createUserMessage(text: string, attachments: ChatAttachment[] = []): ChatMessage {
  return {
    id: generateId('msg'),
    role: 'user',
    text,
    attachments,
    toolPayload: null,
    toolRuns: [],
    toolStatusText: null,
    intent: null,
    createdAt: Date.now(),
    isStreaming: false,
  }
}

function createAssistantMessage(id: string): ChatMessage {
  return {
    id,
    role: 'assistant',
    text: '',
    toolPayload: null,
    toolRuns: [],
    toolStatusText: null,
    intent: null,
    createdAt: Date.now(),
    isStreaming: true,
  }
}

function createBranchOption(
  id: string,
  title: string,
  createdAt: number,
  messages: ChatMessage[]
): ChatBranchOption {
  return {
    id,
    title: title.length > 40 ? `${title.substring(0, 37)}...` : title,
    createdAt,
    messages: stripBranchNavigationFromMessages(messages),
  }
}

function stripBranchNavigationFromMessages(messages: ChatMessage[]): ChatMessage[] {
  return messages.map(stripBranchNavigationFromMessage)
}

function stripBranchNavigationFromMessage(message: ChatMessage): ChatMessage {
  const {
    branchOptions,
    activeBranchId,
    ...rest
  } = message

  return {
    ...rest,
    isStreaming: false,
    branchOptions: null,
    activeBranchId: null,
  }
}

function buildAttachmentFromImage(image: UIImage, name: string): ChatAttachment | null {
  const data = Data.fromJPEG(image, 0.82)
  if (!data) return null

  return {
    id: generateId('att'),
    kind: 'image',
    name,
    mediaType: 'image/jpeg',
    data: `data:image/jpeg;base64,${data.toBase64String()}`,
  }
}

function buildAttachmentFromFile(path: string): ChatAttachment | null {
  const data = Data.fromFile(path)
  if (!data) return null

  const mediaType = safeMimeType(path)
  const name = fileNameFromPath(path)
  const base64 = data.toBase64String()
  const isImage = mediaType.startsWith('image/')

  return {
    id: generateId('att'),
    kind: isImage ? 'image' : 'document',
    name,
    mediaType,
    data: isImage
      ? `data:${mediaType};base64,${base64}`
      : base64,
  }
}

function safeMimeType(path: string): string {
  try {
    return FileManager.mimeType(path) || 'application/octet-stream'
  } catch {
    return 'application/octet-stream'
  }
}

function fileNameFromPath(path: string): string {
  const parts = String(path || '').split('/')
  return parts[parts.length - 1] || 'Attachment'
}
