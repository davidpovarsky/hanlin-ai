import { HStack, Image, Link, Text } from 'scripting'
import { CityInfoDisplayData } from '../../types/chat'
import { Strings, isRTL } from '../../l10n'
import { ToolCardFrame, ToolHeader, SoftPanel, ToolPill } from '../nativeToolUI'

type Props = {
  data: CityInfoDisplayData
  strings: Strings
  locale?: string
}

export function CityInfoCard({ data, strings, locale }: Props) {
  const rtl = isRTL(locale || '')
  const align = rtl ? 'trailing' : 'leading'

  return (
    <ToolCardFrame alignment={align}>
      <ToolHeader
        title={data.title}
        subtitle={strings.cityInfo}
        icon="book.closed.fill"
        accent="systemIndigo"
        alignment={align}
      />

      {data.thumbnailUrl ? (
        <Image
          imageUrl={data.thumbnailUrl}
          resizable
          frame={{ height: 150, maxWidth: 'infinity' }}
          clipShape={{ type: 'rect', cornerRadius: 22, style: 'continuous' }}
        />
      ) : null}

      <SoftPanel alignment={align} spacing={10} fill="secondarySystemGroupedBackground">
        <Text font="subheadline" foregroundStyle="label" multilineTextAlignment={align}>
          {data.summary}
        </Text>

        {data.pageUrl ? (
          <HStack frame={{ maxWidth: 'infinity', alignment: align }}>
            <Link url={data.pageUrl}>
              <ToolPill icon="arrow.up.right.square" text={strings.readMore} color="accentColor" />
            </Link>
          </HStack>
        ) : null}
      </SoftPanel>
    </ToolCardFrame>
  )
}
