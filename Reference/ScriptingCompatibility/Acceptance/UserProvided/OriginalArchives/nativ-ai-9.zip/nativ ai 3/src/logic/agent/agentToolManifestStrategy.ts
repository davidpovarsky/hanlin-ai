// src/logic/agent/agentToolManifestStrategy.ts
//
// Optional two-step tool-manifest strategy for the custom agent loop.
//
// Tool metadata is loaded from src/tools/<toolName>/tool.json via src/tools/index.ts.
// This strategy controls how much of that metadata is shown to the model.
//
// false = previous behavior: show the full detailed manifest every planning round.
// true  = first show a compact tool index, then show detailed metadata only for
//         the selected tools.

import type { ChatMessage } from '../../types/chat'
import {
  type AgentToolName,
  normalizeAgentToolName,
  ensureAgentToolRegistryForPlanning,
  buildCompactToolIndexPrompt,
  buildSelectedToolManifestPrompt,
  buildToolManifestPrompt,
} from './agentToolManifest'
import type { ToolResultForPlanning } from './agentActionPlanner'
import { USE_AGENT_SAMPLE_RESPONSES } from './agentSampleMode'
import { getLanguageName, getStrings } from '../../l10n'

/**
 * Main feature flag.
 *
 * Set true when you have many tools and want to save tokens.
 * Set false to send the full detailed manifest directly to the planner.
 */
export const USE_TWO_STEP_TOOL_MANIFEST_SELECTION = true

/**
 * If the compact selector fails, fall back to the previous full-manifest flow
 * instead of losing access to tools.
 */
export const FALL_BACK_TO_FULL_MANIFEST_ON_SELECTOR_ERROR = true

/**
 * Upper bound for selected tools. Keep this small when you eventually have many tools.
 */
export const MAX_SELECTED_TOOLS_FOR_DETAIL = 5

export type ToolManifestStrategyInput = {
  userMessage: string
  language: string
  currentDateTimeISO: string
  currentLocationLabel: string | null
  chatHistory?: ChatMessage[]
  toolResults?: ToolResultForPlanning[]
  extraDetailedTools?: AgentToolName[]
}

type ToolSelectionRaw = {
  selectedTools?: Array<{
    tool?: string
    reason?: string
  }>
  noToolLikely?: boolean
  reason?: string
  confidence?: number
}

type SelectedTool = {
  tool: AgentToolName
  reason: string
}

const toolSelectionSchema = {
  type: 'object',
  description: 'Select which internal tools might be relevant for the next agent step.',
  properties: {
    selectedTools: {
      type: 'array',
      description: [
        'Tools that might be relevant for the next action.',
        'Return an empty array if no tool seems needed.',
        'Select tools broadly when uncertain; the next planner step will decide whether to call them.',
      ].join(' '),
      items: {
        type: 'object',
        description: 'A possibly relevant internal tool.',
        properties: {
          tool: {
            type: 'string',
            description: 'Internal tool name exactly as shown in the compact tool index.',
          },
          reason: {
            type: 'string',
            description: 'Very short reason why this tool may be relevant.',
          },
        },
      },
    },
    noToolLikely: {
      type: 'boolean',
      description: 'true if the next step likely needs no tool and can be handled with normal text.',
    },
    reason: {
      type: 'string',
      description: 'Brief reason for the selection based on the full conversation context.',
    },
    confidence: {
      type: 'number',
      description: 'Confidence from 0 to 1.',
    },
  },
}

/**
 * Builds the manifest section that the main planner should see.
 */
export async function buildPlannerToolManifestPrompt(
  input: ToolManifestStrategyInput,
  aiProvider?: string
): Promise<string> {
  if (USE_AGENT_SAMPLE_RESPONSES) {
    return [
      'Sample mode is active.',
      'Tool manifest selection is skipped to avoid AI model calls.',
      'The next planner action comes from sampleAgentResponses.ts; any tool calls are still executed by real tools.',
    ].join('\n')
  }

  await ensureAgentToolRegistryForPlanning()
  console.log('[Agent manifest] building planner manifest', {
    twoStep: USE_TWO_STEP_TOOL_MANIFEST_SELECTION,
    latestUserMessage: input.userMessage,
  })

  if (!USE_TWO_STEP_TOOL_MANIFEST_SELECTION) {
    return buildToolManifestPrompt({
      language: input.language,
      currentLocationLabel: input.currentLocationLabel,
    })
  }

  try {
    const selected = await selectRelevantToolsForNextStep(input, aiProvider)

    // Reliability guard: the compact selector is intentionally lightweight and
    // can occasionally miss a required tool, especially when the latest user
    // message is a short continuation such as a city name, time, or option.
    // If it selects nothing, fall back to the full manifest for this planning
    // round instead of leaving the planner with no tool definitions.
    console.log('[Agent manifest] compact selected tools:', selected.map(item => item.tool))

    const extraDetailedTools = normalizeExtraDetailedTools(input.extraDetailedTools || [])

    if (selected.length === 0 && extraDetailedTools.length === 0) {
      console.log('[Agent manifest] compact selector returned no tools; falling back to full manifest for this round.')
      return buildToolManifestPrompt({
        language: input.language,
        currentLocationLabel: input.currentLocationLabel,
      })
    }

    const selectedTools = mergeSelectedToolNames(
      selected.map(item => item.tool),
      extraDetailedTools
    )
    console.log('[Agent manifest] using selected detailed manifest:', {
      selectedTools,
      extraDetailedTools,
    })
    return buildSelectedToolManifestPrompt({
      selectedTools,
      language: input.language,
      currentLocationLabel: input.currentLocationLabel,
      includeOtherCompactIndex: true,
    })
  } catch (err) {
    console.error('Tool manifest pre-selection failed:', err)

    if (FALL_BACK_TO_FULL_MANIFEST_ON_SELECTOR_ERROR) {
      console.log('[Agent manifest] selector failed; falling back to full manifest.')
      return buildToolManifestPrompt({
        language: input.language,
        currentLocationLabel: input.currentLocationLabel,
      })
    }

    return buildSelectedToolManifestPrompt({
      selectedTools: normalizeExtraDetailedTools(input.extraDetailedTools || []),
      language: input.language,
      currentLocationLabel: input.currentLocationLabel,
      includeOtherCompactIndex: true,
    })
  }
}

function normalizeExtraDetailedTools(values: AgentToolName[]): AgentToolName[] {
  const output: AgentToolName[] = []
  const seen = new Set<AgentToolName>()

  for (const value of values) {
    const tool = normalizeAgentToolName(value)
    if (!tool || seen.has(tool)) continue
    seen.add(tool)
    output.push(tool)
  }

  return output
}

function mergeSelectedToolNames(
  selectedTools: AgentToolName[],
  extraDetailedTools: AgentToolName[]
): AgentToolName[] {
  const output: AgentToolName[] = []
  const seen = new Set<AgentToolName>()

  for (const tool of [...selectedTools, ...extraDetailedTools]) {
    const normalized = normalizeAgentToolName(tool)
    if (!normalized || seen.has(normalized)) continue
    seen.add(normalized)
    output.push(normalized)
  }

  return output
}

/**
 * Step 1: show the model only a compact index and ask which tools may matter.
 * This does not decide the final action and does not call tools.
 */
export async function selectRelevantToolsForNextStep(
  input: ToolManifestStrategyInput,
  aiProvider?: string
): Promise<SelectedTool[]> {
  if (USE_AGENT_SAMPLE_RESPONSES) {
    return []
  }

  await ensureAgentToolRegistryForPlanning()

  const prompt = buildToolSelectionPrompt(input)

  try {
    const raw = await Assistant.requestStructuredData<ToolSelectionRaw>(
      prompt,
      toolSelectionSchema as never,
      aiProvider ? { provider: aiProvider as Assistant.Provider } : undefined
    )

    return normalizeSelectedTools(raw)
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    const fullErrorText = String(err instanceof Error ? err.stack || err.message : err)
    const recoveredRaw = extractStructuredJsonFromError<ToolSelectionRaw>(message)
      || extractStructuredJsonFromError<ToolSelectionRaw>(fullErrorText)

    if (recoveredRaw) {
      const recovered = normalizeSelectedTools(recoveredRaw)
      console.warn('[Agent manifest] recovered compact tool selection from parse error:', {
        selectedTools: recovered.map(item => item.tool),
        confidence: recoveredRaw.confidence,
      })
      return recovered
    }

    throw err
  }
}

function buildToolSelectionPrompt(input: ToolManifestStrategyInput): string {
  const langName = getStrings(input.language).modelLanguageName || getLanguageName(input.language)

  return [
    'You are the lightweight tool-index selector for a custom AI agent.',
    `The user-visible conversation language is ${langName}.`,
    '',
    'Your only job: choose which tools MAY be relevant for the next agent step.',
    'You do not decide the final answer.',
    'You do not write the final user response.',
    'You do not call tools.',
    '',
    'Read the latest user message AND the relevant conversation history.',
    'Important: A short latest user message can be a continuation of a previous assistant question.',
    'For example, a place, time, name, topic, option, or confirmation may complete the previous request.',
    '',
    'Select tools broadly when there is a real request. It is safer to include a possibly relevant tool than to omit a needed tool.',
    'If the latest user message is only punctuation or otherwise unclear, select tools only when the conversation clearly contains an unfinished tool workflow. Otherwise return selectedTools: [] and noToolLikely: true.',
    `Select at most ${MAX_SELECTED_TOOLS_FOR_DETAIL} tools.`,
    '',
    'Compact tool index:',
    buildCompactToolIndexPrompt(),
    '',
    `Current date/time ISO: ${input.currentDateTimeISO}`,
    `Current location label: ${input.currentLocationLabel || 'not available'}`,
    '',
    'Recent conversation history:',
    formatHistory(input.chatHistory || []) || '(none)',
    '',
    'Previous tool results in this agent run:',
    formatToolResults(input.toolResults || []) || '(none)',
    '',
    'Latest user message:',
    input.userMessage || '(empty)',
    '',
    'Return ONLY structured data matching the schema.',
  ].join('\n')
}


function extractStructuredJsonFromError<T>(value: unknown): T | null {
  const text = String(value || '').trim()
  if (!text) return null

  const candidates: string[] = []

  const outputMatch = text.match(/<output>\s*([\s\S]*?)\s*<\/output>/i)
  if (outputMatch?.[1]) candidates.push(outputMatch[1])

  const fencePattern = /```(?:json)?\s*([\s\S]*?)\s*```/gi
  let fenceMatch: RegExpExecArray | null
  while ((fenceMatch = fencePattern.exec(text)) !== null) {
    if (fenceMatch[1]) candidates.push(fenceMatch[1])
  }

  candidates.push(text)

  for (const candidate of candidates) {
    const jsonText = extractBalancedJson(candidate)
    if (!jsonText) continue

    try {
      const parsed = JSON.parse(jsonText)
      if (parsed && typeof parsed === 'object') return parsed as T
    } catch {
      // Try the next candidate.
    }
  }

  return null
}

function extractBalancedJson(value: string): string | null {
  const text = stripCodeFence(String(value || '').trim())
  if (!text) return null

  if ((text.startsWith('{') && text.endsWith('}')) || (text.startsWith('[') && text.endsWith(']'))) {
    return text
  }

  const object = extractBalancedJsonFrom(text, '{', '}')
  if (object) return object

  return extractBalancedJsonFrom(text, '[', ']')
}

function stripCodeFence(value: string): string {
  return String(value || '')
    .trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim()
}

function extractBalancedJsonFrom(value: string, open: string, close: string): string | null {
  const text = stripCodeFence(value)
  const start = text.indexOf(open)
  if (start < 0) return null

  let depth = 0
  let inString = false
  let escaped = false

  for (let i = start; i < text.length; i++) {
    const ch = text[i]

    if (inString) {
      if (escaped) {
        escaped = false
      } else if (ch === '\\') {
        escaped = true
      } else if (ch === '"') {
        inString = false
      }
      continue
    }

    if (ch === '"') {
      inString = true
      continue
    }

    if (ch === open) depth++
    if (ch === close) depth--

    if (depth === 0) {
      return text.slice(start, i + 1)
    }
  }

  return null
}

function normalizeSelectedTools(raw: ToolSelectionRaw | null | undefined): SelectedTool[] {
  const output: SelectedTool[] = []
  const seen = new Set<AgentToolName>()

  for (const item of (raw?.selectedTools || [])) {
    const tool = normalizeAgentToolName(item?.tool)
    if (!tool || seen.has(tool)) continue

    seen.add(tool)
    output.push({
      tool,
      reason: String(item?.reason || '').trim(),
    })

    if (output.length >= MAX_SELECTED_TOOLS_FOR_DETAIL) break
  }

  return output
}

function formatHistory(history: ChatMessage[]): string {
  return history
    .filter(m => (m.role === 'user' || m.role === 'assistant') && !m.isStreaming && String(m.text || '').trim().length > 0)
    .slice(-12)
    .map(m => `${m.role}: ${m.text}`)
    .join('\n')
}

function formatToolResults(results: ToolResultForPlanning[]): string {
  if (!results.length) return ''
  return JSON.stringify(results.slice(-10), null, 2)
}
