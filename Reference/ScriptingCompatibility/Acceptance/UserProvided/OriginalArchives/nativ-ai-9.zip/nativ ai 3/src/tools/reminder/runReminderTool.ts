// Platform adapter for the reminder tool.
// Uses Scripting's `Reminder` and `DateComponents` APIs.

import { ReminderIntentParams } from '../../types/intents'
import { priorityToInt } from '../../utils/priority'
import { parseISOToParts } from '../../utils/dateFormat'

export type ReminderToolResult =
  | { ok: true; identifier: string }
  | { ok: false; message: string }

export async function createReminder(
  params: ReminderIntentParams
): Promise<ReminderToolResult> {
  try {
    const reminder = new Reminder()
    reminder.title = params.title || 'Reminder'

    if (params.notes && params.notes.trim().length > 0) {
      reminder.notes = params.notes
    }

    if (params.dueDateISO) {
      const parts = parseISOToParts(params.dueDateISO)
      if (parts) {
        reminder.dueDateComponents = new DateComponents({
          year: parts.year,
          month: parts.month,
          day: parts.day,
          hour: parts.hour,
          minute: parts.minute,
        })
      }
    }

    if (params.priority !== 'none') {
      reminder.priority = priorityToInt(params.priority)
    }

    await reminder.save()

    return { ok: true, identifier: reminder.identifier }
  } catch (err) {
    return { ok: false, message: extractMessage(err) }
  }
}

function extractMessage(err: unknown): string {
  if (err instanceof Error) return err.message
  if (typeof err === 'string') return err
  try {
    return JSON.stringify(err)
  } catch {
    return 'Unknown error'
  }
}
