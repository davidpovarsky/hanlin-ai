import {
  Button,
  HStack,
  ProgressView,
  Spacer,
  Text,
  TextField,
  useObservable,
  type Color,
} from 'scripting'
import { EmailDraftDisplayData } from '../../types/chat'
import { Strings, isRTL } from '../../l10n'
import {
  ToolCardFrame,
  ToolHeader,
  SoftPanel,
  SectionCaption,
  NativeDivider,
} from '../nativeToolUI'

type Props = {
  data: EmailDraftDisplayData
  strings: Strings
  locale: string
}

type EditableEmailDraft = {
  recipientName: string
  toEmail: string
  subject: string
  body: string
}

type SendState = 'draft' | 'sent' | 'saved' | 'cancelled' | 'failed' | 'stopped'

const EMAIL_DRAFT_EDIT_SCHEMA = {
  type: 'object',
  description: 'Edited email draft fields.',
  properties: {
    recipientName: {
      type: 'string',
      description: 'Recipient display name or relationship. Preserve unless the user asked to change it.',
    },
    toEmail: {
      type: 'string',
      description: 'Recipient email address or comma-separated addresses. Preserve unless the user asked to change it. Empty string if unknown.',
    },
    subject: {
      type: 'string',
      description: 'Edited subject line.',
    },
    body: {
      type: 'string',
      description: 'Edited complete email body.',
    },
  },
}

export function EmailDraftCard({ data, strings, locale }: Props) {
  const rtl = isRTL(locale)
  const align = rtl ? 'trailing' : 'leading'
  const recipientName = useObservable(clean(data.recipientName))
  const toEmail = useObservable(clean(data.toEmail))
  const subject = useObservable(clean(data.subject))
  const body = useObservable(clean(data.body))
  const editInstruction = useObservable('')
  const isEditingWithModel = useObservable(false)
  const sendState = useObservable<SendState>(normalizeInitialState(data.status))
  const errorMessage = useObservable(clean(data.errorMessage))

  const recipients = parseRecipients(toEmail.value)
  const hasInvalidRecipient = toEmail.value.trim().length > 0 && recipients.length === 0
  const canSend = recipients.length > 0 && !isEditingWithModel.value && sendState.value !== 'stopped'
  const canAskModel = editInstruction.value.trim().length > 0 && !isEditingWithModel.value && sendState.value !== 'stopped'
  const status = describeStatus(sendState.value, strings, errorMessage.value)

  async function sendEmail() {
    if (!canSend) return

    const mailUI = getMailUI()
    if (!mailUI?.isAvailable || typeof mailUI.present !== 'function') {
      sendState.setValue('failed')
      errorMessage.setValue(strings.emailMailUnavailable)
      return
    }

    try {
      const result = await mailUI.present({
        toRecipients: recipients,
        subject: subject.value,
        body: body.value,
      })

      if (result === 'sent') {
        sendState.setValue('sent')
        errorMessage.setValue('')
      } else if (result === 'saved') {
        sendState.setValue('saved')
        errorMessage.setValue('')
      } else if (result === 'cancelled') {
        sendState.setValue('cancelled')
        errorMessage.setValue('')
      } else {
        sendState.setValue('failed')
        errorMessage.setValue(strings.emailSendFailed)
      }
    } catch (error) {
      sendState.setValue('failed')
      errorMessage.setValue(`${strings.emailSendFailed}: ${extractMessage(error)}`)
    }
  }

  async function editWithModel() {
    const instruction = editInstruction.value.trim()
    if (!instruction) return

    const assistant = getAssistant()
    if (!assistant?.requestStructuredData) {
      sendState.setValue('failed')
      errorMessage.setValue(strings.emailAssistantUnavailable)
      return
    }

    isEditingWithModel.setValue(true)
    errorMessage.setValue('')

    try {
      const result = await assistant.requestStructuredData(
        buildModelEditPrompt({
          instruction,
          locale,
          strings,
          draft: {
            recipientName: recipientName.value,
            toEmail: toEmail.value,
            subject: subject.value,
            body: body.value,
          },
        }),
        EMAIL_DRAFT_EDIT_SCHEMA as never
      ) as EditableEmailDraft

      recipientName.setValue(clean(result.recipientName) || recipientName.value)
      toEmail.setValue(clean(result.toEmail) || toEmail.value)
      subject.setValue(clean(result.subject) || subject.value)
      body.setValue(clean(result.body) || body.value)
      editInstruction.setValue('')
      sendState.setValue('draft')
    } catch (error) {
      sendState.setValue('failed')
      errorMessage.setValue(`${strings.emailDraftModelEditFailed}: ${extractMessage(error)}`)
    } finally {
      isEditingWithModel.setValue(false)
    }
  }

  if (sendState.value === 'stopped') {
    return (
      <ToolCardFrame alignment={align}>
        <ToolHeader
          title={strings.emailDraft}
          subtitle={strings.emailDraftStopped}
          icon="stop.circle.fill"
          accent="systemOrange"
          alignment={align}
        />
        <SoftPanel alignment={align}>
          <Text foregroundStyle="secondaryLabel" multilineTextAlignment={align}>
            {strings.emailDraftStopped}
          </Text>
        </SoftPanel>
      </ToolCardFrame>
    )
  }

  return (
    <ToolCardFrame alignment={align} spacing={12}>
      <ToolHeader
        title={strings.emailDraft}
        subtitle={status.label}
        icon={status.icon}
        accent={status.color}
        alignment={align}
        trailing={
          <Button
            title=""
            systemImage="stop.circle"
            action={() => sendState.setValue('stopped')}
            buttonStyle="borderless"
          />
        }
      />

      {data.request ? (
        <SoftPanel alignment={align} spacing={6} fill="secondarySystemGroupedBackground">
          <SectionCaption title={strings.emailAskModelTitle} alignment={align} />
          <Text font="caption" foregroundStyle="secondaryLabel" multilineTextAlignment={align}>
            {data.request}
          </Text>
        </SoftPanel>
      ) : null}

      <SoftPanel alignment={align} spacing={10} fill="secondarySystemGroupedBackground">
        <SectionCaption title={strings.emailToField} alignment={align} />
        <TextField
          title={strings.emailRecipientName}
          value={recipientName.value}
          onChanged={value => recipientName.setValue(value)}
          prompt={strings.emailRecipientNamePrompt}
          textInputAutocapitalization="words"
          textFieldStyle="roundedBorder"
        />

        <TextField
          title={strings.emailToField}
          value={toEmail.value}
          onChanged={value => toEmail.setValue(value)}
          prompt={strings.emailToPrompt}
          keyboardType="emailAddress"
          textContentType="emailAddress"
          textInputAutocapitalization="never"
          autocorrectionDisabled={true}
          textFieldStyle="roundedBorder"
        />

        {toEmail.value.trim().length === 0 ? (
          <Text font="caption" foregroundStyle="systemOrange" multilineTextAlignment={align}>
            {strings.emailMissingRecipientEmail}
          </Text>
        ) : hasInvalidRecipient ? (
          <Text font="caption" foregroundStyle="systemRed" multilineTextAlignment={align}>
            {strings.emailInvalidRecipientEmail}
          </Text>
        ) : null}

        <NativeDivider />

        <TextField
          title={strings.emailSubjectField}
          value={subject.value}
          onChanged={value => subject.setValue(value)}
          prompt={strings.emailSubjectPrompt}
          textInputAutocapitalization="sentences"
          textFieldStyle="roundedBorder"
        />

        <TextField
          title={strings.emailBodyField}
          value={body.value}
          onChanged={value => body.setValue(value)}
          prompt={strings.emailBodyPrompt}
          axis="vertical"
          lineLimit={{ min: 5, max: 12 }}
          textInputAutocapitalization="sentences"
          autocorrectionDisabled={false}
          textFieldStyle="roundedBorder"
        />
      </SoftPanel>

      <SoftPanel alignment={align} spacing={8} fill="secondarySystemGroupedBackground">
        <SectionCaption title={strings.emailAskModelTitle} alignment={align} color="systemPurple" />
        <TextField
          title={strings.emailEditInstructionField}
          value={editInstruction.value}
          onChanged={value => editInstruction.setValue(value)}
          prompt={strings.emailEditInstructionPrompt}
          axis="vertical"
          lineLimit={{ min: 1, max: 4 }}
          submitLabel="send"
          onSubmit={editWithModel}
          textFieldStyle="roundedBorder"
        />
      </SoftPanel>

      <HStack spacing={10} frame={{ maxWidth: 'infinity', alignment: align }}>
        <Button
          title={strings.emailEditWithModelButton}
          systemImage="sparkles"
          action={editWithModel}
          disabled={!canAskModel}
          buttonStyle="bordered"
        />
        <Spacer />
        {isEditingWithModel.value ? (
          <ProgressView progressViewStyle="circular" />
        ) : null}
        <Button
          title={strings.emailSendButton}
          systemImage="paperplane.fill"
          action={sendEmail}
          disabled={!canSend}
          buttonStyle="borderedProminent"
        />
      </HStack>
    </ToolCardFrame>
  )
}
function buildModelEditPrompt({
  instruction,
  locale,
  strings,
  draft,
}: {
  instruction: string
  locale: string
  strings: Strings
  draft: EditableEmailDraft
}): string {
  return [
    'Edit the email draft according to the user instruction.',
    `UI locale: ${locale}. User-facing language: ${strings.modelLanguageName || locale}.`,
    'Return only the edited fields required by the schema.',
    'Preserve recipientName and toEmail unless the instruction explicitly changes them.',
    'Do not invent email addresses. If toEmail is empty and the instruction does not provide one, keep it empty.',
    'Keep the body ready to paste into a real email composer.',
    '',
    'Current draft:',
    JSON.stringify(draft, null, 2),
    '',
    'User edit instruction:',
    instruction,
  ].join('\n')
}

function describeStatus(state: SendState, strings: Strings, errorMessage: string): {
  icon: string
  color: Color
  label: string
} {
  if (state === 'sent') {
    return { icon: 'checkmark.circle.fill', color: 'systemGreen', label: strings.emailSent }
  }
  if (state === 'saved') {
    return { icon: 'tray.and.arrow.down.fill', color: 'systemGreen', label: strings.emailSavedDraft }
  }
  if (state === 'cancelled') {
    return { icon: 'xmark.circle.fill', color: 'systemOrange', label: strings.emailSendCancelled }
  }
  if (state === 'failed') {
    return {
      icon: 'exclamationmark.triangle.fill',
      color: 'systemRed',
      label: errorMessage || strings.emailSendFailed,
    }
  }
  return { icon: 'pencil.and.scribble', color: 'systemBlue', label: strings.emailDraftReady }
}

function normalizeInitialState(value: unknown): SendState {
  return value === 'failed' ? 'failed' : 'draft'
}

function parseRecipients(value: string): string[] {
  return value
    .split(/[;,\n]/g)
    .map(part => extractEmail(part.trim()))
    .filter((item): item is string => !!item && isValidEmail(item))
}

function extractEmail(value: string): string {
  const angleMatch = value.match(/<([^>]+)>/)
  return (angleMatch?.[1] || value).trim()
}

function isValidEmail(value: string): boolean {
  return /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value)
}

function clean(value: unknown): string {
  return typeof value === 'string' ? value.trim() : ''
}

function extractMessage(error: unknown): string {
  if (error instanceof Error) return error.message
  if (typeof error === 'string') return error
  try {
    return JSON.stringify(error)
  } catch {
    return 'Unknown error'
  }
}

function getAssistant(): any {
  return (globalThis as any).Assistant
}

function getMailUI(): any {
  return (globalThis as any).MailUI
}
