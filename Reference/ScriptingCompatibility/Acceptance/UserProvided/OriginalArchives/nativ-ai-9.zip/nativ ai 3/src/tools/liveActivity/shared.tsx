import { Capsule, HStack, Image, ProgressView, RoundedRectangle, Spacer, Text, VStack } from 'scripting'
import type { AgentLiveActivityPayload, AgentLiveActivityRegion, AgentLiveActivityToolState } from '../../liveActivity/types'
import { isRTL } from '../../l10n'

export function ToolMiniLiveActivityView({
  payload,
  tool,
  region,
  icon,
  accent = 'systemBlue',
  title,
  subtitle,
  detail,
}: {
  payload: AgentLiveActivityPayload
  tool: AgentLiveActivityToolState
  region: AgentLiveActivityRegion
  icon: string
  accent?: string
  title?: string | null
  subtitle?: string | null
  detail?: string | null
}) {
  const rtl = isRTL(payload.locale)
  const alignment = rtl ? 'trailing' : 'leading'
  const isRunning = tool.status === 'running'
  const compact = region !== 'expanded'
  const statusColor = tool.status === 'success'
    ? 'systemGreen'
    : tool.status === 'error'
      ? 'systemRed'
      : accent
  const statusIcon = tool.status === 'success'
    ? 'checkmark.circle.fill'
    : tool.status === 'error'
      ? 'exclamationmark.triangle.fill'
      : 'sparkles'

  return (
    <HStack
      spacing={12}
      padding={{ leading: 14, trailing: 14, top: compact ? 10 : 12, bottom: compact ? 10 : 12 }}
      background={<RoundedRectangle cornerRadius={compact ? 22 : 26} fill="regularMaterial" />}
      clipShape={{ type: 'rect', cornerRadius: compact ? 22 : 26, style: 'continuous' }}
      activityBackgroundTint={{ light: 'clear', dark: 'clear' }}
      activitySystemActionForegroundColor={accent}
    >
      <Image
        systemName={icon}
        foregroundStyle={statusColor}
        font={{ size: compact ? 20 : 24, weight: 'semibold' }}
        padding={compact ? 8 : 9}
        background={<RoundedRectangle cornerRadius={compact ? 14 : 16} fill="tertiarySystemFill" />}
        clipShape={{ type: 'rect', cornerRadius: compact ? 14 : 16, style: 'continuous' }}
      />
      <VStack alignment={alignment} spacing={3} frame={{ maxWidth: 'infinity', alignment }}>
        <Text
          font={{ size: compact ? 12 : 14, weight: 'semibold' }}
          foregroundStyle="label"
          lineLimit={compact ? 1 : 2}
          multilineTextAlignment={alignment}
        >
          {title || tool.displayName}
        </Text>
        <Text
          font={{ size: compact ? 10 : 11, weight: 'medium' }}
          foregroundStyle={statusColor}
          lineLimit={compact ? 1 : 2}
          multilineTextAlignment={alignment}
        >
          {subtitle || payload.subtitle}
        </Text>
        {detail && !compact ? (
          <Text
            font={{ size: 10 }}
            foregroundStyle="secondaryLabel"
            lineLimit={2}
            multilineTextAlignment={alignment}
          >
            {detail}
          </Text>
        ) : null}
      </VStack>
      <Spacer />
      {isRunning ? (
        <ProgressView progressViewStyle="circular" />
      ) : (
        <HStack
          spacing={4}
          padding={{ horizontal: 8, vertical: 5 }}
          background={<Capsule fill="tertiarySystemFill" />}
          clipShape="capsule"
        >
          <Image systemName={statusIcon} foregroundStyle={statusColor} font={{ size: 11, weight: 'semibold' }} />
        </HStack>
      )}
    </HStack>
  )
}

export function firstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) return value.trim()
  }
  return null
}

export function firstNumber(...values: unknown[]): number | null {
  for (const value of values) {
    if (typeof value === 'number' && Number.isFinite(value)) return value
    if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) return Number(value)
  }
  return null
}
