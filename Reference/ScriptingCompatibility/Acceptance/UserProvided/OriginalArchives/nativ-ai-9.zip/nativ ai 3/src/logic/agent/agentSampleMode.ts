// src/logic/agent/agentSampleMode.ts
//
// Development flag for running the custom agent with local planner responses
// instead of calling the AI model.
//
// Important:
// - This mode replaces ONLY the model/planner output.
// - Tool calls returned by sampleAgentResponses.ts are still executed by the
//   real registered tool modules.
// - To return to real AI planning, set USE_AGENT_SAMPLE_RESPONSES = false.

export const USE_AGENT_SAMPLE_RESPONSES = false

/**
 * Which local sample response set should be used.
 * This build intentionally demonstrates only the currently enabled tools.
 */
export const AGENT_SAMPLE_RESPONSE_SET = 'enabled-tools-demo'

/**
 * Optional console logging while testing the sample flow.
 */
export const LOG_AGENT_SAMPLE_MODE = false
