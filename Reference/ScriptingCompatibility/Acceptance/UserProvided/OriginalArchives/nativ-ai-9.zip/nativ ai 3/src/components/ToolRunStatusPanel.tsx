import {
  Button,
  HStack,
  Image,
  ProgressView,
  Spacer,
  Text,
  VStack,
  useObservable,
} from 'scripting'
import { ToolRunRecord } from '../types/chat'
import { Strings, isRTL } from '../l10n'

type Props = {
  runs: ToolRunRecord[]
  statusText?: string | null
  locale?: string
  strings: Strings
}

export function ToolRunStatusPanel({ runs, statusText, locale, strings }: Props) {
  const cleanStatus = String(statusText || '').trim()
  const safeRuns = Array.isArray(runs) ? runs.filter(Boolean) : []
  const rtl = isRTL(locale || 'en')

  if (safeRuns.length === 0 && !cleanStatus) {
    return <VStack />
  }

  return (
    <VStack alignment={rtl ? 'trailing' : 'leading'} spacing={8}>
      {safeRuns.length > 0 ? (
        <VStack alignment={rtl ? 'trailing' : 'leading'} spacing={8}>
          {safeRuns.map((run, index) => (
            <ToolRunCard
              key={run.id}
              run={run}
              locale={locale}
              strings={strings}
              statusText={run.status === 'running' ? cleanStatus : ''}
              initiallyExpanded={false}
            />
          ))}
        </VStack>
      ) : cleanStatus ? (
        <VStack
          alignment={rtl ? 'trailing' : 'leading'}
          spacing={6}
          padding={{ horizontal: 12, vertical: 10 }}
          background="secondarySystemBackground"
          clipShape={{ type: 'rect', cornerRadius: 12 }}
        >
          <Text
            font="subheadline"
            foregroundStyle="secondaryLabel"
            multilineTextAlignment={rtl ? 'trailing' : 'leading'}
          >
            {cleanStatus}
          </Text>
          <HStack spacing={8}>
            <ProgressView progressViewStyle="circular" />
            <Text font="caption" foregroundStyle="secondaryLabel">
              {strings.thinking.replace(/…|\.\.\./g, '')}
            </Text>
          </HStack>
        </VStack>
      ) : null}
    </VStack>
  )
}

function ToolRunCard({
  run,
  locale,
  strings,
  statusText,
  initiallyExpanded,
}: {
  run: ToolRunRecord
  locale?: string
  strings: Strings
  statusText?: string
  initiallyExpanded?: boolean
}) {
  const rtl = isRTL(locale || 'en')
  const expanded = useObservable(Boolean(initiallyExpanded))
  const title = displayToolName(run.tool, run.action)
  const response = run.response !== undefined
    ? run.response
    : run.errorMessage
      ? { errorMessage: run.errorMessage }
      : null
  const align = rtl ? 'trailing' : 'leading'
  const chevron = expanded.value ? 'chevron.down' : (rtl ? 'chevron.left' : 'chevron.right')

  return (
    <VStack
      alignment={align}
      spacing={8}
      padding={{ horizontal: 12, vertical: 10 }}
      background="secondarySystemBackground"
      clipShape={{ type: 'rect', cornerRadius: 12 }}
    >
      {statusText && run.status === 'running' ? (
        <Text
          font="subheadline"
          foregroundStyle="secondaryLabel"
          multilineTextAlignment={align}
        >
          {statusText}
        </Text>
      ) : null}

      <Button
        action={() => expanded.setValue(!expanded.value)}
        buttonStyle="plain"
      >
        <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment: align }}>
          {run.status === 'running' ? (
            <ProgressView progressViewStyle="circular" />
          ) : (
            <Image
              systemName={getStatusIcon(run.status)}
              foregroundStyle={getStatusColor(run.status)}
              imageScale="medium"
            />
          )}

          <Text
            font="caption"
            foregroundStyle="label"
            multilineTextAlignment={align}
          >
            {title}
          </Text>

          <Spacer />

          <Image
            systemName={chevron}
            foregroundStyle="tertiaryLabel"
            imageScale="small"
          />
        </HStack>
      </Button>

      {expanded.value ? (
        <VStack alignment={align} spacing={8}>
          <KeyValueBlock
            label={strings.tool}
            value={run.tool}
            align={align}
          />
          {run.action ? (
            <KeyValueBlock
              label={strings.action}
              value={run.action}
              align={align}
            />
          ) : null}
          <KeyValueBlock
            label={strings.parameters}
            value={previewJson(run.params)}
            align={align}
          />
          {response != null ? (
            <KeyValueBlock
              label={strings.response}
              value={previewJson(response)}
              align={align}
            />
          ) : null}
          {run.errorMessage ? (
            <KeyValueBlock
              label={strings.error}
              value={run.errorMessage}
              error
              align={align}
            />
          ) : null}
        </VStack>
      ) : null}
    </VStack>
  )
}

function KeyValueBlock({
  label,
  value,
  error,
  align = 'leading',
}: {
  label: string
  value: string
  error?: boolean
  align?: 'leading' | 'trailing'
}) {
  return (
    <VStack alignment={align} spacing={3}>
      <Text font="caption2" foregroundStyle="secondaryLabel">
        {label}
      </Text>
      <Text
        font="caption"
        foregroundStyle={error ? 'systemRed' : 'label'}
        multilineTextAlignment={align}
      >
        {value}
      </Text>
    </VStack>
  )
}

function getStatusIcon(status: ToolRunRecord['status']): string {
  if (status === 'running') return 'arrow.triangle.2.circlepath'
  if (status === 'success') return 'checkmark.circle.fill'
  return 'exclamationmark.triangle.fill'
}

function getStatusColor(status: ToolRunRecord['status']): string {
  if (status === 'running') return 'systemBlue'
  if (status === 'success') return 'systemGreen'
  return 'systemOrange'
}

function displayToolName(tool: string, action?: string | null): string {
  const normalizedTool = String(tool || 'tool').trim()
  const normalizedAction = String(action || '').trim()
  const toolLabel = normalizedTool
    .replace(/^ios-/, 'iOS ')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, letter => letter.toUpperCase())

  if (!normalizedAction) return toolLabel

  const actionLabel = normalizedAction.replace(/_/g, ' ')
  return `${toolLabel} · ${actionLabel}`
}

function previewJson(value: unknown): string {
  if (value == null) return 'null'
  if (typeof value === 'string') return truncate(value.replace(/\s+/g, ' ').trim(), 1200)

  try {
    return truncate(JSON.stringify(value, null, 2), 1800)
  } catch {
    return truncate(String(value), 1200)
  }
}

function truncate(value: string, max: number): string {
  const text = String(value || '').trim()
  if (text.length <= max) return text
  return text.slice(0, max) + '\n…'
}
