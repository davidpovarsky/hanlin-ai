import { Button } from 'scripting'
import { Strings } from '../l10n'

type Props = {
  strings: Strings
  sessionId: string
  isBusy: boolean
  onPick: (text: string) => void
}

export function SuggestionsList({ strings, sessionId, isBusy, onPick }: Props) {
  const items = [
    { id: 'weather', icon: 'cloud.sun', text: strings.suggestionWeather },
    { id: 'reminder', icon: 'bell', text: strings.suggestionReminder },
    { id: 'city', icon: 'mappin.and.ellipse', text: strings.suggestionCity },
  ]

  return (
    <>
      {items.map(item => (
        <Button
          key={`${sessionId}:${item.id}`}
          title={item.text}
          systemImage={item.icon}
          action={() => {
            if (!isBusy) onPick(item.text)
          }}
          disabled={isBusy}
        />
      ))}
    </>
  )
}
