// src/logic/agent/agentOrchestrator.ts
//
// Platform adapter layer for the custom agent loop.
//
// The orchestrator no longer imports individual tools. It executes tools via
// the central registry in src/tools/index.ts. Adding a registered tool should
// not require editing this file.

import { ParsedIntent } from '../../types/intents'
import { ToolPayload, ChatAttachment, ChatMessage, ToolRunRecord } from '../../types/chat'
import {
  getAgentToolRunner,
  getAgentToolCard,
  ensureAgentToolRegistryLoaded,
  type AgentToolRunner,
  type AgentToolRunResult,
} from '../../tools'
import {
  buildAssistantSystemPrompt,
  buildFallbackStreamingUserMessage,
} from './replyPrompt'
import {
  AgentToolCall,
  AgentToolName,
} from './agentToolManifest'
import {
  planNextAgentAction,
  PlannedAgentAction,
  ToolResultForPlanning,
} from './agentActionPlanner'
import {
  LOG_AGENT_SAMPLE_MODE,
  USE_AGENT_SAMPLE_RESPONSES,
} from './agentSampleMode'
import { getNextSampleAgentAction } from './sampleAgentResponses'
import { getStrings } from '../../l10n'

export type AgentRunInput = {
  userMessage: string
  language: string
  currentLocationLabel: string | null
  aiProvider?: string
  chatHistory?: ChatMessage[]
  attachments?: ChatAttachment[]
  shouldCancel?: () => boolean
}

export type AgentToolPhase =
  | { kind: 'intent'; intent: ParsedIntent }
  | { kind: 'tool'; payload: ToolPayload | null; errorMessage: string | null }

export type AgentEventHandlers = {
  onIntent?: (intent: ParsedIntent) => void
  onToolPayload?: (payload: ToolPayload | null) => void
  onToolStart?: (run: ToolRunRecord) => void
  onToolFinish?: (runId: string, patch: Partial<ToolRunRecord>) => void
  onToolStatusText?: (text: string | null) => void
  onTextChunk?: (chunk: string) => void
  onDone?: () => void
  onError?: (err: unknown) => void
}

type ToolExecutionResult = {
  tool: AgentToolName
  params: Record<string, unknown>
  ok: boolean
  payload: ToolPayload | null
  errorMessage: string | null
}

const MAX_AGENT_ROUNDS = 7
const MAX_TOTAL_TOOL_CALLS = 10
const THINKING_STATUS_MARKER = '__agent_thinking__'

/**
 * Runs the agent loop and streams events to the caller.
 * Resolves when the agent has responded, completed tool work, or chosen no-op.
 */
export async function runAgent(
  input: AgentRunInput,
  handlers: AgentEventHandlers
): Promise<void> {
  try {
    const toolResults: ToolResultForPlanning[] = []
    let totalToolCalls = 0
    let emittedAnyText = false
    let emittedAnyToolPayload = false
    const extraDetailedTools = new Set<AgentToolName>()

    if (USE_AGENT_SAMPLE_RESPONSES && LOG_AGENT_SAMPLE_MODE) {
      console.log('[Agent sample mode] runAgent started. AI planner is mocked; real tools still execute.', {
        userMessage: input.userMessage,
        language: input.language,
        currentLocationLabel: input.currentLocationLabel,
      })
    }

    for (let round = 0; round < MAX_AGENT_ROUNDS; round++) {
      if (input.shouldCancel?.()) break
      handlers.onToolStatusText?.(THINKING_STATUS_MARKER)
      const plannerInput = {
        userMessage: buildMessageTextWithReadableAttachments(input.userMessage, input.attachments || []),
        language: input.language,
        currentDateTimeISO: new Date().toISOString(),
        currentLocationLabel: input.currentLocationLabel,
        chatHistory: input.chatHistory,
        toolResults,
        extraDetailedTools: Array.from(extraDetailedTools),
      }

      console.log('[Agent loop] planning round:', {
        round,
        userMessage: input.userMessage,
        toolResults: toolResults.length,
      })

      const action = USE_AGENT_SAMPLE_RESPONSES
        ? await getNextSampleAgentAction({
            ...plannerInput,
            round,
          })
        : await planNextAgentAction(plannerInput, input.aiProvider)

      console.log('[Agent loop] planned action:', {
        round,
        action: action.action,
        textLength: action.text.length,
        toolCalls: action.toolCalls.map(call => ({ tool: call.tool, params: call.params })),
        requestedTools: action.requestedTools,
        extraDetailedTools: Array.from(extraDetailedTools),
      })

      // If the planner returns an empty response, do not fall back to normal
      // streaming. A normal streaming reply does not see the structured tool
      // contract and can incorrectly claim it lacks live tools or invent live data.
      if (action.action === 'respond' && !action.text && action.toolCalls.length === 0) {
        handlers.onTextChunk?.(getStrings(input.language).toolPlanningFailed)
        emittedAnyText = true
        break
      }

      if (action.action === 'request_more_tool_manifests') {
        const newlyAdded: AgentToolName[] = []
        for (const tool of action.requestedTools || []) {
          if (!extraDetailedTools.has(tool)) {
            extraDetailedTools.add(tool)
            newlyAdded.push(tool)
          }
        }

        console.log('[Agent manifest] planner requested more tool manifests:', {
          requestedTools: action.requestedTools,
          newlyAdded,
          extraDetailedTools: Array.from(extraDetailedTools),
          reason: action.reason,
        })

        if (newlyAdded.length === 0) {
          toolResults.push({
            tool: 'system',
            params: { requestedTools: action.requestedTools || [] },
            ok: false,
            errorMessage: 'The requested tool manifests are already available in the detailed manifest. Do not request them again; either call one of those tools now, use previous tool results, or ask a concise clarification if a required value still cannot be obtained.',
          })
        }

        continue
      }

      const shouldTreatTextAsToolStatus = action.action === 'respond_and_call_tools' && action.toolCalls.length > 0
      const toolStatusTextForThisAction = shouldTreatTextAsToolStatus ? action.text.trim() : ''
      if (shouldTreatTextAsToolStatus) {
        const statusText = action.text.trim()
        if (statusText) {
          handlers.onToolStatusText?.(statusText)
        }
      } else if (action.action === 'respond' && action.toolCalls.length === 0) {
        const fallbackText = action.text.trim()
        handlers.onToolStatusText?.(null)
        try {
          await streamFinalReply(input, handlers, toolResults, fallbackText)
          emittedAnyText = true
        } catch (streamErr) {
          console.warn('[Agent reply] streaming final reply failed, falling back to planner text:', streamErr)
          if (fallbackText) {
            handlers.onTextChunk?.(fallbackText)
            emittedAnyText = true
          } else {
            throw streamErr
          }
        }
        break
      } else if (shouldEmitText(action)) {
        const chunk = action.text.trim()
        if (chunk) {
          handlers.onTextChunk?.(chunk)
          emittedAnyText = true
        }
      }

      if (action.action === 'none' && action.toolCalls.length === 0) {
        break
      }

      if (action.toolCalls.length === 0) {
        break
      }

      for (const toolCall of action.toolCalls) {
        if (input.shouldCancel?.()) break
        if (totalToolCalls >= MAX_TOTAL_TOOL_CALLS) {
          toolResults.push({
            tool: 'system',
            params: {},
            ok: false,
            errorMessage: 'Maximum tool call limit reached.',
          })
          break
        }

        handlers.onIntent?.(toolCallToParsedIntent(toolCall))
        if (!toolStatusTextForThisAction) {
          handlers.onToolStatusText?.(null)
        }

        const toolRunId = createToolRunId(toolCall.tool)
        const actionName = getToolActionName(toolCall.params)
        handlers.onToolStart?.({
          id: toolRunId,
          tool: toolCall.tool,
          action: actionName,
          params: toolCall.params,
          status: 'running',
          startedAt: Date.now(),
          finishedAt: null,
        })

        console.log('[Agent tool] executing:', { tool: toolCall.tool, params: toolCall.params })
        const result = await executeToolCall(toolCall, input.language)
        if (input.shouldCancel?.()) break
        console.log('[Agent tool] result:', {
          tool: result.tool,
          ok: result.ok,
          hasPayload: !!result.payload,
          errorMessage: result.errorMessage,
        })
        totalToolCalls++

        const hasUICard = !!(result.payload && getAgentToolCard(result.payload.kind))
        handlers.onToolFinish?.(toolRunId, {
          status: result.ok ? 'success' : 'error',
          finishedAt: Date.now(),
          response: buildToolRunResponse(result),
          errorMessage: result.errorMessage,
          payloadKind: result.payload?.kind || null,
          hasUICard,
        })
        if (result.ok) {
          handlers.onToolStatusText?.(null)
        }

        if (result.payload) {
          emittedAnyToolPayload = true
        }
        handlers.onToolPayload?.(result.payload)

        toolResults.push({
          tool: result.tool,
          params: result.params,
          ok: result.ok,
          payload: result.payload,
          errorMessage: result.errorMessage,
        })
      }

      if (totalToolCalls >= MAX_TOTAL_TOOL_CALLS) {
        if (!USE_AGENT_SAMPLE_RESPONSES) {
          await streamFallbackReply(input, handlers, toolResults)
          emittedAnyText = true
        } else {
          handlers.onTextChunk?.(
            `\n\n${getStrings(input.language).sampleToolLimit}`
          )
          emittedAnyText = true
        }
        break
      }

      // Loop again: now the model/sample planner sees the tool results and can
      // choose a final response, more tool calls, text+tool calls, or none.
    }

    if (!emittedAnyText && !emittedAnyToolPayload) {
      handlers.onTextChunk?.('')
    }

    if (!input.shouldCancel?.()) {
      handlers.onDone?.()
    }
  } catch (err) {
    handlers.onError?.(err)
  }
}

function shouldEmitText(action: PlannedAgentAction): boolean {
  return (
    action.action === 'respond' ||
    action.action === 'respond_and_call_tools'
  ) && action.text.trim().length > 0
}


function createToolRunId(tool: string): string {
  const safeTool = String(tool || 'tool').replace(/[^a-zA-Z0-9_-]+/g, '_')
  return `tool_${safeTool}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`
}

function getToolActionName(params: Record<string, unknown>): string | null {
  const action = params?.action
  return typeof action === 'string' && action.trim() ? action.trim() : null
}

function buildToolRunResponse(result: ToolExecutionResult): unknown {
  if (result.payload?.data !== undefined) return result.payload.data
  if (result.errorMessage) return { ok: false, errorMessage: result.errorMessage }
  return { ok: result.ok }
}

function findPlaceholderParamPath(value: unknown, path = 'params'): string | null {
  if (value == null) return null

  if (typeof value === 'string') {
    return isPlaceholderString(value) ? path : null
  }

  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i++) {
      const nested = findPlaceholderParamPath(value[i], `${path}[${i}]`)
      if (nested) return nested
    }
    return null
  }

  if (typeof value === 'object') {
    const obj = value as Record<string, unknown>
    for (const [key, nestedValue] of Object.entries(obj)) {
      const nested = findPlaceholderParamPath(nestedValue, `${path}.${key}`)
      if (nested) return nested
    }
  }

  return null
}

function isPlaceholderString(value: string): boolean {
  const text = value.trim().toLowerCase()
  if (!text) return true

  const exactPlaceholders = new Set([
    'unknown',
    'unspecified',
    'not specified',
    'not provided',
    'missing',
    'n/a',
    'na',
    'null',
    'undefined',
    'לא ידוע',
    'לא צויין',
    'לא צוין',
    'לא סופק',
    'חסר',
  ])

  if (exactPlaceholders.has(text)) return true

  return /^(לא\s+(צויין|צוין|ידוע|סופק)|not\s+(specified|provided|known)|missing\b|unknown\b|unspecified\b)/i.test(value.trim())
}

async function executeToolCall(
  toolCall: AgentToolCall,
  language: string
): Promise<ToolExecutionResult> {
  const placeholderPath = findPlaceholderParamPath(toolCall.params)
  if (placeholderPath) {
    const errorMessage = [
      `Tool call was blocked before execution because parameter ${placeholderPath} contains a placeholder or missing value.`,
      'Re-plan using previous context and available helper tools when possible; ask the user only if no tool can obtain the missing value.',
    ].join(' ')

    console.warn('[Agent tool] blocked placeholder parameters:', {
      tool: toolCall.tool,
      placeholderPath,
      params: toolCall.params,
    })

    return {
      tool: toolCall.tool,
      params: toolCall.params,
      ok: false,
      payload: buildToolErrorPayload(toolCall.tool, toolCall.params, errorMessage),
      errorMessage,
    }
  }

  try {
    await ensureAgentToolRegistryLoaded()
    const runner = getAgentToolRunner(toolCall.tool)

    if (!runner) {
      console.log('[Agent tool] unsupported tool after registry load:', toolCall.tool)
      const errorMessage = `Unsupported tool: ${toolCall.tool}`
      return {
        tool: toolCall.tool,
        params: toolCall.params,
        ok: false,
        payload: buildToolErrorPayload(toolCall.tool, toolCall.params, errorMessage),
        errorMessage,
      }
    }

    return await executeRegisteredToolCall(toolCall, language, runner)
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : String(err)
    return {
      tool: toolCall.tool,
      params: toolCall.params,
      ok: false,
      payload: buildToolErrorPayload(toolCall.tool, toolCall.params, errorMessage),
      errorMessage,
    }
  }
}

async function executeRegisteredToolCall(
  toolCall: AgentToolCall,
  language: string,
  runner: AgentToolRunner
): Promise<ToolExecutionResult> {
  const result: AgentToolRunResult = await runner(toolCall.params, language)
  const hasDisplayData = 'data' in result && result.data !== undefined
  const errorMessage = result.ok ? null : (result as { message: string }).message

  return {
    tool: toolCall.tool,
    params: toolCall.params,
    ok: result.ok,
    payload: result.ok
      ? (hasDisplayData
          ? {
              kind: toolCall.tool,
              data: result.data,
            }
          : null)
      : {
          // Use a generic kind for failures so a tool-specific card that
          // expects successful data (for example WeatherCard) is not asked to
          // render an error object. The generic card can safely show the
          // failure and the planner still receives the structured error below.
          kind: 'tool-error',
          data: {
            ok: false,
            tool: toolCall.tool,
            params: toolCall.params,
            errorMessage: errorMessage || 'Tool failed.',
            data: hasDisplayData ? result.data : null,
          },
        },
    errorMessage,
  }
}


function buildToolErrorPayload(
  tool: string,
  params: Record<string, unknown>,
  errorMessage: string
): ToolPayload {
  return {
    kind: 'tool-error',
    data: {
      ok: false,
      tool,
      params,
      errorMessage,
      data: null,
    },
  }
}


async function streamFinalReply(
  input: AgentRunInput,
  handlers: AgentEventHandlers,
  toolResults: ToolResultForPlanning[],
  fallbackText: string
): Promise<void> {
  if (!Assistant || typeof Assistant.requestStreaming !== 'function') {
    if (fallbackText) {
      handlers.onTextChunk?.(fallbackText)
      return
    }
    throw new Error('Assistant.requestStreaming is not available')
  }

  const historyMessages = (input.chatHistory || [])
    .filter(m => (m.role === 'user' || m.role === 'assistant') && !m.isStreaming && m.text.length > 0)
    .slice(-8)
    .map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.text,
    }))

  const stream = await Assistant.requestStreaming({
    systemPrompt: buildAssistantSystemPrompt(input.language),
    messages: [
      ...historyMessages,
      {
        role: 'user',
        content: buildStreamingMessageContent({
          text: buildFallbackStreamingUserMessage({
            userMessage: input.userMessage,
            language: input.language,
            toolResults,
          }),
          attachments: input.attachments || [],
        }),
      },
    ],
    ...(input.aiProvider ? { provider: input.aiProvider as Assistant.Provider } : {}),
  })

  let emitted = false
  for await (const chunk of stream) {
    if (input.shouldCancel?.()) break
    if (chunk.type === 'text' && chunk.content) {
      emitted = true
      handlers.onTextChunk?.(chunk.content)
    }
  }

  if (!input.shouldCancel?.() && !emitted && fallbackText) {
    handlers.onTextChunk?.(fallbackText)
  }
}

async function streamFallbackReply(
  input: AgentRunInput,
  handlers: AgentEventHandlers,
  toolResults: ToolResultForPlanning[]
): Promise<void> {
  if (!Assistant || typeof Assistant.requestStreaming !== 'function') {
    throw new Error('Assistant.requestStreaming is not available')
  }

  const historyMessages = (input.chatHistory || [])
    .filter(m => (m.role === 'user' || m.role === 'assistant') && !m.isStreaming && m.text.length > 0)
    .slice(-8)
    .map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.text,
    }))

  const stream = await Assistant.requestStreaming({
    systemPrompt: buildAssistantSystemPrompt(input.language),
    messages: [
      ...historyMessages,
      {
        role: 'user',
        content: buildStreamingMessageContent({
          text: buildFallbackStreamingUserMessage({
            userMessage: input.userMessage,
            language: input.language,
            toolResults,
          }),
          attachments: input.attachments || [],
        }),
      },
    ],
    ...(input.aiProvider ? { provider: input.aiProvider as Assistant.Provider } : {}),
  })

  for await (const chunk of stream) {
    if (input.shouldCancel?.()) break
    if (chunk.type === 'text' && chunk.content) {
      handlers.onTextChunk?.(chunk.content)
    }
  }
}


function buildStreamingMessageContent({
  text,
  attachments,
}: {
  text: string
  attachments: ChatAttachment[]
}): any {
  if (!attachments || attachments.length === 0) return text

  const readableText = buildMessageTextWithReadableAttachments(text, attachments)
  const imageAttachments = attachments.filter(item => item.kind === 'image')

  if (imageAttachments.length === 0) return readableText

  return [
    { type: 'text', content: readableText },
    ...imageAttachments.map(item => ({
      type: 'image',
      content: item.data,
    })),
  ]
}

function buildMessageTextWithReadableAttachments(
  text: string,
  attachments: ChatAttachment[]
): string {
  if (!attachments || attachments.length === 0) return text

  const attachmentBlocks = attachments
    .filter(item => item.kind === 'document')
    .map((item, index) => formatDocumentAttachmentForModel(item, index))
    .filter(Boolean)

  if (attachmentBlocks.length === 0) return text

  return [
    text || 'Analyze the attached file content.',
    '',
    'Attached file content:',
    ...attachmentBlocks,
  ].join('\n')
}

function formatDocumentAttachmentForModel(item: ChatAttachment, index: number): string {
  const name = item.name || `attachment-${index + 1}`
  const mediaType = item.mediaType || 'application/octet-stream'
  const decoded = decodeAttachmentText(item.data)

  if (!decoded.trim()) {
    return [
      `--- Attachment ${index + 1}: ${name} (${mediaType}) ---`,
      '[The file could not be decoded as readable text in this runtime. Ask the user to attach a text-based file or paste the contents.]',
      `--- End attachment ${index + 1} ---`,
    ].join('\n')
  }

  const maxChars = 50000
  const clipped = decoded.length > maxChars
    ? `${decoded.slice(0, maxChars)}\n\n[Attachment truncated after ${maxChars} characters.]`
    : decoded

  return [
    `--- Attachment ${index + 1}: ${name} (${mediaType}) ---`,
    clipped,
    `--- End attachment ${index + 1} ---`,
  ].join('\n')
}

function decodeAttachmentText(value: string): string {
  const raw = String(value || '')
  const base64 = raw.includes('base64,') ? raw.split('base64,').pop() || '' : raw
  if (!base64.trim()) return ''

  try {
    const decodedData = Data.fromBase64String(base64)
    if (decodedData) {
      return decodedData.toDecodedString()
    }
  } catch (error) {
    console.log('Failed to decode attachment via Data.fromBase64String:', String(error))
  }

  try {
    if (typeof atob === 'function') {
      return decodeURIComponent(escape(atob(base64)))
    }
  } catch (error) {
    console.log('Failed to decode attachment via atob:', String(error))
  }

  return ''
}

function toolCallToParsedIntent(toolCall: AgentToolCall): ParsedIntent {
  return {
    type: toolCall.tool,
    params: toolCall.params,
    confidence: 1,
  } as ParsedIntent
}
