// Pure JS - generates unique IDs

let counter = 0

export function generateId(prefix: string = 'id'): string {
  counter += 1
  const time = Date.now().toString(36)
  const rand = Math.random().toString(36).slice(2, 8)
  return `${prefix}_${time}_${rand}_${counter}`
}
