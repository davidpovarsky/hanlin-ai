import type { AgentToolLiveActivityComponent } from '../types'
import { ToolMiniLiveActivityView, firstString } from '../liveActivity/shared'

export const WeatherLiveActivity: AgentToolLiveActivityComponent = ({ payload, tool, region, data }) => {
  const location = firstString(data?.locationName, tool.params?.locationName, tool.params?.location, tool.params?.city)
  const temperature = firstString(data?.temperature)
  const condition = firstString(data?.condition)
  const detail = [temperature, condition].filter(Boolean).join(' · ') || tool.action || null

  return (
    <ToolMiniLiveActivityView
      payload={payload}
      tool={tool}
      region={region}
      icon={firstString(data?.symbolName) || 'cloud.sun.fill'}
      accent="systemOrange"
      title={location || tool.displayName}
      subtitle={payload.subtitle}
      detail={detail}
    />
  )
}
