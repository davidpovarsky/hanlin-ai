import {
  VStack,
  HStack,
  List,
  Section,
  Text,
  Button,
  Image,
  Group,
  useState,
} from 'scripting'
import { Strings } from '../l10n'
import { ChatSession } from '../types/chat'
import { formatDate, formatTime } from '../utils/dateFormat'
import { SettingsScreen } from '../screens/SettingsScreen'

function formatSessionDate(timestamp: number, locale: string): string {
  const diffHours = (Date.now() - timestamp) / (1000 * 60 * 60)
  return diffHours < 24 ? formatTime(timestamp, locale) : formatDate(timestamp, locale)
}

type Props = {
  sessions: ChatSession[]
  currentSessionId: string
  searchQuery: string
  hasMoreSessions: boolean
  onSearchChange: (query: string) => void
  onLoadMore: () => void
  onSelect: (sessionId: string) => void
  onDelete: (sessionId: string) => void
  onRename: (sessionId: string, title: string) => void
  onToggleFavorite: (sessionId: string) => void
  onNewChat: () => void
  onClose: () => void
  strings: Strings
  locale: string
  isBusy: boolean
}

export function ChatHistorySidebar({
  sessions,
  currentSessionId,
  searchQuery,
  hasMoreSessions,
  onSearchChange,
  onLoadMore,
  onSelect,
  onDelete,
  onRename,
  onToggleFavorite,
  onNewChat,
  onClose,
  strings,
  locale,
  isBusy,
}: Props) {
  const [settingsSheetPresented, setSettingsSheetPresented] = useState(false)
  const favoriteSessions = sessions.filter(session => session.isFavorite)
  const historySessions = sessions.filter(session => !session.isFavorite)
  const hasSearch = searchQuery.trim().length > 0
  const emptyMessage = hasSearch ? strings.noSearchResults : strings.noHistory

  return (
    <List
      navigationTitle={strings.appName}
      navigationBarTitleDisplayMode="inline"
      searchable={{
        value: searchQuery,
        onChanged: onSearchChange,
        placement: 'sidebar',
        prompt: strings.searchChats,
      }}
      toolbar={{
        topBarLeading: [
          <Button
            title={strings.done}
            systemImage="xmark"
            action={onClose}
          />,
        ],
        topBarTrailing: [
          <Button
            title={strings.settings}
            systemImage="gearshape"
            action={() => setSettingsSheetPresented(true)}
            sheet={{
              isPresented: settingsSheetPresented,
              onChanged: setSettingsSheetPresented,
              content: <SettingsScreen />,
            }}
          />,
        ],
      }}
      safeAreaInset={{
        bottom: {
          content: (
            <VStack
              padding={{ horizontal: 16, vertical: 12 }}
              frame={{ maxWidth: 'infinity', alignment: 'center' }}
            >
              <Button
                title={strings.newChat}
                systemImage="square.and.pencil"
                action={onNewChat}
                disabled={isBusy}
                buttonStyle="borderedProminent"
              />
            </VStack>
          ),
        },
      }}
    >
      {favoriteSessions.length > 0 ? (
        <Section title={strings.favoriteChats}>
          {favoriteSessions.map(session => (
            <SessionRow
              key={session.id}
              session={session}
              isActive={session.id === currentSessionId}
              onSelect={onSelect}
              onDelete={onDelete}
              onRename={onRename}
              onToggleFavorite={onToggleFavorite}
              locale={locale}
              strings={strings}
              isBusy={isBusy}
            />
          ))}
        </Section>
      ) : null}

      <Section title={strings.chatHistory}>
        {historySessions.length === 0 ? (
          <Text
            foregroundStyle="tertiaryLabel"
            font="subheadline"
          >
            {emptyMessage}
          </Text>
        ) : (
          historySessions.map(session => (
            <SessionRow
              key={session.id}
              session={session}
              isActive={session.id === currentSessionId}
              onSelect={onSelect}
              onDelete={onDelete}
              onRename={onRename}
              onToggleFavorite={onToggleFavorite}
              locale={locale}
              strings={strings}
              isBusy={isBusy}
            />
          ))
        )}

        {hasMoreSessions ? (
          <Button
            title={strings.loadMoreChats}
            systemImage="chevron.down"
            action={onLoadMore}
            disabled={isBusy}
            onAppear={onLoadMore}
          />
        ) : null}
      </Section>
    </List>
  )
}

type SessionRowProps = {
  session: ChatSession
  isActive: boolean
  onSelect: (id: string) => void
  onDelete: (id: string) => void
  onRename: (id: string, title: string) => void
  onToggleFavorite: (id: string) => void
  locale: string
  strings: Strings
  isBusy: boolean
}

function SessionRow({
  session,
  isActive,
  onSelect,
  onDelete,
  onRename,
  onToggleFavorite,
  locale,
  strings,
  isBusy,
}: SessionRowProps) {
  const requestRename = async () => {
    if (isBusy) return
    const nextTitle = await Dialog.prompt({
      title: strings.renameChat,
      defaultValue: session.title,
      placeholder: strings.renameChatPlaceholder,
      cancelLabel: strings.cancel,
      confirmLabel: strings.save,
      selectAll: true,
    })
    const trimmed = nextTitle?.trim()
    if (trimmed) onRename(session.id, trimmed)
  }

  const renderRowContent = (preview = false) => (
    <HStack
      spacing={8}
      padding={preview ? { horizontal: 14, vertical: 12 } : { horizontal: 10, vertical: 8 }}
      frame={preview ? { width: 300, alignment: 'leading' } : { maxWidth: 'infinity', alignment: 'leading' }}
      fixedSize={preview ? { horizontal: false, vertical: true } : undefined}
      background={preview ? 'secondarySystemBackground' : (isActive ? 'quaternarySystemFill' : undefined)}
      clipShape={{ type: 'rect', cornerRadius: preview ? 18 : 10 }}
      contentShape={{
        kind: 'contextMenuPreview',
        shape: {
          type: 'rect',
          cornerRadius: preview ? 18 : 10,
        },
      }}
    >
      {session.isFavorite ? (
        <Image
          systemName="pin.fill"
          foregroundStyle="secondaryLabel"
          imageScale="small"
        />
      ) : null}
      <VStack alignment="leading" spacing={3} frame={{ maxWidth: 'infinity', alignment: 'leading' }}>
        <Text
          font={preview ? 'body' : 'subheadline'}
          fontWeight={isActive ? 'semibold' : 'regular'}
          lineLimit={preview ? 2 : 1}
          foregroundStyle="label"
          fixedSize={preview ? { horizontal: false, vertical: true } : undefined}
        >
          {session.title}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel">
          {formatSessionDate(session.updatedAt ?? session.createdAt, locale)}
        </Text>
      </VStack>
    </HStack>
  )

  const renderRowPreview = () => (
    <VStack
      spacing={0}
      padding={{ horizontal: 2, vertical: 2 }}
      fixedSize={{ horizontal: false, vertical: true }}
      contentShape={{
        kind: 'contextMenuPreview',
        shape: {
          type: 'rect',
          cornerRadius: 20,
        },
      }}
    >
      {renderRowContent(true)}
    </VStack>
  )

  return (
    <Button
      action={() => onSelect(session.id)}
      disabled={isBusy}
      buttonStyle="plain"
      contentShape={{
        kind: 'interaction',
        shape: {
          type: 'rect',
          cornerRadius: 10,
        },
      }}
      trailingSwipeActions={{
        allowsFullSwipe: true,
        actions: [
          <Button
            title={strings.deleteChat}
            role="destructive"
            action={() => onDelete(session.id)}
            disabled={isBusy}
          />,
        ],
      }}
      contextMenu={{
        menuItems: (
          <Group>
            <Button
              title={session.isFavorite ? strings.unpinChat : strings.pinChat}
              systemImage={session.isFavorite ? 'pin.slash' : 'pin'}
              action={() => onToggleFavorite(session.id)}
              disabled={isBusy}
            />
            <Button
              title={strings.renameChat}
              systemImage="pencil"
              action={requestRename}
              disabled={isBusy}
            />
            <Button
              title={strings.deleteChat}
              systemImage="trash"
              role="destructive"
              action={() => onDelete(session.id)}
              disabled={isBusy}
            />
          </Group>
        ),
        preview: renderRowPreview(),
      }}
    >
      {renderRowContent(false)}
    </Button>
  )
}
