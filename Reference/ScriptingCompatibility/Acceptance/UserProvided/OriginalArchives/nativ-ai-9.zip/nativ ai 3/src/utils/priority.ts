// Pure JS - priority enum mapping
// Apple Reminders priority is integer 0-9. We map our enum to those values.

export type PriorityLevel = 'none' | 'low' | 'medium' | 'high'

export function priorityToInt(priority: PriorityLevel): number {
  switch (priority) {
    case 'none': return 0
    case 'low': return 9
    case 'medium': return 5
    case 'high': return 1
    default: return 0
  }
}

export function intToPriority(value: number): PriorityLevel {
  if (value <= 0) return 'none'
  if (value <= 4) return 'high'
  if (value <= 6) return 'medium'
  return 'low'
}
