// src/logic/agent/agentToolManifest.ts
//
// Agent-facing manifest helpers.
//
// Native tool metadata lives next to each built-in tool in src/tools/*/tool.json.
// External Scripting skills are discovered dynamically at runtime from the
// scripting-skills directory and are exposed through the same manifest helpers.

import {
  ensureAgentToolRegistryLoaded,
  getAllAgentToolSpecs,
  getCompactAgentToolIndex,
  type AgentToolName,
  type AgentToolParamSpec,
  type AgentToolSpec,
} from '../../tools'

export type { AgentToolName, AgentToolParamSpec, AgentToolSpec }

export type AgentToolCall = {
  tool: AgentToolName
  params: Record<string, unknown>
  reason?: string
}

/**
 * Backwards-compatible snapshot export. Runtime prompt builders use
 * getCurrentAgentTools() after ensureAgentToolRegistryForPlanning().
 */
export const AGENT_TOOLS: AgentToolSpec[] = getAllAgentToolSpecs()

export async function ensureAgentToolRegistryForPlanning(): Promise<void> {
  await ensureAgentToolRegistryLoaded()
}

export function getCurrentAgentTools(): AgentToolSpec[] {
  return getAllAgentToolSpecs()
}

export function normalizeAgentToolName(value: unknown): AgentToolName | null {
  const raw = String(value || '').trim()
  if (!raw) return null

  const normalized = raw.toLowerCase()

  for (const tool of getCurrentAgentTools()) {
    if (normalized === tool.name.toLowerCase()) return tool.name

    if ((tool.aliases || []).some(alias => normalized === alias.toLowerCase())) {
      return tool.name
    }
  }

  return null
}

export function getKnownToolNamesAndAliases(): string[] {
  const names: string[] = []
  for (const tool of getCurrentAgentTools()) {
    names.push(tool.name, ...(tool.aliases || []))
  }
  return Array.from(new Set(names)).filter(Boolean)
}

/**
 * Tiny list used by the two-step selector.
 */
export function buildCompactToolIndexPrompt(): string {
  return getCompactAgentToolIndex()
    .map(tool => {
      const aliases = tool.aliases?.length
        ? ` Aliases: ${tool.aliases.join(', ')}.`
        : ''
      return `- ${tool.name}: ${tool.shortDescription}${aliases}`
    })
    .join('\n')
}

/**
 * Full detailed manifest for all tools.
 * Used when two-step selection is disabled, or as a fallback.
 */
export function buildToolManifestPrompt(options: {
  language: string
  currentLocationLabel: string | null
  includeOtherCompactIndex?: boolean
}): string {
  return buildSelectedToolManifestPrompt({
    selectedTools: getCurrentAgentTools().map(tool => tool.name),
    language: options.language,
    currentLocationLabel: options.currentLocationLabel,
    includeOtherCompactIndex: false,
  })
}

/**
 * Detailed manifest for only the selected tools.
 * Used by the two-step manifest strategy.
 */
export function buildSelectedToolManifestPrompt(options: {
  selectedTools: AgentToolName[]
  language: string
  currentLocationLabel: string | null
  includeOtherCompactIndex?: boolean
}): string {
  const selectedSet = new Set(options.selectedTools)
  const selectedSpecs = getCurrentAgentTools().filter(tool => selectedSet.has(tool.name))

  const lines: string[] = []

  lines.push('Available tools for this planning round:')

  if (selectedSpecs.length === 0) {
    lines.push('(No detailed tools were selected by the compact selector.)')
    lines.push('You normally should respond without tools unless the conversation clearly still requires a tool; if a required tool is missing from this detailed list, ask one concise clarification or respond normally without inventing tool results.')
    lines.push('Never invent live/current data or claim that a real action was completed without a successful tool result.')
    lines.push('')
    lines.push(`User language: ${options.language || 'en'}`)
    lines.push(`Current location label: ${options.currentLocationLabel || 'not available'}`)
    return lines.join('\n')
  }

  for (const tool of selectedSpecs) {
    appendDetailedToolSpec(lines, tool)
  }

  if (options.includeOtherCompactIndex) {
    appendOtherCompactToolIndex(lines, selectedSet)
  }

  lines.push('')
  lines.push(`User language: ${options.language || 'en'}`)
  lines.push(`Current location label: ${options.currentLocationLabel || 'not available'}`)
  lines.push('')
  lines.push('Important: Tool calls must use the internal tool names exactly as listed above, not aliases or function-style names.')
  lines.push('Important: External skills are exposed as one tool per skill. For those, include all tool parameters in paramsJson as a JSON object string. For external skills, paramsJson must include action plus script parameters as flat fields. If the selected script itself has a parameter named action, put script parameters under scriptParams inside paramsJson.')
  lines.push('Important: cityInfo is a legacy internal name for Wikipedia encyclopedic lookup. Use cityInfo in tool calls.')

  return lines.join('\n')
}

function appendOtherCompactToolIndex(lines: string[], selectedSet: Set<AgentToolName>): void {
  const otherTools = getCurrentAgentTools().filter(tool => !selectedSet.has(tool.name))
  if (!otherTools.length) return

  lines.push('')
  lines.push('Other available tools, compact index only:')
  lines.push('These tools are NOT available for direct toolCalls in this planning round because their full manifests are not loaded yet.')
  lines.push('If one of these tools may provide missing data or enable the next step, choose action=request_more_tool_manifests and list it in requestedTools.')

  for (const tool of otherTools) {
    const aliases = tool.aliases?.length
      ? ` Aliases: ${tool.aliases.join(', ')}.`
      : ''
    lines.push(`- ${tool.name}: ${tool.shortDescription || tool.description}${aliases}`)
  }
}

function appendDetailedToolSpec(lines: string[], tool: AgentToolSpec): void {
  lines.push('')
  lines.push(`Tool: ${tool.name}`)
  lines.push(`Public name: ${tool.publicName}`)

  if (tool.aliases?.length) {
    lines.push(`Aliases you may recognize but must normalize to ${tool.name}: ${tool.aliases.join(', ')}`)
  }

  lines.push(`Description: ${tool.description}`)

  lines.push('Use this tool when:')
  for (const item of tool.whenToUse || []) {
    lines.push(`- ${item}`)
  }

  lines.push('Do NOT use this tool when:')
  for (const item of tool.whenNotToUse || []) {
    lines.push(`- ${item}`)
  }

  lines.push('Parameters:')
  for (const [key, spec] of Object.entries(tool.params || {})) {
    lines.push(`- ${key}${spec.required ? ' (required)' : ' (optional)'}: ${spec.description}`)
  }

  if (tool.resultPolicy) {
    lines.push(`Result policy: ${tool.resultPolicy}`)
  }

  // Keep examples limited. The metadata lives in tool.json/SKILL.md, but we
  // should not send every example for every tool once the project grows.
  if (tool.examples?.length) {
    lines.push('Examples:')
    for (const example of tool.examples.slice(0, 2)) {
      lines.push(`- User: ${example.user}`)
      lines.push(`  Tool call: ${JSON.stringify({ tool: example.call.tool, paramsJson: JSON.stringify(example.call.params || {}) })}`)
    }
  }
}
