// src/logic/intents/classifyIntent.ts
//
// Bridges pure-JS intent logic (prompt builder + schema + normalizer)
// to Scripting's platform Assistant API.
// This is the only file in the intents/ folder that touches the platform.

import { ParsedIntent } from '../../types/intents'
import { intentClassificationSchema, IntentClassificationRaw } from './intentSchema'
import { buildIntentPrompt, IntentPromptInput } from './intentPrompt'
import { normalizeIntent } from './intentNormalizer'

export async function classifyIntent(
  input: IntentPromptInput,
  aiProvider?: string
): Promise<ParsedIntent> {
  const prompt = buildIntentPrompt(input)

  try {
    if (!Assistant || typeof Assistant.requestStructuredData !== 'function') {
      console.error('classifyIntent: Assistant.requestStructuredData is not available')
      return { type: 'unknown', params: {}, confidence: 0 }
    }

    const raw = await Assistant.requestStructuredData<IntentClassificationRaw>(
      prompt,
      intentClassificationSchema as never,
      aiProvider ? { provider: aiProvider as Assistant.Provider } : undefined
    )
    return normalizeIntent(raw)
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    // Re-throw fatal provider errors so the caller can surface them to the user
    // instead of silently falling back and failing again in streaming.
    if (/insufficient balance|unauthorized|invalid.*key|quota/i.test(message)) {
      throw err
    }
    console.error('classifyIntent failed:', err)
    return { type: 'unknown', params: {}, confidence: 0 }
  }
}
