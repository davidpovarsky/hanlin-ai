import { EmailDraftDisplayData } from '../../types/chat'
import { getStrings } from '../../l10n'
import { buildEmailDraftDisplay, EmailDraftInput, markEmailDraftFailed } from './buildEmailDraftDisplay'

export type EmailDraftToolParams = EmailDraftInput

export type EmailDraftToolResult =
  | { ok: true; data: EmailDraftDisplayData }
  | { ok: false; message: string; data: EmailDraftDisplayData }

type GeneratedEmailDraft = {
  recipientName?: string
  toEmail?: string
  subject?: string
  body?: string
}

const EMAIL_DRAFT_SCHEMA = {
  type: 'object',
  description: 'Editable email draft fields.',
  properties: {
    recipientName: {
      type: 'string',
      description: 'Recipient display name or relationship. Empty string if not known.',
    },
    toEmail: {
      type: 'string',
      description: 'Recipient email address or comma-separated addresses. Empty string if not known.',
    },
    subject: {
      type: 'string',
      description: 'Concise email subject.',
    },
    body: {
      type: 'string',
      description: 'Complete email body.',
    },
  },
}

export async function runEmailDraftTool(
  params: EmailDraftToolParams,
  language: string
): Promise<EmailDraftToolResult> {
  const initial = buildEmailDraftDisplay(params)
  const strings = getStrings(language)

  if (initial.subject && initial.body) {
    return { ok: true, data: initial }
  }

  try {
    const generated = await generateMissingDraftFields(initial, language)
    const merged = buildEmailDraftDisplay({
      ...initial,
      recipientName: generated.recipientName || initial.recipientName,
      toEmail: generated.toEmail || initial.toEmail,
      subject: generated.subject || initial.subject,
      body: generated.body || initial.body,
    })

    return { ok: true, data: merged }
  } catch (error) {
    const fallback = buildEmailDraftDisplay({
      ...initial,
      subject: initial.subject || fallbackSubject(initial),
      body: initial.body || fallbackBody(initial),
    })

    return {
      ok: true,
      data: markEmailDraftFailed(
        fallback,
        `${strings.emailDraftModelEditFailed}: ${extractMessage(error)}`
      ),
    }
  }
}

async function generateMissingDraftFields(
  draft: EmailDraftDisplayData,
  language: string
): Promise<GeneratedEmailDraft> {
  const assistant = getAssistant()
  if (!assistant?.requestStructuredData) {
    throw new Error('Assistant.requestStructuredData is not available')
  }

  const strings = getStrings(language)
  const prompt = [
    'Create a concise editable email draft from the provided request.',
    `User interface language: ${strings.modelLanguageName || language}.`,
    'Return fields only. Do not include markdown.',
    'Important: Do not invent an email address. If the recipient email is not explicitly known, return an empty toEmail string.',
    'Preserve any existing field values unless they are empty.',
    '',
    'Current draft fields:',
    JSON.stringify({
      recipientName: draft.recipientName,
      toEmail: draft.toEmail,
      subject: draft.subject,
      body: draft.body,
      tone: draft.tone,
      request: draft.request,
    }, null, 2),
  ].join('\n')

  return await assistant.requestStructuredData(
    prompt,
    EMAIL_DRAFT_SCHEMA as never
  ) as GeneratedEmailDraft
}

function fallbackSubject(draft: EmailDraftDisplayData): string {
  const topic = draft.request || draft.body || ''
  const firstLine = topic.replace(/\s+/g, ' ').trim().slice(0, 64)
  return firstLine || 'Email draft'
}

function fallbackBody(draft: EmailDraftDisplayData): string {
  if (draft.request) return draft.request
  return ''
}

function extractMessage(error: unknown): string {
  if (error instanceof Error) return error.message
  if (typeof error === 'string') return error
  try {
    return JSON.stringify(error)
  } catch {
    return 'Unknown error'
  }
}

function getAssistant(): any {
  return (globalThis as any).Assistant
}
