import { NavigationStack, Form, Section, Picker, Text, Button, Navigation, Path, Script } from 'scripting'
import { useApp, AIProvider } from '../context/AppContext'
import { supportedLocales, Locale } from '../l10n'
import { CHAT_BACKGROUND_OPTIONS, ChatBackgroundId } from '../theme/chatBackgrounds'
import { syncToolsRegistry } from '../tools/syncToolsRegistry'

type AIProviderOption = {
  value: AIProvider
  label: (strings: ReturnType<typeof useApp>['strings']) => string
}

const AI_PROVIDER_OPTIONS: AIProviderOption[] = [
  { value: 'app_default', label: s => s.aiProviderDefault },
  { value: 'openai',      label: s => s.aiProviderOpenAI },
  { value: 'gemini',      label: s => s.aiProviderGemini },
  { value: 'anthropic',   label: s => s.aiProviderAnthropic },
  { value: 'deepseek',    label: s => s.aiProviderDeepSeek },
  { value: 'openrouter',  label: s => s.aiProviderOpenRouter },
]

export function SettingsScreen() {
  const dismiss = Navigation.useDismiss()
  const {
    strings,
    locale,
    setLocale,
    aiProvider,
    setAIProvider,
    chatBackground,
    chatBackgroundPhotoPath,
    setChatBackground,
    setChatBackgroundPhotoPath,
  } = useApp()

  const handleChooseChatBackgroundPhoto = async () => {
    try {
      const images = await Photos.pickPhotos(1)
      const image = images?.[0]

      if (!image) return

      const data = Data.fromJPEG(image, 0.88)
      if (!data) {
        await Dialog.alert({
          title: strings.error,
          message: strings.chatBackgroundPhotoSaveFailed,
          buttonLabel: strings.ok,
        })
        return
      }

      const directory = chatBackgroundsDirectory()
      await FileManager.createDirectory(directory, true)

      const filePath = Path.join(directory, `chat-background-${Date.now()}.jpg`)
      await FileManager.writeAsData(filePath, data)

      setChatBackgroundPhotoPath(filePath)
      setChatBackground('customPhoto')
    } catch (err) {
      await Dialog.alert({
        title: strings.error,
        message: err instanceof Error
          ? `${strings.chatBackgroundPhotoPickFailed}\n${err.message}`
          : strings.chatBackgroundPhotoPickFailed,
        buttonLabel: strings.ok,
      })
    }
  }

  const handleSyncToolsRegistry = async () => {
    try {
      const result = await syncToolsRegistry({ projectRoot: Script.directory })
      const enabled = result.enabledTools.length
        ? result.enabledTools.join(', ')
        : strings.syncToolsNoTools

      const shouldRestart = await Dialog.confirm({
        title: strings.syncToolsSuccess,
        message: [
          strings.syncToolsRestartHint,
          '',
          `${strings.syncToolsEnabledTools}: ${enabled}`,
        ].join('\n'),
        cancelLabel: strings.ok,
        confirmLabel: strings.restartScriptNow,
      })

      if (shouldRestart) {
        await restartCurrentScript(strings)
      }
    } catch (err) {
      await Dialog.alert({
        title: strings.syncToolsFailure,
        message: err instanceof Error ? err.message : String(err),
        buttonLabel: strings.ok,
      })
    }
  }

  const handleRestartScript = async () => {
    const confirmed = await Dialog.confirm({
      title: strings.restartScriptTitle,
      message: strings.restartScriptConfirmationMessage,
      cancelLabel: strings.cancel,
      confirmLabel: strings.restartScriptNow,
    })

    if (!confirmed) return

    await restartCurrentScript(strings)
  }

  return (
    <NavigationStack
      presentationDragIndicator="visible"
      presentationDetents={["medium", "large"]}
      presentationCornerRadius={28}
    >
      <Form
        navigationTitle={strings.settings}
        toolbar={{
          confirmationAction: (
            <Button title={strings.done} action={dismiss} />
          ),
        }}
      >
        <Section title={strings.language}>
          <Picker
            title={strings.language}
            value={locale}
            onChanged={(next: string) => setLocale(next as Locale)}
          >
            {supportedLocales.map(item => (
              <Text key={item.locale} tag={item.locale}>
                {item.nativeName}
              </Text>
            ))}
          </Picker>
        </Section>

        <Section
          title={strings.chatBackground}
          footer={
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {strings.chatBackgroundPhotoDescription}
            </Text>
          }
        >
          <Picker
            title={strings.chatBackground}
            value={chatBackground}
            onChanged={(next: string) => setChatBackground(next as ChatBackgroundId)}
          >
            {CHAT_BACKGROUND_OPTIONS.map(option => (
              <Text key={option.id} tag={option.id}>
                {labelForChatBackground(strings, option.labelKey)}
              </Text>
            ))}
            {chatBackgroundPhotoPath ? (
              <Text key="customPhoto" tag="customPhoto">
                {strings.chatBackgroundPhoto}
              </Text>
            ) : null}
          </Picker>

          <Button
            title={strings.chooseChatBackgroundPhoto}
            systemImage="photo.on.rectangle"
            action={handleChooseChatBackgroundPhoto}
          />
        </Section>

        <Section title={strings.aiProvider}>
          <Picker
            title={strings.aiProvider}
            value={aiProvider}
            onChanged={(next: string) => setAIProvider(next as AIProvider)}
          >
            {AI_PROVIDER_OPTIONS.map(opt => (
              <Text key={opt.value} tag={opt.value}>
                {opt.label(strings)}
              </Text>
            ))}
          </Picker>
        </Section>

        <Section title={strings.tools}>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {strings.syncToolsDescription}
          </Text>
          <Button
            title={strings.syncTools}
            systemImage="arrow.triangle.2.circlepath"
            action={handleSyncToolsRegistry}
          />
          <Button
            title={strings.restartScriptNow}
            systemImage="arrow.clockwise"
            action={handleRestartScript}
          />
        </Section>

        <Section title={strings.about}>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            {strings.appName} • v1.0.0
          </Text>
        </Section>
      </Form>
    </NavigationStack>
  )
}

function chatBackgroundsDirectory(): string {
  return Path.join(Script.directory, 'data', 'chat-backgrounds')
}

function labelForChatBackground(
  strings: ReturnType<typeof useApp>['strings'],
  labelKey: string
): string {
  return (strings as Record<string, string>)[labelKey] || labelKey
}


async function restartCurrentScript(strings: ReturnType<typeof useApp>['strings']): Promise<void> {
  try {
    const scriptName = getCurrentScriptName()

    if (!scriptName) {
      await Dialog.alert({
        title: strings.restartScriptFailure,
        message: strings.restartScriptMissingName,
        buttonLabel: strings.ok,
      })
      return
    }

    const url = Script.createRunSingleURLScheme(scriptName, {
      restartedAt: String(Date.now()),
      reason: 'tools-sync',
    })

    const opened = await Safari.openURL(url)

    if (!opened) {
      await Dialog.alert({
        title: strings.restartScriptFailure,
        message: strings.restartScriptOpenFailed,
        buttonLabel: strings.ok,
      })
      return
    }

    Script.exit()
  } catch (err) {
    await Dialog.alert({
      title: strings.restartScriptFailure,
      message: err instanceof Error ? err.message : String(err),
      buttonLabel: strings.ok,
    })
  }
}

function getCurrentScriptName(): string {
  const script = Script as any
  const candidates = [
    script?.name,
    script?.scriptName,
    script?.projectName,
    script?.currentScriptName,
    script?.metadata?.name,
    script?.metadata?.localizedName,
    script?.current?.name,
    script?.current?.scriptName,
  ]

  for (const candidate of candidates) {
    const value = String(candidate || '').trim()
    if (value && value !== 'undefined' && value !== 'null') {
      return value
    }
  }

  return ''
}
