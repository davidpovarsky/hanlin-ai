import { DisclosureGroup, HStack, Label, Text, VStack } from 'scripting'
import { isRTL } from '../../l10n'
import {
  TransitDirectionsDisplayData,
  TransitItineraryDisplay,
  TransitStepDisplay,
} from './buildTransitDirectionsDisplay'
import { ToolCardFrame, ToolHeader, SoftPanel, ToolPill, NativeDivider } from '../nativeToolUI'

type Props = {
  data: TransitDirectionsDisplayData
  strings?: Record<string, string>
  locale?: string
}

export function TransitDirectionsCard({ data, locale }: Props) {
  const hasRoutes = data.itineraries.length > 0
  const rtl = isRTL(locale || '')
  const align = rtl ? 'trailing' : 'leading'

  return (
    <ToolCardFrame alignment={align}>
      <ToolHeader
        title={data.title}
        subtitle={data.generatedAtLabel ? `Updated at ${data.generatedAtLabel}` : 'Public transit routes'}
        icon="arrow.triangle.turn.up.right.diamond.fill"
        accent="systemGreen"
        alignment={align}
      />

      <Header data={data} alignment={align} />

      {data.warnings.length > 0 ? (
        <Warnings warnings={data.warnings} alignment={align} />
      ) : null}

      {hasRoutes ? (
        <VStack alignment={align} spacing={10} frame={{ maxWidth: 'infinity', alignment: align }}>
          {data.itineraries.map(itinerary => (
            <ItineraryGroup key={itinerary.id} itinerary={itinerary} alignment={align} />
          ))}
        </VStack>
      ) : (
        <SoftPanel alignment={align}>
          <Label
            title={data.summary || 'No routes found.'}
            systemImage="bus.slash"
            foregroundStyle="secondaryLabel"
          />
        </SoftPanel>
      )}
    </ToolCardFrame>
  )
}

function Header({ data, alignment }: { data: TransitDirectionsDisplayData; alignment: 'leading' | 'trailing' }) {
  return (
    <SoftPanel alignment={alignment} spacing={10} fill="secondarySystemGroupedBackground">
      <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
        {data.subtitle}
      </Text>

      <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment }}>
        <ToolPill icon="location.fill" text={`Origin: ${data.from.name}`} color="systemBlue" />
        <ToolPill icon="mappin.circle.fill" text={`Destination: ${data.to.name}`} color="systemRed" />
      </HStack>

      <ToolPill icon="scope" text={`Origin source: ${data.usedLocationSourceLabel}`} color="secondaryLabel" />

      {data.summary ? (
        <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
          {data.summary}
        </Text>
      ) : null}
    </SoftPanel>
  )
}

function ItineraryGroup({
  itinerary,
  alignment,
}: {
  itinerary: TransitItineraryDisplay
  alignment: 'leading' | 'trailing'
  key?: string
}) {
  return (
    <SoftPanel alignment={alignment} spacing={10} padding={12}>
      <DisclosureGroup title={`${itinerary.title} · ${itinerary.durationLabel}`}>
        <VStack alignment={alignment} spacing={10}>
          <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment }}>
            <ToolPill icon="clock" text={itinerary.timeRangeLabel} color="secondaryLabel" />
            <ToolPill icon="creditcard" text={itinerary.fareText} color="secondaryLabel" />
          </HStack>

          <MetricsRow itinerary={itinerary} alignment={alignment} />

          {itinerary.routeBadges.length > 0 ? (
            <HStack spacing={6} frame={{ maxWidth: 'infinity', alignment }}>
              {itinerary.routeBadges.map(route => (
                <ToolPill key={`route_${route}`} icon="bus.fill" text={`Line ${route}`} color="systemGreen" />
              ))}
            </HStack>
          ) : null}

          {itinerary.alerts.length > 0 ? (
            <Warnings warnings={itinerary.alerts} alignment={alignment} />
          ) : null}

          <NativeDivider />

          <VStack alignment={alignment} spacing={10}>
            {itinerary.steps.map(step => (
              <StepRow key={step.id} step={step} alignment={alignment} />
            ))}
          </VStack>
        </VStack>
      </DisclosureGroup>
    </SoftPanel>
  )
}

function MetricsRow({ itinerary, alignment }: { itinerary: TransitItineraryDisplay; alignment: 'leading' | 'trailing' }) {
  return (
    <HStack spacing={8} frame={{ maxWidth: 'infinity', alignment }}>
      <ToolPill icon="figure.walk" text={`${itinerary.walkDistanceLabel} · ${itinerary.walkTimeMinutes} min`} color="secondaryLabel" />
      <ToolPill icon="arrow.left.arrow.right" text={itinerary.transfersLabel} color="secondaryLabel" />
      <ToolPill icon="clock" text={`${itinerary.waitingTimeMinutes} min waiting`} color="secondaryLabel" />
    </HStack>
  )
}

function StepRow({
  step,
  alignment,
}: {
  step: TransitStepDisplay
  alignment: 'leading' | 'trailing'
  key?: string
}) {
  const hasRoute = step.route && step.mode.toUpperCase() !== 'WALK'
  const title = hasRoute ? `Line ${step.route}` : step.modeLabel

  return (
    <VStack alignment={alignment} spacing={4} frame={{ maxWidth: 'infinity', alignment }}>
      <Label
        title={title}
        systemImage={step.iconName}
        font="caption"
        foregroundStyle={hasRoute ? 'systemGreen' : 'secondaryLabel'}
      />

      <Text font="caption" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
        {step.startTime && step.endTime ? `${step.startTime}–${step.endTime} · ` : ''}{step.durationLabel}
        {step.distanceLabel ? ` · ${step.distanceLabel}` : ''}
        {step.realtime ? ' · real time' : ''}
      </Text>

      <Text font="footnote" multilineTextAlignment={alignment}>
        {step.from} → {step.to}
      </Text>

      {step.agency || step.stopCodeFrom || step.stopCodeTo ? (
        <Text font="caption2" foregroundStyle="secondaryLabel" multilineTextAlignment={alignment}>
          {buildStepMeta(step)}
        </Text>
      ) : null}
    </VStack>
  )
}

function Warnings({ warnings, alignment }: { warnings: string[]; alignment: 'leading' | 'trailing' }) {
  return (
    <SoftPanel alignment={alignment} spacing={6} fill="tertiarySystemFill">
      {warnings.map((warning, index) => (
        <Label
          key={`warning_${index}`}
          title={warning}
          systemImage="exclamationmark.triangle.fill"
          font="caption"
          foregroundStyle="systemOrange"
        />
      ))}
    </SoftPanel>
  )
}

function buildStepMeta(step: TransitStepDisplay): string {
  const parts: string[] = []
  if (step.agency) parts.push(step.agency)
  if (step.stopCodeFrom) parts.push(`Origin stop ${step.stopCodeFrom}`)
  if (step.stopCodeTo) parts.push(`Destination stop ${step.stopCodeTo}`)
  return parts.join(' · ')
}
