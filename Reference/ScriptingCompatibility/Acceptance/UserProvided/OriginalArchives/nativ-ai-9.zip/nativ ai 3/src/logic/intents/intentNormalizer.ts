// Pure JS - normalizes raw model output into a strict ParsedIntent.
// No platform dependencies; safe to reuse across environments.

import { ParsedIntent } from '../../types/intents'
import { IntentClassificationRaw } from './intentSchema'

export function normalizeIntent(raw: IntentClassificationRaw): ParsedIntent {
  const intent = String(raw.intent ?? 'unknown').toLowerCase()
  const confidence = clampNumber(raw.confidence, 0, 1, 0)

  if (intent === 'weather') {
    const name = String(raw.weatherLocationName ?? '').trim()
    const useCurrent =
      raw.weatherUseCurrentLocation === true || name.length === 0
    return {
      type: 'weather',
      params: {
        locationName: name.length > 0 ? name : null,
        useCurrentLocation: useCurrent,
      },
      confidence,
    }
  }

  if (intent === 'reminder') {
    const title = String(raw.reminderTitle ?? '').trim()
    const notes = String(raw.reminderNotes ?? '').trim()
    const dueIso = String(raw.reminderDueDateISO ?? '').trim()
    const priorityRaw = String(raw.reminderPriority ?? 'none').trim().toLowerCase()
    const priority = isValidPriority(priorityRaw) ? priorityRaw : 'none'

    return {
      type: 'reminder',
      params: {
        title: title || 'Reminder',
        notes: notes.length > 0 ? notes : null,
        dueDateISO: dueIso.length > 0 ? dueIso : null,
        priority,
      },
      confidence,
    }
  }

  if (intent === 'cityinfo' || intent === 'city_info' || intent === 'city') {
    const q = String(raw.cityQuery ?? '').trim()
    return {
      type: 'cityInfo',
      params: {
        query: q,
        language: '',
      },
      confidence,
    }
  }

  if (intent === 'chat') {
    return { type: 'chat', params: {}, confidence }
  }

  return { type: 'unknown', params: {}, confidence }
}

function clampNumber(value: unknown, min: number, max: number, fallback: number): number {
  const n = typeof value === 'number' ? value : Number(value)
  if (!Number.isFinite(n)) return fallback
  if (n < min) return min
  if (n > max) return max
  return n
}

function isValidPriority(value: string): value is 'none' | 'low' | 'medium' | 'high' {
  return value === 'none' || value === 'low' || value === 'medium' || value === 'high'
}
