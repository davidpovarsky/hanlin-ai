import {
  Capsule,
  Divider,
  HStack,
  Image,
  RoundedRectangle,
  Spacer,
  Text,
  VStack,
  type Color,
} from 'scripting'

export type ToolAlignment = 'leading' | 'trailing' | 'center'

type ToolCardFrameProps = {
  children: any
  alignment?: ToolAlignment
  spacing?: number
  padding?: number
}

export function ToolCardFrame({
  children,
  alignment = 'leading',
  spacing = 14,
  padding = 16,
}: ToolCardFrameProps) {
  return (
    <VStack
      alignment={alignment}
      spacing={spacing}
      padding={padding}
      frame={{ maxWidth: 'infinity', alignment }}
      background={<RoundedRectangle cornerRadius={30} fill="regularMaterial" />}
      clipShape={{ type: 'rect', cornerRadius: 30, style: 'continuous' }}
      shadow={{ color: 'rgba(0,0,0,0.10)', radius: 14, x: 0, y: 5 }}
    >
      {children}
    </VStack>
  )
}

type ToolHeaderProps = {
  title: string
  subtitle?: string | null
  icon: string
  accent?: Color
  alignment?: ToolAlignment
  trailing?: any
}

export function ToolHeader({
  title,
  subtitle,
  icon,
  accent = 'systemBlue',
  alignment = 'leading',
  trailing,
}: ToolHeaderProps) {
  return (
    <HStack
      spacing={12}
      alignment="center"
      frame={{ maxWidth: 'infinity', alignment }}
    >
      <Image
        systemName={icon}
        foregroundStyle={accent}
        font={{ size: 22, weight: 'semibold' }}
        padding={10}
        background={<RoundedRectangle cornerRadius={16} fill="tertiarySystemFill" />}
        clipShape={{ type: 'rect', cornerRadius: 16, style: 'continuous' }}
      />
      <VStack alignment={alignment} spacing={2} frame={{ maxWidth: 'infinity', alignment }}>
        <Text
          font={{ size: 17, weight: 'semibold' }}
          foregroundStyle="label"
          lineLimit={2}
          multilineTextAlignment={alignment}
        >
          {title}
        </Text>
        {subtitle ? (
          <Text
            font="caption"
            foregroundStyle="secondaryLabel"
            lineLimit={2}
            multilineTextAlignment={alignment}
          >
            {subtitle}
          </Text>
        ) : null}
      </VStack>
      <Spacer />
      {trailing ? trailing : null}
    </HStack>
  )
}

type SoftPanelProps = {
  children: any
  alignment?: ToolAlignment
  spacing?: number
  padding?: number
  fill?: Color
}

export function SoftPanel({
  children,
  alignment = 'leading',
  spacing = 8,
  padding = 12,
  fill = 'secondarySystemBackground',
}: SoftPanelProps) {
  return (
    <VStack
      alignment={alignment}
      spacing={spacing}
      padding={padding}
      frame={{ maxWidth: 'infinity', alignment }}
      background={<RoundedRectangle cornerRadius={20} fill={fill} />}
      clipShape={{ type: 'rect', cornerRadius: 20, style: 'continuous' }}
    >
      {children}
    </VStack>
  )
}

type PillProps = {
  text: string
  icon?: string
  color?: Color
}

export function ToolPill({ text, icon, color = 'secondaryLabel' }: PillProps) {
  return (
    <HStack
      spacing={5}
      padding={{ horizontal: 10, vertical: 6 }}
      background={<Capsule fill="tertiarySystemFill" />}
      clipShape="capsule"
    >
      {icon ? (
        <Image systemName={icon} foregroundStyle={color} font={{ size: 11, weight: 'semibold' }} />
      ) : null}
      <Text font="caption" fontWeight="medium" foregroundStyle={color} lineLimit={1}>
        {text}
      </Text>
    </HStack>
  )
}

export function NativeDivider() {
  return <Divider opacity={0.45} />
}

type SectionCaptionProps = {
  title: string
  alignment?: ToolAlignment
  color?: Color
}

export function SectionCaption({
  title,
  alignment = 'leading',
  color = 'secondaryLabel',
}: SectionCaptionProps) {
  return (
    <Text
      font="caption"
      fontWeight="semibold"
      foregroundStyle={color}
      multilineTextAlignment={alignment}
      frame={{ maxWidth: 'infinity', alignment }}
    >
      {title}
    </Text>
  )
}
