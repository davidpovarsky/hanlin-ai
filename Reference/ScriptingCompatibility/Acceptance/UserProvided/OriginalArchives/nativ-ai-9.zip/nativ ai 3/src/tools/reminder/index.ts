import toolJson from './tool.json'
import {
  buildPendingReminderDisplay,
  markReminderCreated,
  markReminderFailed,
} from './buildReminderDisplay'
import { createReminder } from './runReminderTool'
import { ReminderCard } from './ReminderCard'
import {
  AgentToolModule,
  AgentToolRunResult,
  asAgentToolSpec,
} from '../types'
import { ReminderIntentParams } from '../../types/intents'

import { ReminderLiveActivity } from './liveActivity'
export * from './buildReminderDisplay'
export * from './runReminderTool'
export * from './ReminderCard'
export * from './liveActivity'

export const REMINDER_TOOL_SPEC = asAgentToolSpec(toolJson)

async function runRegisteredReminderTool(
  params: Record<string, unknown>
): Promise<AgentToolRunResult> {
  const normalized = normalizeReminderParams(params)
  const pending = buildPendingReminderDisplay(normalized)
  const result = await createReminder(normalized)

  if (result.ok) {
    return { ok: true, data: markReminderCreated(pending) }
  }

  const failure = result as { message: string }
  return {
    ok: false,
    message: failure.message,
    data: markReminderFailed(pending, failure.message),
  }
}

function normalizeReminderParams(params: Record<string, unknown>): ReminderIntentParams {
  return {
    title: stringOrDefault(params.title, 'Reminder'),
    notes: stringOrNull(params.notes),
    dueDateISO: stringOrNull(params.dueDateISO),
    priority: normalizePriority(params.priority),
  }
}

function stringOrDefault(value: unknown, fallback: string): string {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback
}

function stringOrNull(value: unknown): string | null {
  return typeof value === 'string' && value.trim() ? value.trim() : null
}

function normalizePriority(value: unknown): ReminderIntentParams['priority'] {
  if (value === 'low' || value === 'medium' || value === 'high' || value === 'none') {
    return value
  }

  if (typeof value === 'number') {
    if (value >= 8) return 'high'
    if (value >= 5) return 'medium'
    if (value >= 1) return 'low'
  }

  return 'none'
}

export const AGENT_TOOL_MODULE: AgentToolModule = {
  spec: REMINDER_TOOL_SPEC,
  run: runRegisteredReminderTool,
  Card: ReminderCard,
  LiveActivity: ReminderLiveActivity,
}

export default AGENT_TOOL_MODULE
