import type { AgentToolLiveActivityComponent } from '../types'
import { ToolMiniLiveActivityView, firstString } from '../liveActivity/shared'

export const NearbyTransitArrivalsLiveActivity: AgentToolLiveActivityComponent = ({ payload, tool, region, data }) => {
  const title = firstString(data?.title, tool.params?.stopName, tool.params?.locationName) || tool.displayName
  const subtitle = firstString(data?.subtitle, payload.subtitle)
  const warning = Array.isArray(data?.warnings) ? firstString(...data.warnings) : null

  return (
    <ToolMiniLiveActivityView
      payload={payload}
      tool={tool}
      region={region}
      icon="tram.fill"
      accent="systemIndigo"
      title={title}
      subtitle={subtitle || payload.subtitle}
      detail={warning || tool.action || null}
    />
  )
}
