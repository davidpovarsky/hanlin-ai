import { ContentUnavailableView } from 'scripting'
import { Strings } from '../l10n'

type Props = {
  strings: Strings
  onPickSuggestion: (text: string) => void
}

export function EmptyChatView({ strings }: Props) {
  return (
    <ContentUnavailableView
      title={strings.chatEmptyTitle}
      systemImage="sparkles"
      description={strings.chatEmptySubtitle}
    />
  )
}
