import {
  HStack,
  Image,
  ProgressView,
  Spacer,
  Text,
  VStack,
} from 'scripting'
import { getStrings, isRTL } from '../l10n'
import { getAgentToolLiveActivity } from '../tools'
import type {
  AgentLiveActivityPayload,
  AgentLiveActivityRegion,
  AgentLiveActivityToolState,
} from './types'

const CARD_BG = { light: 'secondarySystemBackground', dark: 'secondarySystemBackground' }
const ACCENT = 'systemBlue'
const SUCCESS = 'systemGreen'
const WARNING = 'systemOrange'
const ERROR = 'systemRed'
const PURPLE = 'systemPurple'

export function renderAgentLockScreen(payload: AgentLiveActivityPayload) {
  return renderMainPayload(payload, 'lockScreen')
}

export function renderAgentExpanded(payload: AgentLiveActivityPayload) {
  return renderMainPayload(payload, 'expanded')
}

export function renderAgentCompactLeading(payload: AgentLiveActivityPayload) {
  const icon = getPhaseIcon(payload)
  const color = getPhaseColor(payload)
  return (
    <Image
      systemName={icon}
      foregroundStyle={color}
      font={{ size: 13, weight: 'semibold' }}
      padding={{ leading: 4 }}
    />
  )
}

export function renderAgentCompactTrailing(payload: AgentLiveActivityPayload) {
  if (payload.phase === 'thinking' || payload.tool?.status === 'running') {
    return (
      <ProgressView
        progressViewStyle="circular"
        padding={{ trailing: 4 }}
      />
    )
  }

  return (
    <Image
      systemName={payload.phase === 'error' ? 'exclamationmark.triangle.fill' : 'checkmark.circle.fill'}
      foregroundStyle={payload.phase === 'error' ? ERROR : SUCCESS}
      font={{ size: 13, weight: 'semibold' }}
      padding={{ trailing: 4 }}
    />
  )
}

export function renderAgentMinimal(payload: AgentLiveActivityPayload) {
  return (
    <Image
      systemName={getPhaseIcon(payload)}
      foregroundStyle={getPhaseColor(payload)}
      font={{ size: 12, weight: 'semibold' }}
    />
  )
}

function renderMainPayload(payload: AgentLiveActivityPayload, region: AgentLiveActivityRegion) {
  if (payload.phase === 'tool' && payload.tool) {
    const ToolLiveActivity = getAgentToolLiveActivity(payload.tool.name)
    if (ToolLiveActivity) {
      return (
        <ToolLiveActivity
          payload={payload}
          tool={payload.tool}
          data={payload.tool.data}
          region={region}
          strings={getStrings(payload.locale)}
          locale={payload.locale}
        />
      )
    }

    return <GenericToolActivityView payload={payload} tool={payload.tool} region={region} />
  }

  if (payload.phase === 'result') {
    return <ResultActivityView payload={payload} region={region} />
  }

  if (payload.phase === 'error') {
    return <ErrorActivityView payload={payload} region={region} />
  }

  if (payload.phase === 'cancelled') {
    return <CancelledActivityView payload={payload} region={region} />
  }

  return <ThinkingActivityView payload={payload} region={region} />
}

function ThinkingActivityView({
  payload,
  region,
}: {
  payload: AgentLiveActivityPayload
  region: AgentLiveActivityRegion
}) {
  const strings = getStrings(payload.locale)
  return (
    <ActivityCard
      payload={payload}
      region={region}
      icon="sparkles"
      iconColor={PURPLE}
      title={payload.query || strings.appName}
      subtitle={payload.subtitle || strings.thinking}
      trailing={<ProgressView progressViewStyle="circular" />}
    />
  )
}

function GenericToolActivityView({
  payload,
  tool,
  region,
}: {
  payload: AgentLiveActivityPayload
  tool: AgentLiveActivityToolState
  region: AgentLiveActivityRegion
}) {
  const strings = getStrings(payload.locale)
  const isRunning = tool.status === 'running'
  const title = tool.displayName || tool.name || strings.tool
  const status = getToolStatusLabel(payload, tool)
  const action = tool.action ? `${strings.action}: ${tool.action}` : payload.detail

  return (
    <ActivityCard
      payload={payload}
      region={region}
      icon={isRunning ? 'wrench.and.screwdriver.fill' : getToolStatusIcon(tool.status)}
      iconColor={isRunning ? ACCENT : getToolStatusColor(tool.status)}
      title={title}
      subtitle={status}
      detail={action}
      trailing={isRunning
        ? <ProgressView progressViewStyle="circular" />
        : <Image systemName={getToolStatusIcon(tool.status)} foregroundStyle={getToolStatusColor(tool.status)} />}
    />
  )
}

function ResultActivityView({
  payload,
  region,
}: {
  payload: AgentLiveActivityPayload
  region: AgentLiveActivityRegion
}) {
  const strings = getStrings(payload.locale)
  const detail = payload.toolsUsed && payload.toolsUsed.length > 0
    ? payload.toolsUsed.slice(0, 3).join(' · ')
    : payload.answerPreview || null

  return (
    <ActivityCard
      payload={payload}
      region={region}
      icon="checkmark.circle.fill"
      iconColor={SUCCESS}
      title={payload.title || strings.done}
      subtitle={payload.answerPreview || strings.actionCompleted}
      detail={detail}
      trailing={<Image systemName="checkmark" foregroundStyle={SUCCESS} />}
    />
  )
}

function ErrorActivityView({
  payload,
  region,
}: {
  payload: AgentLiveActivityPayload
  region: AgentLiveActivityRegion
}) {
  const strings = getStrings(payload.locale)
  return (
    <ActivityCard
      payload={payload}
      region={region}
      icon="exclamationmark.triangle.fill"
      iconColor={ERROR}
      title={payload.title || strings.error}
      subtitle={payload.subtitle || strings.unknownError}
      detail={payload.detail}
      trailing={<Image systemName="xmark" foregroundStyle={ERROR} />}
    />
  )
}

function CancelledActivityView({
  payload,
  region,
}: {
  payload: AgentLiveActivityPayload
  region: AgentLiveActivityRegion
}) {
  const strings = getStrings(payload.locale)
  return (
    <ActivityCard
      payload={payload}
      region={region}
      icon="stop.circle.fill"
      iconColor={WARNING}
      title={payload.title || strings.stopResponse}
      subtitle={payload.subtitle || strings.actionCancelledBeforeTool}
      detail={payload.answerPreview}
      trailing={<Image systemName="stop.fill" foregroundStyle={WARNING} />}
    />
  )
}

function ActivityCard({
  payload,
  region,
  icon,
  iconColor,
  title,
  subtitle,
  detail,
  trailing,
}: {
  payload: AgentLiveActivityPayload
  region: AgentLiveActivityRegion
  icon: string
  iconColor: string
  title: string
  subtitle: string
  detail?: string | null
  trailing?: any
}) {
  const rtl = isRTL(payload.locale)
  const alignment = rtl ? 'trailing' : 'leading'
  const compact = region !== 'expanded'

  return (
    <HStack
      spacing={12}
      padding={{ leading: 14, trailing: 14, top: compact ? 10 : 12, bottom: compact ? 10 : 12 }}
      activityBackgroundTint={CARD_BG}
      activitySystemActionForegroundColor={ACCENT}
    >
      <Image
        systemName={icon}
        foregroundStyle={iconColor}
        font={{ size: compact ? 22 : 26, weight: 'semibold' }}
      />
      <VStack alignment={alignment} spacing={3} frame={{ maxWidth: 'infinity', alignment }}>
        <Text
          font={{ size: compact ? 12 : 13, weight: 'semibold' }}
          foregroundStyle="label"
          lineLimit={compact ? 1 : 2}
          multilineTextAlignment={alignment}
        >
          {title}
        </Text>
        <Text
          font={{ size: 11 }}
          foregroundStyle={iconColor}
          lineLimit={compact ? 1 : 2}
          multilineTextAlignment={alignment}
        >
          {subtitle}
        </Text>
        {detail ? (
          <Text
            font={{ size: 10 }}
            foregroundStyle="secondaryLabel"
            lineLimit={compact ? 1 : 2}
            multilineTextAlignment={alignment}
          >
            {detail}
          </Text>
        ) : null}
      </VStack>
      <Spacer />
      {trailing || <Image systemName="ellipsis" foregroundStyle="secondaryLabel" />}
    </HStack>
  )
}

function getToolStatusLabel(payload: AgentLiveActivityPayload, tool: AgentLiveActivityToolState): string {
  const strings = getStrings(payload.locale)
  if (tool.status === 'running') return payload.subtitle || strings.liveActivityRunningTool
  if (tool.status === 'success') return strings.liveActivityToolCompleted
  return tool.errorMessage || strings.liveActivityToolFailed
}

function getToolStatusIcon(status: string): string {
  switch (status) {
    case 'success':
      return 'checkmark.circle.fill'
    case 'error':
      return 'exclamationmark.triangle.fill'
    default:
      return 'wrench.and.screwdriver.fill'
  }
}

function getToolStatusColor(status: string): string {
  switch (status) {
    case 'success':
      return SUCCESS
    case 'error':
      return ERROR
    default:
      return ACCENT
  }
}

function getPhaseIcon(payload: AgentLiveActivityPayload): string {
  if (payload.phase === 'tool') return payload.tool?.status === 'running' ? 'wrench.and.screwdriver.fill' : getToolStatusIcon(payload.tool?.status || 'running')
  if (payload.phase === 'result') return 'checkmark.circle.fill'
  if (payload.phase === 'error') return 'exclamationmark.triangle.fill'
  if (payload.phase === 'cancelled') return 'stop.circle.fill'
  return 'sparkles'
}

function getPhaseColor(payload: AgentLiveActivityPayload): string {
  if (payload.phase === 'tool') return payload.tool?.status ? getToolStatusColor(payload.tool.status) : ACCENT
  if (payload.phase === 'result') return SUCCESS
  if (payload.phase === 'error') return ERROR
  if (payload.phase === 'cancelled') return WARNING
  return PURPLE
}
