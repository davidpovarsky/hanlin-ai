// src/tools/transitDirections/runTransitDirectionsTool.ts
// Scripting-native adaptation of the supplied BusNearby MCP transit directions tool.

import {
  TransitDirectionsDisplayData,
  TransitDirectionsStructuredResult,
  TransitItinerarySummary,
  TransitStepSummary,
  buildTransitDirectionsDisplay,
} from './buildTransitDirectionsDisplay'
import { getIntlLocale, getStrings } from '../../l10n'

export type TransitDirectionsIntentParams = {
  fromQuery?: string | null
  fromLat?: number | string | null
  fromLon?: number | string | null
  toQuery?: string | null
  locale?: string | null
  numItineraries?: number | string | null
  maxWalkDistance?: number | string | null
}

export type TransitDirectionsToolResult =
  | { ok: true; data: TransitDirectionsDisplayData }
  | { ok: false; message: string; reason?: string; data?: TransitDirectionsDisplayData }

type GeocodeCandidate = {
  lat: number
  lng: number
  formatted_address: string
}

type ReverseGeocodeResult = {
  lat: number
  lon: number
  display_name: string
  road?: string
  suburb?: string
  city?: string
  country?: string
  formatted_for_directions: string
}

type OriginCoordinates = {
  lat: number
  lon: number
  source: 'explicit_arguments' | 'device_location'
}

const DEFAULT_LOCALE = 'he'
const DEFAULT_NUM_ITINERARIES = 3
const DEFAULT_MAX_WALK_DISTANCE = 1207
const REQUEST_TIMEOUT_SECONDS = 18
const BUSNEARBY_USER_AGENT = 'chatgpt-transit-app/0.1.0'

export async function runTransitDirectionsTool(
  params: TransitDirectionsIntentParams = {},
  language = 'he'
): Promise<TransitDirectionsToolResult> {
  try {
    const normalized = normalizeParams(params, language)

    const toQuery = normalized.toQuery

    if (!toQuery) {
      return {
        ok: false,
        reason: 'missingDestination',
        message: 'Missing destination. Send toQuery with an address or place name.',
      }
    }

    const structured = await resolveTransitDirections({
      ...normalized,
      toQuery,
    })
    const display = buildTransitDirectionsDisplay(structured)

    return { ok: true, data: display }
  } catch (error) {
    const message = extractMessage(error)
    return {
      ok: false,
      reason: 'failed',
      message,
      data: buildFailureDisplay(message, params, language),
    }
  }
}

function normalizeParams(params: TransitDirectionsIntentParams, language: string) {
  return {
    fromQuery: firstString(params.fromQuery),
    fromLat: toOptionalNumber(params.fromLat),
    fromLon: toOptionalNumber(params.fromLon),
    toQuery: firstString(params.toQuery),
    locale: firstString(params.locale) || getIntlLocale(language),
    numItineraries: clampInt(params.numItineraries, DEFAULT_NUM_ITINERARIES, 1, 6),
    maxWalkDistance: clampInt(params.maxWalkDistance, DEFAULT_MAX_WALK_DISTANCE, 100, 5000),
  }
}

async function resolveTransitDirections(args: {
  fromQuery: string | null
  fromLat: number | null
  fromLon: number | null
  toQuery: string
  locale: string
  numItineraries: number
  maxWalkDistance: number
}): Promise<TransitDirectionsStructuredResult> {
  let usedLocationSource = ''
  let from: ReverseGeocodeResult

  if (args.fromQuery && args.fromQuery.trim().length > 0) {
    const fromCandidates = await geocodeAddress(args.fromQuery.trim(), args.locale)
    const fromCandidate = fromCandidates[0]

    from = {
      lat: fromCandidate.lat,
      lon: fromCandidate.lng,
      display_name: fromCandidate.formatted_address,
      formatted_for_directions: fromCandidate.formatted_address,
    }

    usedLocationSource = 'from_query'
  } else {
    const origin = await getOriginCoordinates(args)
    from = await reverseGeocodeLocation(origin.lat, origin.lon, args.locale)
    usedLocationSource = origin.source
  }

  const toCandidates = await geocodeAddress(args.toQuery, args.locale)
  const to = toCandidates[0]

  const rawDirections = await getDirections({
    fromName: from.formatted_for_directions,
    fromLat: from.lat,
    fromLon: from.lon,
    toName: to.formatted_address,
    toLat: to.lat,
    toLon: to.lng,
    locale: args.locale,
    numItineraries: args.numItineraries,
    maxWalkDistance: args.maxWalkDistance,
  })

  const allItineraries = summarizeDirections(rawDirections, 'he-IL')
  const itineraries = allItineraries.slice(0, args.numItineraries)

  const summary = buildHumanSummary(
    from.formatted_for_directions,
    to.formatted_address,
    itineraries
  )

  return {
    usedLocationSource,
    from: {
      name: from.formatted_for_directions,
      lat: from.lat,
      lon: from.lon,
      display_name: from.display_name,
    },
    to: {
      name: to.formatted_address,
      lat: to.lat,
      lon: to.lng,
    },
    summary,
    itineraries,
  }
}

async function getOriginCoordinates(args: {
  fromLat: number | null
  fromLon: number | null
}): Promise<OriginCoordinates> {
  if (typeof args.fromLat === 'number' && typeof args.fromLon === 'number') {
    return {
      lat: args.fromLat,
      lon: args.fromLon,
      source: 'explicit_arguments',
    }
  }

  const LocationApi = (globalThis as any).Location
  if (!LocationApi || typeof LocationApi.requestCurrent !== 'function') {
    throw new Error(
      'Missing origin. Send fromQuery, fromLat/fromLon, or run in an environment where Location.requestCurrent is available.'
    )
  }

  const location = await LocationApi.requestCurrent()
  const latitude = toOptionalNumber(location?.latitude)
  const longitude = toOptionalNumber(location?.longitude)

  if (typeof latitude !== 'number' || typeof longitude !== 'number') {
    throw new Error(
      'Could not get the current location. You can enter fromQuery or fromLat/fromLon manually.'
    )
  }

  return {
    lat: latitude,
    lon: longitude,
    source: 'device_location',
  }
}

function summarizeDirections(data: any, locale = 'he-IL'): TransitItinerarySummary[] {
  const itineraries = data?.plan?.itineraries

  if (!Array.isArray(itineraries)) {
    throw new Error('Directions API returned an unexpected response: missing plan.itineraries')
  }

  return itineraries.map((itinerary: any, index: number) => {
    const legs = Array.isArray(itinerary.legs) ? itinerary.legs : []

    const steps: TransitStepSummary[] = legs.map((leg: any) => {
      const mode = typeof leg.mode === 'string' ? leg.mode : 'UNKNOWN'
      const route = typeof leg.routeShortName === 'string' ? leg.routeShortName : undefined
      const agency = typeof leg.agencyName === 'string' ? leg.agencyName : undefined

      const from = typeof leg.from?.name === 'string' ? leg.from.name : 'Origin'
      const to = typeof leg.to?.name === 'string' ? leg.to.name : 'Destination'

      const startTime = typeof leg.startTime === 'number' ? formatTime(leg.startTime, locale) : ''
      const endTime = typeof leg.endTime === 'number' ? formatTime(leg.endTime, locale) : ''

      const durationMinutes =
        typeof leg.duration === 'number'
          ? minutes(leg.duration, 'seconds')
          : typeof leg.startTime === 'number' && typeof leg.endTime === 'number'
            ? minutes(leg.endTime - leg.startTime, 'ms')
            : 0

      return {
        mode,
        route,
        agency,
        from,
        to,
        startTime,
        endTime,
        durationMinutes,
        distanceMeters: typeof leg.distance === 'number' ? Math.round(leg.distance) : undefined,
        realtime: typeof leg.realTime === 'boolean' ? leg.realTime : undefined,
        stopCodeFrom: typeof leg.from?.stopCode === 'string' ? leg.from.stopCode : undefined,
        stopCodeTo: typeof leg.to?.stopCode === 'string' ? leg.to.stopCode : undefined,
      }
    })

    const routes = uniqueStrings(
      steps.filter(step => step.mode !== 'WALK').map(step => step.route || '')
    )

    const legAlerts = legs.flatMap((leg: any) =>
      Array.isArray(leg.alerts)
        ? leg.alerts.map((alert: any) => alert?.alertHeaderText).filter(Boolean)
        : []
    )

    const planAlerts = Array.isArray(data?.plan?.areaAlerts)
      ? data.plan.areaAlerts.map((alert: any) => alert?.alertHeaderText).filter(Boolean)
      : []

    return {
      index: index + 1,
      durationMinutes: typeof itinerary.duration === 'number' ? minutes(itinerary.duration) : 0,
      startTime: typeof itinerary.startTime === 'number' ? formatTime(itinerary.startTime, locale) : '',
      endTime: typeof itinerary.endTime === 'number' ? formatTime(itinerary.endTime, locale) : '',
      walkDistanceMeters:
        typeof itinerary.walkDistance === 'number' ? Math.round(itinerary.walkDistance) : 0,
      walkTimeMinutes: typeof itinerary.walkTime === 'number' ? minutes(itinerary.walkTime) : 0,
      transitTimeMinutes:
        typeof itinerary.transitTime === 'number' ? minutes(itinerary.transitTime) : 0,
      waitingTimeMinutes:
        typeof itinerary.waitingTime === 'number' ? minutes(itinerary.waitingTime) : 0,
      transfers: typeof itinerary.transfers === 'number' ? itinerary.transfers : 0,
      fareText: getFareText(itinerary),
      routes,
      steps,
      alerts: uniqueStrings([...legAlerts, ...planAlerts]).slice(0, 5),
    }
  })
}

function buildHumanSummary(fromName: string, toName: string, itineraries: TransitItinerarySummary[]): string {
  if (itineraries.length === 0) {
    return `No routes found from ${fromName} to ${toName}.`
  }

  const first = itineraries[0]
  const routeText = first.routes.length > 0 ? first.routes.join(' → ') : 'No transit lines'

  return [
    `Found a route from ${fromName} to ${toName}.`,
    `Fastest route: ${first.durationMinutes} min, ${first.startTime}–${first.endTime}.`,
    `Routes: ${routeText}.`,
    `Walking: ${first.walkDistanceMeters} meters, fare: ${first.fareText}.`,
  ].join(' ')
}

async function geocodeAddress(query: string, locale = DEFAULT_LOCALE): Promise<GeocodeCandidate[]> {
  const url = buildUrl('https://api.busnearby.co.il/geocode', {
    locale,
    query,
  })

  const response = await fetchJsonResponse(url, {
    accept: 'application/json',
    'accept-language': locale,
    origin: 'https://busnear.by',
    referer: 'https://busnear.by/',
    'user-agent': BUSNEARBY_USER_AGENT,
  })

  const data = await response.json()

  if (!Array.isArray(data)) {
    throw new Error('Geocode API returned an unexpected response')
  }

  const candidates = data
    .map((item: any) => {
      const latRaw = item?.lat
      const lngRaw = item?.lng ?? item?.lon

      const lat = toOptionalNumber(latRaw)
      const lng = toOptionalNumber(lngRaw)

      const formattedAddress =
        typeof item?.formatted_address === 'string' && item.formatted_address.trim().length > 0
          ? item.formatted_address.trim()
          : typeof item?.display_name === 'string' && item.display_name.trim().length > 0
            ? item.display_name.trim()
            : typeof item?.name === 'string' && item.name.trim().length > 0
              ? item.name.trim()
              : query

      if (typeof lat !== 'number' || typeof lng !== 'number') {
        return null
      }

      return {
        lat,
        lng,
        formatted_address: formattedAddress,
      }
    })
    .filter((candidate: GeocodeCandidate | null): candidate is GeocodeCandidate => candidate !== null)

  if (candidates.length === 0) {
    throw new Error(`No valid coordinates found for: ${query}`)
  }

  return candidates
}

async function reverseGeocodeLocation(
  lat: number,
  lon: number,
  locale = DEFAULT_LOCALE
): Promise<ReverseGeocodeResult> {
  const url = buildUrl('https://nominatim.openstreetmap.org/reverse', {
    format: 'json',
    addressdetails: '1',
    extratags: '1',
    namedetails: '1',
    lat,
    lon,
  })

  const response = await fetchJsonResponse(url, {
    accept: 'application/json',
    'accept-language': locale,
    'user-agent': BUSNEARBY_USER_AGENT,
  })

  const data = await response.json()

  if (!data || typeof data !== 'object') {
    throw new Error('Reverse geocode API returned an unexpected response')
  }

  const displayName =
    typeof data.display_name === 'string' && data.display_name.length > 0
      ? data.display_name
      : `${lat}, ${lon}`

  const address = data.address && typeof data.address === 'object' ? data.address : {}

  const road = typeof address.road === 'string' ? address.road : undefined
  const suburb = typeof address.suburb === 'string' ? address.suburb : undefined
  const city = typeof address.city === 'string'
    ? address.city
    : typeof address.town === 'string'
      ? address.town
      : typeof address.village === 'string'
        ? address.village
        : undefined
  const country = typeof address.country === 'string' ? address.country : undefined

  const formattedParts = [road, city].filter(Boolean)
  const formattedForDirections =
    formattedParts.length > 0 ? formattedParts.join(', ') : displayName

  return {
    lat: typeof data.lat === 'string' ? Number(data.lat) : lat,
    lon: typeof data.lon === 'string' ? Number(data.lon) : lon,
    display_name: displayName,
    road,
    suburb,
    city,
    country,
    formatted_for_directions: formattedForDirections,
  }
}

async function getDirections(params: {
  fromName: string
  fromLat: number
  fromLon: number
  toName: string
  toLat: number
  toLon: number
  locale: string
  numItineraries: number
  maxWalkDistance: number
}) {
  const url = buildUrl('https://api.busnearby.co.il/directions', {
    fromPlace: formatPlaceForDirections(params.fromName, params.fromLat, params.fromLon),
    toPlace: formatPlaceForDirections(params.toName, params.toLat, params.toLon),
    arriveBy: 'false',
    locale: params.locale,
    wheelchair: 'false',
    mode: 'WALK,TRANSIT',
    showIntermediateStops: 'true',
    numItineraries: params.numItineraries,
    maxWalkDistance: params.maxWalkDistance,
    optimize: 'QUICK',
    ignoreRealtimeUpdates: 'false',
  })

  const response = await fetchJsonResponse(url, {
    accept: 'application/json',
    'accept-language': params.locale,
    origin: 'https://busnear.by',
    referer: 'https://busnear.by/',
    'user-agent': BUSNEARBY_USER_AGENT,
    'x-bnb-variant': 'busnear.by',
  })

  return response.json()
}

async function fetchJsonResponse(url: string, headers: Record<string, string>): Promise<any> {
  const fetchFn = (globalThis as any).fetch

  if (typeof fetchFn !== 'function') {
    throw new Error('fetch API is not available in this Scripting environment.')
  }

  const response = await fetchFn(url, {
    method: 'GET',
    headers,
    timeout: REQUEST_TIMEOUT_SECONDS,
  } as any)

  if (!response || !(response as any).ok) {
    const status = Number((response as any)?.status)
    const statusText = String((response as any)?.statusText || '')
    let bodyPreview = ''

    try {
      if (typeof (response as any)?.text === 'function') {
        bodyPreview = String(await (response as any).text()).slice(0, 300)
      }
    } catch {
      bodyPreview = ''
    }

    throw new Error(
      `Transit request failed: ${Number.isFinite(status) ? status : 'unknown'} ${statusText}${bodyPreview ? ` — ${bodyPreview}` : ''}`
    )
  }

  return response
}


function buildUrl(base: string, params: Record<string, string | number | boolean | null | undefined>): string {
  const query = Object.entries(params)
    .filter(([, value]) => value !== null && value !== undefined && String(value).length > 0)
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`)
    .join('&')

  return query.length > 0 ? `${base}?${query}` : base
}

function minutes(secondsOrMs: number, unit: 'seconds' | 'ms' = 'seconds'): number {
  const seconds = unit === 'ms' ? secondsOrMs / 1000 : secondsOrMs
  return Math.round(seconds / 60)
}

function formatTime(ms: number, locale = 'he-IL'): string {
  return new Intl.DateTimeFormat(locale, {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: 'Asia/Jerusalem',
  }).format(new Date(ms))
}

function formatPlaceForDirections(name: string, lat: number, lon: number): string {
  return `${name}::${lat},${lon}`
}

function getFareText(itinerary: any): string {
  const regular = itinerary?.fare?.fare?.regular
  const cents = regular?.cents
  const symbol = regular?.currency?.symbol || '₪'

  if (typeof cents !== 'number') {
    return 'Unknown'
  }

  return `${symbol}${(cents / 100).toFixed(2)}`
}

function uniqueStrings(values: string[]): string[] {
  return Array.from(new Set(values.filter(Boolean)))
}

function buildFailureDisplay(
  message: string,
  params: TransitDirectionsIntentParams,
  language: string
): TransitDirectionsDisplayData {
  const now = new Date()
  const locale = firstString(params.locale) || getIntlLocale(language)
  const toQuery = firstString(params.toQuery) || 'Destination'
  const fromQuery = firstString(params.fromQuery) || 'Origin'

  return buildTransitDirectionsDisplay(
    {
      usedLocationSource: firstString(params.fromQuery) ? 'from_query' : 'device_location',
      from: {
        name: fromQuery,
        lat: toOptionalNumber(params.fromLat) || 0,
        lon: toOptionalNumber(params.fromLon) || 0,
        display_name: fromQuery,
      },
      to: {
        name: toQuery,
        lat: 0,
        lon: 0,
      },
      summary: message || getStrings(language).transitRouteNotFound,
      itineraries: [],
    },
    now
  )
}

function clampInt(value: unknown, fallback: number, min: number, max: number): number {
  const numberValue = toOptionalNumber(value)
  const intValue = typeof numberValue === 'number' ? Math.round(numberValue) : fallback
  return Math.max(min, Math.min(max, intValue))
}

function toOptionalNumber(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) return Number(value)
  return null
}

function firstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === 'string' && value.trim().length > 0) {
      return value.trim()
    }
  }
  return null
}

function extractMessage(error: unknown): string {
  if (error instanceof Error) return error.message
  if (typeof error === 'string') return error
  try {
    return JSON.stringify(error)
  } catch {
    return 'Unknown transit directions error'
  }
}
