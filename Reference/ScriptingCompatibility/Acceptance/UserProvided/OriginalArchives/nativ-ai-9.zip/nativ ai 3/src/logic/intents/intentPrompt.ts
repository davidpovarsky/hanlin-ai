// Pure JS - prompt builder for intent classification
// No platform dependencies.

export type IntentPromptInput = {
  userMessage: string
  language: string // 'he' | 'en' or any other tag
  currentDateTimeISO: string
  currentLocationLabel: string | null
}

export function buildIntentPrompt(input: IntentPromptInput): string {
  const lines: string[] = []

  lines.push('You are an intent classifier for a personal assistant app.')
  lines.push('Classify the user message into one of these intents:')
  lines.push('  - "weather": user asks about current weather or forecast.')
  lines.push('  - "reminder": user wants to create a reminder/task.')
  lines.push('  - "cityInfo": user asks for general information about a place, city, country, or landmark.')
  lines.push('  - "chat": user makes small talk, says hello, or asks a general question not related to tools.')
  lines.push('  - "unknown": none of the above.')
  lines.push('')
  lines.push('Extract the parameters for the matched intent and leave the others as empty strings or false.')
  lines.push('')
  lines.push(`Current date/time (ISO-8601, user time zone): ${input.currentDateTimeISO}`)
  if (input.currentLocationLabel) {
    lines.push(`User's approximate current location: ${input.currentLocationLabel}`)
  }
  lines.push(`User's preferred language: ${input.language}`)
  lines.push('')
  lines.push('Rules:')
  lines.push('- For reminder due dates, resolve relative expressions ("tomorrow", "in 2 hours", "next Monday at 9am") into a concrete ISO-8601 timestamp using the current date/time context.')
  lines.push('- For weather, if the user did not mention a specific place, set weatherUseCurrentLocation=true and weatherLocationName="".')
  lines.push('- For cityInfo, extract a clean, lookup-friendly query (e.g. "Tel Aviv" not "tell me about Tel Aviv please").')
  lines.push('- Confidence should be high (>=0.8) only when the intent is unambiguous.')
  lines.push('')
  lines.push('User message:')
  lines.push(input.userMessage)

  return lines.join('\n')
}
