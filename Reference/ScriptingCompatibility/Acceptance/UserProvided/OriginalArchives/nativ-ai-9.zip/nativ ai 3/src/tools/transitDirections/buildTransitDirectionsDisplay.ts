// src/tools/transitDirections/buildTransitDirectionsDisplay.ts
// Display/data types for the BusNearby transit directions tool.

export type TransitPlaceDisplay = {
  name: string
  lat: number
  lon: number
  displayName?: string
}

export type TransitStepDisplay = {
  id: string
  mode: string
  modeLabel: string
  iconName: string
  route?: string
  agency?: string
  from: string
  to: string
  startTime: string
  endTime: string
  durationMinutes: number
  durationLabel: string
  distanceMeters?: number
  distanceLabel?: string
  realtime?: boolean
  stopCodeFrom?: string
  stopCodeTo?: string
}

export type TransitItineraryDisplay = {
  id: string
  index: number
  title: string
  durationMinutes: number
  durationLabel: string
  timeRangeLabel: string
  walkDistanceMeters: number
  walkDistanceLabel: string
  walkTimeMinutes: number
  transitTimeMinutes: number
  waitingTimeMinutes: number
  transfers: number
  transfersLabel: string
  fareText: string
  routes: string[]
  routeBadges: string[]
  steps: TransitStepDisplay[]
  alerts: string[]
  isFastest: boolean
}

export type TransitDirectionsDisplayData = {
  title: string
  subtitle: string
  summary: string
  usedLocationSource: string
  usedLocationSourceLabel: string
  from: TransitPlaceDisplay
  to: TransitPlaceDisplay
  generatedAt: string
  generatedAtLabel: string
  itineraries: TransitItineraryDisplay[]
  warnings: string[]
}

export type TransitStepSummary = {
  mode: string
  route?: string
  agency?: string
  from: string
  to: string
  startTime: string
  endTime: string
  durationMinutes: number
  distanceMeters?: number
  realtime?: boolean
  stopCodeFrom?: string
  stopCodeTo?: string
}

export type TransitItinerarySummary = {
  index: number
  durationMinutes: number
  startTime: string
  endTime: string
  walkDistanceMeters: number
  walkTimeMinutes: number
  transitTimeMinutes: number
  waitingTimeMinutes: number
  transfers: number
  fareText: string
  routes: string[]
  steps: TransitStepSummary[]
  alerts: string[]
}

export type TransitDirectionsStructuredResult = {
  usedLocationSource: string
  from: {
    name: string
    lat: number
    lon: number
    display_name: string
  }
  to: {
    name: string
    lat: number
    lon: number
  }
  summary: string
  itineraries: TransitItinerarySummary[]
}

export function buildTransitDirectionsDisplay(
  result: TransitDirectionsStructuredResult,
  generatedAt = new Date()
): TransitDirectionsDisplayData {
  const itineraries = Array.isArray(result.itineraries)
    ? result.itineraries.map((itinerary, index) => buildItineraryDisplay(itinerary, index))
    : []

  const warnings: string[] = []
  if (itineraries.length === 0) {
    warnings.push('No public transit routes were found for this request.')
  }

  const fastest = itineraries[0]
  const subtitle = fastest
    ? `${fastest.durationLabel} · ${fastest.timeRangeLabel}`
    : 'No route is currently available'

  return {
    title: `Route to ${result.to?.name || 'the destination'}`,
    subtitle,
    summary: result.summary || '',
    usedLocationSource: result.usedLocationSource || '',
    usedLocationSourceLabel: formatLocationSource(result.usedLocationSource),
    from: {
      name: result.from?.name || 'Origin',
      lat: safeNumber(result.from?.lat),
      lon: safeNumber(result.from?.lon),
      displayName: result.from?.display_name || result.from?.name || '',
    },
    to: {
      name: result.to?.name || 'Destination',
      lat: safeNumber(result.to?.lat),
      lon: safeNumber(result.to?.lon),
    },
    generatedAt: generatedAt.toISOString(),
    generatedAtLabel: formatGeneratedAt(generatedAt),
    itineraries,
    warnings,
  }
}

function buildItineraryDisplay(
  itinerary: TransitItinerarySummary,
  zeroBasedIndex: number
): TransitItineraryDisplay {
  const steps = Array.isArray(itinerary.steps)
    ? itinerary.steps.map((step, index) => buildStepDisplay(step, index))
    : []

  const routeBadges = Array.isArray(itinerary.routes) && itinerary.routes.length > 0
    ? itinerary.routes.slice(0, 6)
    : []

  return {
    id: `itinerary_${itinerary.index || zeroBasedIndex + 1}`,
    index: itinerary.index || zeroBasedIndex + 1,
    title: zeroBasedIndex === 0 ? 'Fastest route' : `Option ${itinerary.index || zeroBasedIndex + 1}`,
    durationMinutes: safeNumber(itinerary.durationMinutes),
    durationLabel: formatMinutes(itinerary.durationMinutes),
    timeRangeLabel: formatTimeRange(itinerary.startTime, itinerary.endTime),
    walkDistanceMeters: safeNumber(itinerary.walkDistanceMeters),
    walkDistanceLabel: formatDistance(itinerary.walkDistanceMeters),
    walkTimeMinutes: safeNumber(itinerary.walkTimeMinutes),
    transitTimeMinutes: safeNumber(itinerary.transitTimeMinutes),
    waitingTimeMinutes: safeNumber(itinerary.waitingTimeMinutes),
    transfers: safeNumber(itinerary.transfers),
    transfersLabel: formatTransfers(itinerary.transfers),
    fareText: itinerary.fareText || 'Unknown',
    routes: Array.isArray(itinerary.routes) ? itinerary.routes : [],
    routeBadges,
    steps,
    alerts: Array.isArray(itinerary.alerts) ? itinerary.alerts : [],
    isFastest: zeroBasedIndex === 0,
  }
}

function buildStepDisplay(step: TransitStepSummary, index: number): TransitStepDisplay {
  return {
    id: `step_${index}_${step.mode}_${step.route || ''}`,
    mode: step.mode || 'UNKNOWN',
    modeLabel: formatMode(step.mode),
    iconName: iconForMode(step.mode),
    route: step.route,
    agency: step.agency,
    from: step.from || 'Origin',
    to: step.to || 'Destination',
    startTime: step.startTime || '',
    endTime: step.endTime || '',
    durationMinutes: safeNumber(step.durationMinutes),
    durationLabel: formatMinutes(step.durationMinutes),
    distanceMeters: typeof step.distanceMeters === 'number' ? Math.round(step.distanceMeters) : undefined,
    distanceLabel: typeof step.distanceMeters === 'number' ? formatDistance(step.distanceMeters) : undefined,
    realtime: step.realtime,
    stopCodeFrom: step.stopCodeFrom,
    stopCodeTo: step.stopCodeTo,
  }
}

function formatLocationSource(source: string): string {
  switch (source) {
    case 'from_query':
      return 'Entered origin address'
    case 'explicit_arguments':
      return 'Origin coordinates'
    case 'device_location':
      return 'Device current location'
    case 'openai_userLocation_meta':
      return 'User location provided to the model'
    default:
      return source || 'Unknown'
  }
}

function formatGeneratedAt(date: Date): string {
  try {
    return new Intl.DateTimeFormat('he-IL', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: 'Asia/Jerusalem',
    }).format(date)
  } catch {
    return ''
  }
}

function formatMinutes(value: unknown): string {
  const minutes = safeNumber(value)
  if (minutes <= 0) return 'Less than a minute'
  if (minutes === 1) return 'One minute'
  return `${minutes} min`
}

function formatDistance(value: unknown): string {
  const meters = Math.round(safeNumber(value))
  if (meters <= 0) return '0 m'
  if (meters < 1000) return `${meters} m`
  return `${(meters / 1000).toFixed(1)} km`
}

function formatTransfers(value: unknown): string {
  const transfers = safeNumber(value)
  if (transfers <= 0) return 'No transfers'
  if (transfers === 1) return '1 transfer'
  return `${transfers} transfers`
}

function formatTimeRange(start: string, end: string): string {
  if (start && end) return `${start}–${end}`
  if (start) return `Departure ${start}`
  if (end) return `Arrival ${end}`
  return 'Unknown time'
}

function formatMode(modeRaw: string): string {
  const mode = String(modeRaw || '').toUpperCase()
  switch (mode) {
    case 'WALK':
      return 'Walking'
    case 'BUS':
      return 'Bus'
    case 'RAIL':
      return 'Train'
    case 'TRAM':
    case 'SUBWAY':
      return 'Light rail'
    case 'TRANSIT':
      return 'public transit'
    default:
      return mode || 'Step'
  }
}

function iconForMode(modeRaw: string): string {
  const mode = String(modeRaw || '').toUpperCase()
  switch (mode) {
    case 'WALK':
      return 'figure.walk'
    case 'BUS':
      return 'bus.fill'
    case 'RAIL':
      return 'tram.fill'
    case 'TRAM':
    case 'SUBWAY':
      return 'tram.fill'
    default:
      return 'arrow.triangle.turn.up.right.diamond.fill'
  }
}

function safeNumber(value: unknown): number {
  if (typeof value === 'number' && Number.isFinite(value)) return Math.round(value)
  if (typeof value === 'string' && Number.isFinite(Number(value))) return Math.round(Number(value))
  return 0
}
