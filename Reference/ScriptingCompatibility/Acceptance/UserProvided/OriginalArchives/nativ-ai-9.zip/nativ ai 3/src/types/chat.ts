// Pure type definitions for chat messages

import { ParsedIntent } from './intents'

export type ChatRole = 'user' | 'assistant' | 'tool'

export type ToolPayload = {
  kind: string
  data: unknown
}

export type ChatAttachmentKind = 'image' | 'document'

export type ChatAttachment = {
  id: string
  kind: ChatAttachmentKind
  name: string
  mediaType: string
  data: string
}

export type ToolRunStatus = 'running' | 'success' | 'error'

export type ToolRunRecord = {
  id: string
  tool: string
  action?: string | null
  params: Record<string, unknown>
  status: ToolRunStatus
  startedAt: number
  finishedAt?: number | null
  response?: unknown
  errorMessage?: string | null
  payloadKind?: string | null
  hasUICard?: boolean
}

export type WeatherDisplayData = {
  locationName: string
  temperature: string
  feelsLike: string
  condition: string
  humidity: number
  windSpeed: string
  symbolName: string
}

export type ReminderDisplayData = {
  title: string
  notes: string | null
  dueDateISO: string | null
  priority: 'none' | 'low' | 'medium' | 'high'
  status: 'pending' | 'created' | 'failed'
  errorMessage: string | null
}


export type EmailDraftDisplayData = {
  recipientName: string
  toEmail: string
  subject: string
  body: string
  request: string
  tone: string
  status: 'draft' | 'failed'
  lastEditInstruction: string | null
  errorMessage: string | null
}

export type CityInfoDisplayData = {
  title: string
  summary: string
  pageUrl: string | null
  thumbnailUrl: string | null
}

export type ChatBranchOption = {
  id: string
  title: string
  createdAt: number
  messages: ChatMessage[]
}

export type ChatMessage = {
  id: string
  role: ChatRole
  text: string
  attachments?: ChatAttachment[]
  toolPayload: ToolPayload | null
  toolRuns?: ToolRunRecord[]
  toolStatusText?: string | null
  intent: ParsedIntent | null
  createdAt: number
  isStreaming: boolean

  // Conversation branching metadata.
  // Present only on the first message of a branch/version group.
  branchGroupId?: string | null
  activeBranchId?: string | null
  branchOptions?: ChatBranchOption[] | null
  editedFromId?: string | null
}

export type ChatSession = {
  id: string
  title: string
  createdAt: number
  updatedAt?: number
  isFavorite?: boolean
  titleManuallyEdited?: boolean
  messages: ChatMessage[]
}
