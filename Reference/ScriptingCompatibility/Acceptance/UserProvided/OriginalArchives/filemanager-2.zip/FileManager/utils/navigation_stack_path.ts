export { NavigationDestination, NavigationStack } from 'scripting'
