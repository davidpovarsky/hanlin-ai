export type FileEntry = { name: string; path: string; isDir: boolean; stat?: FileStat }

/**
 * 读取目录并返回排好序的文件/文件夹元数据。
 * - 隐藏文件通过 showHidden 控制
 * - 同步一次 isDirectory/stat，避免渲染阶段重复 I/O
 */
export async function loadEntries(path: string, showHidden: boolean): Promise<FileEntry[]> {
  const names = await FileManager.readDirectory(path)
  const filtered = names.filter((n: string) => showHidden || !n.startsWith('.'))

  const withMeta: FileEntry[] = filtered.map((name: string) => {
    const fullPath = path + '/' + name
    let isDir = false
    let stat: FileStat | undefined = undefined
    try {
      isDir = FileManager.isDirectorySync(fullPath)
    } catch (err) {
      console.error('[FileEntries] isDirectorySync failed', fullPath, err)
    }
    try {
      stat = FileManager.statSync(fullPath)
    } catch (err) {
      console.error('[FileEntries] statSync failed', fullPath, err)
    }
    return { name, path: fullPath, isDir, stat }
  })

  return withMeta.sort((a, b) => {
    if (a.isDir && !b.isDir) return -1
    if (!a.isDir && b.isDir) return 1
    return a.name.localeCompare(b.name)
  })
}
