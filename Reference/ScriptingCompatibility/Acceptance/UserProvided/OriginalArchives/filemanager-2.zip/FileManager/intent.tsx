import { Intent, Navigation, Script } from "scripting"
import { FileListScreen } from './screens/FileListScreen'

async function runIntent() {
  await Navigation.present({
    element: <FileListScreen />
  })
  Script.exit()
}

runIntent()
