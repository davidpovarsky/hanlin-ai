import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'scripting'

type ToastConfig = {
  isPresented: boolean
  onChanged: (value: boolean) => void
  message: string
  duration?: number
  position?: 'top' | 'bottom' | 'center'
}

type ToastContextValue = {
  toastProps?: ToastConfig
  showToast: (message: string) => void
  hideToast: () => void
}

const ToastContext = createContext<ToastContextValue | null>()

export const ToastProvider = ({ children }: { children: JSX.Element }) => {
  const [toastState, setToastState] = useState<{ message: string; id: number } | null>(null)
  const [isPresented, setIsPresented] = useState(false)
  const pendingTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const showToast = useCallback((message: string) => {
    setToastState({ message, id: Date.now() })
    setIsPresented(false)
    if (pendingTimer.current) {
      clearTimeout(pendingTimer.current)
    }
    pendingTimer.current = setTimeout(() => {
      setIsPresented(true)
      pendingTimer.current = null
    }, 0)
  }, [])

  const hideToast = useCallback(() => {
    setIsPresented(false)
    setToastState(null)
  }, [])

  useEffect(() => {
    return () => {
      if (pendingTimer.current) {
        clearTimeout(pendingTimer.current)
      }
    }
  }, [])

  const handleChanged = useCallback((value: boolean) => {
    setIsPresented(value)
    if (!value) {
      setToastState(null)
    }
  }, [])

  const toastProps = useMemo(() => {
    if (!toastState) {
      return undefined
    }
    return {
      isPresented,
      onChanged: handleChanged,
      message: toastState.message,
      duration: 2,
      position: 'bottom' as const
    }
  }, [handleChanged, isPresented, toastState])

  const value = useMemo(() => ({ toastProps, showToast, hideToast }), [toastProps, showToast, hideToast])

  return <ToastContext.Provider value={value}>{children}</ToastContext.Provider>
}

export const useToast = () => {
  const ctx = useContext(ToastContext)
  if (!ctx) {
    throw new Error('useToast must be used within ToastProvider')
  }
  return ctx
}
