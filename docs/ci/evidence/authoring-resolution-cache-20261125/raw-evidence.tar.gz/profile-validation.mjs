import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {pathToFileURL} from 'node:url';

// Diagnostic only: invoke the shipping validator and its exact staged compiler.
// No fixture, timeout, type-checking option, or emitted report is rewritten.
const configuration = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const fileHash = file => hash(fs.readFileSync(file));
const sdkManifestPath = path.join(configuration.sdkRoot, 'miniapp-sdk.json');
const sdk = JSON.parse(fs.readFileSync(sdkManifestPath, 'utf8'));
const compilerPath = path.join(configuration.sdkRoot, sdk.engines.expo.typescriptPath);
const sourceHash = fileHash(configuration.modulePath);
if (sourceHash !== configuration.expectedModuleSHA256) throw new Error('Validator source changed');
if (fileHash(sdkManifestPath) !== configuration.expectedSDKManifestSHA256) throw new Error('SDK manifest changed');
const ts = (await import(pathToFileURL(compilerPath).href)).default;
const {runMiniAppOperation} = await import(pathToFileURL(configuration.modulePath).href);
const counters = {};
function measure(name, operation, receiver) {
  return function (...args) {
    const start = performance.now();
    try { return operation.apply(receiver, args); }
    finally {
      const counter = counters[name] ??= {calls: 0, milliseconds: 0};
      counter.calls += 1;
      counter.milliseconds += performance.now() - start;
    }
  };
}
const compiler = {...ts};
for (const name of ['createProgram', 'getPreEmitDiagnostics', 'resolveModuleName', 'resolveTypeReferenceDirective']) {
  compiler[name] = measure(name, ts[name], ts);
}
compiler.createCompilerHost = function (...args) {
  const host = ts.createCompilerHost(...args);
  for (const name of ['fileExists', 'readFile', 'directoryExists', 'getDirectories', 'realpath']) {
    if (typeof host[name] === 'function') host[name] = measure('host.' + name, host[name], host);
  }
  return host;
};
const sourceFiles = {};
function inventory(directory) {
  for (const entry of fs.readdirSync(directory, {withFileTypes: true})) {
    if (['node_modules', '.git', '.hanlin-build', '.hanlin-authoring'].includes(entry.name)) continue;
    const location = path.join(directory, entry.name);
    if (entry.isDirectory()) inventory(location);
    else if (entry.isFile()) sourceFiles[path.relative(configuration.projectRoot, location)] = fileHash(location);
    else throw new Error('Unexpected diagnostic consumer member: ' + location);
  }
}
inventory(configuration.projectRoot);
const startedAt = new Date().toISOString();
const started = performance.now();
const report = await runMiniAppOperation({
  operation: 'validate', engine: 'expo', projectRoot: configuration.projectRoot,
}, {sdkRoot: configuration.sdkRoot, compiler});
const elapsedMilliseconds = performance.now() - started;
if (fileHash(configuration.modulePath) !== sourceHash ||
    fileHash(sdkManifestPath) !== configuration.expectedSDKManifestSHA256) {
  throw new Error('Diagnostic input changed during validation');
}
for (const [relative, expected] of Object.entries(sourceFiles)) {
  if (fileHash(path.join(configuration.projectRoot, relative)) !== expected) throw new Error('Consumer changed');
}
const result = {
  kind: 'COMPONENT_VALIDATION_PROFILE_NOT_SIMULATOR_ACCEPTANCE',
  source: configuration.source, startedAt, finishedAt: new Date().toISOString(),
  nodeVersion: process.version, nodeArguments: process.execArgv,
  architecture: process.arch, platform: process.platform,
  validatorSHA256: sourceHash, sdkManifestSHA256: configuration.expectedSDKManifestSHA256,
  compilerVersion: ts.version, compilerEntryPath: compilerPath,
  compilerEntrySHA256: fileHash(compilerPath), sourceFiles,
  elapsedMilliseconds, counters, report,
  maximumResidentSetKiB: process.resourceUsage().maxRSS,
};
fs.writeFileSync(configuration.outputPath, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({outputPath: configuration.outputPath,
  succeeded: report.succeeded, diagnostics: report.diagnostics.length,
  elapsedMilliseconds, counters, maximumResidentSetKiB: result.maximumResidentSetKiB}));
process.exitCode = report.succeeded ? 0 : 1;
