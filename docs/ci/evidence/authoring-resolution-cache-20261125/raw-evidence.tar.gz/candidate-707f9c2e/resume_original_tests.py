from pathlib import Path
import datetime,hashlib,json,importlib.util,os,re,signal
BASE=Path('/Users/m1/caches/HanlinThreeWaves/expo-authoring-profile-a146bc7a-20261125/candidate-707f9c2e')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(BASE/'controller.py')=='8ea3a02fe04bab009ea8479dd420fb1175f87301da62eb1801a6f0b752aaed20'
assert digest(BASE/'receipt.json')=='55be254c0fbf851739a1bf2d75d8a7141bb49647ba4b26410368d520b6db3fed'
assert digest(BASE/'profile-result.json')=='71518f0e42e772ec1bb6621a8612fafbeaa266b057915aa05374a574a58a522f'
old=json.loads((BASE/'receipt.json').read_text());assert old['profile']['reportExactlyEqual']
spec=importlib.util.spec_from_file_location('owned_component_controller',BASE/'controller.py');core=importlib.util.module_from_spec(spec);spec.loader.exec_module(core)
root=BASE/'tests-r2';root.mkdir(exist_ok=False)
core.CONTROL=root
core.state={'kind':'ORIGINAL_TESTS_ONLY_AFTER_COMPILER_URL_SERIALIZATION_REPAIR','source':core.SOURCE,'startedAt':core.now(),'controllerSHA256':digest(__file__),'importedControllerSHA256':digest(BASE/'controller.py'),'priorReceiptSHA256':digest(BASE/'receipt.json'),'profileResultSHA256':digest(BASE/'profile-result.json'),'profileReexecuted':False,'status':'PREPARING','steps':[]}
manifest=json.loads((BASE/'inputs.json').read_text());repository=BASE/'repository';host=repository/'AI_HLY/Downstream/RuntimeCore/Node/Host'
compiler=Path(old['compilerIdentity']['underlyingEntry'])
assert digest(compiler)==old['compilerIdentity']['underlyingEntrySHA256']
for name in ['miniapp-authoring.test.mjs','miniapp-sdk-resolution.test.mjs']:assert digest(host/'Tests'/name)==manifest['files'][name]
assert digest(repository/'Scripts/MiniApps/miniapp.mjs')==manifest['files']['miniapp.mjs']
assert digest(host/'miniapp-authoring.mjs')==core.CANDIDATE
compiler_uri=core.read_command([str(core.NODE),'-e',"const {pathToFileURL,fileURLToPath}=require('node:url');const u=pathToFileURL(process.argv[1]);if(fileURLToPath(u)!==process.argv[1]||new URL('../package.json',u).pathname.includes('%'))throw Error('Invalid existing fixture URL');console.log(u.href)",str(compiler)])
assert compiler_uri.startswith('file:///') and '/@typescript/old/' in compiler_uri
environment=dict(os.environ);temp=root/'temp';temp.mkdir()
environment.update(HANLIN_AUTHORING_TYPESCRIPT=compiler_uri,HANLIN_MINIAPP_REPOSITORY_ROOT=str(repository),HANLIN_AUTHORING_TMP=str(temp),TMPDIR=str(temp),PATH=str(core.NODE.parent)+':/Users/m1/builds/hanlin-ai-ce49e30d-miniapp-complete-tools/bin:/usr/bin:/bin:/usr/sbin:/sbin')
core.state['testEnvironment']={k:environment[k] for k in ['HANLIN_AUTHORING_TYPESCRIPT','HANLIN_MINIAPP_REPOSITORY_ROOT','HANLIN_AUTHORING_TMP','TMPDIR']};core.checkpoint()
for sig in [signal.SIGTERM,signal.SIGINT]:
 signal.signal(sig,lambda value,frame: (_ for _ in ()).throw(RuntimeError('Controller interrupted '+str(value))))
try:
 core.capacity('tests');core.state['status']='TESTING';core.checkpoint()
 command=[core.NODE,'--jitless','--max-old-space-size=2048','--test-concurrency=1','--test-reporter=tap','--test',host/'Tests/miniapp-authoring.test.mjs',host/'Tests/miniapp-sdk-resolution.test.mjs']
 log=core.run('original17',command,600,env=environment,cwd=repository)
 tap=log.read_text();counts={k:int(re.search(r'^# '+k+r' (\d+)\s*$',tap,re.M).group(1)) for k in ['tests','pass','fail','cancelled','skipped']}
 assert counts=={'tests':17,'pass':17,'fail':0,'cancelled':0,'skipped':0},counts
 identities=re.findall(r'^ok \d+ - (.+)$',tap,re.M);assert len(identities)==17
 core.state['tests']={'counts':counts,'identities':identities,'logSHA256':digest(log)}
 for name in ['miniapp-authoring.test.mjs','miniapp-sdk-resolution.test.mjs']:assert digest(host/'Tests'/name)==manifest['files'][name]
 assert digest(repository/'Scripts/MiniApps/miniapp.mjs')==manifest['files']['miniapp.mjs']
 assert digest(host/'miniapp-authoring.mjs')==core.CANDIDATE
 assert digest(BASE/'receipt.json')=='55be254c0fbf851739a1bf2d75d8a7141bb49647ba4b26410368d520b6db3fed'
 assert digest(BASE/'profile-result.json')=='71518f0e42e772ec1bb6621a8612fafbeaa266b057915aa05374a574a58a522f'
 shipping=Path('/Users/m1/builds/hanlin-wave2-a146bc7a-20261125/AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-authoring.mjs');assert digest(shipping)==core.ORIGINAL
 assert digest(core.BASE/'baseline-r2-receipt.json')==core.BASELINE_RECEIPT and digest(core.BASE/'baseline-r2/result.json')==core.BASELINE_RESULT
 core.state['status']='EXECUTED_PASS_17_ORIGINAL_CASES';core.state['sourceTestsBaselineAndProfileUnchanged']=True
except BaseException as e:
 core.state.update(status='FAILED',error=type(e).__name__+': '+str(e));raise
finally:
 core.stop_owned();core.state['finishedAt']=core.now();core.checkpoint()
print(json.dumps({'status':core.state['status'],'receipt':str(root/'receipt.json'),'receiptSHA256':digest(root/'receipt.json'),'tests':core.state.get('tests')}))
