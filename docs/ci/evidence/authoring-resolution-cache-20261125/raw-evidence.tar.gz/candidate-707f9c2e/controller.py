#!/usr/bin/env python3
"""One isolated authoring cache profile and the original affected portable tests."""
from pathlib import Path
import datetime, fcntl, hashlib, json, os, re, shutil, signal, subprocess, sys, time

BASE = Path('/Users/m1/caches/HanlinThreeWaves/expo-authoring-profile-a146bc7a-20261125')
CONTROL = BASE / 'candidate-707f9c2e'
HOST = BASE / 'host'
SOURCE = '707f9c2e3ea8488fafb284e14a7b7636ebb25a48'
CANDIDATE = '6eb7130890499768b72990cc48cf84b515232635bf00b4ca023bcc1b161182fc'
ORIGINAL = 'fa5121902e231d5d44ad08bf47699784fd4d0bc2a98102f3a156e6e4ae79b9b9'
BASELINE_RECEIPT = '99ad8dd38fd35a73157b14033e0c9c550225bbccfa9a5a16cb0831ca1d6c8fe2'
BASELINE_RESULT = '51a3f121fbd74f05b3f4fec14d2dcb1db9ea9525875ecaaee80b649c9a57dc7c'
PROFILE = '9380f307b20212b3796ddf6fcd27677804e63b3afdd2d5ca178d4d2060d1a9c0'
NODE = Path('/Users/m1/builds/hanlin-ai-ce49e30d-miniapp-complete-tools/node-v24.5.0-darwin-arm64/bin/node')
GIB = 1024 ** 3
state = None
current = None

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p, value):
    p = Path(p)
    temporary = p.with_name(p.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(p)
def checkpoint(): save(CONTROL / 'receipt.json', state)
def read_command(args):
    return subprocess.check_output(args, text=True, stderr=subprocess.PIPE, timeout=30).strip()

def capacity(phase):
    available = int(read_command(['df', '-k', '/System/Volumes/Data']).splitlines()[-1].split()[3]) * 1024
    pressure = int(read_command(['sysctl', '-n', 'kern.memorystatus_vm_pressure_level']))
    memory = read_command(['memory_pressure', '-Q'])
    free = re.search(r'System-wide memory free percentage:\s*(\d+)%', memory)
    assert free, 'Memory observation unavailable'
    memory_bytes = int(read_command(['sysctl', '-n', 'hw.memsize'])) * int(free.group(1)) // 100
    incremental = 64 * 1024 ** 2 if phase == 'profile' else 256 * 1024 ** 2
    observation = {'at': now(), 'phase': phase, 'availableBytes': available,
        'phaseIncrementalBudgetBytes': incremental, 'osMarginBytes': 2 * GIB,
        'concurrentGrowthBytes': 2 * GIB, 'kernelPressureLevel': pressure,
        'estimatedAvailableMemoryBytes': memory_bytes,
        'swapUsage': read_command(['sysctl', 'vm.swapusage']),
        'policy': 'mac-storage-lifecycle-v2',
        'basis': 'Existing Host/SDK reused. Original compiler package measured 24108 KiB; serial fixture copies are bounded by 6 such packages plus logs/profile headroom. Baseline RSS397344 KiB; parent plus original CLI child budget1.5GiB. Independent native compiles/UI are not a conflict for this component-only operation.'}
    state.setdefault('capacity', []).append(observation)
    checkpoint()
    assert available >= incremental + 4 * GIB, 'Measured phase plus concurrent/OS margins do not fit'
    assert pressure < 4, 'Critical memory pressure'
    assert pressure < 2 or memory_bytes >= 3 * GIB // 2, 'Warning pressure leaves insufficient component memory'

def stop_owned():
    global current
    if current is not None and current.poll() is None:
        os.killpg(current.pid, signal.SIGTERM)
        try: current.wait(timeout=8)
        except subprocess.TimeoutExpired:
            os.killpg(current.pid, signal.SIGKILL)
            current.wait(timeout=8)
    current = None

def run(name, command, timeout, env=None, cwd=None):
    global current
    log = CONTROL / (name + '.log')
    step = {'name': name, 'command': list(map(str, command)), 'startedAt': now(), 'log': str(log)}
    state['steps'].append(step)
    checkpoint()
    start = time.monotonic()
    try:
        with log.open('xb') as output:
            current = subprocess.Popen(list(map(str, command)), stdout=output, stderr=subprocess.STDOUT,
                env=env, cwd=cwd, start_new_session=True)
            step['pid'] = current.pid
            checkpoint()
            while True:
                try:
                    current.wait(timeout=min(20, max(1, timeout - (time.monotonic() - start))))
                    break
                except subprocess.TimeoutExpired:
                    if time.monotonic() - start >= timeout: raise
                    available = int(read_command(['df', '-k', '/System/Volumes/Data']).splitlines()[-1].split()[3]) * 1024
                    if available < 2 * GIB: raise RuntimeError('Concurrent disk growth consumed the OS margin')
            step['exitCode'] = current.returncode
        step.update(finishedAt=now(), seconds=time.monotonic() - start, logSHA256=digest(log))
        checkpoint()
        if step['exitCode']: raise RuntimeError(name + ' failed: ' + str(step['exitCode']))
        return log
    finally:
        stop_owned()

def execute():
    global state
    manifest = json.loads((CONTROL / 'inputs.json').read_text())
    assert manifest['commit'] == SOURCE and manifest['candidateSHA256'] == CANDIDATE
    for name, expected in manifest['files'].items():
        assert digest(CONTROL / 'inputs' / name) == expected, 'Staged input changed: ' + name
    assert digest(BASE / 'baseline-r2-receipt.json') == BASELINE_RECEIPT
    assert digest(BASE / 'baseline-r2/result.json') == BASELINE_RESULT
    assert digest(BASE / 'profile-validation.mjs') == PROFILE
    original_config = json.loads((BASE / 'baseline-r2/configuration.json').read_text())
    baseline = json.loads((BASE / 'baseline-r2/result.json').read_text())
    assert baseline['compilerVersion'] == '6.0.3' and baseline['nodeVersion'] == 'v24.5.0'
    target = HOST / 'miniapp-authoring.mjs'
    assert digest(target) == ORIGINAL and not target.is_symlink()
    shipping = Path('/Users/m1/builds/hanlin-wave2-a146bc7a-20261125/AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-authoring.mjs')
    assert not os.path.samefile(target, shipping)
    shipping_hash = digest(shipping)
    assert shipping_hash == ORIGINAL
    state = {'kind': 'COMPONENT_PROFILE_AND_PORTABLE_TESTS_NOT_NATIVE_ACCEPTANCE',
        'owner': '/root/sidebar', 'source': SOURCE, 'base': '5204240a3d0d5e05e366123bb7f7bbdb9d0ebfd0',
        'candidateFileSHA256': CANDIDATE, 'baselineReceiptSHA256': BASELINE_RECEIPT,
        'controllerSHA256': digest(__file__), 'startedAt': now(), 'status': 'PREPARING', 'steps': []}
    checkpoint()
    capacity('profile')
    shutil.copy2(target, CONTROL / 'original-miniapp-authoring.mjs')
    pending = target.with_name('miniapp-authoring.candidate-tmp')
    assert not pending.exists()
    pending.write_bytes((CONTROL / 'inputs/miniapp-authoring.mjs').read_bytes())
    pending.chmod(target.stat().st_mode & 0o777)
    pending.replace(target)
    assert digest(target) == CANDIDATE

    repository = CONTROL / 'repository'
    test_host = repository / 'AI_HLY/Downstream/RuntimeCore/Node/Host'
    (test_host / 'Tests').mkdir(parents=True)
    (test_host / 'miniapp-authoring.mjs').symlink_to(target)
    for name in ['miniapp-authoring.test.mjs', 'miniapp-sdk-resolution.test.mjs']:
        shutil.copy2(CONTROL / 'inputs' / name, test_host / 'Tests' / name)
    cli = repository / 'Scripts/MiniApps/miniapp.mjs'
    cli.parent.mkdir(parents=True)
    shutil.copy2(CONTROL / 'inputs/miniapp.mjs', cli)
    assert (test_host / 'miniapp-authoring.mjs').resolve() == target.resolve()

    config = dict(original_config)
    config.update(source=SOURCE, expectedModuleSHA256=CANDIDATE, outputPath=str(CONTROL / 'profile-result.json'))
    save(CONTROL / 'configuration.json', config)
    state['profileConfigurationSHA256'] = digest(CONTROL / 'configuration.json')
    state['status'] = 'PROFILING'
    checkpoint()
    original_command = json.loads((BASE / 'baseline-r2-receipt.json').read_text())['command']
    command = [str(CONTROL / 'configuration.json') if x == str(BASE / 'baseline-r2/configuration.json')
        else '--cpu-prof-dir=' + str(CONTROL) if x.startswith('--cpu-prof-dir=')
        else '--cpu-prof-name=candidate.cpuprofile' if x.startswith('--cpu-prof-name=') else x for x in original_command]
    assert command[0] == str(NODE)
    run('profile', command, 120)
    result = json.loads((CONTROL / 'profile-result.json').read_text())
    for key in ['report', 'sourceFiles', 'compilerVersion', 'compilerEntryPath', 'compilerEntrySHA256', 'sdkManifestSHA256', 'platform', 'architecture']:
        assert result[key] == baseline[key], 'Candidate changed the original validation report/input: ' + key
    state['profile'] = {'resultSHA256': digest(CONTROL / 'profile-result.json'),
        'reportExactlyEqual': True, 'inputFilesExactlyEqual': True,
        'baselineMilliseconds': baseline['elapsedMilliseconds'], 'candidateMilliseconds': result['elapsedMilliseconds'],
        'savedPercent': (baseline['elapsedMilliseconds'] - result['elapsedMilliseconds']) / baseline['elapsedMilliseconds'] * 100,
        'baselineCounters': baseline['counters'], 'candidateCounters': result['counters'],
        'baselineMaximumRSSKiB': baseline['maximumResidentSetKiB'], 'candidateMaximumRSSKiB': result['maximumResidentSetKiB']}
    checkpoint()

    # The staged npm typescript entry is a wrapper for @typescript/old. Use that
    # exact underlying compiler package in the original tests' SDK symlink fixture,
    # avoiding a fabricated package that omits the wrapper's npm dependency.
    wrapper = Path(result['compilerEntryPath'])
    compiler = wrapper.parent.parent.parent / '@typescript/old/lib/typescript.js'
    identity_script = "const r=require('node:module').createRequire(process.argv[1]);const a=r(process.argv[1]);const b=r(process.argv[2]);if(a!==b||a.version!=='6.0.3')throw Error('Compiler identity mismatch');console.log(JSON.stringify({version:a.version,sameCompilerObject:a===b}));"
    identity = run('compiler-identity', [NODE, '--jitless', '-e', identity_script, wrapper, compiler], 30)
    state['compilerIdentity'] = {'wrapper': str(wrapper), 'wrapperSHA256': digest(wrapper),
        'underlyingEntry': str(compiler), 'underlyingEntrySHA256': digest(compiler),
        'sameCompilerObject': True, 'version': '6.0.3', 'proofLogSHA256': digest(identity)}
    capacity('tests')
    environment = dict(os.environ)
    environment.update(HANLIN_AUTHORING_TYPESCRIPT=compiler.as_uri(), HANLIN_MINIAPP_REPOSITORY_ROOT=str(repository),
        HANLIN_AUTHORING_TMP=str(CONTROL / 'test-temp'), TMPDIR=str(CONTROL / 'test-temp'),
        PATH=str(NODE.parent) + ':/Users/m1/builds/hanlin-ai-ce49e30d-miniapp-complete-tools/bin:/usr/bin:/bin:/usr/sbin:/sbin')
    (CONTROL / 'test-temp').mkdir()
    state['testEnvironment'] = {key: environment[key] for key in ['HANLIN_AUTHORING_TYPESCRIPT', 'HANLIN_MINIAPP_REPOSITORY_ROOT', 'HANLIN_AUTHORING_TMP', 'TMPDIR']}
    state['status'] = 'TESTING'
    checkpoint()
    log = run('original-authoring-and-resolution-tests', [NODE, '--jitless', '--max-old-space-size=2048',
        '--test-concurrency=1', '--test-reporter=tap', '--test', test_host / 'Tests/miniapp-authoring.test.mjs',
        test_host / 'Tests/miniapp-sdk-resolution.test.mjs'], 600, env=environment, cwd=repository)
    tap = log.read_text()
    counts = {key: int(re.search(r'^# ' + key + r' (\d+)\s*$', tap, re.M).group(1)) for key in ['tests', 'pass', 'fail', 'cancelled', 'skipped']}
    assert counts == {'tests': 17, 'pass': 17, 'fail': 0, 'cancelled': 0, 'skipped': 0}, counts
    passed = re.findall(r'^ok \d+ - (.+)$', tap, re.M)
    assert len(passed) == 17
    state['tests'] = {'status': 'EXECUTED_PASS', 'counts': counts, 'identities': passed, 'logSHA256': digest(log)}
    assert digest(target) == CANDIDATE and digest(shipping) == shipping_hash
    assert digest(BASE / 'baseline-r2-receipt.json') == BASELINE_RECEIPT
    assert digest(BASE / 'baseline-r2/result.json') == BASELINE_RESULT
    assert digest(BASE / 'profile-validation.mjs') == PROFILE
    for name, expected in manifest['files'].items():
        assert digest(CONTROL / 'inputs' / name) == expected
    for name in ['miniapp-authoring.test.mjs', 'miniapp-sdk-resolution.test.mjs']:
        assert digest(test_host / 'Tests' / name) == manifest['files'][name]
    assert digest(cli) == manifest['files']['miniapp.mjs']
    state['baselineAndShippingSourceUnchanged'] = True
    state['status'] = 'EXECUTED_PASS_COMPONENT_PROFILE_AND_17_ORIGINAL_TESTS'

def main():
    global state
    with (CONTROL / 'owner.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not (CONTROL / 'receipt.json').exists(), 'Never repeat the profile or overwrite an existing result'
        for sig in [signal.SIGTERM, signal.SIGINT]:
            signal.signal(sig, lambda value, frame: (_ for _ in ()).throw(RuntimeError('Controller interrupted ' + str(value))))
        try:
            execute()
        except BaseException as error:
            if state is not None:
                state.update(status='FAILED', error=type(error).__name__ + ': ' + str(error))
            raise
        finally:
            stop_owned()
            if state is not None:
                state['finishedAt'] = now()
                checkpoint()
        print(json.dumps({'status': state['status'], 'receipt': str(CONTROL / 'receipt.json'),
            'receiptSHA256': digest(CONTROL / 'receipt.json'), 'profile': state.get('profile'), 'tests': state.get('tests')}))

if __name__ == '__main__': main()
