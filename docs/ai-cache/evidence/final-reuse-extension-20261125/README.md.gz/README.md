# Bounded reuse extension after original standalone resolution

Target: `948bdb1fe75d31559dc8d65ae8d2e70fa69de276`  
Previous review: `6fbcf703dd9f40f5b1d42592d58a0a69573dcdfa`

**All bounded source inputs remain identical. The previously identified standalone lock gap is now resolved by an actual original Apple producer run.** This extension performed only read-only source/evidence comparisons; no tests, native operations, builds or package resolutions ran here.

| Retained proof | Verified extension to target |
| --- | --- |
| 44 core +4 producer tests originally passed at 04c1942 | All 80 canonical source hashes match; complete memberships remain 29 PlatformContracts +24 ChatCore +26 ChatCoreTests plus 1 canonical manifest. The two runner/generator files and two original producer fixtures also match. |
| 18 local/cache/accounting tests originally passed at 1bb4bdb | All 11 production/test inputs match; LRU 1.3.0 and its exact revision remain unchanged in the canonical app graph. |
| 15 active JavaScript facade/VM tests originally passed at e0a/0cf | All 25 source/fixture/generated inputs match. Both npm lockfiles are fully unchanged since 6fbc, and every consumed entry still matches the original proof. |

The entire canonical Xcode application lock is also byte-identical to 6fbc. All four core proof pins still match: SDK `abf0921c6e89e6521cc2b510ff11016b45a0ef08`, OTel 2.6.0 `c6fcee77cfc21ba400366f12475217c7b6e1d605`, Atomics 1.3.1 `0442cb5a3f98ab802acb777929fdb446bda11a34`, and argument-parser 1.8.2 `6a52f3251125d74daf04fcbd5e6f08a75d074382`.

## The standalone lock qualification is resolved

The original Apple producer ran at source `37367b3d6bbd7e8321d6828a9052d502dd9d7522` from 04:58:06 through 04:58:36 UTC on 2026-11-25 and exited 0. Its receipt records six resolutions, zero builds and zero tests. Generated commit `0e782f60bb28c704cae6200d5ff161826b771154` is an ancestor of the target.

Every current standalone lock is byte-identical to the producer's retained original output:

- HanlinPlatform
- HanlinAgentSDK
- HanlinParityMiniApp
- HanlinTextStudioMiniApp
- HanlinSefariaMiniApp
- HanlinWikipediaMiniApp

Each graph added only the exact approved OTel 2.6.0 and Atomics 1.3.1 pins. No existing pin changed or disappeared. All four consumed core proof pins now match each of these six graphs as well as the canonical app lock. The six manifests, producer script, canonical pin reader and canonical reference lock match the actual resolution input hashes.

The retained original resolution log, six graph logs, six generated locks and other evidence all match their storage hashes; compressed logs also match their recorded decompressed hashes. The outer original raw-log SHA-256 is `bbc8b176d3c74d4c5a7fd00b40280f98168e116d5272273bfe8e71407625540e`.

The old review's statement about the missing Platform entries remains an accurate historical statement at 6fbc. All nine files indexed by the old review remain byte-identical and were not rewritten. This extension closes that specific gap; it does not claim every repository lock must have an identical graph.

## Remaining limits

The earlier 48 core/producer, 18 local/accounting and 15 JavaScript passes remain **reused verified evidence**, not fresh test executions at 948. Complete historical transitive checkout dirty-state, compiler/SDK binary and environment hashes were not retained; the original Expo proof also retained a TypeScript API version rather than compiler/codec file hashes. Those provenance limits are unchanged.

The original six-graph operation proves resolution, not compilation or tests. App07 and the current native Host acceptance are separate root-owned gates. Live provider cache hits, billing savings, paid explicit Google lifecycle and release acceptance are not inferred.

`reuse-extension.json` contains every comparison, exact pins, raw evidence identities and the resolved qualification. `index.json` binds the included extension artifacts.
