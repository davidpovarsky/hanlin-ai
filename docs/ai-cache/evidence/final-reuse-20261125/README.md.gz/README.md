# Exact-input reuse review for final concurrent integration

Source: `6fbcf703dd9f40f5b1d42592d58a0a69573dcdfa`  
Tree: `d0dc201253ea9a57a4837c9a47cf4049004185fb`

**All recorded source inputs and consumed dependency entries match the retained original proofs. No tests or builds were run for this comparison.**

| Earlier original proof | Actual historical result | Freshly verified source boundary |
| --- | --- | --- |
| Core and original producer | 44 Hanlin core +4 producer tests passed at 04c1942 | All 80 canonical hashes match; full directory memberships 29 PlatformContracts +24 ChatCore +26 ChatCoreTests, plus 1 canonical manifest; original runner/generator 2 and producer fixture 2 also match |
| Local search/cache and usage accounting | 11 lifecycle +7 accounting tests passed at 1bb4bdb | All 9 production and 2 test files match; original LRU 1.3.0 revision matches current canonical application pin |
| Active JavaScript facade and VM | 7 shared assistant/publication +8 NativeScript/Expo VM tests passed at original e0a/0cf snapshots | All 25 source, generated facade, declarations, fixtures, harness and package inputs match; exact consumed npm entries/integrities unchanged |

The pre-App04 closure contains 36 unique local/JS paths. Every path matches the original execution receipts or explicitly identified supplemental Git source comparison, the 1710 checkpoint receipt, and target 6fbc. Actual counts were read from retained original logs, whose hashes are included in the detailed receipts.

## Dependency boundary

The core proof consumed Swift AI SDK `abf0921c6e89e6521cc2b510ff11016b45a0ef08`, OTel 2.6.0 `c6fcee77cfc21ba400366f12475217c7b6e1d605`, Atomics 1.3.1 `0442cb5a3f98ab802acb777929fdb446bda11a34`, and argument-parser 1.8.2 `6a52f3251125d74daf04fcbd5e6f08a75d074382`. All four pins match the current Xcode application lock. The local proof consumed LRU 1.3.0 `f0570e943ea4445d258113ba73f50cb2b7e564ac`, also unchanged.

The Node proof consumed TypeScript 5.9.3 for NativeScript; the Expo TypeScript wrapper @typescript/typescript6 6.0.2 forwarded to TypeScript 6.0.3; base64-js remained 1.5.1. Complete relevant lock entry objects, URLs and integrities match. The entire npm lockfiles are not identical, so this proof does not certify the whole Host graph.

The standalone HanlinPlatform lock still lacks OTel/Atomics. It was not the consumed proof lock; the retained dedicated proof lock and current Xcode application lock are the matching dependency evidence. No all-lock consistency claim is made.

## What can and cannot be reported

The earlier 48 core/producer, 18 local/accounting and 15 JavaScript results can be retained for these unchanged bounded inputs. They should be labelled reused verified evidence, not new test executions at 6fbc. No whole-upstream-suite, full iOS app or native Host pass follows from this comparison.

Complete canonical source membership is proven for the core targets. Complete transitive compiler/OS/dependency dirty-state reproduction is not: the original receipt does not retain every checkout file or compiler/SDK/environment binary hash. Likewise, the original Expo VM receipt retained a TypeScript API version rather than a compiler/codec hash; current observations are not retroactive historical evidence.

Root owns the separate original native Host refresh and final full application build plus 48 selected application invocations. Live-provider cache hits, billing savings, paid explicit Google lifecycle and release acceptance remain outside this review.

## Files

- `reuse-receipt.json`: combined exact-input conclusions and limits.
- `core/core48-reuse.json`: all 80 canonical comparisons, membership, consumed pins, retained raw log counts and producer provenance.
- `local-js/receipt.json`: all 36 unique local/JS comparisons, original receipts/logs, consumed dependency details and historical-hash limits.
- `local-js/verify-reuse.py` and execution record/log: reproducible read-only comparison logic; no tests/compiler/package manager calls.
- `index.json`: SHA-256 and size for every included evidence file except itself.
