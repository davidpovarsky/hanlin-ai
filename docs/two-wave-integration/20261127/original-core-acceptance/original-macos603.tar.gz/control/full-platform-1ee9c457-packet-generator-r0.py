import pathlib,json,hashlib,re,collections,subprocess,datetime,tarfile,shutil
s=pathlib.Path("/Users/m1/builds/hanlin-two-wave-root-20261126");r=s/"source";e=s/"validation/full-platform-1ee9c457-r1";rp=s/"full-platform-1ee9c457-r1.json";source="1ee9c45796f41893c3b59745864de3412c17ddb4"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads(rp.read_text());assert d["finishedAt"] and d["source"]==source
assert d["status"]=="ORIGINAL_UNFILTERED_MACOS_SWIFT_SUITE_PASSED" and d["exitCode"]==0 and not d.get("stopReason") and d["originalFullSuitePassed"] is True
lp=e/"original-swift-test.log";assert sha(lp)==d["log"]["sha256"]
text=lp.read_text(errors="replace");text=re.sub(r"\x1b\][^\x1b\x07]*(?:\x07|\x1b\\)","",text);text=re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]","",text)
starts=collections.Counter(x for x in re.findall(r"^.*?\bTest (.+?) started\.$",text,re.M) if x!="run" and not x.startswith("case passing"))
term=re.findall(r"^.*?\bTest (.+?) (passed|failed|skipped) after ",text,re.M);term=[(n,k) for n,k in term if not n.startswith("run with ")]
ends=collections.Counter(n for n,k in term);states=collections.Counter(k for n,k in term)
summaries=re.findall(r"Test run with (\d+) tests?[^\n]*(?:passed|failed)[^\n]*",text)
assert sum(starts.values())==sum(ends.values())==sum(int(n) for n in summaries)==603
assert starts==ends and dict(states)=={"passed":603} and len(summaries)==13
assert d["originalSourceUnchanged"] is True
recon={"source":source,"nativeExitCode":d["exitCode"],"stopReason":d.get("stopReason"),"nativeStatus":d["status"],"nativeLogSHA256":sha(lp),"controllerReceiptSHA256":sha(rp),"methodStarts":sum(starts.values()),"methodTerminals":sum(ends.values()),"states":dict(states),"parameterStartRowsSeparate":len(re.findall(r"^.*?\bTest case passing .* started\.$",text,re.M)),"testRunSummaryCount":len(summaries),"testRunSummaryTotal":sum(int(n) for n in summaries),"methodNamesMatchAsMultisets":starts==ends,"unmatchedStartNames":dict(starts-ends),"unmatchedTerminalNames":dict(ends-starts),"failedTestLines":[line for line in text.splitlines() if re.search(r"\bTest .+? failed after ",line)],"passedTestNames":[n for n,k in term if k=="passed"],"rawControllerDiagnosticCountersPreserved":"Original controller also counts run headers and parameter rows; this separate normalized reconciliation preserves its original PASS verdict.","sourceUnchanged":d["originalSourceUnchanged"],"actualSamples":[{"pid":x["actualOwnedTarget"]["pid"],"sha256":x.get("sampleSHA256"),"exitCode":x.get("exitCode"),"checkpointAgeSeconds":x["trigger"].get("checkpointAgeSeconds")} for x in d.get("samples",[])]}
np=e/"normalized-test-reconciliation.json";assert not np.exists();np.write_text(json.dumps(recon,indent=2)+"\n")
must=["originalScriptWidgetHTTPUsesBoundedRealTransport()","originalPromiseRetainsPendingContinuationThroughGarbageCollection()","originalPromiseCancellationReleasesPendingContinuationAndDisposesContext()",'"Imports FileManager selections and previews the package copy through system UI"']
assert all(recon["passedTestNames"].count(x)==1 for x in must)
controlLines=[line for line in text.splitlines() if any("Test "+n+" passed after " in line for n in must)]
cr=e/"original-http-filemanager-promise-control-results.json";cr.write_text(json.dumps({"source":source,"scope":"Original unfiltered603","actualPassLines":controlLines,"httpOriginalTestSHA256":"433703973e69d764686c6761ad1851c40d76f5e53afa4561d1720d873a5a1ae4","originalNativeHTTPSeconds":5,"temporaryDebugCallbackDiscriminatorRemoved":True,"nativeExitCode":0},indent=2)+"\n")
target=s/"evidence/full-platform-1ee9c457-r1";assert not target.exists();target.mkdir()
for p in e.rglob("*"):
 assert not p.is_symlink(),str(p)
 if p.is_file():
  out=target/"validation"/p.relative_to(e);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
extra=[rp,s/"source-stage-1ee9c457-r1.json",s/"full-platform-1ee9c457-capacity-plan-r1.json",s/"full-platform-1ee9c457-prelaunch-health-r1.json",s/"original-full-platform-1ee9c457-binding.json",s/"original-full-platform-1ee9c457-binding.diff",s/"run-original-full-platform-1ee9c457.py",s/"original-full-platform-1ee9c457-launch-r1.json",s/"original-full-platform-1ee9c457-supervisor-r1.log",s/"source-stage-1ee9c457-preflight-failure-r0.json",s/"source-stage-1ee9c457-original-basename-preflight.py",s/"source-stage-1ee9c457-manifest-preflight-r0.json"]
extra+=list((s/"import-1ee9c457").glob("*.json"))
for p in extra:
 out=target/"control"/p.name;out.parent.mkdir(exist_ok=True);assert not out.exists();shutil.copyfile(p,out)
stage=json.loads((s/"source-stage-1ee9c457-r1.json").read_text())
for rel in [*stage["packageChangedSourceHashes"],stage["nativeManifest"]["path"],"Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinOriginalPromiseLifetimeTests.swift"]:
 out=target/"source"/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r/rel,out)
assert subprocess.check_output(["git","-C",str(r),"rev-parse","HEAD"],text=True,timeout=20).strip()==source
assert not subprocess.check_output(["git","-C",str(r),"status","--porcelain=v1"],text=True,timeout=20).strip()
members=[{"path":str(p.relative_to(target)),"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(target.rglob("*")) if p.is_file()]
mf=target/"manifest.json";mf.write_text(json.dumps({"source":source,"status":"ORIGINAL_FULL603_PASS_RAW_PROOF","members":members},indent=2)+"\n")
archive=target.with_suffix(".tar.gz")
with tarfile.open(archive,"w:gz") as t:
 for p in sorted(target.rglob("*")):
  if p.is_file():t.add(p,arcname=str(p.relative_to(target)),recursive=False)
print(json.dumps({"path":str(target),"manifestSHA256":sha(mf),"archive":str(archive),"archiveBytes":archive.stat().st_size,"archiveSHA256":sha(archive),"files":len(members),"receiptSHA256":sha(rp),"rawLogSHA256":sha(lp),"reconciliationSHA256":sha(np),"reconciliation":{k:v for k,v in recon.items() if k!="passedTestNames"},"controls":controlLines,"startedAt":d["commandStartedAt"],"finishedAt":d["finishedAt"],"freeEnd":d["freeEnd"]}))
