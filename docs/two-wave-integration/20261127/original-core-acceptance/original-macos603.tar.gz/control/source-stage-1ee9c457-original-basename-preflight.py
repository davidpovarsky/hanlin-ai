import pathlib,json,hashlib,subprocess,datetime,fcntl,os,time
s=pathlib.Path("/Users/m1/builds/hanlin-two-wave-root-20261126");r=s/"source";imp=s/"import-1ee9c457"
source="1ee9c45796f41893c3b59745864de3412c17ddb4";base="778ed7e597a2fe19708e1dde5598350b56b25d6d"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(["/usr/bin/git","-C",str(r),*a],text=True,stderr=subprocess.PIPE,timeout=40).strip()
def gitbytes(*a):return subprocess.check_output(["/usr/bin/git","-C",str(r),*a],stderr=subprocess.PIPE,timeout=40)
locks=[]
for name,mode in [("hanlin-two-wave-native-app.lock",fcntl.LOCK_EX),(".scaleway-cache-maintenance.lock",fcntl.LOCK_SH)]:
 f=open("/Users/m1/caches/"+name,"a+");fcntl.flock(f,mode|fcntl.LOCK_NB);locks.append(f)
assert git("rev-parse","HEAD")==base and not git("status","--porcelain=v1")
before=(r/"Packages/HanlinPlatform/.build").stat().st_ino;assert before==71920668
ip=imp/"root-causal-promise-mac-intake.json";assert sha(ip)=="836cb9332e26c9e6262d5bea2ba6848e5b957bd4ddfb0ed91eb34a615162cc0f"
intake=json.loads(ip.read_text());assert intake["source"]==source and intake["macBase"]==base
bundle=imp/"root-causal-promise-from-778.bundle";assert bundle.stat().st_size==intake["bundleBytes"]==94279
assert sha(bundle)==intake["bundleSHA256"]=="a98973100e5ac65aff3857c2d92cae3738042cb5714cb756e5a8aabf69138124"
git("bundle","verify",str(bundle));git("fetch",str(bundle),"HEAD");assert git("rev-parse","FETCH_HEAD")==source
assert subprocess.run(["git","-C",str(r),"merge-base","--is-ancestor",base,source],capture_output=True).returncode==0
assert git("rev-parse",source+":Packages/HanlinPlatform")==intake["packageTree"]=="b1e54c6d1aa3c4ef2dd761e15b7b6df9d946a29a"
assert git("rev-parse",source+":Packages/HanlinPlatform/Sources")==intake["productionSourcesTree"]=="182cad448c545daa956db88dc251e318022e748a"
diff=git("diff","--name-only",base,source).splitlines()
reviewHashes={intake["rootReviewSHA256"]:"root-causal-source-review.json",intake["w1ReviewSHA256"]:"w1-causal-source-review.json"}
reviews={}
for rel in [p for p in diff if p.startswith("docs/") and p.endswith(".json")]:
 blob=gitbytes("show",source+":"+rel);digest=hashlib.sha256(blob).hexdigest()
 if digest in reviewHashes:
  dst=imp/reviewHashes[digest];assert not dst.exists();dst.write_bytes(blob)
  reviews[reviewHashes[digest]]={"gitPath":rel,"sha256":digest,"contents":json.loads(blob)}
assert len(reviews)==2,reviews
http="Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinDualWidgetEnginesTests.swift"
pkgDelta=git("diff","--name-only",base,source,"--","Packages/HanlinPlatform").splitlines()
assert len(pkgDelta)==4 and http in pkgDelta,pkgDelta
assert sorted(pathlib.Path(p).name for p in pkgDelta if p!=http)==["Fetch.swift","Promise.swift","RunningState.swift"]
git("update-ref","refs/heads/codex/mac-full603-778-callback-proof",base);git("checkout","--detach",source)
assert git("rev-parse","HEAD")==source and not git("status","--porcelain=v1")
trees={rel:git("rev-parse","HEAD:"+rel) for rel in ["Packages/HanlinPlatform","Packages/HanlinPlatform/Sources","Packages/HanlinPlatform/Tests","Fixtures/Widgets"]}
assert sha(r/http)==intake["httpTestSHA256"]=="433703973e69d764686c6761ad1851c40d76f5e53afa4561d1720d873a5a1ae4"
prior=json.loads((s/"source-stage-778ed7e5-r1.json").read_text())
pins={rel:sha(r/rel) for rel in prior["pins"]};assert pins==prior["pins"]
tests={rel:sha(r/rel) for rel in prior["testSources"]};assert all(tests[k]==v for k,v in prior["testSources"].items() if k!=http)
fm={rel:sha(r/rel) for rel in prior["originalFileManagerProductionAndTestHashes"]};assert fm==prior["originalFileManagerProductionAndTestHashes"]
changed={rel:sha(r/rel) for rel in pkgDelta}
nativeManifest=[p for p in diff if p.endswith(".json") and "source-manifest" in p]
if len(nativeManifest)!=1:
 nativeManifest=[p for p in diff if p.endswith(".json") and not p.startswith("docs/") and sha(r/p)==intake["manifestSHA256"]]
assert len(nativeManifest)==1,nativeManifest
assert sha(r/nativeManifest[0])==intake["manifestSHA256"]
assert (r/"Packages/HanlinPlatform/.build").stat().st_ino==before
stage={"status":"EXACT_REVIEWED_PACKAGE_SOURCE_STAGED","source":source,"base":base,"sourceClean":True,"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"packageTrees":trees,"pins":pins,"testSources":tests,"originalFileManagerProductionAndTestHashes":fm,"packageDeltaFrom778":pkgDelta,"packageChangedSourceHashes":changed,"nativeManifest":{"path":nativeManifest[0],"sha256":sha(r/nativeManifest[0])},"intakeSHA256":sha(ip),"bundleSHA256":sha(bundle),"sourceDonor":intake["sourceDonor"],"rootReviewSHA256":intake["rootReviewSHA256"],"w1ReviewSHA256":intake["w1ReviewSHA256"],"sourceReviews":{k:{"gitPath":v["gitPath"],"sha256":v["sha256"]} for k,v in reviews.items()},"warmBuildInode":before,"productionChangeScope":"Reviewed pending Promise continuation lifetime/cancellation ownership correction; temporary DEBUG Fetch/Promise/test callback discriminator removed. Original live-path HTTP433 restored. All original assertions and5-second execution timeout retained."}
sp=s/"source-stage-1ee9c457-r1.json";assert not sp.exists();sp.write_text(json.dumps(stage,indent=2)+"\n")
previous=json.loads((s/"full-platform-778ed7e5-capacity-plan-r2.json").read_text());selected=[]
for item in previous["measuredAffectedOutputs"]:
 path=pathlib.Path(item["path"]);assert path.exists(),str(path)
 d=subprocess.run(["du","-sk",str(path)],capture_output=True,text=True,timeout=15);assert d.returncode==0
 selected.append({"path":str(path),"allocatedBytes":int(d.stdout.split()[0])*1024})
assert len([x for x in selected if x["path"].endswith(".xctest")])==13
measured=sum(x["allocatedBytes"] for x in selected)
components=dict(previous["budgetComponentsBytes"]);components["incrementalCompileAndLink"]=max(536870912,2*measured)
capacity={"status":"MEASURED_WARM_ORIGINAL_PHASE_CAPACITY_PLAN","source":source,"command":previous["command"],"originalPhaseDeadlineSeconds":3600,"stageReceiptSHA256":sha(sp),"budgetComponentsBytes":components,"admissionBytes":sum(components.values()),"continuousReserveBytes":components["osReserve"],"measuredAffectedOutputsBytes":measured,"measuredAffectedOutputs":selected,"rationale":"Same warm Swift6.4 backend/pins retained. Reviewed Promise/RunningState correction and removal of diagnostic-only Fetch/test code. Reserve twice all13 original test bundles plus runtime object/modules,512MiB fixture growth,64MiB evidence,2GiB concurrent foreign growth and1GiB OS reserve; no cold-build threshold.","actualWarmBuildBackend":previous["actualWarmBuildBackend"],"updatedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"freeAtPlan":os.statvfs("/System/Volumes/Data").f_bavail*os.statvfs("/System/Volumes/Data").f_frsize}
cp=s/"full-platform-1ee9c457-capacity-plan-r1.json";assert not cp.exists();cp.write_text(json.dumps(capacity,indent=2)+"\n")
t=time.monotonic();ps=subprocess.run(["/bin/ps","-axo","pid=,ppid=,pgid=,stat=,lstart=,comm="],capture_output=True,text=True,timeout=10,check=True);elapsed=time.monotonic()-t
health={"at":datetime.datetime.now(datetime.timezone.utc).isoformat(),"psElapsedSeconds":elapsed,"psRows":len(ps.stdout.splitlines()),"psExitCode":ps.returncode,"freeBytes":capacity["freeAtPlan"],"admissionBytes":capacity["admissionBytes"]}
hp=s/"full-platform-1ee9c457-prelaunch-health-r1.json";assert not hp.exists();hp.write_text(json.dumps(health,indent=2)+"\n")
assert capacity["freeAtPlan"]>=capacity["admissionBytes"]
print(json.dumps({"sourceStagePath":str(sp),"sourceStageSHA256":sha(sp),"capacityPath":str(cp),"capacitySHA256":sha(cp),"healthPath":str(hp),"healthSHA256":sha(hp),"health":health,"packageTrees":trees,"changedSources":changed,"nativeManifest":stage["nativeManifest"],"warmBuildInode":before,"sourceClean":True,"reviews":reviews}))
