import fs from 'node:fs'; import crypto from 'node:crypto'; import {pathToFileURL} from 'node:url';
const [compilerPath, oldPath, candidatePath]=process.argv.slice(2);
const ts=(await import(pathToFileURL(compilerPath).href)).default;
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const options={module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022,verbatimModuleSyntax:true};
function project(file){const input=fs.readFileSync(file,'utf8');const output=ts.transpileModule(input,{fileName:'assistant-tool.ts',compilerOptions:options}).outputText;
 const root=ts.createSourceFile('assistant-tool.js',output,ts.ScriptTarget.ES2022,true,ts.ScriptKind.JS);
 function shape(n){const children=[];ts.forEachChild(n,c=>{children.push(shape(c));});
 const v={kind:ts.SyntaxKind[n.kind],children};if(ts.isIdentifier(n)||ts.isStringLiteralLike(n)||ts.isNumericLiteral(n))v.text=n.text;return v;}
 return {inputSHA256:sha(input),emittedSHA256:sha(output),runtimeASTSHA256:sha(JSON.stringify(shape(root))),output};}
const before=project(oldPath),after=project(candidatePath);
const result={compilerVersion:ts.version,compilerSHA256:sha(fs.readFileSync(compilerPath)),compilerOptions:{module:'ESNext',target:'ES2022',verbatimModuleSyntax:true},before:{...before,output:undefined},after:{...after,output:undefined},emittedBytesEqual:before.output===after.output,runtimeASTEqual:before.runtimeASTSHA256===after.runtimeASTSHA256,applicationCodeExecuted:false};
console.log(JSON.stringify(result,null,2));if(!result.runtimeASTEqual)process.exitCode=1;
