import datetime,gzip,hashlib,json,os,pathlib,pwd,signal,subprocess,tarfile,io,time
ROOT=pathlib.Path('/mnt/development/projects/worktrees/hanlin-two-wave-integration-20261126')
W=pathlib.Path('/mnt/development/projects/worktrees/hanlin-modular-search-types-20261127')
H=pathlib.Path('/mnt/development/projects/evidence/hanlin-two-wave-native-20261126/handoff/modular-search-types-ce896542')
E=H/'portable-original-r2'
SDK=H/'accepted-sdk/MiniAppSDK'
NODE=pathlib.Path('/mnt/development/projects/toolchains/node-v24.5.0-linux-arm64/bin/node')
BASE='39006ce6586c1be056f53de9483bfd907cea6cbd'
REL='Scripts/Expo/miniapps/modular-text-search'
CHANGED=REL+'/assistant-tool.ts'
account=pwd.getpwnam('chatgpt-agent')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):
 return subprocess.run(['runuser','-u','chatgpt-agent','--','git','-C',str(W),*a],capture_output=True,check=True).stdout
def snapshot(root):
 return {p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777,'sha256':sha(p.read_bytes())} for p in sorted(root.rglob('*')) if p.is_file()}
def save(name,obj):
 p=E/name;p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
assert not E.exists()
E.mkdir()
os.chown(E,account.pw_uid,account.pw_gid)
assert git('rev-parse','HEAD').decode().strip()==BASE
assert sha((W/CHANGED).read_bytes())=='6152a4e57babe9cfaca5ab6d43ccf495cc9d1fa8ebd8426c9ce810c861185748'
assert sha((SDK/'miniapp-sdk.json').read_bytes())=='7f2702e52587fe1d126cef37f068ab3a9e3a26adb275ffafb687cb38a2db9b87'
assert subprocess.run([str(NODE),'--version'],capture_output=True,text=True,check=True).stdout.strip()=='v24.5.0'
archive=git('archive',BASE,REL)
original=E/'original-source'
original.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as t:t.extractall(original,filter='data')
for p in [original,*original.rglob('*')]:os.chown(p,account.pw_uid,account.pw_gid)
old=original/REL
assert sha((old/'assistant-tool.ts').read_bytes())==sha(git('show',BASE+':'+CHANGED))
codePaths=['Scripts/MiniApps/miniapp.mjs','AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-authoring.mjs','AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-assistant-tools.mjs']
codeBefore={p:sha((W/p).read_bytes()) for p in codePaths}
projectBefore={p:sha(git('show',BASE+':'+p)) for p in git('ls-tree','-r','--name-only',BASE,'--',REL).decode().splitlines()}
sdkBefore=snapshot(SDK);save('sdk-before.json',sdkBefore)
env=dict(os.environ)
if env.get('HANLIN_AUTHORING_TYPESCRIPT'):raise RuntimeError('Unexpected compiler override; no run admitted')
env['PATH']=str(NODE.parent)+os.pathsep+env['PATH']
commands=[]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(name,operation,project,expected):
 report=E/(name+'.json')
 argv=[str(NODE),'Scripts/MiniApps/miniapp.mjs',operation,'--sdk',str(SDK),'--engine','expo','--project',str(project)]
 if operation=='build':argv += ['--archive',str(E/'ModularTextSearch.hanlinExpo')]
 argv += ['--report',str(report)]
 began=time.monotonic();t0=datetime.datetime.now(datetime.timezone.utc).isoformat()
 out=E/(name+'.stdout.log');err=E/(name+'.stderr.log')
 stop=None
 with out.open('xb') as so,err.open('xb') as se:
  p=subprocess.Popen(['runuser','-u','chatgpt-agent','--',*argv],cwd=W,env=env,stdout=so,stderr=se,start_new_session=True)
  save(name+'.start.json', {'pid':p.pid,'pgid':p.pid,'argv':argv,'startedAtUTC':t0,'timeoutSeconds':300})
  try:p.wait(timeout=300)
  except subprocess.TimeoutExpired:
   stop='ORIGINAL_300_SECOND_COMMAND_DEADLINE'
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:p.wait(timeout=10)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait(timeout=10)
 row={'name':name,'argv':argv,'cwd':str(W),'executionUser':'chatgpt-agent','startedAtUTC':t0,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeoutSeconds':300,'elapsedSeconds':time.monotonic()-began,'exitCode':p.returncode,'stopReason':stop,'stdout':{'bytes':out.stat().st_size,'sha256':sha(out.read_bytes())},'stderr':{'bytes':err.stat().st_size,'sha256':sha(err.read_bytes())}}
 if report.exists():
  value=json.loads(report.read_text());row['reportSHA256']=sha(report.read_bytes());row['succeeded']=value.get('succeeded');row['diagnostics']=value.get('diagnostics');row['sdk']=value.get('sdk');row['typecheck']=value.get('typecheck')
 commands.append(row);save('commands.json',commands)
 print(json.dumps({'phase':name,'exit':p.returncode,'succeeded':row.get('succeeded'),'elapsed':row['elapsedSeconds'],'diagnostics':row.get('diagnostics')}),flush=True)
 if stop or p.returncode!=expected:raise RuntimeError(name+' did not match expected source-supported outcome')
 return value
failure=None
try:
 red=run('original-validate','validate',old,1)
 assert any(x.get('code')=='TS7006' and x.get('file')=='assistant-tool.ts' and x.get('line')==35 for x in red['diagnostics'])
 green=run('candidate-validate','validate',W/REL,0)
 assert green['succeeded'] is True and green['diagnostics']==[]
 built=run('candidate-build','build',W/REL,0)
 assert built['succeeded'] is True and built['diagnostics']==[]
 assert all(x['typecheck']=={'strict':True,'checkJs':False,'skipLibCheck':False,'dependencyDeclarationsChecked':True} for x in commands)
except Exception as e:
 failure=str(e)
finally:
 sdkAfter=snapshot(SDK);save('sdk-after.json',sdkAfter)
 trackedNow={p:sha((W/p).read_bytes()) for p in projectBefore}
 expected=dict(projectBefore);expected[CHANGED]='6152a4e57babe9cfaca5ab6d43ccf495cc9d1fa8ebd8426c9ce810c861185748'
 sourceUnchanged=trackedNow==expected and all(sha((W/p).read_bytes())==v for p,v in codeBefore.items())
 receipt={'schema':1,'startedAtUTC':started,'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceBase':BASE,'sourceSHA256':expected[CHANGED],'originalSourceSHA256':projectBefore[CHANGED],'originalCLISourceSHA256':codeBefore,'originalProjectSourceSHA256':projectBefore,'commands':commands,'sdkManifestSHA256':sha((SDK/'miniapp-sdk.json').read_bytes()),'sdkArchiveSHA256':'a088d98b8f85ae1e1ad767fca92132c03f0155d5ddd379d57b8cc98c38f19383','sdkFullFileCount':len(sdkBefore),'sdkCompleteBytesModesUnchanged':sdkBefore==sdkAfter,'sourceUnchangedExceptReviewedTypeOnlyDelta':sourceUnchanged,'node':{'version':'v24.5.0','path':str(NODE),'sha256':sha(NODE.read_bytes())},'nativeCommandsExecuted':0,'hostedWorkflowExecuted':False,'failure':failure,'status':'PASS_ORIGINAL_RED_CANDIDATE_VALIDATE_AND_BUILD' if failure is None and sdkBefore==sdkAfter and sourceUnchanged else 'FAILED_OR_INCOMPLETE'}
 save('receipt.json',receipt)
 print(json.dumps({'terminal':receipt['status'],'receiptSHA256':sha((E/'receipt.json').read_bytes()),'failure':failure}),flush=True)
if failure is not None:raise SystemExit(1)
assert sdkBefore==sdkAfter and sourceUnchanged
