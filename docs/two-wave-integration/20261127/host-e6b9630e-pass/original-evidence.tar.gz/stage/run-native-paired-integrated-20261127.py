import pathlib,subprocess,json,os,time,datetime,hashlib,signal,fcntl,sys,traceback
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126')
root=stage/'source';dd=pathlib.Path('/Users/m1/caches/DerivedData/hanlin-two-wave-root-20261126')
expected,hostTag,requiredRaw,attempt=sys.argv[1:]
required=int(requiredRaw);tag=expected[:8]+'-'+attempt
parent=stage/'validation'/tag
receipt=stage/('native-paired-'+tag+'.json');logPath=stage/('native-paired-'+tag+'.log')
data={'status':'PREPARING','source':expected,'hostPreparationTag':hostTag,'derivedData':str(dd),'evidence':str(parent/'paired-product'),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requiredFreeBytes':required,'acceptanceBoundary':'Original paired miniapp_complete acceptance on two shipping app targets and actual iOS27.2 simulator; build SDK remains27.0. Additive focused suites and physical-device behavior are separate.'}
def free():
 s=os.statvfs('/System/Volumes/Data');return s.f_bavail*s.f_frsize
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():receipt.write_text(json.dumps(data,indent=2)+'\n')
def execute(args,timeout=120):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True,timeout=timeout,env=env)
 if p.returncode:raise RuntimeError({'args':args,'exit':p.returncode,'stdout':p.stdout[-5000:],'stderr':p.stderr[-5000:]})
 return p.stdout
env=os.environ.copy();env['PATH']=str(stage/'tool-bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
lock=open('/Users/m1/caches/hanlin-two-wave-native-app.lock','a+')
maintenance=open('/Users/m1/caches/.scaleway-cache-maintenance.lock','a+')
process=None
assert not receipt.exists() and not logPath.exists() and not parent.exists(),'Unique controller evidence path already exists'
data['freeBefore']=free();data['controllerPID']=os.getpid();data['controllerSHA256']=digest(pathlib.Path(__file__));data['coordinationLocks']={'native':'exclusive','existingMaintenance':'shared'}
data['capacityEstimate']={'requiredFreeBytes':required,'planningEstimateNotGuaranteedPeak':True,'warmProductsReadback':str(stage/'full-app-warm-capacity-0456adbe.json'),'continuousFloorBytes':1073741824,'scope':'Current warm two-app build, original paired fixtures and results, shared OS margin; unrelated writers are measured separately by live free bytes.'};save()
try:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 fcntl.flock(maintenance,fcntl.LOCK_SH|fcntl.LOCK_NB)
 seal=json.loads((stage/('source-seal-'+expected[:8]+'.json')).read_text())
 assert seal['status']=='EXACT_GENERATED_DOCUMENTS_SEALED' and seal['head']==expected
 assert execute(['/usr/bin/git','diff','--name-only',seal['base'],expected]).splitlines()==seal['changedPaths']
 for d in seal['generatedDocs']:assert digest(root/d['path'])==d['sha256'],d['path']
 assert not execute(['/usr/bin/git','diff','--name-only']).strip(),'Tracked source must be sealed before app admission'
 assert not execute(['/usr/bin/git','diff','--cached','--name-only']).strip()
 data['sourceSeal']={'path':str(stage/('source-seal-'+expected[:8]+'.json')),'sha256':digest(stage/('source-seal-'+expected[:8]+'.json')),'base':seal['base'],'head':expected,'changedPaths':seal['changedPaths']}
 assert execute(['/usr/bin/git','rev-parse','HEAD']).strip()==expected
 for repairName in ['stale-flat-module-quarantine-759e5cf9-r1.json','stale-flat-miniappcore-quarantine-759e5cf9-r4-r2.json']:
  repairPath=stage/repairName;repair=json.loads(repairPath.read_text())
  assert repair['status']=='EXACT_STALE_FLAT_MODULE_QUARANTINED'
  assert not pathlib.Path(repair['quarantineFrom']).exists() and pathlib.Path(repair['quarantineTo']).is_dir()
  data.setdefault('retainedCacheRepairs',[]).append({'path':str(repairPath),'sha256':digest(repairPath),'scope':'Exact obsolete flat module remains quarantined with all bytes retained; original Xcode rescans current framework modules.'})
 assert dd.is_dir() and dd.resolve()==dd
 host=json.loads((stage/('host-preparation-'+hostTag+'.json')).read_text())
 assert host['status']=='FRESH_HOST_AND_SDK_VERIFIED',host['status']
 sdk=pathlib.Path(host['sdk']['path']);manifest=json.loads((sdk/'miniapp-sdk.json').read_text())
 data['sdkSourceAudit']=execute([str(stage/'tool-bin/node'),'Scripts/Audit/audit-miniapp-sdk.mjs','--check'],120).strip()
 data['reachabilityAudit']=execute([str(stage/'tool-bin/python3'),'Scripts/Audit/audit_miniapp_reachability.py','--check'],120).strip()
 current=json.loads(execute([str(stage/'tool-bin/node'),'Scripts/MiniApps/stage-sdk.mjs','--fingerprint','--repository',str(root)]))
 if current['sha256']!=manifest['inputSHA256']:
  old={x['path']:x['sha256'] for x in manifest['sourceInputs']}
  new={x['path']:x['sha256'] for x in current['files']}
  data['changedSDKInputs']=[x for x in sorted(set(old)|set(new)) if old.get(x)!=new.get(x)]
  raise RuntimeError('Current exact source requires refreshed canonical SDK/Host preparation')
 assert digest(root/'AI_HLY/RuntimeHostResources.zip')==host['archive']['sha256']
 nodeFingerprint=execute([str(stage/'tool-bin/node'),'-p','JSON.stringify({versions:process.versions,platform:process.platform,arch:process.arch})']).strip()
 data['hostReuseValidation']=execute([str(stage/'tool-bin/python3'),'Scripts/Runtime/runtime_host_archive.py','reuse',str(root/'build/runtime-host'),'--source-root',str(root/'AI_HLY/Downstream/RuntimeCore/Node/Host'),'--node-fingerprint',nodeFingerprint],180).strip()
 data['sourceSDKBinding']={'source':expected,'preparedSource':host['source'],'inputSHA256':current['sha256'],'sourceInputs':len(current['files']),'archiveSHA256':host['archive']['sha256'],'manifestSHA256':digest(sdk/'miniapp-sdk.json')}
 data['freeAtAdmission']=free()
 assert data['freeAtAdmission']>=required,{'reason':'Actual phase footprint does not fit at admission','free':data['freeAtAdmission'],'required':required}
 assert not parent.exists(),'Unique evidence root already exists'
 parent.mkdir(parents=True)
 env.update({'SPLIT_EVIDENCE':str(parent),'SPLIT_DERIVED_DATA':str(dd),'PAIRED_TEST_SCOPE':'miniapp_complete','PAIRED_SIM_RUNTIME':'com.apple.CoreSimulator.SimRuntime.iOS-27-2','GITHUB_RUN_ID':'two-wave-'+tag,'RUNNER_TEMP':str(stage/('native-temp-'+tag))})
 pathlib.Path(env['RUNNER_TEMP']).mkdir()
 cmd=[str(stage/'tool-bin/python3'),'Scripts/ProductSplit/run_paired_acceptance.py']
 data['command']=cmd;data['runnerSHA256']=digest(root/'Scripts/ProductSplit/run_paired_acceptance.py');data['status']='RUNNING';save()
 with logPath.open('w') as log:
  process=subprocess.Popen(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  data['pid']=process.pid;save()
  while True:
   try:code=process.wait(timeout=15);break
   except subprocess.TimeoutExpired:
    observation={'at':time.time(),'freeBytes':free(),'logBytes':logPath.stat().st_size}
    active=parent/'paired-product/active-command.json'
    if active.is_file():
     try:observation['originalActiveCommand']=json.loads(active.read_text())
     except Exception:pass
    data['lastObservation']=observation;save()
    if observation['freeBytes']<1073741824:
     data['resourceStop']={'at':time.time(),'freeBytes':observation['freeBytes'],'reason':'Actual disk safety margin exhausted while this owned gate was active. Only this owned process group is interrupted.'};save()
     os.killpg(process.pid,signal.SIGINT)
     try:code=process.wait(timeout=55)
     except subprocess.TimeoutExpired:
      os.killpg(process.pid,signal.SIGTERM)
      try:code=process.wait(timeout=20)
      except subprocess.TimeoutExpired:
       os.killpg(process.pid,signal.SIGKILL);code=process.wait(timeout=10)
     break
 data['exitCode']=code
 result=parent/'paired-product/acceptance.json'
 if result.is_file():data['originalAcceptance']=json.loads(result.read_text())
 assert execute(['/usr/bin/git','rev-parse','HEAD']).strip()==expected,'Source changed during native acceptance'
 for d in seal['generatedDocs']:assert digest(root/d['path'])==d['sha256'],'Generated source input changed during native gate: '+d['path']
 assert 'resourceStop' not in data,'Gate interrupted for actual disk shortage'
 assert code==0 and data.get('originalAcceptance',{}).get('status')=='EXECUTED_PASS',{'exit':code,'originalStatus':data.get('originalAcceptance',{}).get('status')}
 assert data['originalAcceptance']['sha']==expected
 assert data['originalAcceptance']['runtime']=='com.apple.CoreSimulator.SimRuntime.iOS-27-2'
 data['status']='ORIGINAL_PAIRED_ACCEPTANCE_PASSED'
except Exception as e:
 data['status']='RESOURCE_STOPPED' if 'resourceStop' in data else 'FAILED'
 data['error']=repr(e);data['traceback']=traceback.format_exc()
finally:
 data['freeAfter']=free();data['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if logPath.exists():data['logSHA256']=digest(logPath)
 save()
 try:fcntl.flock(maintenance,fcntl.LOCK_UN)
 except Exception:pass
 try:fcntl.flock(lock,fcntl.LOCK_UN)
 except Exception:pass
 print(json.dumps(data),flush=True)
if data['status']!='ORIGINAL_PAIRED_ACCEPTANCE_PASSED':raise SystemExit(1)
