"""Original strict NativeScript surface CLI validate/build against the actual new shipping SDK."""
import pathlib,json,subprocess,hashlib,os,datetime,fcntl,time,signal,traceback,zipfile
S=pathlib.Path("/Users/m1/builds/hanlin-two-wave-root-20261126");ROOT=S/"source"
SOURCE="78ec8f97a607f5e1f8c01de5109ae850791b9e04";PRODUCER_SOURCE="764ed325b3b3bbf1be4ce471b3a7574db2c44bc7"
EVIDENCE=S/"validation/ns-surface-764ed325-sdk396-r1";RECEIPT=S/"ns-surface-764ed325-sdk396-r1.json"
def digest(p):
 with p.open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def free():
 f=os.statvfs("/System/Volumes/Data");return f.f_bavail*f.f_frsize
def git(*a):return subprocess.check_output(["git","-C",str(ROOT),*a],text=True,timeout=30).strip()
assert not EVIDENCE.exists() and not RECEIPT.exists();EVIDENCE.mkdir(parents=True)
data={"status":"PREPARING_ORIGINAL_STRICT_SURFACE_CLI","source":SOURCE,"hostExecutionSource":PRODUCER_SOURCE,"startedAt":now(),"controllerPID":os.getpid(),"phases":[],"boundary":"Original NativeScript surface authoring validate/build only; no app or OS execution claimed."}
def save():
 p=RECEIPT.with_suffix(".pending");p.write_text(json.dumps(data,indent=2)+"\n");p.replace(RECEIPT)
proc=None
native=open("/Users/m1/caches/hanlin-two-wave-native-app.lock","a+");maintenance=open("/Users/m1/caches/.scaleway-cache-maintenance.lock","a+")
try:
 fcntl.flock(native,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(maintenance,fcntl.LOCK_SH|fcntl.LOCK_NB)
 assert git("rev-parse","HEAD")==SOURCE and not git("status","--porcelain=v1")
 seal=S/"host764-source-seal.json";assert digest(seal)=="55eb73b7391e0dd765ea42a86a8586497848e73f0f15fa8d9b7a609d768ae23b"
 hr=S/"host-preparation-764ed325-original-phases-r1.json";assert digest(hr)=="6046e68027dbb0acf87a42fd6b310c21405f9a58f721c4b17e90a5b775404942"
 host=json.loads(hr.read_text());assert host["status"]=="FRESH_HOST_AND_SDK_VERIFIED" and host["source"]==PRODUCER_SOURCE
 archive=ROOT/"AI_HLY/RuntimeHostResources.zip";assert digest(archive)==host["archive"]["sha256"]=="7e37a818f7502a44dc44c6369d3ca19164d8fae072504166aa18bf9e86cba241"
 sdk=pathlib.Path(host["sdk"]["path"]);mp=sdk/"miniapp-sdk.json"
 assert digest(mp)==host["sdk"]["manifestSHA256"]=="fde01eda875902fd4b399921902ad8589f03f6c7926d3298fcb4f4c929339838"
 sm=json.loads(mp.read_text());assert sm["inputSHA256"]=="7e2d370d0753b37bb1c589e4c2b28e3e8383c6fb948b09b0556e651efcfa4a9e" and len(sm["sourceInputs"])==396
 for row in sm["sourceInputs"]:assert digest(ROOT/row["path"])==row["sha256"],row["path"]
 with zipfile.ZipFile(archive) as z:assert z.read("MiniAppSDK/miniapp-sdk.json")==mp.read_bytes()
 project=ROOT/"Fixtures/HostActionSurfaces/nativescript"
 assert git("rev-parse","HEAD:Fixtures/HostActionSurfaces/nativescript")=="10213eccc90704d8a0a5bde2f4b33f62e95d14fd"
 names=["package.json","script.json","tsconfig.json","hanlin.authoring.json","index.ts","proof.ts","widget.jsx"]
 inputs={str((project/n).relative_to(ROOT)):digest(project/n) for n in names}
 originals={"Scripts/MiniApps/miniapp.mjs":digest(ROOT/"Scripts/MiniApps/miniapp.mjs"),"Scripts/ProductSplit/run_paired_acceptance.py":digest(ROOT/"Scripts/ProductSplit/run_paired_acceptance.py")}
 data.update(sourceInputs=inputs,originalCLIAndRunner=originals,shippingArchiveSHA256=digest(archive),sdkManifestSHA256=digest(mp),sdkInputSHA256=sm["inputSHA256"],sdkInputCount=396,freeStart=free())
 # Reuse the exact SDK already extracted and hash-bound by the completed original Host producer.
 # No separate SDK is staged, rebuilt, or synthesized.
 data["sdkOrigin"]="Actual fresh Host764 archive extraction; exact packed manifest and every396 current input verified."
 data["capacity"]={"incrementalAllowanceBytes":536870912,"sharedHostGrowthAllowanceBytes":1073741824,"reserveBytes":750000000,"requiredBytes":2360612736}
 assert free()>=data["capacity"]["requiredBytes"]
 env=os.environ.copy();env["PATH"]=str(S/"tool-bin")+":/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin"
 assert digest((S/"tool-bin/node").resolve())=="336b5b3ebc5deb86df842102b20b6e4761605b7a667823e68dda7761b91a161b"
 output=EVIDENCE/"SurfaceNativeScript.hanlinNativeScript"
 base=["node","Scripts/MiniApps/miniapp.mjs","--sdk",str(sdk),"--project",str(project)]
 reports=[]
 for verb,limit in [("validate",300),("build",600)]:
  report=EVIDENCE/("nativescript-"+verb+".json");log=EVIDENCE/("nativescript-surface-"+verb+".log")
  args=base[:2]+[verb]+base[2:]+(["--archive",str(output)] if verb=="build" else [])+["--report",str(report)]
  row={"name":"original-nativescript-surface-"+verb,"command":args,"cwd":str(ROOT),"timeoutSeconds":limit,"startedAt":now(),"log":str(log)}
  data["phases"].append(row);data["status"]="RUNNING_ORIGINAL_STRICT_SURFACE_CLI";save()
  with log.open("w") as stream:
   proc=subprocess.Popen(args,cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
   row["pid"]=proc.pid;row["pgid"]=os.getpgid(proc.pid);save();start=time.monotonic()
   while proc.poll() is None:
    if time.monotonic()-start>limit or free()<data["capacity"]["reserveBytes"]:
     row["stopReason"]="ORIGINAL_PHASE_DEADLINE_OR_DISK_RESERVE";os.killpg(proc.pid,signal.SIGTERM)
     try:proc.wait(timeout=8)
     except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=8)
     break
    time.sleep(1)
   row["exitCode"]=proc.wait(timeout=10)
  row.update(finishedAt=now(),logSHA256=digest(log))
  if report.is_file():row["reportSHA256"]=digest(report);row["report"]=str(report)
  save();assert row["exitCode"]==0 and not row.get("stopReason"),row
  content=json.loads(report.read_text());assert content.get("succeeded") is True,content
  reports.append({"operation":verb,"path":str(report),"sha256":digest(report)})
 for rel,sha in inputs.items():assert digest(ROOT/rel)==sha,rel
 for rel,sha in originals.items():assert digest(ROOT/rel)==sha,rel
 assert git("rev-parse","HEAD")==SOURCE and not git("status","--porcelain=v1")
 assert digest(archive)==data["shippingArchiveSHA256"] and digest(mp)==data["sdkManifestSHA256"]
 assert output.is_file()
 data.update(status="ORIGINAL_STRICT_NATIVE_SCRIPT_SURFACE_VALIDATE_BUILD_PASSED",sourceUnchanged=True,fixtureInputsUnchanged=True,reports=reports,archive={"path":str(output),"bytes":output.stat().st_size,"sha256":digest(output)})
except BaseException as e:
 if proc is not None and proc.poll() is None:
  os.killpg(proc.pid,signal.SIGTERM)
  try:proc.wait(timeout=8)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=8)
 data.update(status="ORIGINAL_STRICT_SURFACE_CLI_FAILED",error=repr(e),traceback=traceback.format_exc())
finally:
 data["finishedAt"]=now();data["freeEnd"]=free();save()
 fcntl.flock(maintenance,fcntl.LOCK_UN);fcntl.flock(native,fcntl.LOCK_UN)
 print(json.dumps({k:data.get(k) for k in ["status","source","error","finishedAt","archive","freeEnd"]}),flush=True)
if data["status"]!="ORIGINAL_STRICT_NATIVE_SCRIPT_SURFACE_VALIDATE_BUILD_PASSED":raise SystemExit(1)
