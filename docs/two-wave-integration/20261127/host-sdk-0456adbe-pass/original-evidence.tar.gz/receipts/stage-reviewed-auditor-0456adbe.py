import pathlib,subprocess,json,hashlib,datetime,fcntl,os,traceback,shutil
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=stage/'source'
base='16b4af4490d96c41cb76ed185a1e6d4e828899e7';target='0456adbe395cde2fb986cf058c4a9497c38d1d21';audit='Scripts/Audit/audit_miniapp_reachability.py'
proof=stage/'source-update-0456adbe-audit-proof';receipt=stage/'source-update-0456adbe-audit.json'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
data={'status':'PREPARING','startedAt':now(),'sourceBefore':base,'sourceAfter':target,'phases':[],'scope':'Reviewed exact audit-anchor correction and documentation only. Native58/79 remains executed at16b4 and is qualified by exact unchanged package/test/fixture/pin inputs; no repeat native execution is claimed.'}
def save():p=receipt.with_suffix('.tmp');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(receipt)
def git(*a):return subprocess.check_output(['/usr/bin/git','-C',str(root),*a],text=True,timeout=900).strip()
def run(name,args):
 p=proof/(name+'.log')
 with p.open('wb') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 data['phases'].append({'name':name,'command':args,'exitCode':r.returncode,'log':str(p),'sha256':sha(p)});save()
 assert r.returncode==0,p.read_text(errors='replace')[-2000:]
native=open('/Users/m1/caches/hanlin-two-wave-native-app.lock','a+');maintenance=open('/Users/m1/caches/.scaleway-cache-maintenance.lock','a+')
try:
 fcntl.flock(native,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(maintenance,fcntl.LOCK_SH|fcntl.LOCK_NB)
 assert not proof.exists() and not receipt.exists();proof.mkdir();save();assert git('rev-parse','HEAD')==base
 hostPath=stage/'host-preparation-16b4af44-original-phases-r1.json';host=json.loads(hostPath.read_text());assert host['status']=='FAILED' and host['phases'][-1]['exitCode']==1
 nativeProof=stage/'validation/platform-16b4af44/test-r1/required-scope-reconciliation.json'
 assert sha(nativeProof)=='7ad10028a450e27cc112b9bac8c90c115a7e2c15932a896ca296ee669fbe7f35' and json.loads(nativeProof.read_text())['acceptancePassed']
 reviewPath=stage/'independent-camera-audit-review-0456adbe.json';assert sha(reviewPath)=='38b7cb5edb56648ff2ba2bb044a71c6c441a6ab0a1384e1436d56f3908ecc060'
 review=json.loads(reviewPath.read_text());assert review['source']==target and review['decision']=='APPROVED_EXACT_CURRENT_SOURCE_AUDIT_ANCHOR'
 generated='docs/miniapp-sdk/source-inventory.json'
 dirty=git('diff','--name-only','HEAD').splitlines();assert dirty==[generated],dirty;assert not git('diff','--cached','--name-only')
 p=root/generated;assert sha(p)=='a0f62b0f50185d3a025d412c0a47f5f72614e0f88b9075a4448784cfb2e37ff6'
 backup=proof/'failed-16b4-pretest-generated-source-inventory.json';assert not backup.exists();shutil.copyfile(p,backup);assert sha(backup)==sha(p)
 data['preservedGeneratedChange']={'sourcePath':generated,'backup':str(backup),'sha256':sha(backup),'generatedBy':'Original failed16b4 Host pretest source inventory writer; immutable copy retained before returning only this derived document to its committed input.'};save()
 for name,size,digest,ref in [('provisional-package-8a97425e.bundle',23620,'9722bb7a7f87a3238535452734e6da6c3cef874c4a1f51d393e1979c66829189','8a97425e922aca83c81d75ed6cdb13774fde0893'),('provisional-audit-0456adbe.bundle',1902,'61f79342c50bb465965a31f15edc29fae3525232ac69c79c7d42655397261956',target)]:
  b=stage/name;assert b.stat().st_size==size and sha(b)==digest;run('fetch-'+ref[:8],['/usr/bin/git','fetch',str(b),ref])
 changed=git('diff','--name-only',base,target).splitlines();assert changed and all(x==audit or x.startswith('docs/') for x in changed),changed
 before=git('show',base+':'+audit);after=git('show',target+':'+audit)
 old='struct HanlinMiniAppsCameraCaptureExtension: LockedCameraCaptureExtension';new='struct HanlinMiniAppsCameraCaptureExtension: @MainActor LockedCameraCaptureExtension'
 assert before.count(old)==1 and before.replace(old,new)==after
 assert git('diff','--name-only',base,target,'--','Packages','AI_HLY','HanlinMiniAppsApp','HanlinMiniAppsExtensions','HanlinMiniAppsTests','AI_HLYTests','AI_HLYUITests','Fixtures','Scripts/Widgets','Scripts/NativeScript','Scripts/MiniApps','Scripts/Expo','Scripts/Runtime')==''
 invPath=stage/'platform-test-inventory-16b4af44-provisional.json';inv=json.loads(invPath.read_text());assert inv['sourceCommit']==base
 for rel,digest in inv['sourceSHA256'].items():
  assert sha(root/rel)==digest,rel
  blob=subprocess.check_output(['/usr/bin/git','-C',str(root),'show',target+':'+rel],timeout=60);assert hashlib.sha256(blob).hexdigest()==digest,rel
 trees={}
 for rel in ['Packages/HanlinPlatform','Packages/HanlinPlatform/Sources','Packages/HanlinPlatform/Tests','Fixtures/Widgets']:
  beforeTree=git('rev-parse',base+':'+rel);afterTree=git('rev-parse',target+':'+rel);assert beforeTree==afterTree;trees[rel]=afterTree
 run('restore-preserved-generated-document',['/usr/bin/git','restore','--source',base,'--',generated])
 assert not git('diff','--name-only','HEAD')
 run('checkout-reviewed-auditor',['/usr/bin/git','checkout','--detach',target])
 assert git('rev-parse','HEAD')==target and not git('diff','--name-only','HEAD')
 for rel,digest in inv['sourceSHA256'].items():assert sha(root/rel)==digest,rel
 data['changedPaths']=changed;data['independentReview']={'path':str(reviewPath),'sha256':sha(reviewPath)}
 data['nativeQualification']={'status':'REUSE_ACCEPTED_EXACT_NATIVE_INPUTS','executedSource':base,'currentSource':target,'freshNativeExecutionAtCurrentSource':False,'actualDefinitions':58,'actualInvocations':79,'passedInvocations':79,'skippedInvocations':0,'parameterInvocations':28,'collateralInvocations':0,'nativeReceipt':str(nativeProof),'nativeReceiptSHA256':sha(nativeProof),'inventorySHA256':sha(invPath),'unchangedTrees':trees,'allRecordedSourceFixtureAndPinHashesEqual':True}
 data['canonicalHostStatus']='Fresh original producer required and not yet executed at this source.'
 data['tree']=git('rev-parse','HEAD^{tree}');data['status']='REVIEWED_AUDITOR_SOURCE_STAGED_NATIVE_INPUTS_QUALIFIED'
except Exception as e:data.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
finally:
 data['finishedAt']=now();v=os.statvfs('/System/Volumes/Data');data['freeAfter']=v.f_bavail*v.f_frsize;save();print(json.dumps({k:data.get(k) for k in ['status','sourceAfter','tree','error','finishedAt','freeAfter','nativeQualification']}),flush=True)
if data['status']!='REVIEWED_AUDITOR_SOURCE_STAGED_NATIVE_INPUTS_QUALIFIED':raise SystemExit(1)
