import CryptoKit
import Foundation
import HanlinPlatformContracts
import HanlinScriptCompiler
import HanlinScriptContracts
import HanlinScriptStore
import HanlinScriptUI
import HanlinLegacyWidgetStoreFixture
@testable import HanlinScriptExtensions
import Testing
import SwiftUI
#if os(macOS)
import AppKit
import JavaScriptCore
import Network
@testable import HanlinScriptWidgetOriginal
#endif

private typealias Store = HanlinScriptExtensions.HanlinScriptExtensionStore
private typealias Snapshot = HanlinScriptExtensions.HanlinScriptExtensionSnapshot
private typealias Identity = HanlinScriptExtensions.HanlinScriptExtensionIdentity
private typealias Widget = HanlinScriptExtensions.HanlinScriptWidgetSnapshot

@Suite("Pass 3 installed widget programs, actions and transactions")
struct HanlinDualWidgetEnginesTests {
    @Test func scriptWidgetUsesOriginalElementLimitsWithoutExtraMaterialQuotas() throws {
        func run(_ source: String) throws -> HanlinScriptWidgetExecution {
            try HanlinScriptWidgetRuntime.shared.run(program: .init(engine: .scriptwidget,
                sourceSHA256: String(repeating: "a", count: 64), compilerSHA256: String(repeating: "b", count: 64),
                javaScript: "async function $main() { \(source) }", actions: [], families: ["systemMedium"]), values: [:], environment: [:])
        }
        for source in [
            "$render(ScriptWidget.createElement('text', {}, Array(1001).fill('x')));",
            "$render(ScriptWidget.createElement('vstack', {}, Array.from({length:250}, () => ScriptWidget.createElement('text', {title:'x'.repeat(1100)}, 'x'))));",
            "const props = {}; for (let i=0;i<120;i++) props['key'+i] = 'x'.repeat(2300); $render(ScriptWidget.createElement('text', props, 'x'));"
        ] {
            #expect(try run(source).node.tag != "")
        }
        let valid = try run("$render(ScriptWidget.createElement('text', {}, Array(1100).fill('x'.repeat(1024))));")
        #expect(valid.node.children.count == 1100)
        #expect(try JSONEncoder().encode(valid.node).count > 1_048_576)
        #expect(throws: HanlinScriptWidgetError.self) {
            _ = try run("$render(ScriptWidget.createElement('vstack', {}, Array.from({length:1001}, () => ScriptWidget.createElement('text',{},'x'))));")
        }
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        let identity = Identity(installedPackageID: try .init(validating: "installed.budget"), packageID: try .init(validating: "package.budget"), generation: 1, entrypointID: "widget")
        let program = HanlinWidgetProgram(engine: .scriptwidget, sourceSHA256: String(repeating: "a", count: 64), compilerSHA256: String(repeating: "b", count: 64), javaScript: "async function $main() { $storage.set('staged',true); $render(ScriptWidget.createElement('vstack',{},Array.from({length:1001},()=>ScriptWidget.createElement('text',{},'x')))); }", actions: [], families: ["systemMedium"])
        let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: identity.installedPackageID, generation: 1)
        let widget = Widget(identity: identity, displayName: "Budget failure", validUntil: .distantFuture, engine: .scriptwidget,
            payload: .scriptwidget(.init(script: "", scriptRef: artifact.ref, scriptSHA256: artifact.sha256)), root: .init(kind: .text))
        try store.publishWidgetTemplates([widget], intentEntities: [], translationApps: [], installedPackageIDs: [identity.installedPackageID])
        let entityID = try #require(try store.load()?.widgetInstances.first?.entityID)
        guard case .failure = HanlinWidgetPreparation.prepare(store: store, entityID: entityID, family: "systemMedium") else { Issue.record("An invalid original element tree was published"); return }
        #expect(try store.load()?.widgetStates.isEmpty == true, "Failed preparation committed staged script storage")
    }
    @Test func sameSourceActionTargetAcrossInstalledPackagesAndVariantsIsIsolated() async throws {
        let first = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo", installationID: "installed.first", packageID: "package.first")
        defer { first.remove() }
        let second = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo", installationID: "installed.second", packageID: "package.second")
        defer { second.remove() }
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        var templates: [Widget] = []
        for fixture in [first, second] {
            let (program, _) = try fixture.store.loadProgram(for: fixture.template)
            let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: fixture.identity.installedPackageID, generation: fixture.identity.generation)
            templates.append(.init(identity: fixture.identity, displayName: fixture.template.displayName, validUntil: .distantFuture, engine: .expo,
                payload: .expo(.init(layout: "", layoutRef: artifact.ref, layoutSHA256: artifact.sha256)), root: fixture.template.root))
        }
        let installedIDs: Set<HanlinInstalledPackageID> = [first.identity.installedPackageID, second.identity.installedPackageID]
        try store.publishWidgetTemplates(templates, intentEntities: [], translationApps: [], installedPackageIDs: installedIDs)
        let instances = try #require(try store.load()?.widgetInstances)
        let firstBase = try #require(instances.first { $0.identity == first.identity })
        let secondBase = try #require(instances.first { $0.identity == second.identity })
        let a1 = try store.createWidgetInstance(from: firstBase.entityID, displayName: "A1")
        let a2 = try store.createWidgetInstance(from: firstBase.entityID, displayName: "A2")
        for (instance, taps) in [(a1, 1), (a2, 2), (secondBase, 3)] {
            guard case let .expo(_, context) = HanlinWidgetPreparation.prepare(store: store, entityID: instance.entityID, family: "systemMedium") else { Issue.record("Independent installed instance failed preparation"); return }
            for _ in 0..<taps { _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "increment"), store: store) }
        }
        try store.publishWidgetTemplates(templates, intentEntities: [], translationApps: [], installedPackageIDs: installedIDs)
        let reopened = try #require(try Store(root: root).load())
        for (instance, expected) in [(a1, Int64(8)), (a2, Int64(9)), (secondBase, Int64(10))] {
            #expect(reopened.widgetStates.first { $0.identity == instance.identity }?.values["count"] == .integer(expected))
            #expect(reopened.widgetInstances.contains(instance))
        }
        #expect(reopened.widgetStates.first { $0.identity == firstBase.identity } == nil)
    }
    @Test func installedProgramPreparationAndActionMeasurements() async throws {
        let names = ["Hanlin-Expo-Widget-Counter.hanlinExpo", "Hanlin-Expo-Widget-Visuals.hanlinExpo", "Hanlin-ScriptWidget-Dashboard.scripting", "Hanlin-ScriptWidget-Actions.scripting", "Hanlin-Widget-Legacy-Regression.scripting"]
        func milliseconds(since start: ContinuousClock.Instant) -> Double {
            let elapsed = start.duration(to: .now).components
            return Double(elapsed.seconds) * 1_000 + Double(elapsed.attoseconds) / 1e15
        }
        var records: [[String: Any]] = []
        for name in names {
            let installedAt = ContinuousClock.now
            let fixture = try await InstalledFixture(name)
            defer { fixture.remove() }
            let installMS = milliseconds(since: installedAt)
            var preparationMS: [Double] = []
            for _ in 0..<3 {
                let start = ContinuousClock.now
                let presentation = HanlinWidgetPreparation.prepare(store: Store(root: fixture.extensionRoot), entityID: fixture.entityID, family: "systemMedium")
                preparationMS.append(milliseconds(since: start))
                if case let .failure(reason) = presentation { Issue.record("Measured preparation failed: \(reason)") }
            }
            var record: [String: Any] = ["archive": name, "archiveSHA256": sha(try Data(contentsOf: fixtureURL(name))),
                "engine": fixture.template.engine.rawValue, "family": "systemMedium", "installCompilePublishMS": installMS,
                "preparationFirstThenRepeatMS": preparationMS]
            if name.contains("Counter") || name.contains("Actions") {
                let context = try fixture.context()
                let action = name.contains("Counter") ? "increment" : "sync"
                let start = ContinuousClock.now
                _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: action), store: fixture.store)
                record["sourceActionCommitMS"] = milliseconds(since: start)
                record["sourceAction"] = action
                record["programSHA256"] = context.artifactSHA256
                #expect(try fixture.values()[name.contains("Counter") ? "count" : "syncCount"] == .integer(name.contains("Counter") ? 8 : 1))
            }
            records.append(record)
        }
        try recordEvidence(name: "native-program-measurements", values: ["scope": "macOS shared installed-program execution; five isolated temporary installations, not five configured OS widgets",
            "vmLifecycle": "New JavaScriptCore context per preparation/action. Repeated samples do not reuse a VM.",
            "memoryPeak": "NOT_MEASURED", "deviceOrWidgetKitLatency": "NOT_MEASURED", "measurements": records])
    }
    #if os(macOS)
    @Test func originalScriptWidgetHTTPUsesBoundedRealTransport() throws {
        let root = try temporary()
        let stagesFile = root.appending(path: "native-stages.jsonl")
        let stagesLock = NSLock()
        var reachedFinalAssertion = false
        func recordStage(_ label: String, _ phase: String, _ details: [String: Any] = [:]) {
            stagesLock.lock()
            defer { stagesLock.unlock() }
            do {
                var event = details
                event["label"] = label
                event["phase"] = phase
                event["at"] = Date().timeIntervalSince1970
                event["pid"] = ProcessInfo.processInfo.processIdentifier
                event["isMainThread"] = Thread.isMainThread
                var bytes = try JSONSerialization.data(withJSONObject: event, options: [.sortedKeys])
                bytes.append(0x0a)
                if !FileManager.default.fileExists(atPath: stagesFile.path) {
                    try Data().write(to: stagesFile)
                }
                let output = try FileHandle(forWritingTo: stagesFile)
                defer { try? output.close() }
                try output.seekToEnd()
                try output.write(contentsOf: bytes)
            } catch {
                print("Original HTTP diagnostic could not record \(label)/\(phase): \(error)")
            }
        }
        defer {
            recordStage("test", reachedFinalAssertion ? "assertions-reached-end" : "exited-before-end")
            if let directory = ProcessInfo.processInfo.environment["HANLIN_WIDGET_EVIDENCE_DIR"] {
                let retained = URL(filePath: directory).appending(path: "original-http-" + root.lastPathComponent)
                do {
                    try FileManager.default.createDirectory(at: retained, withIntermediateDirectories: true)
                    for name in ["native-stages.jsonl", "wire.jsonl", "server.stdout", "server.stderr", "port"] {
                        let source = root.appending(path: name)
                        if FileManager.default.fileExists(atPath: source.path) {
                            try FileManager.default.copyItem(at: source, to: retained.appending(path: name))
                        }
                    }
                    print("Original HTTP native evidence retained at \(retained.path)")
                    try FileManager.default.removeItem(at: root)
                } catch {
                    print("Original HTTP evidence copy failed; source retained at \(root.path): \(error)")
                }
            } else {
                print("Original HTTP native evidence retained at \(root.path)")
            }
        }
        recordStage("test", "started", ["executionTimeout": HanlinOriginalScriptWidgetSession.executionTimeout])
        let portFile = root.appending(path: "port")
        let wireFile = root.appending(path: "wire.jsonl")
        let authority = "transport.hanlin.invalid:80"
        let server = Process()
        server.executableURL = URL(fileURLWithPath: "/usr/bin/env")
        server.arguments = ["python3", "-u", "-c", #"""
            import http.server, json, pathlib, sys, threading, time, urllib.parse
            authority, wire_path = sys.argv[3], pathlib.Path(sys.argv[2])
            wire_lock = threading.Lock()
            def record(value):
                with wire_lock, wire_path.open('a', encoding='utf-8') as output:
                    output.write(json.dumps(value, sort_keys=True) + '\n')
            class Handler(http.server.BaseHTTPRequestHandler):
                protocol_version = 'HTTP/1.1'
                def log_message(self, *args): pass
                def do_CONNECT(self):
                    record({'phase': 'connect', 'authority': self.path})
                    if self.path != authority:
                        self.send_error(403); return
                    self.tunnel_authority = self.path
                    self.send_response(200, 'Connection Established')
                    self.end_headers()
                    self.close_connection = False
                def handle_request(self):
                    if getattr(self, 'tunnel_authority', None) != authority:
                        self.send_error(403); return
                    path = urllib.parse.urlsplit(self.path).path
                    body = self.rfile.read(int(self.headers.get('Content-Length', '0'))).decode()
                    record({'phase': 'request', 'authority': self.tunnel_authority,
                            'path': path, 'method': self.command, 'host': self.headers.get('Host'),
                            'body': body, 'header': self.headers.get('X-Widget'),
                            'type': self.headers.get('Content-Type'), 'at': time.monotonic()})
                    if path.endswith('/slow'): time.sleep(3)
                    if path.endswith('/redirect'):
                        self.send_response(302)
                        self.send_header('Location', 'file:///etc/hosts')
                        self.send_header('Content-Length', '0'); self.end_headers(); return
                    if path.endswith('/large'): data = b'x' * (2*1024*1024+1)
                    elif path.endswith('/within-limit'): data = b'x' * (2*1024*1024)
                    elif path.endswith('/binary'): data = bytes([0,127,255])
                    else: data = json.dumps({'method': self.command, 'body': body,
                        'header': self.headers.get('X-Widget'), 'type': self.headers.get('Content-Type')}).encode()
                    self.send_response(503 if path.endswith('/status') else 200)
                    self.send_header('Content-Type', 'application/json')
                    self.send_header('Retry-After', '3')
                    self.send_header('Content-Length', str(len(data))); self.end_headers()
                    try:
                        self.wfile.write(data); self.wfile.flush()
                        record({'phase': 'response', 'path': path, 'bytes': len(data), 'at': time.monotonic()})
                    except (BrokenPipeError, ConnectionResetError): pass
                do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = handle_request
            server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
            pathlib.Path(sys.argv[1]).write_text(str(server.server_port))
            server.serve_forever()
            """#, portFile.path, wireFile.path, authority]
        let stdoutFile = root.appending(path: "server.stdout")
        let stderrFile = root.appending(path: "server.stderr")
        try Data().write(to: stdoutFile)
        try Data().write(to: stderrFile)
        let serverOutput = try FileHandle(forWritingTo: stdoutFile)
        let serverError = try FileHandle(forWritingTo: stderrFile)
        defer { try? serverOutput.close(); try? serverError.close() }
        server.standardOutput = serverOutput
        server.standardError = serverError
        try server.run()
        recordStage("server", "started", ["serverPID": server.processIdentifier])
        defer {
            if server.isRunning { server.terminate(); server.waitUntilExit() }
            recordStage("server", "terminated", ["terminationStatus": server.terminationStatus,
                "terminationReason": server.terminationReason.rawValue])
        }
        let startupDeadline = Date().addingTimeInterval(5)
        while !FileManager.default.fileExists(atPath: portFile.path), Date() < startupDeadline {
            Thread.sleep(forTimeInterval: 0.01)
        }
        let port = try #require(UInt16(String(contentsOf: portFile, encoding: .utf8)))
        recordStage("server", "ready", ["port": Int(port)])
        // Keep the original URL/domain policy active. Only this test's real
        // URLSession uses the owned CONNECT proxy; no system proxy is changed.
        let configuration = URLSessionConfiguration.ephemeral
        configuration.proxyConfigurations = [ProxyConfiguration(httpCONNECTProxy:
            .hostPort(host: "127.0.0.1", port: try #require(NWEndpoint.Port(rawValue: port))))]
        let transport = HanlinScriptWidgetOriginal.ScriptWidgetFetchManager(configuration: configuration)
        typealias HTTPResult = (tag: String, children: [String], values: [String: HanlinValue], requests: Int)
        func execute(_ label: String, _ source: String) throws -> HTTPResult {
            recordStage(label, "preparing")
            let base = "http://transport.hanlin.invalid/\(label)"
            let program = HanlinWidgetProgram(engine: .scriptwidget,
                sourceSHA256: String(repeating: "a", count: 64), compilerSHA256: String(repeating: "b", count: 64),
                javaScript: "async function $main() { const base='\(base)'; \(source); $render(ScriptWidget.createElement('text',{},'Transport verified')); }",
                actions: [], families: ["systemMedium"])
            try program.validate(engine: .scriptwidget)
            try HanlinOriginalScriptWidgetSession.validatePreparedJavaScript(program.javaScript)
            let context = try #require(JSContext())
            let native = try HanlinOriginalScriptWidgetSession(context: context,
                root: root.appending(path: label), identity: UUID().uuidString,
                preparedJavaScript: program.javaScript, files: program.resources,
                values: [:], environment: [:], isUserInitiatedAction: false)
            let completed = DispatchSemaphore(value: 0)
            var result: Result<HTTPResult, Error>?
            var rendered: (String, [String])?
            defer {
                native.cancel()
                native.onJavaScriptQueue {
                    native.finish()
                    context.exceptionHandler = nil
                    for key in ["$render", "__httpTestDone", "__httpTestFailed", "__httpTestStore", "__httpTestStage"] {
                        context.setObject(nil, forKeyedSubscript: key as NSString)
                    }
                }
            }
            try native.onJavaScriptQueue {
                let state = try #require(context.scriptWidgetRunningState)
                state.fetchManagerForTesting = transport
                native.installAPIs()
                let failed: @convention(block) (String) -> Void = { message in
                    guard result == nil else { return }
                    recordStage(label, "rejected", ["message": message])
                    result = .failure(HanlinScriptWidgetError(message)); completed.signal()
                }
                let render: @convention(block) (HanlinScriptWidgetOriginal.ScriptWidgetRuntimeElement) -> Void = { element in
                    if let error = HanlinScriptWidgetOriginal.ScriptWidgetRuntimeContract.validateElementTree(element) {
                        failed(error.localizedDescription); return
                    }
                    guard let tag = element.tagAsString(), let children = element.getChildren() as? [String] else {
                        failed("The transport fixture did not render its actual text element"); return
                    }
                    rendered = (tag, children)
                    recordStage(label, "rendered", ["tag": tag, "childCount": children.count])
                }
                // Same compatibility alias as the shipping adapter; storage is
                // still the original session's real transaction and namespace.
                let store: @convention(block) (String, Any) -> Bool = { [weak native] key, value in
                    guard let native else { return false }
                    do { try native.setValue(value, forKey: key); return true }
                    catch { failed(error.localizedDescription); return false }
                }
                let finished: @convention(block) () -> Void = { [weak native] in
                    guard result == nil else { return }
                    do {
                        let native = try #require(native)
                        let rendered = try #require(rendered)
                        result = .success((rendered.0, rendered.1,
                            try HanlinWidgetJSON.dictionary(native.values()), state.executionSession.totalNetworkRequests))
                        recordStage(label, "resolved", ["requests": state.executionSession.totalNetworkRequests])
                    } catch {
                        recordStage(label, "completion-error", ["message": String(describing: error)])
                        result = .failure(error)
                    }
                    completed.signal()
                }
                let stage: @convention(block) (String) -> Void = { name in
                    recordStage(label, "javascript", ["stage": name,
                        "requests": state.executionSession.totalNetworkRequests])
                }
                context.setObject(render, forKeyedSubscript: "$render" as NSString)
                context.setObject(store, forKeyedSubscript: "__httpTestStore" as NSString)
                context.setObject(finished, forKeyedSubscript: "__httpTestDone" as NSString)
                context.setObject(failed, forKeyedSubscript: "__httpTestFailed" as NSString)
                context.setObject(stage, forKeyedSubscript: "__httpTestStage" as NSString)
                context.exceptionHandler = { _, error in failed(error?.toString() ?? "Native HTTP fixture exception") }
                context.evaluateScript("globalThis.$storage = {set: __httpTestStore};")
                context.evaluateScript(try #require(HanlinOriginalScriptWidgetSession.supportScript("util.js")))
                context.evaluateScript(program.javaScript)
                recordStage(label, "evaluating")
                context.evaluateScript("$main().then(__httpTestDone, e => __httpTestFailed(String(e)));")
            }
            guard completed.wait(timeout: .now() + HanlinOriginalScriptWidgetSession.executionTimeout) == .success else {
                recordStage(label, "timeout", ["executionTimeout": HanlinOriginalScriptWidgetSession.executionTimeout])
                throw HanlinScriptWidgetError("The original HTTP execution did not finish within its native budget (stage: \(label); evidence: \(root.path))")
            }
            return try native.onJavaScriptQueue { try #require(result).get() }
        }
        let verbs = try execute("verbs", #"""
            for (const method of ['get','post','put','patch']) {
              __httpTestStage('verb:'+method);
              const result = JSON.parse(await $http[method](base+'/echo', {headers:{'X-Widget':'source'},body:method==='get'?undefined:{count:7}}));
              if (result.method !== method.toUpperCase() || result.header !== 'source') throw Error('HTTP method/header lost');
              if (method !== 'get' && (JSON.parse(result.body).count !== 7 || result.type !== 'application/json')) throw Error('JSON body lost');
              $storage.set(method, result.method);
            }
            for (let index=4; index<32; index++) {
              __httpTestStage('budget:'+index);
              const result = JSON.parse(await $fetch(base+'/budget/'+index));
              if (result.method !== 'GET') throw Error('An admitted request did not reach the real transport');
            }
            let rejected = false;
            __httpTestStage('over-budget');
            try { await $fetch(base+'/over-budget'); }
            catch (error) { rejected = String(error).includes('Network request budget exceeded'); }
            if (!rejected) throw Error('Thirty-third request exceeded budget');
            """#)
        #expect(verbs.values["post"] == .string("POST"))
        #expect(verbs.requests == 32)
        let response = try execute("response", #"""
            __httpTestStage('delete');
            const deleted = JSON.parse(await $http.delete(base+'/echo', {body:'raw source'}));
            if (deleted.method !== 'DELETE' || deleted.body !== 'raw source') throw Error('DELETE body lost');
            __httpTestStage('status');
            const status = await $http.getResponse(base+'/status');
            if (status.status !== 503 || status.headers['retry-after'] !== '3' || JSON.parse(status.body).method !== 'GET') throw Error('Response metadata lost');
            __httpTestStage('binary');
            const bytes = await $fetch(base+'/binary', {responseType:'base64'});
            if (bytes !== 'AH//') throw Error('Binary response lost');
            $storage.set('status', status.status);
            """#)
        #expect(response.values["status"] == .integer(503))
        let limits = try execute("limits", #"""
            __httpTestStage('within-limit');
            const admitted = await $http.get(base+'/within-limit');
            __httpTestStage('within-limit-received');
            if (admitted.length !== 2*1024*1024 || !/^x+$/.test(admitted)) throw Error('The supported response boundary was rejected or changed');
            __httpTestStage('within-limit-validated');
            for (const [path,params] of [['/large',{}],['/redirect',{}],['/slow',{timeoutInterval:0.05}]]) {
              __httpTestStage('limit:'+path);
              const started = Date.now();
              let rejected = false;
              try { await $http.get(base+path, params); }
              catch (error) {
                rejected = true;
                if (path === '/large' && !String(error).includes('Response exceeds the 2097152-byte limit')) throw error;
              }
              if (!rejected) throw Error('Unsafe or over-budget transport accepted: '+path);
              const elapsed = Date.now()-started;
              if (path === '/slow' && (elapsed < 900 || elapsed >= 2500)) throw Error('The one-second timeout floor was not applied to the real slow request');
            }
            for (const [url,reason] of [['file:///etc/hosts','Only HTTP and HTTPS URLs are allowed'],['http://127.0.0.1/private','Local and private network hosts are not allowed']]) {
              __httpTestStage('policy:'+url);
              let rejected = false;
              try { await $fetch(url); } catch (error) { rejected = String(error).includes(reason); }
              if (!rejected) throw Error('Disallowed transport accepted: '+url);
            }
            """#)
        #expect(limits.tag == "text")
        #expect(limits.children == ["Transport verified"])
        #expect(response.requests == 3)
        #expect(limits.requests == 4)
        let wire = try String(contentsOf: wireFile, encoding: .utf8).split(separator: "\n").map {
            try #require(JSONSerialization.jsonObject(with: Data($0.utf8)) as? [String: Any])
        }
        let requests = wire.filter { $0["phase"] as? String == "request" }
        #expect(wire.contains { $0["phase"] as? String == "connect" && $0["authority"] as? String == authority })
        #expect(requests.count == 39)
        #expect(requests.allSatisfy {
            $0["authority"] as? String == authority && ["transport.hanlin.invalid", "transport.hanlin.invalid:80"].contains($0["host"] as? String ?? "")
        })
        #expect(requests.filter { ($0["path"] as? String)?.hasPrefix("/verbs/") == true }.count == 32)
        #expect(requests.filter { $0["path"] as? String == "/response/echo" && $0["method"] as? String == "DELETE" && $0["body"] as? String == "raw source" }.count == 1)
        #expect(requests.filter { $0["path"] as? String == "/limits/slow" }.count == 1)
        #expect(!requests.contains { ($0["path"] as? String)?.contains("over-budget") == true || $0["path"] as? String == "/private" })
        #expect(!wire.contains { $0["phase"] as? String == "response" && $0["path"] as? String == "/limits/slow" })
        reachedFinalAssertion = true
    }
    #endif
    @Test func passiveLegacyNavigationCannotCoverNativeOrNestedButtons() throws {
        let identity = Identity(installedPackageID: try .init(validating: "installed.legacy-link"), packageID: try .init(validating: "package.legacy-link"), generation: 1, entrypointID: "widget")
        let url = try #require(URL(string: "hanlin://scripts/legacy-link"))
        let passive = Widget(identity: identity, displayName: "Legacy link", validUntil: .distantFuture, root: .init(kind: .text), deepLink: url)
        #expect(HanlinPreparedWidget.legacy(passive).passiveLegacyURL == url)
        let interactive = Widget(identity: identity, displayName: "Legacy action", validUntil: .distantFuture,
            root: .init(kind: .vStack, children: [.init(kind: .button)]), deepLink: url)
        #expect(HanlinPreparedWidget.legacy(interactive).passiveLegacyURL == nil)
        let context = HanlinWidgetActionContext(identity: identity, engine: .expo, artifactSHA256: String(repeating: "a", count: 64), family: "systemMedium")
        #expect(HanlinPreparedWidget.expo(node: .object([:]), context: context).passiveLegacyURL == nil)
        #expect(HanlinPreparedWidget.scriptwidget(node: .init(tag: "button", props: [:], children: []), context: context).passiveLegacyURL == nil)
        #expect(HanlinPreparedWidget.failure("Missing widget").passiveLegacyURL == nil)
    }
    @Test func timelinePreparationCommitsOriginalTypedStorageAcrossColdReads() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        let identity = Identity(installedPackageID: try .init(validating: "installed.timeline"), packageID: try .init(validating: "package.timeline"), generation: 1, entrypointID: "widget")
        let program = HanlinWidgetProgram(engine: .scriptwidget, sourceSHA256: String(repeating: "a", count: 64), compilerSHA256: String(repeating: "b", count: 64), javaScript: """
            async function $main() {
              const count = ($storage.get('count') || 0) + 1;
              $storage.set('count', count);
              $storage.set('temporary', true);
              $storage.remove('temporary');
              $render(ScriptWidget.createElement('text', {}, String(count)));
            }
            """, actions: [], families: ["systemMedium"])
        let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: identity.installedPackageID, generation: 1)
        let widget = Widget(identity: identity, displayName: "Timeline storage", validUntil: .distantFuture, engine: .scriptwidget,
            payload: .scriptwidget(.init(script: "", scriptRef: artifact.ref, scriptSHA256: artifact.sha256)), root: .init(kind: .text))
        try store.publishWidgetTemplates([widget], intentEntities: [], translationApps: [], installedPackageIDs: [identity.installedPackageID])
        let instance = try #require(try store.load()?.widgetInstances.first)
        for expected in [1, 2] {
            let reopened = Store(root: root)
            guard case let .scriptwidget(node, _) = HanlinWidgetPreparation.prepare(store: reopened, entityID: instance.entityID, family: "systemMedium") else { Issue.record("Timeline storage preparation failed"); return }
            #expect(node.children == [.value(.string(String(expected)))])
            let state = try #require(try reopened.load()?.widgetStates.first)
            #expect(state.values["count"] == .integer(Int64(expected)))
            #expect(state.values["temporary"] == nil)
            #expect(state.revision == UInt64(expected))
        }
    }
    @Test func originalScriptWidgetImportedHelpersAndVerifiedFileStorage() throws {
        let program = HanlinWidgetProgram(engine: .scriptwidget,
            sourceSHA256: String(repeating: "a", count: 64), compilerSHA256: String(repeating: "b", count: 64),
            javaScript: """
              async function $main() {
                if (!$import('helper.js')) throw Error('helper not found');
                if ($storage.getString('missing') !== '') throw Error('upstream string default');
                if (!$storage.compareAndSetString('mode', '', 'verified')) throw Error('CAS failed');
                $storage.setJSON('payload', $file.readJSON('payload.json'));
                $render(ScriptWidget.createElement('text', {}, helper($storage.getString('mode'))));
              }
              """, actions: [], families: ["systemMedium"],
            resources: ["payload.json": Data(#"{"count":9}"#.utf8)],
            imports: ["helper.js": "function helper(value) { return 'Imported ' + value; }"])
        let result = try HanlinScriptWidgetRuntime.shared.run(program: program, values: [:], environment: [:])
        #expect(result.node.tag == "text")
        #expect(result.node.children == [.value(.string("Imported verified"))])
        #expect(result.values["mode"] == .string("verified"))
        guard case let .object(payload)? = result.values["payload"] else { Issue.record("Verified JSON file did not retain an object value"); return }
        #expect(payload["count"] == .integer(9))
    }
    @Test(arguments: ["Hanlin-Expo-Widget-Counter.hanlinExpo", "Hanlin-Expo-Widget-Visuals.hanlinExpo", "Hanlin-ScriptWidget-Dashboard.scripting", "Hanlin-ScriptWidget-Actions.scripting", "Hanlin-Widget-Legacy-Regression.scripting", "Hanlin-Mixed-Native-Widget.hanlinExpo", "Hanlin-Widget-Invalid-Cases.hanlinExpo"])
    func realArchiveImport(name: String) throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let staged = try HanlinPackageCenter().stageAndInspect(sourceURL: fixtureURL(name), stagingParent: root)
        let preview = try HanlinScriptAnalyzer(inventory: inventory).analyze(staged)
        let expected = !name.contains("Invalid") && !name.contains("Mixed")
        #expect(preview.canInstall == expected, "\(preview.findings)")
        try recordEvidence(name: "analysis-\(name)", values: [
            "scope": "Real shared analyzer; not a native UI assertion",
            "archive": name, "archiveSHA256": sha(try Data(contentsOf: fixtureURL(name))),
            "canInstall": preview.canInstall, "findings": String(describing: preview.findings)
        ])
        if expected {
            let entry = try #require(preview.entrypoints.first)
            #expect(preview.entrypoints.count == 1)
            #expect(entry.kind == .widget)
            #expect(entry.widgetEngine?.rawValue == (name.contains("Legacy") ? "legacy" : name.contains("ScriptWidget") ? "scriptwidget" : "expo"))
            let encoded = try JSONEncoder().encode(entry)
            #expect(try JSONDecoder().decode(HanlinPackageEntrypointDescriptor.self, from: encoded).widgetEngine == entry.widgetEngine)
        }
    }

    @Test(arguments: ["Hanlin-Expo-Widget-Counter.hanlinExpo", "Hanlin-Expo-Widget-Visuals.hanlinExpo", "Hanlin-ScriptWidget-Dashboard.scripting", "Hanlin-ScriptWidget-Actions.scripting", "Hanlin-Widget-Legacy-Regression.scripting"])
    func installAndVerifiedLoader(name: String) async throws {
        let fixture = try await InstalledFixture(name)
        defer { fixture.remove() }
        let snapshot = try #require(try fixture.store.load())
        let reopened = Store(root: fixture.extensionRoot)
        #expect(try reopened.load() == snapshot)
        let widget = try #require(snapshot.widgets.first)
        var preparedNode: HanlinCachedWidgetNode?
        if widget.engine == .legacy {
            guard case let .legacy(prepared) = HanlinWidgetPreparation.prepare(store: fixture.store, entityID: fixture.entityID, family: "systemMedium") else { Issue.record("Installed legacy archive failed to prepare"); return }
            #expect(prepared.root.properties["text"] == .string("Legacy HanlinScriptUINode Tree"))
        } else {
            let (program, _) = try fixture.store.loadProgram(for: widget)
            #expect(program.engine == widget.engine)
            switch HanlinWidgetPreparation.prepare(store: fixture.store, entityID: fixture.entityID, family: "systemMedium") {
            case let .expo(node, _): preparedNode = .expo(node)
            case let .scriptwidget(node, _): preparedNode = .scriptwidget(node)
            default: Issue.record("The actual installed program failed to prepare")
            }
        }
        #expect(widget.identity.generation == 1)
        #expect(try await fixture.installed.snapshots().first?.entrypoints.first?.widgetEngine == widget.engine)
        // Preparation intentionally commits a verified last-good render (and
        // any original script storage writes). Both persistence boundaries must
        // round-trip their own complete committed snapshot.
        let committed = try #require(try fixture.store.load())
        let afterPreparation = Store(root: fixture.extensionRoot)
        #expect(try afterPreparation.load() == committed)
        if widget.engine == .legacy {
            #expect(committed == snapshot)
        } else {
            let expectedNode = try #require(preparedNode)
            let instance = try #require(committed.widgetInstances.first { $0.identity == widget.identity })
            let (_, programSHA256) = try afterPreparation.loadProgram(for: widget)
            #expect(try afterPreparation.lastSuccessfulWidgetNode(in: committed, widget: widget,
                instance: instance, programSHA256: programSHA256) == expectedNode)
        }
        var evidence: [String: Any] = [
            "scope": "Actual shared atomic installation and preparation; not SpringBoard placement",
            "archive": name, "archiveSHA256": sha(try Data(contentsOf: fixtureURL(name))),
            "familyPrepared": "systemMedium", "entityID": fixture.entityID,
            "installedWidget": try JSONSerialization.jsonObject(with: JSONEncoder().encode(widget))
        ]
        if widget.engine != .legacy {
            let (program, _) = try fixture.store.loadProgram(for: widget)
            evidence["sourceSHA256"] = program.sourceSHA256
            evidence["compilerSHA256"] = program.compilerSHA256
            evidence["compiledJavaScriptSHA256"] = sha(Data(program.javaScript.utf8))
            evidence["upstreamCommit"] = program.upstreamCommit
            evidence["declaredFamilies"] = program.families
        }
        try recordEvidence(name: "installed-\(name)", values: evidence)
        #if os(macOS)
        let presentation = HanlinWidgetPreparation.prepare(store: fixture.store, entityID: fixture.entityID, family: "systemMedium")
        if let png = try await installedNativeRaster(presentation) {
            if let directory = ProcessInfo.processInfo.environment["HANLIN_WIDGET_EVIDENCE_DIR"] {
                try png.write(to: URL(filePath: directory).appending(path: "installed-\(name)-native.png"), options: .atomic)
            }
        }
        #endif
    }

    @MainActor @Test
    func emittedExpoIntentCarriesVerifiedIdentityAndCallsSource() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }
        let context = try fixture.context()
        // This factory is the exact path called by the original native renderer's
        // injected Button builder. Actual SpringBoard tapping is a separate UI gate.
        let intent = try HanlinExpoWidgetsViewRenderer.actionIntent(target: "increment", context: context)
        let command = try JSONDecoder().decode(HanlinWidgetActionCommand.self, from: Data(intent.commandJSON.utf8))
        #expect(command.context.engine == .expo)
        #expect(command.context.identity == fixture.identity)
        #expect(command.context.artifactSHA256 == context.artifactSHA256)
        _ = try HanlinWidgetActionExecutor.perform(command, store: fixture.store)
        #expect(try fixture.values()["count"] == .integer(8))
        _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "decrement"), store: fixture.store)
        #expect(try fixture.values()["count"] == .integer(7))
        _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "status"), store: fixture.store)
        #expect(try fixture.values()["status"] == .string("Source callback ran"))
        #expect(try fixture.values()["trace"] == .string("status-handler"))
        #expect(try fixture.values()["count"] == .integer(7))
    }

    @Test func userCreatedInstancesAndHostRefreshPreserveState() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }
        let base = try #require(try fixture.store.load()?.widgetInstances.first)
        let a1 = try fixture.store.createWidgetInstance(from: base.entityID, displayName: "A1")
        let a2 = try fixture.store.createWidgetInstance(from: base.entityID, displayName: "A2")
        #expect(a1.entityID != a2.entityID)
        let context = try fixture.context(entityID: a1.entityID)
        _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "increment"), store: fixture.store)
        try fixture.republish()
        let reopened = Store(root: fixture.extensionRoot)
        let state = try #require(try reopened.load())
        #expect(state.widgetInstances.contains(a1))
        #expect(state.widgetInstances.contains(a2))
        #expect(state.widgetStates.first { $0.identity == a1.identity }?.values["count"] == .integer(8))
        #expect(state.widgetStates.first { $0.identity == a2.identity } == nil)
        guard case let .expo(node, _) = HanlinWidgetPreparation.prepare(store: reopened, entityID: a2.entityID, family: "systemMedium") else { Issue.record("A2 failed to prepare"); return }
        #expect(String(decoding: try node.jsonValue().canonicalJSONData(), as: UTF8.self).contains("\"7\""))
    }

    @Test func scriptWidgetNamedActionsAndBooleanSetValue() async throws {
        let fixture = try await InstalledFixture("Hanlin-ScriptWidget-Actions.scripting")
        defer { fixture.remove() }
        let context = try fixture.context()
        _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "sync"), store: fixture.store)
        _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "named"), store: fixture.store)
        #expect(try fixture.values()["syncCount"] == .integer(1))
        #expect(try fixture.values()["status"] == .string("Named source function ran"))
        for value in [true, true, false, false] {
            _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "backup", desiredValue: value), store: fixture.store)
            #expect(try fixture.values()["backup"] == .bool(value))
            guard case let .scriptwidget(node, _) = HanlinWidgetPreparation.prepare(store: fixture.store, entityID: fixture.entityID, family: "systemMedium") else { Issue.record("Toggle preparation failed"); return }
            #expect(find(node, tag: "toggle")?.props["on"] == .bool(value))
        }
        try fixture.republish()
        #expect(try fixture.values()["backup"] == .bool(false))
    }

    @Test func staleUndeclaredDisabledAndUninstalledActionsRejectBeforeMutation() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }
        let context = try fixture.context()
        let identity = Identity(installedPackageID: fixture.identity.installedPackageID, packageID: fixture.identity.packageID,
            generation: 2, entrypointID: fixture.identity.entrypointID)
        let stale = HanlinWidgetActionContext(identity: identity, engine: .expo, artifactSHA256: context.artifactSHA256, family: context.family)
        let before = try fixture.store.load()
        #expect(throws: HanlinWidgetActionError.self) { try HanlinWidgetActionExecutor.perform(.init(context: stale, actionID: "increment"), store: fixture.store) }
        #expect(throws: HanlinWidgetActionError.undeclaredAction) { try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "not-declared"), store: fixture.store) }
        #expect(try fixture.store.load() == before)
        try fixture.store.invalidateWidgetActions(installedPackageID: fixture.identity.installedPackageID)
        #expect(throws: HanlinWidgetActionError.inactiveInstance) { try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "increment"), store: fixture.store) }
        _ = try fixture.store.publishWidgetTemplates([], intentEntities: [], translationApps: [], installedPackageIDs: [])
        #expect(throws: HanlinWidgetActionError.inactiveInstance) { try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "increment"), store: fixture.store) }
    }

    @Test func concurrentSourceActionsReplayAndHostPublication() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }
        let context = try fixture.context()
        try await withThrowingTaskGroup(of: Void.self) { group in
            for index in 0..<12 {
                group.addTask { _ = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "increment", nonce: "tap-\(index)"), store: fixture.store) }
            }
            group.addTask { try fixture.republish() }
            try await group.waitForAll()
        }
        let snapshot = try #require(try fixture.store.load())
        let state = try #require(snapshot.widgetStates.first)
        #expect(state.revision == 12)
        #expect(state.values["count"] == .integer(19))
        let replay = try HanlinWidgetActionExecutor.perform(.init(context: context, actionID: "increment", nonce: "tap-0"), store: fixture.store)
        #expect(!replay.applied)
        #expect(replay.revision == 12)
        #expect(try fixture.values()["count"] == .integer(19))
    }

    @Test func actionAndPublicationPreserveUnrelatedCollections() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }
        let node = HanlinScriptUINode(kind: .text, properties: ["text": .string("Live")])
        let activity = HanlinScriptExtensions.HanlinScriptLiveActivityDescriptor(identity: fixture.identity, activityID: "live", title: "Live", state: .bool(true), root: node)
        let entity = HanlinScriptExtensions.HanlinScriptIntentEntityRecord(identity: fixture.identity, id: "intent", displayName: "Intent")
        let translation = HanlinScriptExtensions.HanlinScriptTranslationUISnapshot(identity: fixture.identity, appID: "translation", displayName: "Translation", entrypointID: "translation")
        try fixture.store.update { current in
            let current = try #require(current)
            return .init(schemaVersion: 2, generatedAt: .now, widgets: current.widgets, intentEntities: [entity], liveActivities: [activity], translationApps: [translation], widgetInstances: current.widgetInstances)
        }
        _ = try HanlinWidgetActionExecutor.perform(.init(context: fixture.context(), actionID: "increment"), store: fixture.store)
        _ = try fixture.store.publishWidgetTemplates([fixture.template], intentEntities: [entity], translationApps: [translation], installedPackageIDs: [fixture.identity.installedPackageID])
        let after = try #require(try fixture.store.load())
        #expect(after.liveActivities == [activity]); #expect(after.intentEntities == [entity]); #expect(after.translationApps == [translation])
        #expect(after.widgetStates.first?.values["count"] == .integer(8))
    }

    @Test func checkedArtifactsRejectTamperTraversalOtherGenerationAndSymlink() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root), id = try HanlinInstalledPackageID(validating: "installed.test")
        let artifact = try store.storeArtifact(data: Data("program".utf8), installedPackageID: id, generation: 1)
        #expect(try store.loadVerifiedArtifact(ref: artifact.ref, sha256: artifact.sha256, installedPackageID: id, generation: 1) == Data("program".utf8))
        for ref in ["../outside", "/tmp/outside", artifact.ref + "/../" + artifact.sha256] {
            #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.invalidArtifactReference) { try store.loadVerifiedArtifact(ref: ref, sha256: artifact.sha256, installedPackageID: id, generation: 1) }
        }
        #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.invalidArtifactReference) { try store.loadVerifiedArtifact(ref: artifact.ref, sha256: artifact.sha256, installedPackageID: id, generation: 2) }
        let url = root.appending(path: artifact.ref)
        try Data("tampered".utf8).write(to: url)
        #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.integrityMismatch) { try store.loadVerifiedArtifact(ref: artifact.ref, sha256: artifact.sha256, installedPackageID: id, generation: 1) }
        try FileManager.default.removeItem(at: url)
        let outside = root.appending(path: "outside")
        try Data("program".utf8).write(to: outside)
        try FileManager.default.createSymbolicLink(at: url, withDestinationURL: outside)
        #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.invalidArtifactReference) { try store.loadVerifiedArtifact(ref: artifact.ref, sha256: artifact.sha256, installedPackageID: id, generation: 1) }
    }

    @Test func actualHistoricalV1EncoderAndDowngradeReader() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let old = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionStore(root: root)
        let identity = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionIdentity(installedPackageID: try .init(validating: "installed.old"), packageID: try .init(validating: "package.old"), generation: 3, entrypointID: "widget")
        let legacy = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionSnapshot(generatedAt: Date(timeIntervalSince1970: 12), widgets: [.init(identity: identity, displayName: "Old widget", validUntil: Date(timeIntervalSince1970: 120), root: .init(kind: .text, properties: ["text": .string("Legacy bytes")]))])
        try old.save(legacy)
        let store = Store(root: root), migrated = try #require(try store.load())
        #expect(migrated.widgets.first?.engine == .legacy)
        #expect(migrated.widgets.first?.identity.variantID == "default")
        let v2 = Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 13), widgets: migrated.widgets)
        try store.save(v2)
        #expect(try old.load()?.widgets.first?.root == legacy.widgets.first?.root)
        try old.save(legacy)
        #expect(try store.loadWithRecovery().recovery == .legacyWriterDetected)
        #expect(try store.load()?.schemaVersion == 1)
        try store.save(v2)
        #expect(try store.load()?.schemaVersion == 2)
    }

    @Test func v1ShadowProjectsHistoricalFieldsWithoutLosingCurrentMetadata() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        let identity = Identity(installedPackageID: try .init(validating: "installed.presentation"),
            packageID: try .init(validating: "package.presentation"), generation: 1, entrypointID: "widget")
        let node = HanlinScriptUINode(kind: .text, properties: ["text": .string("Historical content")])
        let artifact = try store.storeArtifact(data: Data("prepared presentation".utf8),
            installedPackageID: identity.installedPackageID, generation: identity.generation)
        let presentation = HanlinNativePresentationDescriptor(engine: .expo,
            programRef: artifact.ref, programSHA256: artifact.sha256)
        let widget = Widget(identity: identity, displayName: "Legacy projection",
            actionIdentity: identity, validUntil: Date(timeIntervalSince1970: 120),
            root: node, deepLink: URL(string: "hanlin://widget"))
        let entity = HanlinScriptExtensions.HanlinScriptIntentEntityRecord(identity: identity,
            id: "action", displayName: "Action", subtitle: "Historical subtitle",
            appID: try .init(validating: "presentation.app"), hostActionHandler: "action.js",
            nativePresentation: presentation)
        let translation = HanlinScriptExtensions.HanlinScriptTranslationUISnapshot(identity: identity,
            appID: "translation", displayName: "Translation", summary: "Historical summary",
            iconSymbol: "character.bubble", accentHex: "#123456", isBeta: true,
            entrypointID: "translate", rootNode: node, nativePresentation: presentation)
        let activity = HanlinScriptExtensions.HanlinScriptLiveActivityDescriptor(identity: identity,
            activityID: "activity", title: "Historical activity", state: .integer(3), root: node,
            staleDate: Date(timeIntervalSince1970: 60))
        let current = Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 13),
            widgets: [widget], intentEntities: [entity], liveActivities: [activity],
            translationApps: [translation], nativePresentations: [
                .init(identity: identity, displayName: "Native panel", kind: .keyboard,
                    nativePresentation: presentation)
            ], widgetInstances: [.init(identity: identity, engine: .legacy, displayName: "Default")],
            widgetEntityMigrations: ["old": "current"], inactiveWidgetInstallations: ["another.installation"],
            widgetLastSuccessfulRenders: [.init(identity: identity, engine: .legacy, family: widget.family,
                programSHA256: artifact.sha256, settings: [:], renderRef: artifact.ref,
                renderSHA256: artifact.sha256, renderedAt: Date(timeIntervalSince1970: 12))])
        try store.save(current)
        let frozenStore = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionStore(root: root)
        let legacy = try #require(try frozenStore.load())
        #expect(legacy.widgets.first?.root == node)
        #expect(legacy.widgets.first?.deepLink == widget.deepLink)
        #expect(legacy.widgets.first?.actionIdentity?.entrypointID == identity.entrypointID)
        #expect(legacy.intentEntities.first?.subtitle == entity.subtitle)
        #expect(legacy.liveActivities.first?.state == activity.state)
        #expect(legacy.translationApps.first?.rootNode == node)
        #expect(legacy.translationApps.first?.isBeta == true)
        #expect(try store.load() == current)

        let shadowURL = root.appending(path: "snapshot-v1.json")
        var envelope = try #require(JSONSerialization.jsonObject(with: Data(contentsOf: shadowURL)) as? [String: Any])
        var shadow = try #require(envelope["snapshot"] as? [String: Any])
        #expect(Set(shadow.keys) == Set(["schemaVersion", "generatedAt", "widgets", "intentEntities", "liveActivities", "translationApps"]))
        shadow["generatedAt"] = 14_000
        envelope["snapshot"] = shadow
        try JSONSerialization.data(withJSONObject: envelope, options: [.sortedKeys, .withoutEscapingSlashes])
            .write(to: shadowURL)
        #expect(throws: HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionStoreError.integrityMismatch) {
            try frozenStore.load()
        }
    }

    @Test func interruptedShadowPublicationRestoresExactCommittedRevision() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        let before = Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 1))
        let next = Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 2))
        try store.save(before)
        let marker = try Data(contentsOf: root.appending(path: "commit.json"))
        let shadow = try Data(contentsOf: root.appending(path: "snapshot-v1.json"))
        try store.save(next)
        let candidate = try JSONSerialization.jsonObject(with: Data(contentsOf: root.appending(path: "commit.json")))
        let pending: [String: Any] = ["candidate": candidate, "previousShadowHash": sha(shadow)]
        try JSONSerialization.data(withJSONObject: pending).write(to: root.appending(path: "pending.json"))
        try marker.write(to: root.appending(path: "commit.json"))
        let recovered = try store.loadWithRecovery()
        #expect(recovered.recovery == .interruptedPublication)
        #expect(recovered.snapshot == before)
        #expect(try Data(contentsOf: root.appending(path: "snapshot-v1.json")) == shadow)
        try store.save(next)
        #expect(try store.load() == next)
    }

    @Test func corruptCommittedV2NeverFallsBackToGoodV1() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        try store.save(.init(schemaVersion: 2, generatedAt: .now))
        let marker = try #require(try JSONSerialization.jsonObject(with: Data(contentsOf: root.appending(path: "commit.json"))) as? [String: Any])
        let hash = try #require(marker["snapshotHash"] as? String)
        try Data("broken".utf8).write(to: root.appending(path: "Revisions/\(hash).json"))
        #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.integrityMismatch) { try store.load() }
    }

    @Test func unconfiguredAndWrongFamilyNeverSelectAnotherWidget() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }
        for (id, family) in [("", "systemMedium"), ("other", "systemMedium"), (fixture.entityID, "accessoryInline")] {
            guard case .failure = HanlinWidgetPreparation.prepare(store: fixture.store, entityID: id, family: family) else { Issue.record("Invalid selection rendered content"); continue }
        }
    }

    @Test func pass4PrivateVarAliasedRootCleanLoadArtifactStoreAndSnapshotPublishSucceeds() throws {
        let base = try temporary()
        defer { try? FileManager.default.removeItem(at: base) }

        let realContainer = base.appending(path: "RealContainer", directoryHint: .isDirectory)
        try FileManager.default.createDirectory(at: realContainer, withIntermediateDirectories: true)
        let aliasContainer = base.appending(path: "AliasContainer", directoryHint: .isDirectory)
        try FileManager.default.createSymbolicLink(at: aliasContainer, withDestinationURL: realContainer)

        let rawRealPath = realContainer.path(percentEncoded: false)
        let privatePrefixedPath = rawRealPath.hasPrefix("/private/") ? rawRealPath : "/private" + rawRealPath
        let privateRoot = URL(filePath: privatePrefixedPath, directoryHint: .isDirectory)
            .appending(path: "ScriptingExtensions", directoryHint: .isDirectory)
        let aliasRoot = aliasContainer.appending(path: "ScriptingExtensions", directoryHint: .isDirectory)

        let privateStore = Store(root: privateRoot)
        let aliasStore = Store(root: aliasRoot)

        // Gate D2 exact reproduction: root directory exists on disk under /private/var/...,
        // while commit.json / pending.json do not exist yet. Clean load() must return nil, never throw.
        try FileManager.default.createDirectory(at: privateRoot, withIntermediateDirectories: true)
        #expect(try privateStore.load() == nil)
        #expect(try aliasStore.load() == nil)

        let installedID = try HanlinInstalledPackageID(validating: "install-script-b567e179bfc7e661414077ad")
        let packageID = try HanlinPackageID(validating: "script-b567e179bfc7e661414077ad")
        let identity = Identity(installedPackageID: installedID, packageID: packageID, generation: 1, entrypointID: "widgets/widget.json")
        let payloadBytes = Data("{\"engine\":\"scriptwidget\",\"families\":[\"systemMedium\"]}".utf8)
        let stored = try privateStore.storeArtifact(data: payloadBytes, installedPackageID: installedID, generation: 1)
        let loadedBytes = try aliasStore.loadVerifiedArtifact(
            ref: stored.ref,
            sha256: stored.sha256,
            installedPackageID: installedID,
            generation: 1
        )
        #expect(loadedBytes == payloadBytes)

        let template = Widget(
            identity: identity,
            displayName: "ScriptWidget Actions",
            family: "systemMedium",
            actionIdentity: identity,
            validUntil: .distantFuture,
            engine: .scriptwidget,
            payload: .scriptwidget(.init(script: "", scriptRef: stored.ref, scriptSHA256: stored.sha256)),
            root: .init(kind: .text, properties: ["text": .string("placeholder")])
        )
        let published = try privateStore.publishWidgetTemplates(
            [template],
            intentEntities: [],
            translationApps: [],
            installedPackageIDs: [installedID]
        )
        #expect(published.widgetInstances.count == 1)
        let defaultInstance = try #require(published.widgetInstances.first)
        #expect(defaultInstance.displayName == "Default")
        #expect(defaultInstance.isDefault)

        let secondary = try aliasStore.createWidgetInstance(from: defaultInstance.entityID, displayName: "Secondary")
        #expect(secondary.displayName == "Secondary")
        #expect(!secondary.isDefault)
        let reloaded = try #require( try privateStore.load() )
        #expect(reloaded.widgetInstances.map(\.displayName) == ["Default", "Secondary"])
    }

    @Test func pass4SymlinkAndTraversalSecurityRejectsManagedTreeLinksWithDiagnostics() throws {
        let base = try temporary()
        defer { try? FileManager.default.removeItem(at: base) }

        let outside = base.appending(path: "outside.json")
        try Data("{}".utf8).write(to: outside)

        // 1. Root itself is a symlink -> must reject with symlinkDetected at index 0.
        let symlinkedRoot = base.appending(path: "SymlinkRoot")
        try FileManager.default.createSymbolicLink(at: symlinkedRoot, withDestinationURL: outside.deletingLastPathComponent())
        let rootLinkStore = Store(root: symlinkedRoot)
        #expect(throws: HanlinScriptExtensionStoreError.invalidArtifactReference) {
            _ = try rootLinkStore.load()
        }
        let rootDiag = try #require(HanlinScriptExtensionStore.latestDiagnostic)
        #expect(rootDiag.decisionPoint == .symlinkDetected)
        #expect(rootDiag.failingComponentIndex == 0)
        #expect(!rootDiag.redactedReportString.contains(base.path(percentEncoded: false)))

        // 2. Dangling symlink at commit.json inside valid root -> must reject via lstat.
        let managedRoot = base.appending(path: "ManagedStore", directoryHint: .isDirectory)
        try FileManager.default.createDirectory(at: managedRoot, withIntermediateDirectories: true)
        let danglingCommit = managedRoot.appending(path: "commit.json")
        try FileManager.default.createSymbolicLink(
            atPath: danglingCommit.path(percentEncoded: false),
            withDestinationPath: base.appending(path: "does-not-exist-\(UUID().uuidString)").path(percentEncoded: false)
        )
        let managedStore = Store(root: managedRoot)
        #expect(throws: HanlinScriptExtensionStoreError.invalidArtifactReference) {
            _ = try managedStore.load()
        }
        let danglingDiag = try #require(HanlinScriptExtensionStore.latestDiagnostic)
        #expect(danglingDiag.decisionPoint == .symlinkDetected)
        #expect(danglingDiag.failingComponentName == "commit.json")
        try FileManager.default.removeItem(at: danglingCommit)

        // 3. Traversal in artifact reference -> must reject with lexicalBoundary.
        #expect(throws: HanlinScriptExtensionStoreError.invalidArtifactReference) {
            _ = try managedStore.loadArtifact(ref: "Packages/../outside.json")
        }
        let traversalDiag = try #require(HanlinScriptExtensionStore.latestDiagnostic)
        #expect(traversalDiag.decisionPoint == .lexicalBoundary)
    }

    @Test func pass4TwoStorePublicationFailureRecoveryAndEntrypointRouting() async throws {
        let fixture = try await InstalledFixture("Hanlin-ScriptWidget-Actions.scripting", installationID: "install-script-actions", packageID: "script-actions")
        defer { fixture.remove() }

        let snapshots = try await fixture.installed.snapshots()
        let actionsSnapshot = try #require(snapshots.first)
        #expect(!actionsSnapshot.hasLaunchableApp)
        #expect(actionsSnapshot.hasWidgetEntrypoint)
        #expect(actionsSnapshot.isWidgetOnly)

        let counterFixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo", installationID: "install-expo-counter", packageID: "expo-counter")
        defer { counterFixture.remove() }
        let counterSnapshot = try #require(try await counterFixture.installed.snapshots().first)
        #expect(!counterSnapshot.hasLaunchableApp)
        #expect(counterSnapshot.hasWidgetEntrypoint)
        #expect(counterSnapshot.isWidgetOnly)

        let counterWidgetEntrypoint = try #require(counterSnapshot.entrypoints.first)
        let appEntrypoint = HanlinPackageEntrypointDescriptor(
            id: "app",
            kind: .app,
            sourcePath: "app/index.tsx",
            supportedContexts: counterWidgetEntrypoint.supportedContexts,
            runtimePolicyID: counterWidgetEntrypoint.runtimePolicyID,
            runtimeProfile: .hanlinExpo,
            compatibility: counterWidgetEntrypoint.compatibility
        )

        let combinedSnapshot = HanlinStoredPackageSnapshot(
            record: counterSnapshot.record,
            entrypoints: [appEntrypoint, counterWidgetEntrypoint],
            enabled: true,
            availableGenerations: counterSnapshot.availableGenerations,
            grantedCapabilities: counterSnapshot.grantedCapabilities,
            manifest: counterSnapshot.manifest
        )
        #expect(combinedSnapshot.hasLaunchableApp)
        #expect(combinedSnapshot.hasWidgetEntrypoint)
        #expect(!combinedSnapshot.isWidgetOnly)

        let appOnlySnapshot = HanlinStoredPackageSnapshot(
            record: counterSnapshot.record,
            entrypoints: [appEntrypoint],
            enabled: true,
            availableGenerations: counterSnapshot.availableGenerations
        )
        #expect(appOnlySnapshot.hasLaunchableApp)
        #expect(!appOnlySnapshot.hasWidgetEntrypoint)
        #expect(!appOnlySnapshot.isWidgetOnly)

        // Inject a transient storage fault (dangling symlink at pending.json) before republishing,
        // verify publication fails with a structured diagnostic while installed package store stays at gen 1,
        // then remove the fault and verify idempotent republish succeeds without re-importing.
        let pendingLink = fixture.extensionRoot.appending(path: "pending.json")
        try FileManager.default.createSymbolicLink(
            atPath: pendingLink.path(percentEncoded: false),
            withDestinationPath: fixture.root.appending(path: "missing-target").path(percentEncoded: false)
        )
        #expect(throws: HanlinScriptExtensionStoreError.invalidArtifactReference) {
            try fixture.republish()
        }
        let diag = try #require(fixture.store.lastDiagnostic)
        #expect(diag.decisionPoint == .symlinkDetected)
        #expect(try await fixture.installed.snapshots().first?.record.activeGeneration == 1)

        try FileManager.default.removeItem(at: pendingLink)
        try fixture.republish()
        let recovered = try #require(try fixture.store.load())
        #expect(recovered.widgetInstances.contains { $0.identity.installedPackageID == fixture.identity.installedPackageID && $0.isDefault })
        guard case .scriptwidget = HanlinWidgetPreparation.prepare(store: fixture.store, entityID: fixture.entityID, family: "systemMedium") else {
            Issue.record("Expected ScriptWidget preparation to succeed after idempotent republish")
            return
        }
    }

    @Test func testNativeEntitySuggestionsReadPublishedDefaultAndVariants() async throws {
        let expoFixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo", installationID: "installed.expo", packageID: "package.expo")
        defer { expoFixture.remove() }
        let scriptFixture = try await InstalledFixture("Hanlin-ScriptWidget-Actions.scripting", installationID: "installed.script", packageID: "package.script")
        defer { scriptFixture.remove() }
        let legacyFixture = try await InstalledFixture("Hanlin-Widget-Legacy-Regression.scripting", installationID: "installed.legacy", packageID: "package.legacy")
        defer { legacyFixture.remove() }

        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        var templates: [Widget] = []
        for fixture in [expoFixture, scriptFixture, legacyFixture] {
            let payload: HanlinWidgetPayload
            switch fixture.template.engine {
            case .expo:
                let (program, _) = try fixture.store.loadProgram(for: fixture.template)
                let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: fixture.identity.installedPackageID, generation: fixture.identity.generation)
                payload = .expo(.init(layout: "", layoutRef: artifact.ref, layoutSHA256: artifact.sha256))
            case .scriptwidget:
                let (program, _) = try fixture.store.loadProgram(for: fixture.template)
                let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: fixture.identity.installedPackageID, generation: fixture.identity.generation)
                payload = .scriptwidget(.init(script: "", scriptRef: artifact.ref, scriptSHA256: artifact.sha256))
            case .legacy:
                payload = try #require(fixture.template.payload)
            }
            templates.append(.init(identity: fixture.identity, displayName: fixture.template.displayName, validUntil: .distantFuture, engine: fixture.template.engine, payload: payload, root: fixture.template.root))
        }

        let installedIDs: Set<HanlinInstalledPackageID> = [expoFixture.identity.installedPackageID, scriptFixture.identity.installedPackageID, legacyFixture.identity.installedPackageID]
        try store.publishWidgetTemplates(templates, intentEntities: [], translationApps: [], installedPackageIDs: installedIDs)

        // Create variants A1 and A2 for expo
        let initialSnapshot = try #require(try store.load())
        let expoDefault = try #require(initialSnapshot.widgetInstances.first { $0.identity == expoFixture.identity })
        let expoA1 = try store.createWidgetInstance(from: expoDefault.entityID, displayName: "A1")
        let expoA2 = try store.createWidgetInstance(from: expoDefault.entityID, displayName: "A2")

        let snapshot = try #require(try store.load())
        let selectables = snapshot.selectableWidgetEntities()

        // Verify all 3 engines present: expo, scriptwidget, legacy
        let engines = Set(selectables.map(\.engine))
        #expect(engines.contains(.expo))
        #expect(engines.contains(.scriptwidget))
        #expect(engines.contains(.legacy))

        // Verify Default, A1, A2 entities for expo
        let expoEntities = selectables.filter { $0.identity.installedPackageID == expoFixture.identity.installedPackageID }
        #expect(expoEntities.count == 3)
        #expect(expoEntities.contains { $0.isDefault && $0.variantName == "Default" })
        #expect(expoEntities.contains { !$0.isDefault && $0.variantName == "A1" && $0.id == expoA1.entityID })
        #expect(expoEntities.contains { !$0.isDefault && $0.variantName == "A2" && $0.id == expoA2.entityID })

        // Verify label format "package name · engine · variant"
        for entity in selectables {
            #expect(entity.displayName.contains(entity.packageName))
            #expect(entity.displayName.contains(entity.engine.rawValue))
            #expect(entity.displayName.contains(entity.variantName))
        }

        // Verify deterministic sorting: Default precedes custom variants for same package
        if let defaultIndex = expoEntities.firstIndex(where: \.isDefault),
           let a1Index = expoEntities.firstIndex(where: { $0.variantName == "A1" }) {
            #expect(defaultIndex < a1Index)
        }
    }

    @Test func testNativeEntityLookupResolvesOnlyExactIDs() async throws {
        let fixture = try await InstalledFixture("Hanlin-Expo-Widget-Counter.hanlinExpo")
        defer { fixture.remove() }

        let snapshot = try #require(try fixture.store.load())
        let selectables = snapshot.selectableWidgetEntities()
        #expect(!selectables.isEmpty)

        for entity in selectables {
            let matched = selectables.filter { $0.id == entity.id }
            #expect(matched.count == 1)
            #expect(matched.first?.identity == entity.identity)
        }

        // Unknown ID must not resolve
        let unknownID = "widget-v2:dW5rbm93bg==.dW5rbm93bg==.MQ==.d2lkZ2V0.ZXhwbw==.ZGVmYXVsdA=="
        #expect(selectables.filter { $0.id == unknownID }.isEmpty)

        // Inactive installation must be excluded
        try fixture.store.invalidateWidgetActions(installedPackageID: fixture.identity.installedPackageID)
        let disabledSnapshot = try #require(try fixture.store.load())
        #expect(disabledSnapshot.selectableWidgetEntities().isEmpty)
    }

    @Test func testRegistryAndTemplateJoinHandlesFamilyAndOrphans() async throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        let id = try HanlinInstalledPackageID(validating: "installed.single-family")
        let pkgID = try HanlinPackageID(validating: "package.single-family")
        let identity = Identity(installedPackageID: id, packageID: pkgID, generation: 1, entrypointID: "widget")

        let program = HanlinWidgetProgram(engine: .scriptwidget, sourceSHA256: String(repeating: "a", count: 64),
            compilerSHA256: String(repeating: "b", count: 64), javaScript: "async function $main() { $render(ScriptWidget.createElement('text', {}, 'Medium only')); }",
            actions: [], families: ["systemMedium"])
        let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: id, generation: 1)

        // Template only for systemMedium
        let template = Widget(identity: identity, displayName: "Single Family", family: "systemMedium",
            validUntil: .distantFuture, engine: .scriptwidget,
            payload: .scriptwidget(.init(script: "", scriptRef: artifact.ref, scriptSHA256: artifact.sha256)),
            root: .init(kind: .text))

        try store.publishWidgetTemplates([template], intentEntities: [], translationApps: [], installedPackageIDs: [id])
        let snapshot = try #require(try store.load())
        let selectables = snapshot.selectableWidgetEntities()
        #expect(selectables.count == 1)
        let entity = try #require(selectables.first)
        #expect(entity.supportedFamilies == ["systemMedium"])

        // Preparation for systemMedium succeeds
        let prepMedium = HanlinWidgetPreparation.prepare(store: store, entityID: entity.id, family: "systemMedium")
        guard case .scriptwidget = prepMedium else {
            Issue.record("Expected scriptwidget for systemMedium")
            return
        }

        // Preparation for systemSmall fails with explicit family mismatch message
        let prepSmall = HanlinWidgetPreparation.prepare(store: store, entityID: entity.id, family: "systemSmall")
        guard case let .failure(reason) = prepSmall else {
            Issue.record("Expected failure for systemSmall")
            return
        }
        #expect(reason.contains("systemSmall"))

        // An orphan instance (no templates in snapshot.widgets) must be excluded from selectables
        let orphanInstance = HanlinWidgetInstance(
            identity: Identity(installedPackageID: try .init(validating: "installed.orphan"), packageID: try .init(validating: "package.orphan"), generation: 1, entrypointID: "widget"),
            engine: .scriptwidget,
            displayName: "Orphan"
        )
        let mutatedSnapshot = snapshot.replacing(instances: snapshot.widgetInstances + [orphanInstance])
        let selectablesWithOrphan = mutatedSnapshot.selectableWidgetEntities()
        #expect(!selectablesWithOrphan.contains { $0.id == orphanInstance.entityID })
    }

    @Test func testNativePublisherRepairsMissingDefaultWithoutLosingA1A2() async throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        let id = try HanlinInstalledPackageID(validating: "installed.repair")
        let pkgID = try HanlinPackageID(validating: "package.repair")
        let identity = Identity(installedPackageID: id, packageID: pkgID, generation: 1, entrypointID: "widget")

        let program = HanlinWidgetProgram(engine: .scriptwidget, sourceSHA256: String(repeating: "a", count: 64),
            compilerSHA256: String(repeating: "b", count: 64), javaScript: "async function $main() { $render(ScriptWidget.createElement('text', {}, 'Repair')); }",
            actions: [], families: ["systemMedium"])
        let artifact = try store.storeArtifact(data: JSONEncoder().encode(program), installedPackageID: id, generation: 1)

        let template = Widget(identity: identity, displayName: "Repair Test", family: "systemMedium",
            validUntil: .distantFuture, engine: .scriptwidget,
            payload: .scriptwidget(.init(script: "", scriptRef: artifact.ref, scriptSHA256: artifact.sha256)),
            root: .init(kind: .text))

        // Initial publication produces Default
        try store.publishWidgetTemplates([template], intentEntities: [], translationApps: [], installedPackageIDs: [id])
        let defaultInstance = try #require(try store.load()?.widgetInstances.first { $0.isDefault })
        let a1 = try store.createWidgetInstance(from: defaultInstance.entityID, displayName: "A1")

        // Simulate corrupted state: Default was dropped from widgetInstances, only A1 remains
        try store.update { current in
            let current = try #require(current)
            return current.replacing(instances: [a1])
        }
        let corrupted = try #require(try store.load())
        #expect(corrupted.widgetInstances.count == 1)
        #expect(!corrupted.widgetInstances.first!.isDefault)

        // Republish must restore Default idempotently and preserve A1
        try store.publishWidgetTemplates([template], intentEntities: [], translationApps: [], installedPackageIDs: [id])
        let repaired = try #require(try store.load())
        #expect(repaired.widgetInstances.count == 2)
        #expect(repaired.widgetInstances.contains { $0.isDefault && $0.displayName == "Default" })
        #expect(repaired.widgetInstances.contains { !$0.isDefault && $0.displayName == "A1" && $0.identity.variantID == a1.identity.variantID })

        // Second republish must not duplicate Default or A1
        try store.publishWidgetTemplates([template], intentEntities: [], translationApps: [], installedPackageIDs: [id])
        let reRepaired = try #require(try store.load())
        #expect(reRepaired.widgetInstances.count == 2)
        let defaultCount = reRepaired.widgetInstances.filter(\.isDefault).count
        #expect(defaultCount == 1)
    }

    @Test func testDurableQueryDiagnosticCrossProcess() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        #expect(store.latestDurableQueryDiagnostic == nil)

        let diag = HanlinWidgetStorageDiagnostic(
            phase: .widgetExtensionEntityQuery,
            decisionPoint: .instancePublication,
            relativePath: "ScriptingExtensions",
            errorDomain: "HanlinWidgetStorage",
            errorCode: 42,
            summary: "Test query failure for durable cross-process diagnostic verification."
        )
        store.recordDurableQueryDiagnostic(diag)

        let loaded = try #require(store.latestDurableQueryDiagnostic)
        #expect(loaded.phase == .widgetExtensionEntityQuery)
        #expect(loaded.errorCode == 42)
        #expect(loaded.summary.contains("Test query failure"))
    }

    @Test func testPass7StorageConsistencyReportAndDurableDiagnostic() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        // 1. Fresh store report
        let freshReport = store.generateConsistencyReport()
        #expect(!freshReport.commitPresent)
        #expect(!freshReport.revisionFilePresent)
        #expect(freshReport.failingStage == nil)

        // 2. Save valid v2 snapshot
        let snapshot = Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 100))
        try store.save(snapshot)

        let validReport = store.generateConsistencyReport()
        #expect(validReport.commitPresent)
        #expect(validReport.commitVersion == 1)
        #expect(validReport.revisionFilePresent)
        #expect(validReport.shadowFilePresent)
        #expect(validReport.failingStage == nil)

        // 3. Tamper Revisions/<sha>.json to verify exact checkedRevision throw and diagnostic
        let marker = try #require(try JSONSerialization.jsonObject(with: Data(contentsOf: root.appending(path: "commit.json"))) as? [String: Any])
        let hash = try #require(marker["snapshotHash"] as? String)
        let revisionURL = root.appending(path: "Revisions/\(hash).json")
        try Data("corrupted-revision-payload".utf8).write(to: revisionURL)

        #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.integrityMismatch) {
            try store.load()
        }

        let tamperedDiag = try #require(store.latestDurableQueryDiagnostic)
        #expect(tamperedDiag.decisionPoint == .revisionIntegrityMismatch)
        #expect(tamperedDiag.errorCode == 4)
        #expect(tamperedDiag.summary.contains("checkedRevision"))
        #expect(tamperedDiag.summary.contains(hash.prefix(12)))

        let tamperedReport = store.generateConsistencyReport()
        #expect(tamperedReport.failingStage == "checkedRevision")
    }

    @Test(arguments: [true, false])
    func consistencyReportCannotHideMissingRevisionOrMalformedCommit(missingRevision: Bool) throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)
        try store.save(Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 100)))
        let commitURL = root.appending(path: "commit.json")
        let marker = try #require(try JSONSerialization.jsonObject(with: Data(contentsOf: commitURL)) as? [String: Any])
        if missingRevision {
            let hash = try #require(marker["snapshotHash"] as? String)
            try FileManager.default.removeItem(at: root.appending(path: "Revisions/\(hash).json"))
        } else {
            try Data("broken commit".utf8).write(to: commitURL)
        }
        let preservedCommit = try Data(contentsOf: commitURL)
        let report = store.generateConsistencyReport()
        #expect(report.commitPresent)
        #expect(report.failingStage == (missingRevision ? "checkedRevision" : "commitDecode"))
        #expect(report.summary.contains("validation failed"))
        #expect(try Data(contentsOf: commitURL) == preservedCommit, "Diagnostics must not reset existing data")
    }

    @Test(arguments: [200.0, 1730826191.123456])
    func testPass7HistoricalV1StoreEnvelopeCompatibility(timestamp: Double) throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let old = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionStore(root: root)
        let identity = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionIdentity(
            installedPackageID: try .init(validating: "installed.legacy"),
            packageID: try .init(validating: "package.legacy"),
            generation: 1,
            entrypointID: "widget"
        )
        let legacy = HanlinLegacyWidgetStoreFixture.HanlinScriptExtensionSnapshot(
            generatedAt: Date(timeIntervalSince1970: timestamp),
            widgets: [.init(
                identity: identity,
                displayName: "Legacy Widget",
                validUntil: Date(timeIntervalSince1970: timestamp + 300),
                root: .init(kind: .text, properties: [
                    "text": .string("Legacy Data"),
                    "literal": .string("escaped \"snapshot\": { braces } and slash \\ אבג"),
                    "offset": .number(-0.0),
                    "ratio": .number(1e-7)
                ])
            )]
        )
        try old.save(legacy)
        let snapshotURL = root.appending(path: "snapshot-v1.json")
        let originalBytes = try Data(contentsOf: snapshotURL)

        // Current store must accept genuine historical v1 envelope without integrity mismatch
        let store = Store(root: root)
        let loaded = try #require(try store.load())
        #expect(loaded.schemaVersion == 1)
        #expect(loaded.widgets.first?.displayName == "Legacy Widget")
        #expect(loaded.widgets.first?.root.properties["ratio"] == .number(1e-7))
        #expect(try Data(contentsOf: snapshotURL) == originalBytes)
        let withDecoy = Data((#"{"decoy":{"snapshot":{"text":"}"}},"#
            + String(decoding: originalBytes.dropFirst(), as: UTF8.self)).utf8)
        try withDecoy.write(to: snapshotURL)
        #expect(try store.load() == loaded)
        #expect(try Data(contentsOf: snapshotURL) == withDecoy)
        let changedBytes = Data(String(decoding: originalBytes, as: UTF8.self)
            .replacingOccurrences(of: "Legacy Data", with: "Changed Data").utf8)
        #expect(changedBytes != originalBytes)
        try changedBytes.write(to: snapshotURL)
        #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.integrityMismatch) {
            try store.load()
        }
        #expect(try Data(contentsOf: snapshotURL) == changedBytes)
        if timestamp != 200 {
            let duplicateKey = Data((#"{"snap\u0073hot":{},"#
                + String(decoding: originalBytes.dropFirst(), as: UTF8.self)).utf8)
            try duplicateKey.write(to: snapshotURL)
            #expect(throws: HanlinScriptExtensions.HanlinScriptExtensionStoreError.integrityMismatch) {
                try store.load()
            }
            #expect(try Data(contentsOf: snapshotURL) == duplicateKey)
        }
    }

    @Test(arguments: [Data(), Data("corrupt candidate revision".utf8)])
    func testPass7InterruptedRevisionWriteOverwrittenAndClean(corruptedBytes: Data) throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        let snapshot = Snapshot(schemaVersion: 2, generatedAt: Date(timeIntervalSince1970: 300))
        // Obtain authentic candidate bytes from an independent store. The old test
        // created only a directory, so it never exercised the corrupted-file branch.
        let referenceRoot = try temporary()
        defer { try? FileManager.default.removeItem(at: referenceRoot) }
        try Store(root: referenceRoot).save(snapshot)
        let marker = try #require(try JSONSerialization.jsonObject(
            with: Data(contentsOf: referenceRoot.appending(path: "commit.json"))) as? [String: Any])
        let hash = try #require(marker["snapshotHash"] as? String)
        let expectedBytes = try Data(contentsOf: referenceRoot.appending(path: "Revisions/\(hash).json"))

        let revisionsDir = root.appending(path: "Revisions")
        try FileManager.default.createDirectory(at: revisionsDir, withIntermediateDirectories: true)
        let candidateURL = revisionsDir.appending(path: "\(hash).json")
        try corruptedBytes.write(to: candidateURL)
        #expect(try Data(contentsOf: candidateURL) == corruptedBytes)

        try store.save(snapshot)

        #expect(try Data(contentsOf: candidateURL) == expectedBytes)
        let loaded = try #require(try store.load())
        #expect(loaded.schemaVersion == 2)
        #expect(loaded.generatedAt == Date(timeIntervalSince1970: 300))
    }

    @Test func testPass7SelectableWidgetEntitiesCrossProcess() throws {
        let root = try temporary()
        defer { try? FileManager.default.removeItem(at: root) }
        let store = Store(root: root)

        let id = try HanlinInstalledPackageID(validating: "installed.test")
        let packageID = try HanlinPackageID(validating: "package.test")
        let identity = Identity(installedPackageID: id, packageID: packageID, generation: 1, entrypointID: "widget")
        let template = Widget(
            identity: identity,
            displayName: "Test Widget",
            family: "systemSmall",
            validUntil: .distantFuture,
            engine: .expo,
            payload: .expo(.init(layout: "")),
            root: .init(kind: .text)
        )

        try store.publishWidgetTemplates([template], intentEntities: [], translationApps: [], installedPackageIDs: [id])

        // Add an independent variant using the authentic store API
        let defaultInstance = try #require(try store.load()?.widgetInstances.first)
        _ = try store.createWidgetInstance(from: defaultInstance.entityID, displayName: "A1 Variant")

        // Simulating extension process querying the store
        let extensionStore = Store(root: root)
        let snapshot = try #require(try extensionStore.load())
        let selectable = snapshot.selectableWidgetEntities()

        #expect(selectable.count == 2)
        #expect(selectable.contains(where: { $0.isDefault }))
        #expect(selectable.contains(where: { $0.variantName == "A1 Variant" && !$0.isDefault }))
    }
}

private let inventory = HanlinCompatibilityInventory(baselineID: "widget-tests", baselineDigest: String(repeating: "a", count: 64), symbols: [])
private func temporary() throws -> URL {
    let root = FileManager.default.temporaryDirectory.appending(path: "hanlin-widget-pass3-\(UUID().uuidString)")
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    return root
}
private func fixtureURL(_ name: String) -> URL {
    URL(filePath: #filePath).deletingLastPathComponent().appending(path: "../../../../Fixtures/Widgets/\(name)").standardizedFileURL
}
private func sha(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
#if os(macOS)
@MainActor private func installedNativeRaster(_ presentation: HanlinPreparedWidget) throws -> Data? {
    let view: AnyView
    switch presentation {
    case let .legacy(widget): view = AnyView(HanlinExtensionNodeView(node: widget.root))
    case let .scriptwidget(node, context): view = AnyView(HanlinScriptWidgetDynamicView(node: node, context: context))
    case .expo: return nil // Exact Expo native product is covered by the iOS renderer target.
    case .failure: Issue.record("Installed fixture failed native preparation"); return nil
    }
    let renderer = ImageRenderer(content: view.frame(width: 360, height: 320).environment(\.colorScheme, .light))
    renderer.scale = 1
    let image = try #require(renderer.cgImage)
    #expect(image.width == 360 && image.height == 320)
    return try #require(NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:]))
}
#endif
private func recordEvidence(name: String, values: [String: Any]) throws {
    guard let directory = ProcessInfo.processInfo.environment["HANLIN_WIDGET_EVIDENCE_DIR"] else { return }
    let root = URL(filePath: directory)
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    try JSONSerialization.data(withJSONObject: values, options: [.prettyPrinted, .sortedKeys])
        .write(to: root.appending(path: "\(name).json"), options: .atomic)
}
private func find(_ node: HanlinScriptWidgetPreparedNode, tag: String) -> HanlinScriptWidgetPreparedNode? {
    if node.tag == tag { return node }
    for child in node.children { if case let .element(child) = child, let match = find(child, tag: tag) { return match } }
    return nil
}
private struct ForbiddenScriptingCompiler: HanlinTrustedCompilerClient {
    func compile(_ project: HanlinVirtualTypeScriptProject) async throws -> HanlinTrustedCompilerResult { throw HanlinWidgetProgramError.unsupportedImport }
}
private struct InstalledFixture: Sendable {
    let root: URL
    let extensionRoot: URL
    let store: Store
    let installed: HanlinAtomicScriptStore
    let identity: Identity
    let template: Widget
    var entityID: String { HanlinWidgetInstance(identity: identity, engine: template.engine, displayName: "Default").entityID }
    init(_ name: String, installationID: String = "installed.widget", packageID packageName: String = "package.widget") async throws {
        root = try temporary()
        extensionRoot = root.appending(path: "Extensions")
        store = Store(root: extensionRoot)
        installed = try HanlinAtomicScriptStore(root: root.appending(path: "Installed"))
        let staged = try HanlinPackageCenter().stageAndInspect(sourceURL: fixtureURL(name), stagingParent: root)
        let preview = try HanlinScriptAnalyzer(inventory: inventory).analyze(staged)
        #expect(preview.canInstall, "\(preview.findings)")
        let programs = try HanlinWidgetPackagePreparation.programs(packageRoot: staged.packageRoot, preview: preview)
        let compiled = HanlinScriptingBundle(manifest: .init(compilerVersion: "Widget-ABI-1", compilerIntegrity: preview.source.contentSHA256, compilerOptionsHash: String(repeating: "b", count: 64), baselineID: inventory.baselineID, baselineDigest: inventory.baselineDigest, hanlinABIVersion: "1", packageContentDigest: preview.source.contentSHA256, cacheFingerprint: preview.source.contentSHA256, files: []), modules: [], diagnostics: [])
        let bundler = HanlinScriptingBundler(baseline: inventory, abiVersion: "1", scriptingDeclarations: [], compiler: ForbiddenScriptingCompiler())
        let artifactRoot = root.appending(path: "Artifact")
        let manifest = try bundler.writeInstallArtifact(compiled, packageRoot: staged.packageRoot, to: artifactRoot, preparedWidgetPrograms: programs)
        let entries = HanlinWidgetPackagePreparation.installedEntrypoints(preview: preview, artifactDigest: manifest.cacheFingerprint)
        let id = try HanlinInstalledPackageID(validating: installationID)
        let packageID = try HanlinPackageID(validating: packageName)
        let plan = HanlinInstallPlan(installedPackageID: id, packageID: packageID, version: try .init(validating: "1.0.0"), sourceDigest: preview.source.contentSHA256, entrypoints: entries, requestedCapabilities: preview.requestedCapabilities, manifest: staged.manifest)
        let record = try await installed.install(plan: plan, artifactDirectory: artifactRoot, artifactManifest: manifest)
        let entry = try #require(entries.first)
        identity = .init(installedPackageID: id, packageID: packageID, generation: record.activeGeneration, entrypointID: entry.id)
        let engine = try #require(entry.widgetEngine)
        if engine == .legacy {
            let node = try JSONDecoder().decode(HanlinScriptUINode.self, from: Data(contentsOf: artifactRoot.appending(path: entry.sourcePath)))
            template = .init(identity: identity, displayName: staged.manifest.name, validUntil: .distantFuture, engine: engine, payload: .legacy(node), root: node)
        } else {
            let bytes = try #require(programs[entry.sourcePath])
            let artifact = try store.storeArtifact(data: bytes, installedPackageID: id, generation: record.activeGeneration)
            let payload: HanlinScriptExtensions.HanlinWidgetPayload = engine == .expo ? .expo(.init(layout: "", layoutRef: artifact.ref, layoutSHA256: artifact.sha256)) : .scriptwidget(.init(script: "", scriptRef: artifact.ref, scriptSHA256: artifact.sha256))
            template = .init(identity: identity, displayName: staged.manifest.name, validUntil: .distantFuture, engine: engine, payload: payload, root: .init(kind: .text))
        }
        try republish()
    }
    func republish() throws { try store.publishWidgetTemplates([template], intentEntities: [], translationApps: [], installedPackageIDs: [identity.installedPackageID]) }
    func remove() { try? FileManager.default.removeItem(at: root) }
    func values() throws -> [String: HanlinValue] { try store.load()?.widgetStates.first?.values ?? [:] }
    func context(entityID: String? = nil) throws -> HanlinWidgetActionContext {
        switch HanlinWidgetPreparation.prepare(store: store, entityID: entityID ?? self.entityID, family: "systemMedium") {
        case let .expo(_, context), let .scriptwidget(_, context): return context
        case let .failure(reason): throw HanlinScriptWidgetError(reason)
        case .legacy: throw HanlinWidgetProgramError.invalidProgram
        }
    }
}
