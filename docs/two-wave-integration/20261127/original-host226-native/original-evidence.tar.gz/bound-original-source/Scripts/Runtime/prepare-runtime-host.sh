#!/usr/bin/env bash
set -euo pipefail

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly REPOSITORY_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
readonly HOST_SOURCE="${REPOSITORY_ROOT}/AI_HLY/Downstream/RuntimeCore/Node/Host"
readonly WORK_ROOT="${RUNNER_TEMP:-${TMPDIR:-/tmp}}/hanlin-runtime-host"
readonly OUTPUT_ROOT="${REPOSITORY_ROOT}/build/runtime-host"
readonly GRAMMAR_TOOL_ROOT="${WORK_ROOT}-grammar-tools"

# MiniApp authoring consumes the same original npm packages as the native host.
# This is included with the tool implementation, not installed during an agent run.
# Refresh documentation from the prepared native inputs before any SDK/Host reuse
# fingerprint; a cache hit must not preserve provenance from an earlier graph.
if [[ -f "${HOST_SOURCE}/miniapp-authoring.mjs" ]]; then
  for engine in expo nativescript; do
    node "${REPOSITORY_ROOT}/Scripts/MiniApps/install-tooling.mjs" --repository="${REPOSITORY_ROOT}" --engine="$engine" --ignore-scripts
  done
  node "${REPOSITORY_ROOT}/Scripts/Expo/prepare-types.mjs"
  node "${REPOSITORY_ROOT}/Scripts/MiniApps/generate-scriptwidget-types.mjs" --check
  node "${REPOSITORY_ROOT}/Scripts/Audit/audit-miniapp-sdk.mjs" --write
  node "${REPOSITORY_ROOT}/Scripts/Audit/audit-miniapp-sdk.mjs" --check
  python3 "${REPOSITORY_ROOT}/Scripts/Audit/audit_miniapp_reachability.py"
  python3 "${REPOSITORY_ROOT}/Scripts/Audit/audit_miniapp_reachability.py" --check
fi

readonly NODE_FINGERPRINT="$(node -p 'JSON.stringify({ versions: process.versions, platform: process.platform, arch: process.arch })')"
if python3 "${SCRIPT_DIR}/runtime_host_archive.py" reuse "${OUTPUT_ROOT}" --source-root "${HOST_SOURCE}" --node-fingerprint "${NODE_FINGERPRINT}"; then
  echo "Reusing verified current RuntimeHostResources.zip and its completed Host/JITless checks."
  exit 0
fi

rm -rf "${WORK_ROOT}" "${OUTPUT_ROOT}" "${GRAMMAR_TOOL_ROOT}"
mkdir -p "${WORK_ROOT}" "${OUTPUT_ROOT}" "${GRAMMAR_TOOL_ROOT}"
cp "${SCRIPT_DIR}/HostGrammarTools/package.json" "${SCRIPT_DIR}/HostGrammarTools/package-lock.json" "${GRAMMAR_TOOL_ROOT}/"
(cd "${GRAMMAR_TOOL_ROOT}" && npm ci --ignore-scripts --workspaces=false --no-audit --no-fund)
export HANLIN_HOST_GRAMMAR_COMPILER_ROOT="${GRAMMAR_TOOL_ROOT}"
export HANLIN_MINIAPP_REPOSITORY_ROOT="${REPOSITORY_ROOT}"
export HANLIN_RUNTIME_TEST_FIXTURES="${REPOSITORY_ROOT}/AI_HLYTests/Fixtures/RuntimeNetworkFixtures.bundle"
cp \
  "${HOST_SOURCE}"/*.mjs \
  "${HOST_SOURCE}/package.json" \
  "${HOST_SOURCE}/package-lock.json" \
  "${HOST_SOURCE}/runtime-dependency-overrides.json" \
  "${HOST_SOURCE}/host-dependency-patches.json" \
  "${HOST_SOURCE}/UNICODE-LICENSE.txt" \
  "${HOST_SOURCE}/PEGJS-LICENSE.txt" \
  "${WORK_ROOT}/"
cp -R "${HOST_SOURCE}/Tests" "${WORK_ROOT}/Tests"

if [[ -f "${HOST_SOURCE}/miniapp-authoring.mjs" ]]; then
  node "${REPOSITORY_ROOT}/Scripts/MiniApps/stage-sdk.mjs" --repository="${REPOSITORY_ROOT}" --output="${WORK_ROOT}/MiniAppSDK"
fi

readonly SOURCE_INPUTS_HASH="$(python3 "${SCRIPT_DIR}/runtime_host_archive.py" fingerprint --source-root "${HOST_SOURCE}" --node-fingerprint "${NODE_FINGERPRINT}")"

(
  cd "${WORK_ROOT}"
  npm ci --omit=dev --ignore-scripts --workspaces=false --no-audit --no-fund
  node apply-host-dependency-patches.mjs
  node "${SCRIPT_DIR}/generate-yarn-unicode-patch.mjs" --root "${WORK_ROOT}"
  node "${SCRIPT_DIR}/generate-yarn-multiline-patch.mjs" --root "${WORK_ROOT}" --compiler-root "${GRAMMAR_TOOL_ROOT}"
  npm test
  rm -rf Tests
  find . -type f -print | LC_ALL=C sort | zip -X -q "${OUTPUT_ROOT}/RuntimeHostResources.zip" -@
)

# Validate the actual packed payload, not just the unarchived npm work tree.
python3 "${SCRIPT_DIR}/runtime_host_archive.py" validate "${OUTPUT_ROOT}/RuntimeHostResources.zip" --source-root "${HOST_SOURCE}"
readonly VERIFY_ROOT="$(mktemp -d)"
cleanup_verify() { rm -rf "${VERIFY_ROOT}"; }
trap cleanup_verify EXIT
python3 -m zipfile -e "${OUTPUT_ROOT}/RuntimeHostResources.zip" "${VERIFY_ROOT}"
mkdir -p "${VERIFY_ROOT}/Tests/Fixtures"
cp "${HOST_SOURCE}/Tests/Fixtures/fetch-compatibility-probe.mjs" "${VERIFY_ROOT}/Tests/Fixtures/"
node --jitless "${VERIFY_ROOT}/Tests/Fixtures/fetch-compatibility-probe.mjs"

host_sha256="$(shasum -a 256 "${OUTPUT_ROOT}/RuntimeHostResources.zip" | awk '{print $1}')"
printf '%s  %s\n' "${host_sha256}" "RuntimeHostResources.zip" > "${OUTPUT_ROOT}/runtime-host.sha256"
node -e '
  const fs = require("node:fs");
  const [file, hash, nodeVersion, sourceInputsHash] = process.argv.slice(1);
  fs.writeFileSync(file, `${JSON.stringify({
    nodeVersion, archiveSha256: hash, sourceInputsHash, jitlessArchiveSmoke: "passed", npmInstall: "npm ci --omit=dev --ignore-scripts --workspaces=false --no-audit --no-fund",
    tests: "passed",
  }, null, 2)}\n`);
' "${OUTPUT_ROOT}/host-metadata.json" "${host_sha256}" "$(node --version)" "${SOURCE_INPUTS_HASH}"

rm -rf "${WORK_ROOT}" "${GRAMMAR_TOOL_ROOT}"
echo "Prepared RuntimeHostResources.zip (${host_sha256})."
