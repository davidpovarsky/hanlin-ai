"""One unchanged original FileManager selector on the reviewed native bookmark policy."""
import datetime, fcntl, hashlib, json, os, pathlib, re, signal, subprocess, sys, time, traceback
STAGE = pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126')
ROOT = STAGE / 'source'
SOURCE = '33d949fa8d91d238ba93a9ef09373c5eafe58b84'
STAGE_RECEIPT = STAGE / 'source-stage-33d949fa-r1.json'
EVIDENCE = STAGE / 'validation/original-filemanager-33d949fa-r1'
PRODUCT_SOURCE = 'Packages/HanlinPlatform/Sources/HanlinScriptingApplicationRuntime/HanlinScriptingRuntimeServices.swift'
PRODUCT_SHA256 = 'a1ead7e7e54c6d4e578fd9f3b7b6696f966ab1050540908c4e9d70ba75493cf3'
TEST_SOURCE = 'Packages/HanlinPlatform/Tests/HanlinScriptingApplicationRuntimeTests/HanlinScriptingApplicationRuntimeTests.swift'
TEST_SHA256 = 'fafee829073998c78fc466ed767df87b3717342d170fdf7f334fc331b35a8076'
SELECTOR = 'documentPickerAndQuickLookRuntime'
COMMAND = ['/usr/bin/swift','test','--package-path','Packages/HanlinPlatform','--parallel','--filter',SELECTOR]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def free():
    fs = os.statvfs('/System/Volumes/Data')
    return fs.f_bavail * fs.f_frsize

def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(ROOT), *args], text=True, timeout=30).strip()

def process_snapshot():
    result = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,stat=,lstart=,comm='],
                            capture_output=True, text=True, timeout=10, check=True)
    rows = []
    for line in result.stdout.splitlines():
        fields = line.strip().split(None, 9)
        if len(fields) != 10:
            continue
        rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]),
                     'state': fields[3], 'processStarted': ' '.join(fields[4:9]),
                     'executable': fields[9]})
    return rows

def process_identity(row):
    return row['processStarted'], row['executable']

def owned_tree(parent_pid, rows=None):
    rows = process_snapshot() if rows is None else rows
    ids = {parent_pid}
    while True:
        added = {row['pid'] for row in rows if row['ppid'] in ids} - ids
        if not added:
            break
        ids.update(added)
    owned = [row for row in rows if row['pid'] in ids]
    for row in owned:
        known_owned[row['pid']] = process_identity(row)
    return owned

def stop_owned_processes(process, reason):
    data['stopReason'] = reason
    data['stopRequestedAt'] = now()
    data['stopProcessTree'] = owned_tree(process.pid)
    data['stopSignals'] = []
    save()
    # SwiftPM may create separate child groups. Retain observed identities and
    # address only the same owned processes, including any just-reparented child.
    for sig, grace in [(signal.SIGINT, 3), (signal.SIGTERM, 3), (signal.SIGKILL, 3)]:
        rows = process_snapshot()
        if process.poll() is None:
            owned_tree(process.pid, rows)
        owned = [row for row in rows if known_owned.get(row['pid']) == process_identity(row)]
        owned_ids = {row['pid'] for row in owned}
        if not owned:
            break
        groups = {row['pgid'] for row in owned if row['pgid'] > 1 and row['pgid'] != os.getpgrp()}
        group_members = {group: [row for row in rows if row['pgid'] == group] for group in groups}
        exclusive_groups = {group for group, members in group_members.items()
                            if members and all(row['pid'] in owned_ids for row in members)}
        for group in sorted(exclusive_groups):
            try:
                os.killpg(group, sig)
                data['stopSignals'].append({'signal': sig.name, 'ownedPGID': group})
            except ProcessLookupError:
                pass
        for row in owned:
            if row['pgid'] in exclusive_groups:
                continue
            try:
                # A shared group is never signalled: only its verified owned PID.
                os.kill(row['pid'], sig)
                data['stopSignals'].append({'signal': sig.name, 'ownedPID': row['pid']})
            except ProcessLookupError:
                pass
        save()
        until = time.monotonic() + grace
        while time.monotonic() < until:
            process.poll()
            time.sleep(0.25)
    data['ownedProcessesAfterStop'] = [row for row in process_snapshot()
                                      if known_owned.get(row['pid']) == process_identity(row)]
    save()

known_owned = {}
assert not EVIDENCE.exists(), 'A prior diagnostic attempt must not be overwritten'
EVIDENCE.mkdir(parents=True)
RECEIPT = EVIDENCE / 'controller.json'
LOG = EVIDENCE / 'original-filemanager-selector.log'
data = {
    'status': 'PREPARING_ONE_ORIGINAL_FILEMANAGER_SELECTOR_DIAGNOSTIC',
    'source': SOURCE, 'command': COMMAND, 'cwd': str(ROOT),
    'controllerPID': os.getpid(), 'controllerSHA256': digest(pathlib.Path(__file__)),
    'startedAt': now(), 'nativeCommandsStarted': 0,
    'scope': 'One original failing macOS FileManager selector; the tracked test, assertions, fixture and original test/suite limits remain unchanged.',
    'boundary': 'Diagnostic evidence only. No full601, iOS79, Host188, app54/26 or OS acceptance claim.',
}

def save():
    temporary = RECEIPT.with_suffix('.pending')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(RECEIPT)

native = open('/Users/m1/caches/hanlin-two-wave-native-app.lock', 'a+')
maintenance = open('/Users/m1/caches/.scaleway-cache-maintenance.lock', 'a+')
process = None
try:
    fcntl.flock(native, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(maintenance, fcntl.LOCK_SH | fcntl.LOCK_NB)
    assert digest(STAGE_RECEIPT) == 'ebe26f5fbb9666a2b1f3ba6fec2309c01f2a5a5669f5534c8d9a0a571cf4941e'
    stage = json.loads(STAGE_RECEIPT.read_text())
    assert stage['source'] == SOURCE and stage['SDK392Matched'] == 392
    assert stage['status'] == 'EXACT_REVIEWED_PACKAGE_SOURCE_STAGED'
    assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain=v1')
    assert git('rev-parse', 'HEAD:Packages/HanlinPlatform') == 'e7e9799ec642d8011e87f92563fdb6d5d359093e'
    assert digest(ROOT / PRODUCT_SOURCE) == PRODUCT_SHA256
    assert digest(ROOT / TEST_SOURCE) == TEST_SHA256
    for name, sha in stage['pins'].items():
        assert digest(ROOT / name) == sha
    declaration = git('grep', '-n', '-F', 'func ' + SELECTOR + '(', '--', 'Packages/HanlinPlatform/Tests')
    assert len(declaration.splitlines()) == 1 and declaration.startswith(TEST_SOURCE + ':')
    data['exactSelectorDeclaration'] = declaration
    warm = ROOT / 'Packages/HanlinPlatform/.build'
    assert warm.is_dir() and warm.stat().st_ino == stage['warmBuildInode']
    capacity = {
        'measuredCompleteWarmBuildAllocatedBytes': 2006482944,
        'changedPackageFiles': [PRODUCT_SOURCE],
        'existingCompleteWarmBuildReused': True,
        'budgetComponentsBytes': {'incrementalCompileAndLink': 1024*1024**2,
            'nativeFixtureTemporaryFiles': 64*1024**2, 'logsAndEvidence': 16*1024**2,
            'concurrentGrowthAllowance': 512*1024**2, 'osReserve': 1024*1024**2},
        'rationale': 'One production source file changes private macOS bookmark policy and imports the public Security framework; all test files and pins match the warmed package. The existing complete build occupies2.006GB; a1GiB incremental compile/link allowance plus fixture, foreign-growth and1GiB OS margin fits current free space. This is a measured warm incremental phase, not a fixed global capacity target.',
    }
    admission = sum(capacity['budgetComponentsBytes'].values())
    reserve = capacity['budgetComponentsBytes']['osReserve']
    data['capacity'] = capacity
    data['freeAtAdmission'] = free()
    data['admissionBytes'] = admission
    data['diagnosticOuterBounds'] = {'buildSeconds': 600, 'testSeconds': 120, 'originalTrackedTestLimitsUnchanged': True}
    data['swiftVersion'] = subprocess.check_output(['/usr/bin/swift', '--version'], text=True, timeout=15).strip()
    data['xcodeVersion'] = subprocess.check_output(['/usr/bin/xcodebuild', '-version'], text=True, timeout=15).strip()
    data['stageReceiptSHA256'] = digest(STAGE_RECEIPT)
    data['sourceProductionFileSHA256'] = PRODUCT_SHA256
    save()
    if data['freeAtAdmission'] < admission:
        data['status'] = 'NOT_RUN_MEASURED_INCREMENTAL_PHASE_DOES_NOT_FIT'
    else:
        env = os.environ.copy()
        env['PATH'] = str(STAGE / 'tool-bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
        with LOG.open('xb') as log:
            process = subprocess.Popen(COMMAND, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            data.update(status='RUNNING_ONE_ORIGINAL_FILEMANAGER_SELECTOR', nativeCommandsStarted=1,
                pid=process.pid, pgid=process.pid, commandStartedAt=now())
            save()
            start = time.monotonic()
            test_start = None
            while process.poll() is None:
                elapsed = time.monotonic() - start
                text = LOG.read_text(errors='replace')
                rows = owned_tree(process.pid)
                if test_start is None and ('Test ' + SELECTOR + '() started.') in text:
                    test_start = time.monotonic()
                    data['testStartObservedAt'] = now()
                    data['testStartProcessTree'] = rows
                data['lastObservation'] = {'at': now(), 'elapsedSeconds': elapsed,
                    'freeBytes': free(), 'logBytes': LOG.stat().st_size, 'ownedProcessTree': rows}
                if data['lastObservation']['freeBytes'] < reserve:
                    stop_owned_processes(process, 'MEASURED_OS_RESOURCE_RESERVE_REACHED')
                    break
                if (test_start is None and elapsed >= 600) or (test_start is not None and time.monotonic()-test_start >= 120):
                    stop_owned_processes(process, 'BOUNDED_SINGLE_SELECTOR_DIAGNOSTIC_ENVELOPE')
                    break
                save()
                time.sleep(1)
            data['exitCode'] = process.wait(timeout=10)
        text = LOG.read_text(errors='replace')
        method_starts = re.findall(r'^.*?Test ([A-Za-z_][A-Za-z_0-9]*\([^\n]*\)) started\.$', text, re.MULTILINE)
        method_terminals = re.findall(r'^.*?Test ([A-Za-z_][A-Za-z_0-9]*\([^\n]*\)) (passed|failed|skipped) after [^\n]*', text, re.MULTILINE)
        data['methodStarts'] = method_starts
        data['methodTerminals'] = method_terminals
        data['exactOneSelectorExecuted'] = method_starts == [SELECTOR+'()'] and len(method_terminals) == 1 and method_terminals[0][0] == SELECTOR+'()'
        data['nativeSummaryLines'] = [line for line in text.splitlines() if 'Test run with ' in line or 'recorded an issue' in line or ('Test '+SELECTOR) in line]
        data['diagnosticOriginalSelectorPassed'] = (not data.get('stopReason') and data['exitCode'] == 0
            and data['exactOneSelectorExecuted'] and method_terminals[0][1] == 'passed')
        data['status'] = ('ORIGINAL_FILEMANAGER_SELECTOR_DIAGNOSTIC_STOPPED' if data.get('stopReason') else
            'ORIGINAL_FILEMANAGER_SELECTOR_DIAGNOSTIC_PASSED' if data['diagnosticOriginalSelectorPassed'] else
            'ORIGINAL_FILEMANAGER_SELECTOR_DIAGNOSTIC_FAILED')
except BaseException as error:
    if process is not None and process.poll() is None:
        stop_owned_processes(process, 'SINGLE_SELECTOR_DIAGNOSTIC_CONTROLLER_EXCEPTION')
    data.update(status='FILEMANAGER_DIAGNOSTIC_CONTROLLER_FAILED', error=repr(error), traceback=traceback.format_exc())
finally:
    data['sourceUnchanged'] = (git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain=v1')
        and digest(ROOT / PRODUCT_SOURCE) == PRODUCT_SHA256)
    data['finishedAt'] = now()
    data['freeEnd'] = free()
    data['retainedEvidence'] = [{'path': str(p.relative_to(EVIDENCE)), 'bytes': p.stat().st_size, 'sha256': digest(p)}
        for p in sorted(EVIDENCE.rglob('*')) if p.is_file() and p != RECEIPT and p.suffix != '.pending']
    save()
    fcntl.flock(maintenance, fcntl.LOCK_UN)
    fcntl.flock(native, fcntl.LOCK_UN)
    print(json.dumps({key: data.get(key) for key in ['status','source','pid','exitCode','stopReason','error',
        'exactOneSelectorExecuted','diagnosticOriginalSelectorPassed','nativeSummaryLines','sourceUnchanged','finishedAt','freeEnd']}), flush=True)
if not data.get('diagnosticOriginalSelectorPassed'):
    raise SystemExit(1)
