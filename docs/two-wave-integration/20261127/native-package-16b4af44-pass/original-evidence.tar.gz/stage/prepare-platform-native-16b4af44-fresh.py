import pathlib,subprocess,json,hashlib,datetime,os,fcntl,traceback
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=stage/'source'
source='16b4af4490d96c41cb76ed185a1e6d4e828899e7';dd=stage/'derived-data/platform-16b4af44'
receipt=stage/'platform-native-preparation-16b4af44-fresh.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def free():s=os.statvfs('/System/Volumes/Data');return s.f_bavail*s.f_frsize
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
data={'source':source,'status':'PREPARING','startedAt':now(),'derivedData':str(dd),'route':'Original six pinned bare repositories, independently APFS-cloned from our retained exact app repository cache. No workspace state, checkouts, native products or result bundles copied. Original Xcode resolver will create the current package workspace.','repositories':[],'phases':[]}
def save():p=receipt.with_suffix('.tmp');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(receipt)
native=open('/Users/m1/caches/hanlin-two-wave-native-app.lock','a+');maintenance=open('/Users/m1/caches/.scaleway-cache-maintenance.lock','a+')
try:
 fcntl.flock(native,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(maintenance,fcntl.LOCK_SH|fcntl.LOCK_NB)
 assert not receipt.exists() and not dd.exists()
 data['freeBefore']=free();assert data['freeBefore']>=1273741824
 assert subprocess.check_output(['/usr/bin/git','-C',str(root),'rev-parse','HEAD'],text=True).strip()==source
 previous=json.loads((stage/'platform-native-preparation-9819697c.json').read_text())
 pinPath=root/'Packages/HanlinPlatform/Package.resolved';manifestPath=root/'Packages/HanlinPlatform/Package.swift'
 assert sha(pinPath)==previous['packageLockSHA256']=='453087cb3345b7c6bb24c00a682f41ffa9708ebd328e60b583f6e04276bf789d'
 assert sha(manifestPath)==previous['manifestSHA256']=='78d7081d0e197c3e99746e5b3e476b41280fc5b32110035fab31a3e949cb4dab'
 pins=json.loads(pinPath.read_text())['pins'];assert len(pins)==6
 byIdentity={x['identity']:x for x in previous['repositories']};assert set(byIdentity)=={p['identity'] for p in pins}
 repositories=dd/'SourcePackages/repositories';repositories.mkdir(parents=True);save()
 for pin in pins:
  prior=byIdentity[pin['identity']];donor=pathlib.Path(prior['donor']);assert donor.is_dir() and not donor.is_symlink()
  assert prior['revision']==pin['state']['revision'] and prior['location']==pin['location']
  revision=subprocess.check_output(['/usr/bin/git','--git-dir',str(donor),'rev-parse',pin['state']['revision']+'^{commit}'],text=True,timeout=60).strip();assert revision==pin['state']['revision']
  destination=repositories/donor.name;assert not destination.exists()
  p=subprocess.run(['/bin/cp','-cR',str(donor),str(destination)],capture_output=True,text=True,timeout=180)
  assert p.returncode==0,p.stderr[-1000:]
  actual=subprocess.check_output(['/usr/bin/git','--git-dir',str(destination),'rev-parse',pin['state']['revision']+'^{commit}'],text=True,timeout=60).strip();assert actual==pin['state']['revision'] and destination.stat().st_ino!=donor.stat().st_ino
  data['repositories'].append({'identity':pin['identity'],'revision':actual,'location':pin['location'],'donor':str(donor),'ownedClone':str(destination),'independentInode':True});save()
 assert sorted(p.name for p in (dd/'SourcePackages').iterdir())==['repositories']
 data['packageLockSHA256']=sha(pinPath);data['manifestSHA256']=sha(manifestPath)
 data['priorWarmCacheLoss']={'path':'/Users/m1/caches/DerivedData/hanlin-platform-9819697c-20261126','observationReceipt':str(stage/'platform-cache-presence-16b4af44-readback.json'),'receiptSHA256':sha(stage/'platform-cache-presence-16b4af44-readback.json'),'attribution':'Unknown; no cleanup performed by this controller.'}
 data['coordinationLocks']={'native':'exclusive','existingMaintenance':'shared'}
 data['status']='ORIGINAL_PACKAGE_DEPENDENCIES_PREPARED_NATIVE_NOT_RUN'
except Exception as e:data.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
finally:
 data['finishedAt']=now();data['freeAfter']=free();save();print(json.dumps(data),flush=True)
if data['status']!='ORIGINAL_PACKAGE_DEPENDENCIES_PREPARED_NATIVE_NOT_RUN':raise SystemExit(1)
