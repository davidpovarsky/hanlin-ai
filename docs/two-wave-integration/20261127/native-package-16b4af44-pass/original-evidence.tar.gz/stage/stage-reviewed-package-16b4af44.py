import pathlib,subprocess,json,hashlib,datetime,fcntl,os,traceback,zipfile
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=stage/'source'
base='6975e769e82a7803853180cd6aec6a26fe412f9f';target='16b4af4490d96c41cb76ed185a1e6d4e828899e7'
proof=stage/'source-update-16b4af44-package-proof';receipt=stage/'source-update-16b4af44-package.json'
allowed=["AI_HLYTests/Fixtures/WidgetEngineFixtures.bundle/Hanlin-Expo-Widget-Counter.hanlinExpo","AI_HLYTests/Fixtures/WidgetEngineFixtures.bundle/Hanlin-Expo-Widget-Interactive-Matrix.hanlinExpo","AI_HLYTests/Fixtures/WidgetEngineFixtures.bundle/Hanlin-Expo-Widget-Visuals.hanlinExpo","AI_HLYTests/Fixtures/WidgetEngineFixtures.bundle/Hanlin-Mixed-Native-Widget.hanlinExpo","AI_HLYTests/Fixtures/WidgetEngineFixtures.bundle/Hanlin-Widget-Invalid-Cases.hanlinExpo","AI_HLYUITests/Fixtures/Hanlin-Expo-Widget-Counter.hanlinExpo","AI_HLYUITests/Fixtures/Hanlin-Expo-Widget-Interactive-Matrix.hanlinExpo","AI_HLYUITests/Fixtures/Hanlin-Expo-Widget-Visuals.hanlinExpo","AI_HLYUITests/Fixtures/Hanlin-Mixed-Native-Widget.hanlinExpo","AI_HLYUITests/Fixtures/Hanlin-Widget-Invalid-Cases.hanlinExpo","Fixtures/Widgets/Hanlin-Expo-Widget-Counter.hanlinExpo","Fixtures/Widgets/Hanlin-Expo-Widget-Interactive-Matrix.hanlinExpo","Fixtures/Widgets/Hanlin-Expo-Widget-Visuals.hanlinExpo","Fixtures/Widgets/Hanlin-Mixed-Native-Widget.hanlinExpo","Fixtures/Widgets/Hanlin-Widget-Invalid-Cases.hanlinExpo","Fixtures/Widgets/SHA256.json","Packages/HanlinPlatform/Sources/HanlinScriptExtensions/HanlinScriptExtensionStore.swift","Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinDualWidgetEnginesTests.swift","Scripts/Widgets/Tests/compiler-and-actions.test.mjs","Scripts/Widgets/samples.mjs"]
storePath='Packages/HanlinPlatform/Sources/HanlinScriptExtensions/HanlinScriptExtensionStore.swift'
testPath='Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinDualWidgetEnginesTests.swift'
newFunction='v1ShadowProjectsHistoricalFieldsWithoutLosingCurrentMetadata'
newID='HanlinScriptExtensionsTests/HanlinDualWidgetEnginesTests/'+newFunction+'()'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():s=os.statvfs('/System/Volumes/Data');return s.f_bavail*s.f_frsize
data={'status':'PREPARING','startedAt':now(),'sourceBefore':base,'sourceAfter':target,'phases':[],'scope':'Independently reviewed immutable correction for the original package-only native gate. Root final integration and Host/full-app qualification remain separate. Prior actual76PASS/2FAIL receipts are immutable.','requiredDefinitions':58,'requiredInvocations':79}
env=os.environ.copy();env['PATH']=str(stage/'tool-bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
def save():
 p=receipt.with_suffix('.tmp');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(receipt)
def run(name,args):
 log=proof/(name+'.log')
 with log.open('wb') as f:p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=900)
 data['phases'].append({'name':name,'command':args,'exitCode':p.returncode,'log':str(log),'sha256':sha(log)});save()
 assert p.returncode==0,log.read_text(errors='replace')[-2500:]
 return log.read_text()
def git(*a):return subprocess.check_output(['/usr/bin/git','-C',str(root),*a],timeout=900).decode().strip()
lock=open('/Users/m1/caches/hanlin-two-wave-native-app.lock','a+')
try:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not receipt.exists() and not proof.exists();proof.mkdir();data['freeBefore']=free();assert data['freeBefore']>=1273741824;save()
 assert git('rev-parse','HEAD')==base
 assert not git('diff','--name-only','HEAD','--',*allowed) and not git('diff','--cached','--name-only','--',*allowed)
 oldPath=stage/'platform-native-test-6975e769-r2.json';old=json.loads(oldPath.read_text());assert old['nativeExitCode']==65 and old['sourceProductsAndFixturesUnchanged']
 failedProof=stage/'validation/platform-6975e769/test-r2/required-scope-reconciliation.json'
 assert sha(failedProof)=='be476c5a6739385b129ba5cf428157cef08de8b5714ecd5987d1b19bad584c98'
 assert json.loads(failedProof.read_text())['actualInvocations']==78
 reviewPath=stage/'platform-independent-compatibility-review-16b4af44.json'
 assert sha(reviewPath)=='6474b813c1a524d1261219c8f3a0ff8b5e1883ad65ba9c66637f739b30fd05fb'
 review=json.loads(reviewPath.read_text());assert review['source']==target and review['base']==base and review['decision']=='APPROVED_BOUNDED_SOURCE_CORRECTION_NATIVE_ACCEPTANCE_PENDING'
 data['independentReview']={'path':str(reviewPath),'sha256':sha(reviewPath),'decision':review['decision']}
 b=stage/'provisional-package-16b4af44.bundle';assert b.stat().st_size==6666 and sha(b)=='d3423fb980a86fdd5673775fff4096bea8f54955b1c01f772996ce8844c839ab'
 run('fetch-reviewed-candidate',['/usr/bin/git','fetch',str(b),target])
 changed=git('diff','--name-only',base,target).splitlines();assert changed==allowed,changed
 assert git('diff','--name-only',base,target,'--','Packages').splitlines()==[storePath,testPath]
 before=git('show',base+':'+testPath);after=git('show',target+':'+testPath)
 start=after.index('\n    @Test func '+newFunction+'()');end=after.index('\n    @Test func interruptedShadowPublicationRestoresExactCommittedRevision()',start)
 assert after[:start]+after[end:]==before
 assert after.count('@Test')==before.count('@Test')+1
 frozen='Packages/HanlinPlatform/Tests/Fixtures/LegacyWidgetStore'
 assert git('rev-parse',base+':'+frozen)==git('rev-parse',target+':'+frozen)
 assert git('rev-parse',target+':Packages/HanlinPlatform/Sources')=='d85b17d4f746a5a3f72ac99902d5225c570050d6'
 data['qualification']={'changedPaths':changed,'packageChangedPaths':[storePath,testPath],'originalDualWidgetTestBytesPreservedAfterRemovingOnlyAddedMethod':True,'frozenLegacyFixtureTree':git('rev-parse',target+':'+frozen),'newRegressionIdentifier':newID,'packageSourcesTree':git('rev-parse',target+':Packages/HanlinPlatform/Sources'),'canonicalHostFingerprintChanges':True};save()
 run('checkout-reviewed-candidate',['/usr/bin/git','checkout','--detach',target])
 assert git('rev-parse','HEAD')==target and not git('diff','--name-only','HEAD','--',*allowed)
 pins=root/'Scripts/Expo/package.json';dependencies=json.loads(pins.read_text())['dependencies']
 assert dependencies['@expo/ui']=='58.0.29' and dependencies['expo-widgets']=='58.0.29'
 data['fixtureCopies']=[]
 names=[pathlib.Path(p).name for p in changed if p.startswith('Fixtures/Widgets/') and p.endswith('.hanlinExpo')]
 for name in names:
  rows=[]
  for directory in ['Fixtures/Widgets','AI_HLYTests/Fixtures/WidgetEngineFixtures.bundle','AI_HLYUITests/Fixtures']:
   p=root/directory/name;assert p.is_file() and not p.is_symlink()
   with zipfile.ZipFile(p) as z:
    payload=json.loads(z.read('package.json'));assert payload['hanlinExpo']['runtimeVersion']==dependencies['@expo/ui']
    assert payload['hanlinExpo']['plugins']['@expo/ui']==dependencies['@expo/ui']
    assert payload['dependencies']['@expo/ui']==dependencies['@expo/ui'] and payload['dependencies']['expo-widgets']==dependencies['expo-widgets']
   rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p)})
  assert len({x['sha256'] for x in rows})==1;data['fixtureCopies'].append({'name':name,'copies':rows})
 assert len(data['fixtureCopies'])==5
 assert sha(root/'Fixtures/Widgets/Hanlin-Expo-Widget-Counter.hanlinExpo')=='a52c828cdb87f115c668b7cba544781ce89c023b14a65551844ee7985faa3d9d'
 invPath=stage/'platform-test-inventory-6975e769-provisional.json';inv=json.loads(invPath.read_text());assert inv['sourceCommit']==base and inv['combinedPackage']['definitions']==57 and inv['combinedPackage']['expectedInvocations']==78
 changes=[]
 for rel,oldSHA in list(inv['sourceSHA256'].items()):
  newSHA=sha(root/rel)
  if newSHA!=oldSHA:
   assert rel in [testPath,'Fixtures/Widgets/Hanlin-Expo-Widget-Counter.hanlinExpo'];changes.append({'path':rel,'beforeSHA256':oldSHA,'afterSHA256':newSHA})
  inv['sourceSHA256'][rel]=newSHA
 assert len(changes)==2
 inv['sourceSHA256'][storePath]=sha(root/storePath)
 for p in changed:
  if p.startswith(('Fixtures/Widgets/','Scripts/Widgets/')):inv['sourceSHA256'][p]=sha(root/p)
 inv['sourceCommit']=target;inv['recordedAtUTC']=now();inv['status']='SOURCE_INVENTORY_ONLY_NATIVE_NOT_RUN'
 inv['compatibilityRegression']={'target':'HanlinScriptExtensionsTests','suite':'HanlinDualWidgetEnginesTests','sourceFile':testPath,'sourceLine':(root/testPath).read_text().splitlines().index('    @Test func '+newFunction+'() throws {')+1,'function':newFunction,'signature':newFunction+'()','sourceDerivedIdentifier':newID,'expectedInvocations':1,'parameterValues':None,'note':'New frozen-reader/V2-retention/tamper regression for the actual native V1 projection failure.'}
 inv['combinedPackage']['definitions']=58;inv['combinedPackage']['expectedInvocations']=79;inv['combinedPackage']['argvOnlyTesting'].append('-only-testing:'+newID)
 inv['candidateQualification']={'scope':'Independently reviewed provisional package-only correction pending final root integration','baseSource':base,'baseInventorySHA256':sha(invPath),'reviewSHA256':sha(reviewPath),'sourceChanges':changes,'packageProductionChangedPaths':[storePath],'originalRequiredDefinitions':57,'originalRequiredInvocations':78,'addedDefinitions':1,'addedInvocations':1,'actualRequiredDefinitions':58,'actualRequiredInvocations':79,'parameterInvocations':28,'collateralAcceptance':0}
 out=stage/'platform-test-inventory-16b4af44-provisional.json';assert not out.exists();out.write_text(json.dumps(inv,indent=2)+'\n')
 data['inventory']={'path':str(out),'sha256':sha(out),'expectedDefinitions':58,'expectedInvocations':79}
 data['packagePinSHA256']=sha(root/'Packages/HanlinPlatform/Package.resolved');assert data['packagePinSHA256']=='453087cb3345b7c6bb24c00a682f41ffa9708ebd328e60b583f6e04276bf789d'
 data['appPinSHA256']=sha(root/'AI_HLY.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved');assert data['appPinSHA256']=='56d19a4b8c677831fb91e1f8155a68e411b42fd4807ad618d6f169569e1bb5a4'
 data['tree']=git('rev-parse','HEAD^{tree}');data['status']='REVIEWED_PACKAGE_CANDIDATE_STAGED'
except Exception as e:data.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
finally:
 data['finishedAt']=now();data['freeAfter']=free();save();print(json.dumps({k:data.get(k) for k in ['status','sourceBefore','sourceAfter','inventory','error','finishedAt','freeAfter']}),flush=True)
if data['status']!='REVIEWED_PACKAGE_CANDIDATE_STAGED':raise SystemExit(1)
