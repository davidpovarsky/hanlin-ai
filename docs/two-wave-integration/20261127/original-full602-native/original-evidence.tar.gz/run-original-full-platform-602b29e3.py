"""Run the unchanged original full macOS Swift gate; samples are diagnostic only."""
import collections
import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import re
import signal
import subprocess
import sys
import time
import traceback

STAGE = pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126')
ROOT = STAGE / 'source'
SOURCE = '602b29e303a633155fe07583e9ece28fce0ba113'
ATTEMPT = 'r1'
EVIDENCE = STAGE / ('validation/full-platform-' + SOURCE[:8] + '-' + ATTEMPT)
RECEIPT = STAGE / ('full-platform-' + SOURCE[:8] + '-' + ATTEMPT + '.json')
COMMAND = ['/usr/bin/swift', 'test', '--package-path', 'Packages/HanlinPlatform', '--parallel']
ORIGINAL_PHASE_SECONDS = 3600
STAGE_RECEIPT = STAGE / 'source-stage-602b29e3-r2.json'
STAGE_RECEIPT_SHA256 = '432a7c1d34a30a25f8b7ed5258881e3a277b5cbb1eb2a583d39a3d22cce1929c'
EXPECTED_TREES = {
    'Packages/HanlinPlatform': '0fa9e8a95f7c6f80597abda88a75f390e3e84a8f',
    'Packages/HanlinPlatform/Sources': '3da2ea174d85e089bfa350ecd33835950f33d43d',
    'Packages/HanlinPlatform/Tests': '72b192559666a54e970578985f1ef091d87090d7',
    'Fixtures/Widgets': 'a0b7b0b1cb9e1ce756ccff40593a325ffffa73d6',
}
LOCKS = {
    'Packages/HanlinPlatform/Package.resolved': '453087cb3345b7c6bb24c00a682f41ffa9708ebd328e60b583f6e04276bf789d',
    'AI_HLY.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved': '56d19a4b8c677831fb91e1f8155a68e411b42fd4807ad618d6f169569e1bb5a4',
}
CAPACITY = STAGE / 'full-platform-602b29e3-capacity-plan-r2.json'
assert len(sys.argv) == 2 and re.fullmatch(r'[0-9a-f]{64}', sys.argv[1])
CAPACITY_SHA256 = sys.argv[1]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def free():
    fs = os.statvfs('/System/Volumes/Data')
    return fs.f_bavail * fs.f_frsize


def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(ROOT), *args], text=True, timeout=30).strip()


assert not EVIDENCE.exists() and not RECEIPT.exists(), 'Unique original gate evidence already exists'
EVIDENCE.mkdir(parents=True)
data = {
    'status': 'PREPARING_ORIGINAL_UNFILTERED_GATE', 'source': SOURCE,
    'controllerPID': os.getpid(), 'controllerSHA256': digest(pathlib.Path(__file__)),
    'startedAt': now(), 'command': COMMAND, 'cwd': str(ROOT),
    'scratchPath': str(ROOT / 'Packages/HanlinPlatform/.build'),
    'originalPhaseDeadlineSeconds': ORIGINAL_PHASE_SECONDS,
    'originalPerTestAndSuiteLimits': 'All tracked original declarations remain unchanged by this controller.',
    'boundary': 'Original unfiltered macOS Swift package suite only. This does not replace generic platform builds, selected iOS79, paired54, extra26, or app/OS/distribution acceptance.',
    'nativeCommandsStarted': 0, 'samples': [],
    'requiredUnfilteredMethodCount': 603, 'originalMethods': 601, 'additiveMeaningfulPromiseControls': 2,
    'samplingPolicy': {'trigger': 'Genuine original HTTP within-limit/received checkpoint pending >=1s',
        'maximumSamples': 1, 'sampleSeconds': 1, 'ownedPIDIdentityRechecked': True,
        'extendsOriginalDeadline': False, 'noGeneralSampler': True},
}


def save():
    temporary = RECEIPT.with_suffix('.pending')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(RECEIPT)


def process_snapshot():
    result = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,stat=,lstart=,comm='],
                            capture_output=True, text=True, timeout=10, check=True)
    rows = []
    for line in result.stdout.splitlines():
        fields = line.strip().split(None, 9)
        if len(fields) != 10:
            continue
        rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]),
                     'state': fields[3], 'processStarted': ' '.join(fields[4:9]),
                     'executable': fields[9]})
    return rows


def process_identity(row):
    return row['processStarted'], row['executable']


known_owned = {}


def owned_tree(parent_pid, rows=None):
    rows = process_snapshot() if rows is None else rows
    ids = {parent_pid}
    while True:
        added = {row['pid'] for row in rows if row['ppid'] in ids} - ids
        if not added:
            break
        ids.update(added)
    owned = [row for row in rows if row['pid'] in ids]
    for row in owned:
        known_owned[row['pid']] = process_identity(row)
    return owned


def test_processes(rows):
    candidates = []
    for row in rows:
        name = pathlib.Path(row['executable']).name
        native_test = row['executable'].startswith(str(ROOT / 'Packages/HanlinPlatform/.build') + '/') and name.endswith('Tests')
        if name in {'swiftpm-testing-helper', 'xctest'} or native_test:
            candidates.append(row)
    return sorted(candidates, key=lambda row: ('swiftpm-testing' not in row['executable'], row['pid']))


def stop_owned_processes(process, reason):
    data['stopReason'] = reason
    data['stopRequestedAt'] = now()
    data['stopProcessTree'] = owned_tree(process.pid)
    data['stopSignals'] = []
    save()
    # SwiftPM may create separate child groups. Retain observed identities and
    # address only the same owned processes, including any just-reparented child.
    for sig, grace in [(signal.SIGINT, 3), (signal.SIGTERM, 3), (signal.SIGKILL, 3)]:
        rows = process_snapshot()
        if process.poll() is None:
            owned_tree(process.pid, rows)
        owned = [row for row in rows if known_owned.get(row['pid']) == process_identity(row)]
        owned_ids = {row['pid'] for row in owned}
        if not owned:
            break
        groups = {row['pgid'] for row in owned if row['pgid'] > 1 and row['pgid'] != os.getpgrp()}
        group_members = {group: [row for row in rows if row['pgid'] == group] for group in groups}
        exclusive_groups = {group for group, members in group_members.items()
                            if members and all(row['pid'] in owned_ids for row in members)}
        for group in sorted(exclusive_groups):
            try:
                os.killpg(group, sig)
                data['stopSignals'].append({'signal': sig.name, 'ownedPGID': group})
            except ProcessLookupError:
                pass
        for row in owned:
            if row['pgid'] in exclusive_groups:
                continue
            try:
                # A shared group is never signalled: only its verified owned PID.
                os.kill(row['pid'], sig)
                data['stopSignals'].append({'signal': sig.name, 'ownedPID': row['pid']})
            except ProcessLookupError:
                pass
        save()
        until = time.monotonic() + grace
        while time.monotonic() < until:
            process.poll()
            time.sleep(0.25)
    data['ownedProcessesAfterStop'] = [row for row in process_snapshot()
                                      if known_owned.get(row['pid']) == process_identity(row)]
    save()


def pending_original_http_checkpoint(native_evidence, owned_rows):
    """Follow only the original test's source-bound, owned live-path publication."""
    import tempfile

    candidates = sorted(native_evidence.glob('original-http-*/live-paths.json'))
    if len(candidates) != 1:
        return None
    descriptor_path = candidates[0]
    native_root = native_evidence.resolve()
    if (descriptor_path.is_symlink() or descriptor_path.parent.is_symlink()
            or not descriptor_path.resolve().is_relative_to(native_root)
            or not descriptor_path.is_file()
            or descriptor_path.stat().st_uid != os.getuid()
            or descriptor_path.stat().st_size > 64 * 1024):
        return None
    descriptor_bytes = descriptor_path.read_bytes()
    if len(descriptor_bytes) > 64 * 1024:
        return None
    descriptor = json.loads(descriptor_bytes)
    if (descriptor.get('schema') != 1
            or descriptor.get('kind') != 'hanlin.original-http.live-paths'
            or descriptor.get('test') != 'originalScriptWidgetHTTPUsesBoundedRealTransport'
            or type(descriptor.get('pid')) is not int):
        return None
    targets = [row for row in test_processes(owned_rows) if row['pid'] == descriptor['pid']]
    if len(targets) != 1:
        return None
    run_directory = pathlib.Path(descriptor['runDirectory'])
    if not run_directory.is_absolute() or run_directory.resolve() != native_root:
        return None
    source_relative = 'Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinDualWidgetEnginesTests.swift'
    source_path = pathlib.Path(descriptor['sourceFile'])
    expected_source = ROOT / source_relative
    expected_hash = stage_proof['testSources'][source_relative]
    if (not source_path.is_absolute() or source_path.resolve() != expected_source.resolve()
            or descriptor.get('sourceSHA256') != expected_hash
            or digest(expected_source) != expected_hash):
        return None
    instance = descriptor['instanceID']
    if (not isinstance(instance, str)
            or not re.fullmatch(r'hanlin-widget-pass3-[0-9A-Fa-f]{8}(?:-[0-9A-Fa-f]{4}){3}-[0-9A-Fa-f]{12}', instance)
            or descriptor_path.parent.name != 'original-http-' + instance):
        return None
    temporary_root = pathlib.Path(descriptor['temporaryRoot'])
    if (not temporary_root.is_absolute() or temporary_root.name != instance
            or temporary_root.is_symlink() or not temporary_root.is_dir()
            or temporary_root.stat().st_uid != os.getuid()
            or temporary_root.parent.resolve() != pathlib.Path(tempfile.gettempdir()).resolve()):
        return None
    path = pathlib.Path(descriptor['stagesFile'])
    wire_path = pathlib.Path(descriptor['wireFile'])
    if (not path.is_absolute() or not wire_path.is_absolute()
            or path.parent.resolve() != temporary_root.resolve()
            or wire_path.parent.resolve() != temporary_root.resolve()
            or path.name != 'native-stages.jsonl' or wire_path.name != 'wire.jsonl'
            or path.is_symlink() or wire_path.is_symlink()
            or not path.is_file() or path.stat().st_uid != os.getuid()
            or path.stat().st_size > 1024 * 1024):
        return None
    raw = path.read_bytes()
    if len(raw) > 1024 * 1024:
        return None
    # Only the exact published file is followed. No temporary-directory scan occurs.
    # The fixture may still be appending, so interpret complete actual rows only.
    rows = [json.loads(line) for line in raw.splitlines(keepends=True) if line.endswith(b'\n')]
    starts = [row for row in rows if row.get('label') == 'test' and row.get('phase') == 'started']
    limits = [row for row in rows if row.get('label') == 'limits']
    if len(starts) != 1 or not limits or rows[0] != starts[0]:
        return None
    start, latest = starts[0], limits[-1]
    if (start.get('executionTimeout') != 5 or start.get('pid') != descriptor['pid']
            or latest.get('pid') != descriptor['pid']
            or not datetime.datetime.fromisoformat(data['commandStartedAt']).timestamp()
                   <= start['at'] <= descriptor['at'] <= time.time()):
        return None
    if latest.get('phase') != 'javascript' or latest.get('stage') not in {'within-limit', 'within-limit-received'}:
        return None
    if any(row.get('label') == 'test' and row.get('phase') != 'started' for row in rows):
        return None
    age = time.time() - latest['at']
    if not 1.0 <= age < start['executionTimeout']:
        return None
    return {'actualOwnedTarget': targets[0], 'stage': latest['stage'],
            'checkpoint': latest, 'checkpointAgeSeconds': age,
            'originalObservedExecutionTimeout': start['executionTimeout'],
            'liveDescriptor': {'path': str(descriptor_path),
                'sha256': hashlib.sha256(descriptor_bytes).hexdigest(), 'contents': descriptor},
            'nativeEvidencePath': str(path), 'nativeEvidenceSnapshotSHA256': hashlib.sha256(raw).hexdigest(),
            'nativeEvidenceSnapshotBytes': raw}


native = open('/Users/m1/caches/hanlin-two-wave-native-app.lock', 'a+')
maintenance = open('/Users/m1/caches/.scaleway-cache-maintenance.lock', 'a+')
process = None
samplers = []
log_path = EVIDENCE / 'original-swift-test.log'
try:
    fcntl.flock(native, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(maintenance, fcntl.LOCK_SH | fcntl.LOCK_NB)
    data['coordinationLocks'] = {'native': 'exclusive', 'maintenance': 'shared'}
    assert digest(STAGE_RECEIPT) == STAGE_RECEIPT_SHA256
    stage_proof = json.loads(STAGE_RECEIPT.read_text())
    assert stage_proof['status'] == 'EXACT_REVIEWED_PACKAGE_SOURCE_STAGED'
    assert stage_proof['source'] == SOURCE and stage_proof['sourceClean'] is True
    observer_review_path = STAGE / 'import-602b29e3/root-http-livepath-observer-review-602b29e3.json'
    assert digest(observer_review_path) == '8131df5ea9e05e8deee3ea2009b4cc1f5bb2df1c88543dc947dd8f73cb97cc24'
    observer_review = json.loads(observer_review_path.read_text())
    assert observer_review['decision'] == 'APPROVED_SOURCE_BOUND_LIVE_PATH_HTTP_SAMPLER_ONLY'
    assert observer_review['source'] == SOURCE
    assert observer_review['helperSHA256'] == '3f4f209aff835e2cd555e7bb3a8ee8ef94be76e8eccbf8461ce84877b1e2d6c6'
    assert observer_review['testSHA256'] == stage_proof['testSources']['Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinDualWidgetEnginesTests.swift']
    assert observer_review['originalNativeExecutionBudgetSeconds'] == 5
    assert observer_review['originalUnfilteredGateDeadlineSeconds'] == ORIGINAL_PHASE_SECONDS
    assert observer_review['originalTestCount'] == 603
    data['observerSourceReview'] = {'path': str(observer_review_path), 'sha256': digest(observer_review_path),
        'helperSHA256': observer_review['helperSHA256'], 'testSHA256': observer_review['testSHA256']}
    focused_path = STAGE / 'validation/original-filemanager-33d949fa-r1/source-bound-display-name-reconciliation.json'
    assert digest(focused_path) == 'b2c4e3458813756a68339daff12cc060646defc98184af46248e5fc88d67e460'
    focused = json.loads(focused_path.read_text())
    assert focused['status'] == 'SOURCE_BOUND_ORIGINAL_FILEMANAGER_SELECTOR_EXECUTED_PASS'
    assert focused['source'] == '33d949fa8d91d238ba93a9ef09373c5eafe58b84' and focused['nativeExitCode'] == 0 and focused['testCount'] == 1
    assert focused['selector'] == 'documentPickerAndQuickLookRuntime' and focused['sourceUnchanged']
    for rel, expected in stage_proof['originalFileManagerProductionAndTestHashes'].items():
        assert digest(ROOT / rel) == expected, rel
    for rel, expected in stage_proof['testSources'].items():
        assert digest(ROOT / rel) == expected, rel
    data['focusedOriginalPrerequisite'] = {'path': str(focused_path), 'sha256': digest(focused_path),
        'actualHistoricalSource': focused['source'], 'exactProductionAndTestBytesStillMatch': True,
        'nativePassConfirmedByOriginalDisplayName': True, 'rawFailedReconciliationPreserved': True}
    assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain=v1')
    assert (ROOT / 'Packages/HanlinPlatform/.build').is_dir(), 'Measured existing warm scratch must remain present'
    for rel, expected in EXPECTED_TREES.items():
        assert git('rev-parse', 'HEAD:' + rel) == expected, rel
    for rel, expected in LOCKS.items():
        assert digest(ROOT / rel) == expected, rel
    assert digest(CAPACITY) == CAPACITY_SHA256
    capacity = json.loads(CAPACITY.read_text())
    assert capacity['status'] == 'MEASURED_WARM_ORIGINAL_PHASE_CAPACITY_PLAN'
    assert capacity['source'] == SOURCE and capacity['command'] == COMMAND
    assert capacity['originalPhaseDeadlineSeconds'] == ORIGINAL_PHASE_SECONDS
    assert capacity['stageReceiptSHA256'] == STAGE_RECEIPT_SHA256
    components = capacity['budgetComponentsBytes']
    admission_bytes = sum(components.values())
    reserve_bytes = components['osReserve']
    assert admission_bytes == capacity['admissionBytes'] and reserve_bytes == capacity['continuousReserveBytes']
    assert reserve_bytes > 0 and admission_bytes > reserve_bytes
    assert components['incrementalCompileAndLink'] >= 2 * capacity['measuredAffectedOutputsBytes']
    data['capacityPlan'] = {'path': str(CAPACITY), 'sha256': CAPACITY_SHA256, 'contents': capacity}
    data['exactOriginalSource'] = {'packageTrees': EXPECTED_TREES, 'lockfiles': LOCKS,
                                   'stageReceiptSHA256': STAGE_RECEIPT_SHA256,
                                   'fullSourceHeadPinned': True, 'selectorsOrAssertionsChangedByController': False}
    data['swiftVersion'] = subprocess.check_output(['/usr/bin/swift', '--version'], text=True, timeout=20).strip()
    data['xcodeVersion'] = subprocess.check_output(['/usr/bin/xcodebuild', '-version'], text=True, timeout=20).strip()
    data['freeAtAdmission'] = free()
    if data['freeAtAdmission'] < admission_bytes:
        data['status'] = 'NOT_RUN_MEASURED_PHASE_CAPACITY'
        save()
    else:
        environment = os.environ.copy()
        environment['PATH'] = str(STAGE / 'tool-bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
        environment['HANLIN_WIDGET_EVIDENCE_DIR'] = str(EVIDENCE / 'native')
        (EVIDENCE / 'native').mkdir()
        data['nativeEvidenceDirectory'] = environment['HANLIN_WIDGET_EVIDENCE_DIR']
        with log_path.open('xb') as log:
            process = subprocess.Popen(COMMAND, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            data.update(status='RUNNING_ORIGINAL_UNFILTERED_BUILD', nativeCommandsStarted=1,
                        pid=process.pid, pgid=process.pid, commandStartedAt=now())
            save()
            started = time.monotonic()
            test_started = None
            log_size = 0
            last_growth = started
            samples_taken = set()
            while process.poll() is None:
                current = time.monotonic()
                size = log_path.stat().st_size
                if size != log_size:
                    log_size, last_growth = size, current
                text = log_path.read_text(errors='replace')
                rows = owned_tree(process.pid)
                testers = test_processes(rows)
                if test_started is None and (testers or 'Test run started.' in text):
                    test_started = current
                    data.update(status='RUNNING_ORIGINAL_UNFILTERED_TESTS', testExecutionObservedAt=now(),
                                testStartProcessTree=rows, buildElapsedSeconds=current-started)
                observation = {'at': now(), 'elapsedSeconds': current-started,
                               'testElapsedSeconds': None if test_started is None else current-test_started,
                               'freeBytes': free(), 'logBytes': size,
                               'secondsSinceLogGrowth': current-last_growth, 'ownedProcessTree': rows}
                data['lastObservation'] = observation
                if observation['freeBytes'] < reserve_bytes:
                    stop_owned_processes(process, 'MEASURED_OS_RESOURCE_RESERVE_REACHED')
                    break
                if current-started >= ORIGINAL_PHASE_SECONDS:
                    stop_owned_processes(process, 'ORIGINAL_UNFILTERED_PHASE_3600_SECOND_DEADLINE')
                    break
                # One optional, short sample is bound to the actual original
                # HTTP fixture's pending await/content checkpoint and owned PID.
                # Other tests may continue producing output during the5s budget.
                if test_started is not None and 'original-http-checkpoint' not in samples_taken:
                    try:
                        pending = pending_original_http_checkpoint(EVIDENCE / 'native', rows)
                        if pending is not None:
                            target = pending['actualOwnedTarget']
                            fresh = {row['pid']: row for row in process_snapshot()}
                            still_owned = {row['pid']: row for row in owned_tree(process.pid, list(fresh.values()))}
                            if (target['pid'] in still_owned
                                    and process_identity(still_owned[target['pid']]) == process_identity(target)):
                                samples_taken.add('original-http-checkpoint')
                                snapshot_path = EVIDENCE / 'original-http-pending-at-sample.jsonl'
                                snapshot_path.write_bytes(pending.pop('nativeEvidenceSnapshotBytes'))
                                tree_path = EVIDENCE / 'original-http-pending-process-tree.json'
                                tree_path.write_text(json.dumps({'observation': observation, 'trigger': pending,
                                    'freshOwnedProcessTree': list(still_owned.values())}, indent=2) + '\n')
                                sample_path = EVIDENCE / ('sample-original-http-pid-' + str(target['pid']) + '.txt')
                                capture_log = sample_path.with_suffix('.command.log')
                                with capture_log.open('xb') as capture:
                                    sampler = subprocess.Popen(['/usr/bin/sample', str(target['pid']), '1', '1', '-file', str(sample_path)],
                                        stdin=subprocess.DEVNULL, stdout=capture, stderr=subprocess.STDOUT, start_new_session=True)
                                record = {'trigger': pending, 'actualOwnedTarget': target,
                                    'samplerPID': sampler.pid, 'samplePath': str(sample_path), 'sampleSeconds': 1,
                                    'commandLog': str(capture_log), 'tree': str(tree_path),
                                    'snapshotPath': str(snapshot_path), 'extendsOriginalDeadline': False}
                                data['samples'].append(record)
                                samplers.append((sampler, record, time.monotonic()))
                    except (OSError, ValueError, KeyError, TypeError) as diagnostic_error:
                        data.setdefault('optionalHTTPDiagnosticErrors', []).append({'at': now(), 'error': repr(diagnostic_error)})
                        samples_taken.add('original-http-checkpoint')
                for sampler, record, sample_started in samplers:
                    if 'exitCode' in record:
                        continue
                    if sampler.poll() is None and time.monotonic()-sample_started > 10:
                        sampler.terminate()
                        try:
                            sampler.wait(timeout=3)
                        except subprocess.TimeoutExpired:
                            sampler.kill()
                            sampler.wait(timeout=3)
                        record['samplerStopReason'] = 'DIAGNOSTIC_CAPTURE_10_SECOND_LIMIT'
                    if sampler.poll() is not None:
                        record['exitCode'] = sampler.returncode
                        sample_path = pathlib.Path(record['samplePath'])
                        record['sampleSHA256'] = digest(sample_path) if sample_path.is_file() else None
                save()
                time.sleep(2)
            data['exitCode'] = process.wait(timeout=10)
        final_text = log_path.read_text(errors='replace')
        summary_lines = re.findall(r'Test run with \d+ tests?[^\n]*(?:passed|failed)[^\n]*', final_text)
        passed_counts = re.findall(r'Test run with (\d+) tests?[^\n]*passed[^\n]*', final_text)
        starts = collections.Counter(re.findall(r'^.*?\bTest (.+?) started\.$', final_text, re.MULTILINE))
        terminals = collections.Counter(re.findall(r'^.*?\bTest (.+?) (?:passed|failed|skipped) after ', final_text, re.MULTILINE))
        data['originalTestRunSummaryLines'] = summary_lines
        data['reportedPassedTestRunCounts'] = [int(value) for value in passed_counts]
        data['observedMethodStarts'] = sum(starts.values())
        data['observedMethodTerminals'] = sum(terminals.values())
        data['unmatchedStartedMethodsDiagnosticOnly'] = dict(starts-terminals)
        data['skipLogLines'] = [line for line in final_text.splitlines() if ' skipped ' in line and ('Test ' in line or 'Suite ' in line)]
        data['originalFullSuitePassed'] = (not data.get('stopReason') and data['exitCode'] == 0
                                           and sum(int(value) for value in passed_counts) == 603
                                           and len(summary_lines) == 13 and not data['skipLogLines'])
        data['originalSourceUnchanged'] = (git('rev-parse', 'HEAD') == SOURCE
                                            and not git('status', '--porcelain=v1')
                                            and all(digest(ROOT/rel) == expected for rel, expected in LOCKS.items()))
        assert data['originalSourceUnchanged'], 'Source or pinned lockfile changed during the original full gate'
        data['retainedOwnedScratchExists'] = (ROOT / 'Packages/HanlinPlatform/.build').is_dir()
        data['status'] = ('ORIGINAL_FULL_SUITE_STOPPED' if data.get('stopReason') else
                          'ORIGINAL_UNFILTERED_MACOS_SWIFT_SUITE_PASSED' if data['originalFullSuitePassed'] else
                          'ORIGINAL_UNFILTERED_MACOS_SWIFT_SUITE_FAILED')
except BaseException as error:
    if process is not None and process.poll() is None:
        stop_owned_processes(process, 'FULL_GATE_CONTROLLER_EXCEPTION')
    data.update(status='FULL_GATE_CONTROLLER_FAILED', error=repr(error), traceback=traceback.format_exc())
finally:
    for sampler, record, sample_started in samplers:
        if sampler.poll() is None:
            try:
                sampler.wait(timeout=8)
            except subprocess.TimeoutExpired:
                sampler.terminate()
                try:
                    sampler.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    sampler.kill()
                    sampler.wait(timeout=3)
        record['exitCode'] = sampler.returncode
        sample_path = pathlib.Path(record['samplePath'])
        record['sampleSHA256'] = digest(sample_path) if sample_path.is_file() else None
    data['finishedAt'] = now()
    data['freeEnd'] = free()
    if log_path.is_file():
        data['log'] = {'path': str(log_path), 'bytes': log_path.stat().st_size, 'sha256': digest(log_path)}
    save()
    fcntl.flock(maintenance, fcntl.LOCK_UN)
    fcntl.flock(native, fcntl.LOCK_UN)
    print(json.dumps({key: data.get(key) for key in ['status', 'source', 'pid', 'exitCode', 'stopReason',
                                                   'originalFullSuitePassed', 'error', 'finishedAt', 'freeEnd', 'log']}), flush=True)
if data.get('status') != 'ORIGINAL_UNFILTERED_MACOS_SWIFT_SUITE_PASSED':
    raise SystemExit(1)
