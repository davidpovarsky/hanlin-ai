"""One reviewed additive Promise lifetime class on unchanged shipping production."""
import datetime, fcntl, hashlib, json, os, pathlib, re, signal, subprocess, sys, time, traceback
STAGE = pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126')
ROOT = STAGE / 'source'
SOURCE = '226e7cfcc60a9ace99241f009d3586b9cea7e65e'
STAGE_RECEIPT = STAGE / 'source-stage-226e7cfc-r1.json'
STAGE_SHA256 = '678db8ffd18e5af0686440b9dacb1b44eed0f2bc1109e65215f82141421abff4'
EVIDENCE = STAGE / 'validation/original-promise-gc-226e7cfc-r1'
TEST_SOURCE = 'Packages/HanlinPlatform/Tests/HanlinScriptExtensionsTests/HanlinOriginalPromiseLifetimeTests.swift'
TEST_SHA256 = '65e0f9cb4d9063922bfa92717ff89cdd5b5d9a5220bf40fdc323fd04d8651147'
SELECTOR = 'HanlinOriginalPromiseLifetimeTests'
METHODS = ['originalPromiseRetainsPendingContinuationThroughGarbageCollection()',
    'originalPromiseCancellationReleasesPendingContinuationAndDisposesContext()']
COMMAND = ['/usr/bin/swift','test','--package-path','Packages/HanlinPlatform','--parallel','--filter',SELECTOR]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def free():
    fs = os.statvfs('/System/Volumes/Data')
    return fs.f_bavail * fs.f_frsize

def git(*args):
    return subprocess.check_output(['/usr/bin/git', '-C', str(ROOT), *args], text=True, timeout=30).strip()

def process_snapshot():
    result = subprocess.run(['/bin/ps', '-axo', 'pid=,ppid=,pgid=,stat=,lstart=,comm='],
                            capture_output=True, text=True, timeout=10, check=True)
    rows = []
    for line in result.stdout.splitlines():
        fields = line.strip().split(None, 9)
        if len(fields) != 10:
            continue
        rows.append({'pid': int(fields[0]), 'ppid': int(fields[1]), 'pgid': int(fields[2]),
                     'state': fields[3], 'processStarted': ' '.join(fields[4:9]),
                     'executable': fields[9]})
    return rows

def process_identity(row):
    return row['processStarted'], row['executable']

def owned_tree(parent_pid, rows=None):
    rows = process_snapshot() if rows is None else rows
    ids = {parent_pid}
    while True:
        added = {row['pid'] for row in rows if row['ppid'] in ids} - ids
        if not added:
            break
        ids.update(added)
    owned = [row for row in rows if row['pid'] in ids]
    for row in owned:
        known_owned[row['pid']] = process_identity(row)
    return owned

def stop_owned_processes(process, reason):
    data['stopReason'] = reason
    data['stopRequestedAt'] = now()
    data['stopProcessTree'] = owned_tree(process.pid)
    data['stopSignals'] = []
    save()
    # SwiftPM may create separate child groups. Retain observed identities and
    # address only the same owned processes, including any just-reparented child.
    for sig, grace in [(signal.SIGINT, 3), (signal.SIGTERM, 3), (signal.SIGKILL, 3)]:
        rows = process_snapshot()
        if process.poll() is None:
            owned_tree(process.pid, rows)
        owned = [row for row in rows if known_owned.get(row['pid']) == process_identity(row)]
        owned_ids = {row['pid'] for row in owned}
        if not owned:
            break
        groups = {row['pgid'] for row in owned if row['pgid'] > 1 and row['pgid'] != os.getpgrp()}
        group_members = {group: [row for row in rows if row['pgid'] == group] for group in groups}
        exclusive_groups = {group for group, members in group_members.items()
                            if members and all(row['pid'] in owned_ids for row in members)}
        for group in sorted(exclusive_groups):
            try:
                os.killpg(group, sig)
                data['stopSignals'].append({'signal': sig.name, 'ownedPGID': group})
            except ProcessLookupError:
                pass
        for row in owned:
            if row['pgid'] in exclusive_groups:
                continue
            try:
                # A shared group is never signalled: only its verified owned PID.
                os.kill(row['pid'], sig)
                data['stopSignals'].append({'signal': sig.name, 'ownedPID': row['pid']})
            except ProcessLookupError:
                pass
        save()
        until = time.monotonic() + grace
        while time.monotonic() < until:
            process.poll()
            time.sleep(0.25)
    data['ownedProcessesAfterStop'] = [row for row in process_snapshot()
                                      if known_owned.get(row['pid']) == process_identity(row)]
    save()

known_owned = {}
assert not EVIDENCE.exists(), 'A prior native diagnostic attempt must not be overwritten'
EVIDENCE.mkdir(parents=True)
RECEIPT = EVIDENCE / 'controller.json'
LOG = EVIDENCE / 'original-promise-gc-selector.log'
data = {
    'status': 'PREPARING_ONE_ORIGINAL_PROMISE_GC_CLASS',
    'source': SOURCE, 'command': COMMAND, 'cwd': str(ROOT),
    'controllerPID': os.getpid(), 'controllerSHA256': digest(pathlib.Path(__file__)),
    'startedAt': now(), 'nativeCommandsStarted': 0,
    'scope': 'One newly added two-method class against unchanged original Promise, Fetch, RunningState and complete package production source tree. Original601 test files and assertions unchanged.',
    'boundary': 'Diagnostic baseline only. No original601, iOS79, Host188, app54/26 or OS acceptance claim. GC nonrelease alone is inconclusive, not a proven production leak.',
    'original601Status': 'Historical33 native600PASS/1HTTPFAIL remains open',
    'sourceReview': 'Root and W1 approved original class; root approved exact compiler-only correction65e0f9cb and integrated226e7cfc',
}

def save():
    temporary = RECEIPT.with_suffix('.pending')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(RECEIPT)

native = open('/Users/m1/caches/hanlin-two-wave-native-app.lock', 'a+')
maintenance = open('/Users/m1/caches/.scaleway-cache-maintenance.lock', 'a+')
process = None
stage = None
try:
    fcntl.flock(native, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(maintenance, fcntl.LOCK_SH | fcntl.LOCK_NB)
    assert digest(STAGE_RECEIPT) == STAGE_SHA256
    stage = json.loads(STAGE_RECEIPT.read_text())
    assert stage['source'] == SOURCE and stage['allOriginalPackageFilesUnchanged']
    assert stage['status'] == 'EXACT_REVIEWED_GC_BASELINE_STAGED_UNCHANGED_PRODUCTION'
    assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain=v1')
    assert git('rev-parse', 'HEAD:Packages/HanlinPlatform') == '616f40149045fc9e8ae58a9eb67142379c0ef8b8'
    assert git('rev-parse', 'HEAD:Packages/HanlinPlatform/Sources') == '3da2ea174d85e089bfa350ecd33835950f33d43d'
    assert digest(ROOT / TEST_SOURCE) == TEST_SHA256
    for name, sha in {**stage['pins'], **stage['productionSourceBindings']}.items():
        assert digest(ROOT / name) == sha
    source = (ROOT / TEST_SOURCE).read_text()
    declarations = re.findall(r'@Test\s+func\s+([A-Za-z_][A-Za-z_0-9]*\(\))', source)
    assert sorted(declarations) == sorted(METHODS)
    assert 'struct ' + SELECTOR + ' {' in source
    data['exactSourceDeclarations'] = declarations
    warm = ROOT / 'Packages/HanlinPlatform/.build'
    assert warm.is_dir() and warm.stat().st_ino == stage['warmBuildInode']
    capacity = {
        'measuredCompleteWarmBuildAllocatedBytes': 2006482944,
        'changedPackageFiles': [TEST_SOURCE],
        'existingCompleteWarmBuildReused': True,
        'budgetComponentsBytes': {'incrementalTestCompileAndLink': 512*1024**2,
            'nativeFixtureTemporaryFiles': 64*1024**2, 'logsAndEvidence': 64*1024**2,
            'concurrentGrowthAllowance': 2*1024**3, 'osReserve': 1024**3},
        'rationale': 'The complete2.006GB macOS SwiftPM build is retained. Only one8.4KB additive test file changes inside the package; production, existing tests and both pins are byte-identical to the prior full33 build. Allow512MiB for incremental test compilation/discovery/link,128MiB for fixture/evidence,2GiB observed foreign-growth allowance and1GiB OS margin. This estimate is specific to the warm diagnostic phase.',
    }
    admission = sum(capacity['budgetComponentsBytes'].values())
    reserve = capacity['budgetComponentsBytes']['osReserve']
    data['capacity'] = capacity
    data['freeAtAdmission'] = free()
    data['freeDFAtAdmission'] = subprocess.check_output(['/bin/df','-k','/System/Volumes/Data'], text=True, timeout=10)
    data['admissionBytes'] = admission
    data['diagnosticOuterBounds'] = {'buildSeconds': 600, 'testSeconds': 120, 'originalProductionAnd601LimitsUnchanged': True}
    data['swiftVersion'] = subprocess.check_output(['/usr/bin/swift', '--version'], text=True, timeout=15).strip()
    data['xcodeVersion'] = subprocess.check_output(['/usr/bin/xcodebuild', '-version'], text=True, timeout=15).strip()
    data['stageReceiptSHA256'] = digest(STAGE_RECEIPT)
    data['productionSourceBindings'] = stage['productionSourceBindings']
    save()
    if data['freeAtAdmission'] < admission:
        data['status'] = 'NOT_RUN_MEASURED_INCREMENTAL_PHASE_DOES_NOT_FIT'
    else:
        env = os.environ.copy()
        env['PATH'] = str(STAGE / 'tool-bin') + ':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
        native_evidence = EVIDENCE / 'native'
        native_evidence.mkdir()
        env['HANLIN_WIDGET_EVIDENCE_DIR'] = str(native_evidence)
        data['nativeEvidenceDirectory'] = str(native_evidence)
        with LOG.open('xb') as log:
            process = subprocess.Popen(COMMAND, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            data.update(status='RUNNING_ONE_ORIGINAL_PROMISE_GC_CLASS', nativeCommandsStarted=1,
                pid=process.pid, pgid=process.pid, commandStartedAt=now())
            save()
            start = time.monotonic()
            test_start = None
            while process.poll() is None:
                elapsed = time.monotonic() - start
                text = LOG.read_text(errors='replace')
                rows = owned_tree(process.pid)
                if test_start is None and any(('Test ' + method + ' started.') in text for method in METHODS):
                    test_start = time.monotonic()
                    data['testStartObservedAt'] = now()
                    data['testStartProcessTree'] = rows
                data['lastObservation'] = {'at': now(), 'elapsedSeconds': elapsed,
                    'freeBytes': free(), 'logBytes': LOG.stat().st_size, 'ownedProcessTree': rows}
                if data['lastObservation']['freeBytes'] < reserve:
                    stop_owned_processes(process, 'MEASURED_OS_RESOURCE_RESERVE_REACHED')
                    break
                if (test_start is None and elapsed >= 600) or (test_start is not None and time.monotonic()-test_start >= 120):
                    stop_owned_processes(process, 'BOUNDED_SINGLE_CLASS_DIAGNOSTIC_ENVELOPE')
                    break
                save()
                time.sleep(1)
            data['exitCode'] = process.wait(timeout=10)
        text = LOG.read_text(errors='replace')
        method_starts = re.findall(r'^.*?Test ([A-Za-z_][A-Za-z_0-9]*\([^\n]*\)) started\.$', text, re.MULTILINE)
        method_terminals = re.findall(r'^.*?Test ([A-Za-z_][A-Za-z_0-9]*\([^\n]*\)) (passed|failed|skipped) after [^\n]*', text, re.MULTILINE)
        data['methodStarts'] = method_starts
        data['methodTerminals'] = method_terminals
        data['exactTwoMethodsExecuted'] = (sorted(method_starts) == sorted(METHODS)
            and sorted(row[0] for row in method_terminals) == sorted(METHODS))
        data['nativeSummaryLines'] = [line for line in text.splitlines() if 'Test run with ' in line or 'recorded an issue' in line
            or 'Original Promise observations:' in line or any(('Test '+method) in line for method in METHODS)]
        observations = []
        for path in sorted(native_evidence.glob('original-promise-*.jsonl')):
            observations.append({'path': str(path.relative_to(EVIDENCE)), 'sha256': digest(path),
                'rows': [json.loads(line) for line in path.read_text().splitlines() if line]})
        data['originalPromiseObservations'] = observations
        data['diagnosticClassPassed'] = (not data.get('stopReason') and data['exitCode'] == 0
            and data['exactTwoMethodsExecuted'] and all(row[1] == 'passed' for row in method_terminals)
            and len(observations) == 2)
        data['status'] = ('ORIGINAL_PROMISE_GC_DIAGNOSTIC_STOPPED' if data.get('stopReason') else
            'ORIGINAL_PROMISE_GC_DIAGNOSTIC_PASSED' if data['diagnosticClassPassed'] else
            'ORIGINAL_PROMISE_GC_DIAGNOSTIC_FAILED')
except BaseException as error:
    if process is not None and process.poll() is None:
        stop_owned_processes(process, 'SINGLE_CLASS_DIAGNOSTIC_CONTROLLER_EXCEPTION')
    data.update(status='PROMISE_GC_DIAGNOSTIC_CONTROLLER_FAILED', error=repr(error), traceback=traceback.format_exc())
finally:
    data['sourceUnchanged'] = (git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain=v1')
        and digest(ROOT / TEST_SOURCE) == TEST_SHA256
        and git('rev-parse', 'HEAD:Packages/HanlinPlatform/Sources') == '3da2ea174d85e089bfa350ecd33835950f33d43d'
        and stage is not None and all(digest(ROOT / name) == sha for name,sha in stage['productionSourceBindings'].items()))
    if data.get('diagnosticClassPassed') and not data['sourceUnchanged']:
        data['diagnosticClassPassed'] = False
        data['status'] = 'PROMISE_GC_DIAGNOSTIC_SOURCE_CHANGED'
    data['finishedAt'] = now()
    data['freeEnd'] = free()
    data['freeDFEnd'] = subprocess.check_output(['/bin/df','-k','/System/Volumes/Data'], text=True, timeout=10)
    data['retainedEvidence'] = [{'path': str(p.relative_to(EVIDENCE)), 'bytes': p.stat().st_size, 'sha256': digest(p)}
        for p in sorted(EVIDENCE.rglob('*')) if p.is_file() and p != RECEIPT and p.suffix != '.pending']
    save()
    fcntl.flock(maintenance, fcntl.LOCK_UN)
    fcntl.flock(native, fcntl.LOCK_UN)
    print(json.dumps({key: data.get(key) for key in ['status','source','pid','exitCode','stopReason','error',
        'exactTwoMethodsExecuted','diagnosticClassPassed','nativeSummaryLines','sourceUnchanged','finishedAt','freeEnd']}), flush=True)
if not data.get('diagnosticClassPassed'):
    raise SystemExit(1)
