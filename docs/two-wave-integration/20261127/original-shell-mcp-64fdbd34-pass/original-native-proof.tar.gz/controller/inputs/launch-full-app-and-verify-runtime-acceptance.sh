set -euxo pipefail
SIMULATOR_UDID="$(cat "$LOG_DIR/simulator-udid.txt")"
BUNDLE_ID="$(cat "$LOG_DIR/bundle-id.txt")"
APP_EXECUTABLE="$(cat "$LOG_DIR/app-executable.txt")"
APP_PATH="$(cat "$LOG_DIR/app-path.txt")"

if [ "$SIMULATOR_E2E_ONLY" = "true" ]; then
  printf '%s\n' "simulator-e2e-only" > "$LOG_DIR/validation-profile.txt"
  printf '%s\n' "1" > "$LOG_DIR/alive-duration-seconds.txt"
  exit 0
fi

if [ "$FAST_VALIDATION_ONLY" != "true" ] && [ "$RUN_SIMULATOR_SHELL_ACCEPTANCE" != "true" ] && [ "$RUN_SIMULATOR_MCP_ACCEPTANCE" != "true" ] && [ "$RUN_SIMULATOR_SMOKE_LAUNCH" != "true" ] && [ "$RUN_SIMULATOR_NATIVESCRIPT_POC" != "true" ] && [ "$RUN_FULL_VALIDATION" != "true" ]; then
  printf '%s\n' "targeted-tests-only" > "$LOG_DIR/validation-profile.txt"
  printf '%s\n' "1" > "$LOG_DIR/alive-duration-seconds.txt"
  printf '%s\n' "Full app launch skipped because no launch acceptance groups were affected." > "$LOG_DIR/08-app-launch-skipped.txt"
  exit 0
fi

xcrun simctl boot "$SIMULATOR_UDID" 2>/dev/null || true
xcrun simctl bootstatus "$SIMULATOR_UDID" -b 2>&1 \
  | tee "$LOG_DIR/08-post-tests-bootstatus.log"
xcrun simctl uninstall "$SIMULATOR_UDID" "$BUNDLE_ID" 2>/dev/null || true
xcrun simctl install "$SIMULATOR_UDID" "$APP_PATH"

if [ "$NATIVESCRIPT_POC_ONLY" = "true" ] || [ "$RUN_SIMULATOR_NATIVESCRIPT_POC" = "true" ]; then
  test -z "$(find "$APP_PATH" -path '*fixture-a*' -print -quit)"
  DATA_CONTAINER="$(xcrun simctl get_app_container "$SIMULATOR_UDID" "$BUNDLE_ID" data)"
  FIXTURE_SOURCE="$GITHUB_WORKSPACE/Scripts/NativeScript/Prepared/fixture-a/nativescript/app"
  FIXTURE_DESTINATION="$DATA_CONTAINER/Library/Application Support/HanlinNativeScriptPOC/fixture-a/nativescript/app"
  test -f "$FIXTURE_SOURCE/bundle.mjs"
  test -f "$FIXTURE_SOURCE/package.json"
  test ! -e "$FIXTURE_DESTINATION"
  mkdir -p "$(dirname "$FIXTURE_DESTINATION")"
  ditto "$FIXTURE_SOURCE" "$FIXTURE_DESTINATION"
  test -f "$FIXTURE_DESTINATION/bundle.mjs"
  test -f "$FIXTURE_DESTINATION/package.json"
  {
    echo "install_completed_before_fixture_copy=true"
    echo "app_path=$APP_PATH"
    echo "data_container=$DATA_CONTAINER"
    echo "fixture_destination=$FIXTURE_DESTINATION"
    shasum -a 256 "$FIXTURE_DESTINATION/bundle.mjs"
  } | tee "$LOG_DIR/08-nativescript-post-install-fixture.txt"
fi
touch "$LOG_DIR/launch-marker"

cleanup() {
  xcrun simctl terminate "$SIMULATOR_UDID" "$BUNDLE_ID" 2>/dev/null || true
}
trap cleanup EXIT

if [ "$NATIVESCRIPT_POC_ONLY" = "true" ] || [ "$RUN_SIMULATOR_NATIVESCRIPT_POC" = "true" ]; then
  set +e
  SIMCTL_CHILD_HANLIN_NATIVESCRIPT_POC=1 \
    xcrun simctl launch "$SIMULATOR_UDID" "$BUNDLE_ID" --hanlin-nativescript-poc 2>&1 \
    | tee "$LOG_DIR/08-fast-launch-output.txt"
  launch_status=${PIPESTATUS[0]}
  set -e
  test "$launch_status" -eq 0
  APP_PID="$(awk -F ': ' -v bundle="$BUNDLE_ID" '$1 == bundle { print $2 }' "$LOG_DIR/08-fast-launch-output.txt" | tail -1)"
  test -n "$APP_PID"
  printf '%s\n' "$APP_PID" > "$LOG_DIR/launch-pid.txt"
  for elapsed in $(seq 1 45); do
    xcrun simctl spawn "$SIMULATOR_UDID" log show \
      --style compact \
      --last 10m \
      --predicate "processID == $APP_PID" \
      > "$LOG_DIR/08-application.log" 2>&1 || true
    if grep -Fq 'HANLIN_NS_INITIALIZED_EXTERNAL_ROOT' "$LOG_DIR/08-application.log" \
      && grep -Fq 'HANLIN_NS_FIXTURE_STARTED' "$LOG_DIR/08-application.log" \
      && grep -Fq 'HANLIN_NS_CORE_UI_READY controls=Label,Button' "$LOG_DIR/08-application.log" \
      && grep -Fq 'HANLIN_NS_NATIVE_API_OK' "$LOG_DIR/08-application.log"; then
      break
    fi
    if grep -Fq 'HANLIN_NS_POC_FAILED' "$LOG_DIR/08-application.log"; then
      echo "NativeScript POC reported a bootstrap failure." >&2
      exit 1
    fi
    if ! xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null 2>&1; then
      echo "NativeScript POC app exited before reaching ready state." >&2
      exit 1
    fi
    sleep 1
  done
  grep -Fq 'HANLIN_NS_INITIALIZED_EXTERNAL_ROOT' "$LOG_DIR/08-application.log"
  grep -Fq 'HANLIN_NS_FIXTURE_STARTED' "$LOG_DIR/08-application.log"
  grep -Fq 'HANLIN_NS_CORE_UI_READY controls=Label,Button' "$LOG_DIR/08-application.log"
  grep -Fq 'HANLIN_NS_NATIVE_API_OK' "$LOG_DIR/08-application.log"
  ! grep -Fq 'HANLIN_NS_POC_FAILED' "$LOG_DIR/08-application.log"
  xcrun simctl io "$SIMULATOR_UDID" screenshot "$LOG_DIR/08-nativescript-ui.png"

  for elapsed in $(seq 1 30); do
    xcrun simctl spawn "$SIMULATOR_UDID" log show \
      --style compact \
      --last 10m \
      --predicate "processID == $APP_PID" \
      > "$LOG_DIR/08-application.log" 2>&1 || true
    if grep -Fq 'HANLIN_NS_SHUTDOWN_OK' "$LOG_DIR/08-application.log"; then
      break
    fi
    xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null
    sleep 1
  done
  grep -Fq 'HANLIN_NS_SHUTDOWN_OK' "$LOG_DIR/08-application.log"
  xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null
  sleep 3
  xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null

  : > "$LOG_DIR/08-new-diagnostic-reports.txt"
  for diagnostic_root in \
    "$HOME/Library/Logs/DiagnosticReports" \
    "$HOME/Library/Developer/CoreSimulator/Devices/$SIMULATOR_UDID/data/Library/Logs/CrashReporter" \
    "$HOME/Library/Developer/CoreSimulator/Devices/$SIMULATOR_UDID/data/Library/Logs/DiagnosticReports"; do
    if [ -d "$diagnostic_root" ]; then
      find "$diagnostic_root" -type f -newer "$LOG_DIR/launch-marker" -print \
        >> "$LOG_DIR/08-new-diagnostic-reports.txt"
    fi
  done
  while IFS= read -r diagnostic_report; do
    report_name="$(basename "$diagnostic_report")"
    case "$report_name" in
      "$APP_EXECUTABLE"*|"$BUNDLE_ID"*)
        echo "NativeScript POC generated crash report: $diagnostic_report" >&2
        exit 1
        ;;
    esac
  done < "$LOG_DIR/08-new-diagnostic-reports.txt"
  printf '%s\n' "23" > "$LOG_DIR/alive-duration-seconds.txt"
  printf '%s\n' "nativescript-post-install-poc" > "$LOG_DIR/validation-profile.txt"
  if [ "$NATIVESCRIPT_POC_ONLY" = "true" ] || { [ "$RUN_SIMULATOR_SHELL_ACCEPTANCE" != "true" ] && [ "$RUN_SIMULATOR_MCP_ACCEPTANCE" != "true" ] && [ "$RUN_FULL_VALIDATION" != "true" ]; }; then
    trap - EXIT
    cleanup
    exit 0
  fi
  xcrun simctl terminate "$SIMULATOR_UDID" "$BUNDLE_ID" 2>/dev/null || true
fi

if [ "$FAST_VALIDATION_ONLY" = "true" ] || { [ "$RUN_SIMULATOR_SMOKE_LAUNCH" = "true" ] && [ "$RUN_SIMULATOR_SHELL_ACCEPTANCE" != "true" ] && [ "$RUN_SIMULATOR_MCP_ACCEPTANCE" != "true" ] && [ "$RUN_FULL_VALIDATION" != "true" ]; }; then
  set +e
  xcrun simctl launch "$SIMULATOR_UDID" "$BUNDLE_ID" 2>&1 \
    | tee "$LOG_DIR/08-fast-launch-output.txt"
  launch_status=${PIPESTATUS[0]}
  set -e
  test "$launch_status" -eq 0
  APP_PID="$(awk -F ': ' -v bundle="$BUNDLE_ID" '$1 == bundle { print $2 }' "$LOG_DIR/08-fast-launch-output.txt" | tail -1)"
  test -n "$APP_PID"
  printf '%s\n' "$APP_PID" > "$LOG_DIR/launch-pid.txt"
  for elapsed in $(seq 1 15); do
    xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null
    sleep 1
  done
  xcrun simctl spawn "$SIMULATOR_UDID" log show \
    --style compact \
    --last 2m \
    --predicate "processID == $APP_PID" \
    > "$LOG_DIR/08-application.log" 2>&1 || true
  printf '%s\n' "15" > "$LOG_DIR/alive-duration-seconds.txt"
  printf '%s\n' "fast-debug-tests-and-launch" > "$LOG_DIR/validation-profile.txt"
  trap - EXIT
  cleanup
  exit 0
fi

if [ "$RUN_SIMULATOR_SHELL_ACCEPTANCE" = "true" ] || [ "$RUN_FULL_VALIDATION" = "true" ]; then
  DATA_CONTAINER="$(xcrun simctl get_app_container "$SIMULATOR_UDID" "$BUNDLE_ID" data)"
  ACCEPTANCE_PATH="$DATA_CONTAINER/Library/Application Support/HanlinRuntime/v1/logs/shell-acceptance.json"
  SHELL_LOG_PATH="$DATA_CONTAINER/Library/Application Support/HanlinRuntime/v1/logs/shell-runtime.log"
  rm -f "$ACCEPTANCE_PATH"
  set +e
  SIMCTL_CHILD_HANLIN_CANONICAL_SHADOW_CHECKS=1 \
  SIMCTL_CHILD_HANLIN_RUNTIME_ACCEPTANCE=shell \
    xcrun simctl launch "$SIMULATOR_UDID" "$BUNDLE_ID" 2>&1 | tee "$LOG_DIR/08-launch-output.txt"
  launch_status=${PIPESTATUS[0]}
  set -e
  test "$launch_status" -eq 0
  APP_PID="$(awk -F ': ' -v bundle="$BUNDLE_ID" '$1 == bundle { print $2 }' "$LOG_DIR/08-launch-output.txt" | tail -1)"
  test -n "$APP_PID"
  printf '%s\n' "$APP_PID" > "$LOG_DIR/launch-pid.txt"
  LAUNCH_EPOCH="$(date +%s)"
  for elapsed in $(seq 1 120); do
    if [ -f "$ACCEPTANCE_PATH" ]; then
      break
    fi
    if ! xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null 2>&1; then
      echo "Full app exited before writing shell acceptance JSON after ${elapsed} seconds." >&2
      exit 1
    fi
    sleep 1
  done
  test -f "$ACCEPTANCE_PATH"
  cp "$ACCEPTANCE_PATH" "$LOG_DIR/shell-acceptance.json"
  test -f "$SHELL_LOG_PATH"
  cp "$SHELL_LOG_PATH" "$LOG_DIR/shell-runtime.log"
  python3 Scripts/Runtime/validate_shell_acceptance.py \
    "$LOG_DIR/shell-acceptance.json" \
    --summary-output "$LOG_DIR/08-shell-acceptance-summary.json" \
    | tee "$LOG_DIR/08-shell-acceptance.log"
  python3 - "$LOG_DIR/shell-acceptance.json" <<'PY' | tee "$LOG_DIR/08-shell-canonical-shadow.log"
import json
import sys

payload = json.load(open(sys.argv[1], encoding="utf-8"))
report = payload.get("canonicalShadow")
if report is None:
    raise SystemExit("Shell acceptance did not emit canonical shadow evidence")
domains = {item["domain"]: item for item in report["domains"]}
if report["summary"]["mismatchCount"] != 0:
    raise SystemExit("Shell canonical shadow reported a mismatch")
if domains.get("runtime.core", {}).get("status") != "passed":
    raise SystemExit("Shell RuntimeCore canonical shadow did not pass")
print(
    "HANLIN_CANONICAL_SHADOW_CI acceptance=shell "
    f"passed={report['summary']['passedCount']} "
    f"warnings={report['summary']['warningCount']} "
    f"mismatches={report['summary']['mismatchCount']} "
    f"skipped={report['summary']['skippedCount']}"
)
PY

  ALIVE_SECONDS="$(( $(date +%s) - LAUNCH_EPOCH ))"
  while [ "$ALIVE_SECONDS" -lt 15 ]; do
    xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null
    sleep 1
    ALIVE_SECONDS="$(( $(date +%s) - LAUNCH_EPOCH ))"
  done
  xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$APP_PID" >/dev/null
  printf '%s\n' "$ALIVE_SECONDS" > "$LOG_DIR/alive-duration-seconds.txt"

  xcrun simctl spawn "$SIMULATOR_UDID" log show \
    --style compact \
    --last 5m \
    --predicate "processID == $APP_PID" \
    > "$LOG_DIR/08-application.log" 2>&1 || true

  : > "$LOG_DIR/08-new-diagnostic-reports.txt"
  for diagnostic_root in \
    "$HOME/Library/Logs/DiagnosticReports" \
    "$HOME/Library/Developer/CoreSimulator/Devices/$SIMULATOR_UDID/data/Library/Logs/CrashReporter" \
    "$HOME/Library/Developer/CoreSimulator/Devices/$SIMULATOR_UDID/data/Library/Logs/DiagnosticReports"; do
    if [ -d "$diagnostic_root" ]; then
      find "$diagnostic_root" -type f -newer "$LOG_DIR/launch-marker" -print \
        >> "$LOG_DIR/08-new-diagnostic-reports.txt"
    fi
  done
  while IFS= read -r diagnostic_report; do
    report_name="$(basename "$diagnostic_report")"
    case "$report_name" in
      "$APP_EXECUTABLE"*|"$BUNDLE_ID"*)
        echo "Full app generated crash report: $diagnostic_report" >&2
        exit 1
        ;;
    esac
  done < "$LOG_DIR/08-new-diagnostic-reports.txt"

  xcrun simctl terminate "$SIMULATOR_UDID" "$BUNDLE_ID" 2>/dev/null || true
else
  printf '%s\n' "Shell runtime acceptance skipped by affected-validation router." > "$LOG_DIR/08-shell-acceptance-skipped.txt"
fi

if [ "$RUN_SIMULATOR_MCP_ACCEPTANCE" = "true" ] || [ "$RUN_FULL_VALIDATION" = "true" ]; then
  MCP_ACCEPTANCE_PATH="$DATA_CONTAINER/Library/Application Support/HanlinRuntime/v1/logs/mcp-acceptance.json"
  MCP_RUNTIME_LOG_PATH="$DATA_CONTAINER/Library/Application Support/HanlinRuntime/v1/logs/node-runtime.log"
  rm -f "$MCP_ACCEPTANCE_PATH"
  touch "$LOG_DIR/mcp-launch-marker"
  set +e
  SIMCTL_CHILD_HANLIN_CANONICAL_SHADOW_CHECKS=1 \
  SIMCTL_CHILD_HANLIN_RUNTIME_ACCEPTANCE=mcp \
    xcrun simctl launch "$SIMULATOR_UDID" "$BUNDLE_ID" 2>&1 | tee "$LOG_DIR/08-mcp-launch-output.txt"
  mcp_launch_status=${PIPESTATUS[0]}
  set -e
  test "$mcp_launch_status" -eq 0
  MCP_APP_PID="$(awk -F ': ' -v bundle="$BUNDLE_ID" '$1 == bundle { print $2 }' "$LOG_DIR/08-mcp-launch-output.txt" | tail -1)"
  test -n "$MCP_APP_PID"
  printf '%s\n' "$MCP_APP_PID" > "$LOG_DIR/mcp-launch-pid.txt"
  for elapsed in $(seq 1 360); do
    if [ -f "$MCP_ACCEPTANCE_PATH" ]; then
      break
    fi
    if ! xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$MCP_APP_PID" >/dev/null 2>&1; then
      echo "Full app exited before writing MCP acceptance JSON after ${elapsed} seconds." >&2
      exit 1
    fi
    sleep 1
  done
  test -f "$MCP_ACCEPTANCE_PATH"
  cp "$MCP_ACCEPTANCE_PATH" "$LOG_DIR/mcp-acceptance.json"
  test -f "$MCP_RUNTIME_LOG_PATH"
  cp "$MCP_RUNTIME_LOG_PATH" "$LOG_DIR/node-runtime.log"
  python3 Scripts/Runtime/validate_mcp_acceptance.py \
    "$LOG_DIR/mcp-acceptance.json" \
    --summary-output "$LOG_DIR/08-mcp-acceptance-summary.json" \
    | tee "$LOG_DIR/08-mcp-acceptance.log"
  COMPATIBILITY_REPORT="$(find "$DATA_CONTAINER/Library/Application Support/HanlinRuntime/v1/packages/mcp" -name compatibility-report.json -type f -print -quit)"
  test -n "$COMPATIBILITY_REPORT"
  cp "$COMPATIBILITY_REPORT" "$LOG_DIR/server-everything-compatibility-report.json"
  python3 - "$LOG_DIR/mcp-acceptance.json" <<'PY' | tee "$LOG_DIR/08-mcp-canonical-shadow.log"
import json
import sys

payload = json.load(open(sys.argv[1], encoding="utf-8"))
report = payload.get("canonicalShadow")
if report is None:
    raise SystemExit("MCP acceptance did not emit canonical shadow evidence")
domains = {item["domain"]: item for item in report["domains"]}
if report["summary"]["mismatchCount"] != 0:
    raise SystemExit("MCP canonical shadow reported a mismatch")
for domain in ("native.tools", "mcp", "runtime.core", "cross-domain.tools"):
    if domains.get(domain, {}).get("status") != "passed":
        raise SystemExit(f"{domain} canonical shadow did not pass")
print(
    "HANLIN_CANONICAL_SHADOW_CI acceptance=mcp "
    f"passed={report['summary']['passedCount']} "
    f"warnings={report['summary']['warningCount']} "
    f"mismatches={report['summary']['mismatchCount']} "
    f"skipped={report['summary']['skippedCount']}"
)
PY
  xcrun simctl spawn "$SIMULATOR_UDID" launchctl print "pid/$MCP_APP_PID" >/dev/null
  xcrun simctl terminate "$SIMULATOR_UDID" "$BUNDLE_ID" 2>/dev/null || true

  : > "$LOG_DIR/08-mcp-new-diagnostic-reports.txt"
  for diagnostic_root in \
    "$HOME/Library/Logs/DiagnosticReports" \
    "$HOME/Library/Developer/CoreSimulator/Devices/$SIMULATOR_UDID/data/Library/Logs/CrashReporter" \
    "$HOME/Library/Developer/CoreSimulator/Devices/$SIMULATOR_UDID/data/Library/Logs/DiagnosticReports"; do
    if [ -d "$diagnostic_root" ]; then
      find "$diagnostic_root" -type f -newer "$LOG_DIR/mcp-launch-marker" -print \
        >> "$LOG_DIR/08-mcp-new-diagnostic-reports.txt"
    fi
  done
  while IFS= read -r diagnostic_report; do
    report_name="$(basename "$diagnostic_report")"
    case "$report_name" in
      "$APP_EXECUTABLE"*|"$BUNDLE_ID"*)
        echo "MCP acceptance generated crash report: $diagnostic_report" >&2
        exit 1
        ;;
    esac
  done < "$LOG_DIR/08-mcp-new-diagnostic-reports.txt"
else
  printf '%s\n' "MCP runtime acceptance skipped by affected-validation router." > "$LOG_DIR/08-mcp-acceptance-skipped.txt"
fi
trap - EXIT

