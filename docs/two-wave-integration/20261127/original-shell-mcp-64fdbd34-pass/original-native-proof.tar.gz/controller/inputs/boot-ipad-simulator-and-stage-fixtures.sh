set -euxo pipefail
started_at="$(date +%s)"
APP_PATH="$(cat "$LOG_DIR/app-path.txt")"
BUNDLE_ID="$(/usr/libexec/PlistBuddy -c 'Print CFBundleIdentifier' "$APP_PATH/Info.plist")"
APP_EXECUTABLE="$(/usr/libexec/PlistBuddy -c 'Print CFBundleExecutable' "$APP_PATH/Info.plist")"
ui_plan_selectors="${SIMULATOR_UI_FILTER:-}"
if [ "$RUN_FULL_VALIDATION" = "true" ]; then ui_plan_selectors="AI_HLYUITests"; fi
primary_ui_selectors="$(python3 Scripts/CI/ui_viewport_cohorts.py plan \
  --selectors "$ui_plan_selectors" --output "$LOG_DIR/ui-viewport-plan.json" --primary)"
selection="$(python3 Scripts/CI/select_installed_simulator.py --output "$LOG_DIR/verified-simulator-environment.json" --selectors "$primary_ui_selectors" --create-owned "Hanlin-Phase2-${GITHUB_RUN_ID}-${GITHUB_RUN_ATTEMPT}" --tsv)"
IFS=$'\t' read -r SIMULATOR_UDID SIMULATOR_MODEL SIMULATOR_RUNTIME <<< "$selection"
test -n "$SIMULATOR_UDID"
printf '%s\n' "$SIMULATOR_UDID" > "$LOG_DIR/simulator-udid.txt"
printf '%s\n' "$SIMULATOR_MODEL" > "$LOG_DIR/simulator-model.txt"
printf '%s\n' "$SIMULATOR_RUNTIME" > "$LOG_DIR/simulator-runtime.txt"
printf '%s\n' "$BUNDLE_ID" > "$LOG_DIR/bundle-id.txt"
printf '%s\n' "$APP_EXECUTABLE" > "$LOG_DIR/app-executable.txt"

defer_native_fixtures=false
if [ "$RUN_NATIVESCRIPT_DEPENDENCIES" = "true" ] && [ "$RUN_SIMULATOR_UNIT" = "true" ] && [ "$FAST_VALIDATION_ONLY" != "true" ] \
  && [ -n "${SIMULATOR_UNIT_FILTER:-}" ] && [ "$SIMULATOR_E2E_ONLY" != "true" ] \
  && [ "$NATIVESCRIPT_POC_ONLY" != "true" ] && [ "$RUN_FULL_VALIDATION" != "true" ]; then
  # Install the exact build-for-testing host once through Xcode. Its
  # actual data container is populated below before the requested UI.
  defer_native_fixtures=true
  echo "STAGE_NATIVESCRIPT_AFTER_UNIT=true" >> "$GITHUB_ENV"
fi
if { [ "$RUN_NATIVESCRIPT_DEPENDENCIES" = "true" ] || [ "$RUN_FULL_VALIDATION" = "true" ]; } && [ "$FAST_VALIDATION_ONLY" != "true" ] && [ "$NATIVESCRIPT_POC_ONLY" != "true" ] && [ "$defer_native_fixtures" != "true" ]; then
  python3 Scripts/CI/stage_simulator_fixtures.py \
    --simulator-udid "$SIMULATOR_UDID" \
    --bundle-id "$BUNDLE_ID" \
    --app-path "$APP_PATH" \
    --fixtures-dir "build/NativeScriptE2E" \
    --log-dir "$LOG_DIR"
else
python3 - "$SIMULATOR_UDID" <<'PY'
import os
from pathlib import Path
import sys
from Scripts.CI.stage_simulator_fixtures import BOOT_TIMEOUT_SECONDS, run_bounded
from Scripts.CI.owned_simulator_receipts import record_owned_boot

simulator = sys.argv[1]
run_bounded(["xcrun", "simctl", "boot", simulator], timeout_seconds=15.0)
result = run_bounded(["xcrun", "simctl", "bootstatus", simulator, "-b"], timeout_seconds=BOOT_TIMEOUT_SECONDS)
output = result.stdout + result.stderr
Path(os.environ["LOG_DIR"], "08-bootstatus.log").write_text(output, encoding="utf-8")
print(output, flush=True)
if result.returncode:
    raise SystemExit(f"Simulator boot failed or timed out: {result.returncode}")
record_owned_boot(Path(os.environ["LOG_DIR"]), simulator, result)
PY
  if [ "$defer_native_fixtures" = "true" ]; then
    printf '%s\n' "NativeScript fixtures deferred until actual Xcode unit-host installation." > "$LOG_DIR/08-nativescript-files-staging-deferred.txt"
  else
    printf '%s\n' "NativeScript fixture staging skipped (NativeScript not affected)." > "$LOG_DIR/08-nativescript-files-staging-skipped.txt"
  fi
fi

if [ "$STAGE_SCRIPTUI_FIXTURES" = "true" ] || [ "$RUN_FULL_VALIDATION" = "true" ] || [[ "$SIMULATOR_UI_FILTER" == *"HanlinScriptUIProductionE2ETests"* ]] || [[ "$SIMULATOR_UI_FILTER" == *"HanlinExpoProductionE2ETests"* ]] || [[ "$SIMULATOR_UI_FILTER" == *"HanlinUIPerformanceUITests"* ]]; then
  if [ "$RUN_SIMULATOR_UNIT" = "true" ] && [ -n "${SIMULATOR_UNIT_FILTER:-}" ] \
    && [ "$SIMULATOR_E2E_ONLY" != "true" ] && [ "$NATIVESCRIPT_POC_ONLY" != "true" ] \
    && [ "$RUN_FULL_VALIDATION" != "true" ]; then
    # Xcode installs the exact build-for-testing host for unit execution.
    # Seed its Documents afterwards instead of first installing a different,
    # pruned runtime copy and then replacing it during test-without-building.
    echo "STAGE_SCRIPTUI_AFTER_UNIT=true" >> "$GITHUB_ENV"
    printf '%s\n' "ScriptUI fixtures deferred until successful Xcode unit-host installation." \
      > "$LOG_DIR/08-scriptui-files-staging-deferred.txt"
  else
    python3 Scripts/CI/stage_scriptui_fixtures.py \
      --simulator-udid "$SIMULATOR_UDID" \
      --app-path "$APP_PATH" \
      --bundle-id "$BUNDLE_ID" \
      --log-file "$LOG_DIR/08-scriptui-files-staging.log"
  fi
else
  printf '%s\n' "ScriptUI fixture staging skipped (ScriptUI not affected)." > "$LOG_DIR/08-scriptui-files-staging-skipped.txt"
fi
echo "$(( $(date +%s) - started_at ))" > "$LOG_DIR/08-simulator-staging-duration-seconds.txt"

