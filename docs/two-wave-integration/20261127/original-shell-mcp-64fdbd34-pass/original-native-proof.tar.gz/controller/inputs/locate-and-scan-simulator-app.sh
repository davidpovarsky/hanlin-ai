set -euxo pipefail
APP_PATH="build/SimulatorRuntimeApp/AI_Hanlin.app"
test -d "$APP_PATH"
python3 Scripts/SDK/verify_bundle_resources.py \
  --repository-root . --app "$APP_PATH" \
  --json-output "$LOG_DIR/07-simulator-sdk-bundle-resources.json"
python3 Scripts/CI/validate_chat_localization.py \
  --app "$APP_PATH" --output "$LOG_DIR/07-simulator-sdk-localization.json"
echo "$APP_PATH" > "$LOG_DIR/app-path.txt"
test -f "$APP_PATH/Frameworks/libssh2.framework/libssh2"
test -f "$APP_PATH/Frameworks/openssl.framework/openssl"
test -f "$APP_PATH/Frameworks/curl_ios.framework/curl_ios"
test -f "$APP_PATH/commandDictionary.plist"
test -f "$APP_PATH/extraCommandsDictionary.plist"
plutil -lint "$APP_PATH/commandDictionary.plist"
plutil -lint "$APP_PATH/extraCommandsDictionary.plist"
if [ "$CONFIGURATION" = "Release" ] || [ "$RUN_FULL_VALIDATION" = "true" ]; then
  python3 Scripts/Runtime/validate_ios_system_resources.py \
    --repository-root . \
    --app "$APP_PATH" \
    --json-output "$LOG_DIR/07-simulator-ios-system-resources.json"
else
  printf '%s\n' "Skipped iOS system resources scan in fast Debug targeted validation." > "$LOG_DIR/07-simulator-ios-system-resources-skipped.txt"
fi
if [ "$RUN_NATIVESCRIPT_DEPENDENCIES" = "true" ] || [ "$RUN_FULL_VALIDATION" = "true" ]; then
  npm run preflight:ios-dependencies --prefix Scripts/NativeScript -- --app "$APP_PATH"
else
  printf '%s\n' "Skipped NativeScript dependency preflight scan (NativeScript not affected)." > "$LOG_DIR/07-nativescript-preflight-skipped.txt"
fi
cp "$APP_PATH/commandDictionary.plist" "$LOG_DIR/commandDictionary.plist"
cp "$APP_PATH/extraCommandsDictionary.plist" "$LOG_DIR/extraCommandsDictionary.plist"
find "$APP_PATH" -maxdepth 4 -print | sort > "$LOG_DIR/07-built-app-resources.txt"
if [ "$CONFIGURATION" = "Release" ] && [ "${{ inputs.fast_validation_only }}" != "true" ] && [ "${{ inputs.nativescript_poc_only }}" != "true" ]; then
  python3 Scripts/Runtime/validate-app-dyld-closure.py \
    --app "$APP_PATH" \
    --platform iphonesimulator \
    --json-output "$LOG_DIR/07-simulator-dyld-closure.json" \
    --text-output "$LOG_DIR/07-simulator-dyld-closure.txt"
else
  printf '%s\n' \
    "Skipped production dyld-closure validation for Debug / fast-path targeted validation." \
    > "$LOG_DIR/07-simulator-dyld-closure-skipped.txt"
fi

