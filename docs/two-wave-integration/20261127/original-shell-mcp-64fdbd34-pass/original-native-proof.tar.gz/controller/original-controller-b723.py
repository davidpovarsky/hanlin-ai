import pathlib,subprocess,os,json,hashlib,datetime,time,fcntl,signal,traceback,shutil,sys
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=stage/'source'
inputs=stage/'original-release-b723338e-inputs';binding=json.loads((inputs/'binding.json').read_text())
source=binding['source'];proof=stage/'validation/original-release-b723338e-r1';receipt=stage/'original-release-b723338e-r1.json'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():return shutil.disk_usage(stage).free
def readcmd(args,cwd=root,timeout=20):
 p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
 assert p.returncode==0,{'argv':args,'exit':p.returncode,'stderr':p.stderr}
 return p.stdout
def source_state():
 return {'head':readcmd(['/usr/bin/git','rev-parse','HEAD']).strip(),'status':readcmd(['/usr/bin/git','status','--porcelain']),
 'packageTree':readcmd(['/usr/bin/git','rev-parse','HEAD:Packages/HanlinPlatform']).strip(),
 'sourcesTree':readcmd(['/usr/bin/git','rev-parse','HEAD:Packages/HanlinPlatform/Sources']).strip(),
 'testsTree':readcmd(['/usr/bin/git','rev-parse','HEAD:Packages/HanlinPlatform/Tests']).strip(),
 'workflowSHA256':digest(root/'.github/workflows/build-ios26-unsigned-ipa.yml'),
 'pins':{rel:digest(root/rel) for rel in binding['pins']}}
def verify_input_closure():
 mpath=pathlib.Path(binding['sdkManifest']['path']);assert digest(mpath)==binding['sdkManifest']['sha256']
 m=json.loads(mpath.read_text());assert m['inputSHA256']==binding['sdkManifest']['inputSHA256'] and len(m['sourceInputs'])==392
 for row in m['sourceInputs']:assert digest(root/row['path'])==row['sha256'],row['path']
 for row in binding['criticalInputs']:assert digest(pathlib.Path(row['path']))==row['sha256'],row['path']
 return {'actualSDKInputsMatched':392,'sdkInputSHA256':m['inputSHA256'],'sdkManifestSHA256':digest(mpath),'criticalInputCount':len(binding['criticalInputs'])}
data={'status':'PREPARING','source':source,'controllerPID':os.getpid(),'controllerSHA256':digest(pathlib.Path(__file__)),'startedAt':now(),'originalJobDeadlineSeconds':14400,'phases':[],'commandsStarted':0,'bindingSHA256':digest(inputs/'binding.json'),'route':'Original Release AI_HLY arm64 Simulator build, resource/dyld scans, owned Simulator creation/boot, original combined Shell120/MCP360 acceptance and 15s alive proof. Prior603/79/Host188 not repeated.','capacityPlan':binding['capacityPlan'],'localRunIdentity':binding['localRunIdentity']}
env=os.environ.copy()
for key in list(env):
 if key in ['GITHUB_ACTIONS','GITHUB_RUN_ID','GITHUB_RUN_ATTEMPT','HANLIN_LOCAL_RUN_ID','HANLIN_LOCAL_RUN_ATTEMPT'] or key.startswith('SIMCTL_CHILD_HANLIN_'):
  env.pop(key,None)
env.update(binding['environment'])
env['PATH']=str(stage/'tool-bin')+':/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin'
env['DEVELOPER_DIR']='/Applications/Xcode.app/Contents/Developer'
env['NSUnbufferedIO']='YES'
jobStart=time.monotonic();ownership=None
def save():
 p=receipt.with_suffix('.tmp');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(receipt)
def stop_owned(p,row,reason):
 row['stopReason']=reason;save()
 if p.poll() is None:
  assert os.getpgid(p.pid)==p.pid
  os.killpg(p.pid,signal.SIGINT)
  try:return p.wait(timeout=30)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:return p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);return p.wait()
 return p.returncode
def phase(name,argv):
 assert time.monotonic()-jobStart<14400,'original overall deadline exhausted before next command'
 pth=proof/(name+'-controller.log');row={'name':name,'command':argv,'cwd':str(root),'startedAt':now(),'log':str(pth),'freeBefore':free()};data['phases'].append(row);save()
 if len(argv)>1 and pathlib.Path(argv[1]).is_file():row['scriptSHA256']=digest(pathlib.Path(argv[1]))
 with pth.open('wb') as f:
  p=subprocess.Popen(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  row.update(pid=p.pid,pgid=os.getpgid(p.pid),status='RUNNING');data['commandsStarted']+=1;data['status']='RUNNING';save()
  try:
   while True:
    try:rc=p.wait(timeout=5);break
    except subprocess.TimeoutExpired:
     row['lastObservation']={'at':now(),'freeBytes':free(),'logBytes':pth.stat().st_size,'jobElapsedSeconds':round(time.monotonic()-jobStart,3)};save()
     if free()<750000000:rc=stop_owned(p,row,'ACTUAL_DISK_RESERVE');break
     if time.monotonic()-jobStart>=14400:rc=stop_owned(p,row,'ORIGINAL_14400_SECOND_JOB_DEADLINE');break
  except BaseException:
   stop_owned(p,row,'CONTROLLER_EXCEPTION');raise
 row.update(exitCode=rc,status='PASSED' if rc==0 and not row.get('stopReason') else 'FAILED',finishedAt=now(),logSHA256=digest(pth),freeAfter=free());save()
 assert row['status']=='PASSED',{'phase':name,'exit':rc,'stopReason':row.get('stopReason')}
def disk_size(p):
 return int(readcmd(['/usr/bin/du','-sk',str(p)],timeout=45).split()[0])*1024
def verify_created(require_boot=False):
 sys.path.insert(0,str(root))
 from Scripts.CI.owned_simulator_receipts import verify_owned_simulator_creation,verify_owned_simulator
 identity=binding['localRunIdentity']
 verifier=verify_owned_simulator if require_boot else verify_owned_simulator_creation
 return verifier(proof,identity['run_id'],identity['run_attempt'],run_provider='local-mac')
def simulator_snapshot(uuid):
 result=json.loads(readcmd(['/usr/bin/xcrun','simctl','list','devices','--json'],timeout=30))
 matches=[{'runtime':rt,**d} for rt,devices in result['devices'].items() for d in devices if d.get('udid','').upper()==uuid.upper()]
 assert len(matches)==1
 return matches[0]
def verify_simulator_native(owner):
 selected=json.loads((proof/'verified-simulator-environment.json').read_text());actual=simulator_snapshot(owner['simulator'])
 assert actual['name']==binding['localRunIdentity']['name'] and actual['runtime']==selected['runtime']['identifier'] and actual['deviceTypeIdentifier']==selected['device']['deviceTypeIdentifier'] and actual.get('isAvailable') is True
 return actual
lock=open('/Users/m1/caches/hanlin-two-wave-native-app.lock','a+')
maintenance=open('/Users/m1/caches/.scaleway-cache-maintenance.lock','a+')
try:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(maintenance,fcntl.LOCK_SH|fcntl.LOCK_NB)
 assert not proof.exists() and not receipt.exists(),'unique attempt already exists'
 proof.mkdir(parents=True);(proof/'github-env').write_text('')
 data['coordinationLocks']={'native':'exclusive','maintenance':'shared'}
 data['sourceBefore']=source_state()
 for k in ['packageTree','sourcesTree','testsTree','workflowSHA256','pins']:assert data['sourceBefore'][k]==binding[k],k
 assert data['sourceBefore']['head']==source and data['sourceBefore']['status']==''
 data['inputClosureBefore']=verify_input_closure()
 for name,row in binding['scripts'].items():
  assert digest(inputs/name)==row['originalSHA256']
  assert digest(inputs/(name+'.executed'))==row['executedSHA256']
 data['toolchain']={'xcode':readcmd(['/usr/bin/xcodebuild','-version']),'swift':readcmd(['/usr/bin/swift','--version']),'simSDK':readcmd(['/usr/bin/xcrun','--sdk','iphonesimulator','--show-sdk-version']),'simSDKBuild':readcmd(['/usr/bin/xcrun','--sdk','iphonesimulator','--show-sdk-build-version'])}
 data['psBefore']=readcmd(['/bin/ps','-axo','pid=,ppid=,pgid=,etime=,comm='],timeout=10)
 data['vmStatBefore']=readcmd(['/usr/bin/vm_stat'])
 data['freeAtAdmission']=free();plan=binding['capacityPlan']
 data['requiredBuildAllowanceBytes']=sum(plan[k] for k in ['freshBuildAllowance','runtimeCopyAllowance','resultLogAllowance','observedSharedGrowthAllowance','OSReserve'])
 assert data['freeAtAdmission']>=data['requiredBuildAllowanceBytes'],{'free':data['freeAtAdmission'],'allowance':data['requiredBuildAllowanceBytes']}
 for path in ['SimulatorDerivedData','SimulatorRuntimeApp']:assert not (root/'build'/path).exists(),'fresh original output root must not overwrite another owner'
 data['sourcePackagesBefore']={'path':str(root/'build/SourcePackages'),'inode':(root/'build/SourcePackages').stat().st_ino,'allocatedBytes':disk_size(root/'build/SourcePackages')}
 save()
 phase('original-runtimecore-preflight',['/bin/bash',str(root/'Scripts/Runtime/preflight-runtime-core.sh')])
 phase('original-build-full-arm64-simulator-app',['/bin/bash',str(inputs/'build-full-arm64-simulator-app.sh.executed')])
 data['inputClosureAfterBuild']=verify_input_closure();save()
 phase('original-locate-and-scan-simulator-app',['/bin/bash',str(inputs/'locate-and-scan-simulator-app.sh.executed')])
 app=root/(proof/'app-path.txt').read_text().strip();assert app.is_dir()
 appBytes=disk_size(app);data['actualRuntimeAppBeforeBoot']={'path':str(app),'allocatedBytes':appBytes}
 bootNeed=plan['observedPriorOwnedDeviceBytes']+appBytes+plan['observedSharedGrowthAllowance']+plan['OSReserve']
 data['bootAdmission']={'at':now(),'freeBytes':free(),'requiredBytes':bootNeed,'basis':'Previously measured owned iPad data plus actual app install bytes, shared growth allowance and OS reserve. Build/copy outputs are already allocated.'};save()
 assert free()>=bootNeed,{'phase':'before-owned-simulator','capacity':data['bootAdmission']}
 phase('original-boot-ipad-simulator-and-stage-fixtures',['/bin/bash',str(inputs/'boot-ipad-simulator-and-stage-fixtures.sh.executed')])
 ownership=verify_created(require_boot=True);data['ownership']=ownership;data['simulatorBeforeLaunch']=verify_simulator_native(ownership);save()
 phase('original-launch-full-app-and-verify-runtime-acceptance',['/bin/bash',str(inputs/'launch-full-app-and-verify-runtime-acceptance.sh.executed')])
 for rel in ['shell-acceptance.json','08-shell-acceptance-summary.json','mcp-acceptance.json','08-mcp-acceptance-summary.json','server-everything-compatibility-report.json','08-shell-canonical-shadow.log','08-mcp-canonical-shadow.log','alive-duration-seconds.txt']:
  p=proof/rel;assert p.is_file(),rel
 assert int((proof/'alive-duration-seconds.txt').read_text().strip())>=15
 data['originalRuntimeEvidence']=[{'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(proof.iterdir()) if p.is_file() and p.suffix in ['.json','.log','.txt']]
 data['sourceAfter']=source_state();assert data['sourceAfter']==data['sourceBefore'],'source/pins changed'
 data['inputClosureAfter']=verify_input_closure()
 data['originalSourceAndPinsUnchanged']=True;data['status']='PASSED'
except BaseException as e:
 data['status']='FAILED' if data['commandsStarted'] else 'NOT_RUN';data['error']=str(e);data['traceback']=traceback.format_exc()
finally:
 try:
  if (proof/'simulator-udid.txt').exists() and (proof/'verified-simulator-environment.json').exists():
   owner=verify_created();actual=verify_simulator_native(owner)
   data['ownedCleanup']={'ownership':owner,'actualBefore':actual}
   if actual.get('state')=='Booted':
    p=subprocess.run(['/usr/bin/xcrun','simctl','shutdown',owner['simulator']],capture_output=True,text=True,timeout=45)
    data['ownedCleanup'].update(command=p.args,exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr)
    assert p.returncode==0
    data['ownedCleanup']['actualAfter']=verify_simulator_native(owner)
  data['finishedAt']=now();data['freeEnd']=free();data['jobElapsedSeconds']=round(time.monotonic()-jobStart,3)
 except BaseException as e:
  data['ownedCleanupError']=str(e)
  if data['status']=='PASSED':data['status']='FAILED_CLEANUP'
 finally:
  save();maintenance.close();lock.close()
