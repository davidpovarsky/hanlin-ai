// Evidence-only public SDK declaration admission. Never built into the app.
// The existing domain entity is replaced by String solely to avoid fake modules.
// This does not validate the shipping action, decoder, metadata, or runtime.
import AppIntents
import Foundation
import UniformTypeIdentifiers

struct TypedListParameterAdmission: AppIntent {
    static let title: LocalizedStringResource = "Typed List declaration admission"

    @Parameter(title: LocalizedStringResource("Action", table: "HanlinAppIntents"))
    var action: String

    @Parameter(title: LocalizedStringResource("Input Type", table: "HanlinAppIntents"), default: .text)
    var inputType: MiniAppsShortcutInputType

    @Parameter(title: LocalizedStringResource("Input", table: "HanlinAppIntents"), default: "")
    var input: String

    @Parameter(title: LocalizedStringResource("JSON File", table: "HanlinAppIntents"), supportedContentTypes: [.json])
    var jsonFile: IntentFile?

    @Parameter(title: LocalizedStringResource("Allow Long Running", table: "HanlinAppIntents"), default: false)
    var allowLongRunning: Bool

    // Optional additions preserve previously saved actions with no list fields.
    @Parameter(title: LocalizedStringResource("Text List", table: "HanlinAppIntents"))
    var textItems: [String]?

    @Parameter(title: LocalizedStringResource("Integer List", table: "HanlinAppIntents"))
    var integerItems: [Int]?

    @Parameter(title: LocalizedStringResource("Number List", table: "HanlinAppIntents"))
    var numberItems: [Double]?

    @Parameter(title: LocalizedStringResource("Boolean List", table: "HanlinAppIntents"))
    var booleanItems: [Bool]?

    static var parameterSummary: some ParameterSummary {
        Switch(\.$inputType) {
            Case(.textList) {
                Summary("Run \(\.$action) with \(\.$textItems)") {
                    \.$inputType
                    \.$allowLongRunning
                }
            }
            Case(.integerList) {
                Summary("Run \(\.$action) with \(\.$integerItems)") {
                    \.$inputType
                    \.$allowLongRunning
                }
            }
            Case(.numberList) {
                Summary("Run \(\.$action) with \(\.$numberItems)") {
                    \.$inputType
                    \.$allowLongRunning
                }
            }
            Case(.booleanList) {
                Summary("Run \(\.$action) with \(\.$booleanItems)") {
                    \.$inputType
                    \.$allowLongRunning
                }
            }
            DefaultCase() {
                Summary("Run \(\.$action) with \(\.$input)") {
                    \.$inputType
                    \.$jsonFile
                    \.$allowLongRunning
                }
            }
        }
    }

    init() {}

    func perform() async throws -> some IntentResult { .result() }
}

enum MiniAppsShortcutInputType: String, AppEnum {
    case text, json, jsonFile
    case textList, integerList, numberList, booleanList

    static let typeDisplayRepresentation = TypeDisplayRepresentation(name: LocalizedStringResource("MiniApp Input", table: "HanlinAppIntents"))
    static let caseDisplayRepresentations: [Self: DisplayRepresentation] = [
        .text: DisplayRepresentation(title: LocalizedStringResource("Text", table: "HanlinAppIntents")),
        .json: DisplayRepresentation(title: LocalizedStringResource("Dictionary or List (JSON)", table: "HanlinAppIntents")),
        .jsonFile: DisplayRepresentation(title: LocalizedStringResource("JSON File", table: "HanlinAppIntents")),
        .textList: DisplayRepresentation(title: LocalizedStringResource("Text List", table: "HanlinAppIntents")),
        .integerList: DisplayRepresentation(title: LocalizedStringResource("Integer List", table: "HanlinAppIntents")),
        .numberList: DisplayRepresentation(title: LocalizedStringResource("Number List", table: "HanlinAppIntents")),
        .booleanList: DisplayRepresentation(title: LocalizedStringResource("Boolean List", table: "HanlinAppIntents"))
    ]
}

