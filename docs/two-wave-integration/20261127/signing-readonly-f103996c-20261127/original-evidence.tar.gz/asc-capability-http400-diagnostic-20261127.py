import pathlib,os,sys,time,json,base64,datetime,urllib.request,urllib.parse,urllib.error
import jwt
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126')
out=stage/'asc-capability-http400-diagnostic-20261127.json'
assert not out.exists()
now=int(time.time())
token=jwt.encode({'iss':os.environ['ASC_ISSUER_ID'],'iat':now,'exp':now+600,'aud':'appstoreconnect-v1'},pathlib.Path(os.environ['ASC_KEY_PATH']).read_bytes(),algorithm='ES256',headers={'kid':os.environ['ASC_KEY_ID'],'typ':'JWT'})
class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,req,fp,code,msg,headers,newurl):return None
path='/v1/bundleIds/F7CR948R94/bundleIdCapabilities'
data={'readOnly':True,'method':'GET','path':path,'source':'f103996cc03d2cc5321c7e83b6cdf77c3b60e509','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempts':[]}
for params in ({'limit':200},{}):
 req=urllib.request.Request('https://api.appstoreconnect.apple.com'+path+('?' + urllib.parse.urlencode(params) if params else ''),headers={'Authorization':'Bearer '+token},method='GET')
 row={'parameters':params}
 try:
  with urllib.request.build_opener(NoRedirect).open(req,timeout=30) as res:
   raw=res.read(2*1024*1024+1);assert len(raw)<=2*1024*1024;result=json.loads(raw);row['httpStatus']=res.status
  row['nextPagePresent']=bool(result.get('links',{}).get('next'))
  row['capabilities']=[{'capabilityType':x.get('attributes',{}).get('capabilityType'),'settings':x.get('attributes',{}).get('settings')} for x in result.get('data',[])]
 except urllib.error.HTTPError as error:
  row['httpStatus']=error.code
  try:
   result=json.loads(error.read(16384))
   row['errors']=[{k:str(x[k])[:800] for k in ('status','code','title','detail','source') if k in x} for x in result.get('errors',[])[:4]]
  except Exception:row['errorBody']='UNPARSEABLE_NOT_RECORDED'
 data['attempts'].append(row)
out.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data),flush=True)
