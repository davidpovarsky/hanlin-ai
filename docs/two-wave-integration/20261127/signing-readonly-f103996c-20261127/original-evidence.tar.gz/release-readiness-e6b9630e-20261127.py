import pathlib,json,sys,subprocess,os,datetime,hashlib,plistlib,base64,traceback,ssl,re
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=stage/'source';out=stage/'release-readiness-e6b9630e-20261127.json'
source='e6b9630e62cef3d5a90a5bcd44890974ffcf6afc';now=datetime.datetime.now(datetime.timezone.utc)
sys.path.insert(0,str(root/'Scripts/ProductSplit'))
import audit_release_resources as audit
data={'source':source,'at':now.isoformat(),'status':'RUNNING','readOnly':True,'certificateMutation':False,'profileMutation':False,'archive':False,'upload':False,'physicalAcceptance':'NOT_RUN','products':[],'ascBuildNumbers':[],'newBundleResources':[]}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save():
 t=out.with_suffix('.tmp');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(out)
def command(args,timeout=30):
 p=subprocess.run(args,capture_output=True,timeout=timeout)
 if p.returncode:raise RuntimeError('Command failed: '+pathlib.Path(args[0]).name+' exit '+str(p.returncode))
 return p.stdout
try:
 assert not out.exists()
 assert command(['/usr/bin/git','-C',str(root),'rev-parse','HEAD']).decode().strip()==source
 assert os.environ['APPLE_TEAM_ID']=='NA6HPWARQ2';team=os.environ['APPLE_TEAM_ID'];data['team']=team
 assert len(audit.ROLES)==13
 identity='644940FCF25D1730DBD1BF7596AEBA7229E2B8FD';cert_sha='5aefaf80b344410af7da85678fcb19de9a4be6885a846644df974b1ee38eba4b'
 ids=command(['/usr/bin/security','find-identity','-v','-p','codesigning',os.environ['APPLE_SIGNING_KEYCHAIN']]).decode()
 data['identity']={'sha1':identity,'presentInValidIdentityList':identity in ids,'privateKeyExported':False,'keychainScope':'configured-existing-keychain','keychain':os.environ['APPLE_SIGNING_KEYCHAIN']}
 assert data['identity']['presentInValidIdentityList']
 public=command(['/usr/bin/security','find-certificate','-a','-c','Apple Distribution','-p',os.environ['APPLE_SIGNING_KEYCHAIN']]).decode()
 matches=[]
 for pem in re.findall(r'-----BEGIN CERTIFICATE-----[\s\S]+?-----END CERTIFICATE-----',public):
  der=ssl.PEM_cert_to_DER_cert(pem)
  if hashlib.sha1(der).hexdigest().upper()==identity:
   assert hashlib.sha256(der).hexdigest()==cert_sha
   p=subprocess.run(['/usr/bin/openssl','x509','-noout','-dates','-subject'],input=pem.encode(),capture_output=True,timeout=20)
   assert p.returncode==0
   matches.append({'publicSHA256':cert_sha,'datesAndSubject':p.stdout.decode().splitlines()})
 assert len(matches)>=1
 data['identity']['publicCertificate']=matches[0]
 decoded={};files=[];failures=[]
 for directory in [pathlib.Path.home()/'Library/MobileDevice/Provisioning Profiles',pathlib.Path.home()/'Library/Developer/Xcode/UserData/Provisioning Profiles']:
  if not directory.is_dir():continue
  paths=sorted(directory.glob('*.mobileprovision'));assert len(paths)<=1024
  for path in paths:
   if path.is_symlink():failures.append({'path':str(path),'reason':'SYMLINK_PRESERVED'});continue
   digest=sha(path)
   if digest not in decoded:
    p=subprocess.run(['/usr/bin/security','cms','-D','-k',os.environ['APPLE_SIGNING_KEYCHAIN'],'-i',str(path)],capture_output=True,timeout=20)
    if p.returncode:failures.append({'path':str(path),'reason':'CMS_DECODE_FAILED'});continue
    decoded[digest]=plistlib.loads(p.stdout)
   files.append((path,digest))
 data['decodedUniqueProfileCount']=len(decoded);data['profileReadFailures']=failures
 import importlib.metadata
 data['signingToolVersions']={n:importlib.metadata.version(n) for n in ['PyJWT','cryptography']}
 data['decoderScope']='Original security cms -D with documented -k selecting the configured existing keychain; no default search-list mutation.'
 for role,bundle,_,entitlement in audit.ROLES:
  requiredPath=root/entitlement;required=plistlib.loads(requiredPath.read_bytes());candidates=[]
  for path,digest in files:
   profile=decoded[digest]
   appid=profile.get('Entitlements',{}).get('application-identifier','')
   if not appid.endswith('.'+bundle):continue
   result=audit.evaluate_profile(profile,required,bundle,team,cert_sha,now)
   candidates.append({'path':str(path),'sha256':digest,'uuid':profile.get('UUID'),'name':profile.get('Name'),**result})
  passed=sorted([x for x in candidates if x['status']=='READY_RESOURCE'],key=lambda x:x['expiration'],reverse=True)
  row={'role':role,'bundleID':bundle,'entitlementsPath':entitlement,'entitlementsSHA256':sha(requiredPath),'requiredEntitlements':required,'status':'READY_RESOURCE' if passed else 'MISSING_COMPATIBLE_LOCAL_PROFILE','selected':passed[0] if passed else None,'candidates':candidates}
  data['products'].append(row)
 data['localReadyCount']=sum(x['status']=='READY_RESOURCE' for x in data['products']);save()
 # Use the installed original ASC key only in this process. Never emit or persist credential bytes.
 keypath=pathlib.Path(os.environ['ASC_KEY_PATH'])
 assert keypath.is_file()
 os.environ['ASC_KEY_P8']=base64.b64encode(keypath.read_bytes()).decode()
 for bundle,number in [('com.itorah.chavrusachat','149301'),('com.itorah.hanlinminiapps','8401')]:
  apps=audit.apple_get('/v1/apps',{'filter[bundleId]':bundle,'limit':200})
  assert not apps.get('links',{}).get('next')
  exact=[x for x in apps.get('data',[]) if x.get('attributes',{}).get('bundleId')==bundle]
  assert len(exact)==1,'App identity not unique'
  app_id=exact[0]['id']
  result=audit.apple_get('/v1/builds',{'filter[app]':app_id,'filter[version]':number,'fields[builds]':'version,processingState,uploadedDate,expired','limit':200})
  assert not result.get('links',{}).get('next')
  values=result.get('data',[]);assert isinstance(values,list)
  data['ascBuildNumbers'].append({'bundleID':bundle,'appID':app_id,'proposedBuildNumber':number,'queriedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'ABSENT_AT_ASC_READBACK' if not values else 'ALREADY_PRESENT','matchingBuilds':[{'id':v['id'],**v.get('attributes',{})} for v in values]});save()
 for row in data['products']:
  if row['role'] not in ['miniapps_keyboard','miniapps_notification_content','miniapps_camera_capture']:continue
  response=audit.apple_get('/v1/bundleIds',{'filter[identifier]':row['bundleID'],'fields[bundleIds]':'identifier,name,platform,seedId','limit':200})
  assert not response.get('links',{}).get('next')
  exact=audit.exact_bundles(response,row['bundleID'])
  item={'role':row['role'],'bundleID':row['bundleID'],'exactRegisteredIDs':[{'id':v['id'],**v.get('attributes',{})} for v in exact],'status':'REGISTERED' if len(exact)==1 else 'MISSING_OR_AMBIGUOUS'}
  if len(exact)==1:
   response=audit.apple_get('/v1/bundleIds/'+exact[0]['id']+'/bundleIdCapabilities',{'limit':200})
   assert not response.get('links',{}).get('next')
   item['capabilities']=[{'id':v['id'],'capabilityType':v.get('attributes',{}).get('capabilityType'),'settings':v.get('attributes',{}).get('settings')} for v in response.get('data',[])]
  data['newBundleResources'].append(item);save()
 data['status']='READ_ONLY_RESOURCE_QUALIFICATION_COMPLETE'
except Exception as e:
 data['status']='READ_ONLY_RESOURCE_QUALIFICATION_PARTIAL'
 data['errorKind']=type(e).__name__
 data['error']=str(e) if isinstance(e,(AssertionError,audit.AppleReadFailure)) else 'Read-only prerequisite failed; no account mutation performed.'
finally:
 os.environ.pop('ASC_KEY_P8',None)
 data['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 print(json.dumps(data),flush=True)
if data['status']!='READ_ONLY_RESOURCE_QUALIFICATION_COMPLETE':raise SystemExit(1)
