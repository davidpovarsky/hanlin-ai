import pathlib, sys, os, json, datetime, hashlib, subprocess, plistlib, tempfile, base64
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126')
root=stage/'source'
out=stage/'release-bundle-profile-readback-f103996c-20261127.json'
sys.path.insert(0,str(root/'Scripts/ProductSplit'))
import audit_release_resources as audit
now=datetime.datetime.now(datetime.timezone.utc)
data={'status':'RUNNING','at':now.isoformat(),'source':subprocess.check_output(['/usr/bin/git','-C',str(root),'rev-parse','HEAD'],text=True).strip(),'readOnly':True,'httpMethods':['GET'],'certificateMutation':False,'profileMutation':False,'profileInstall':False,'archive':False,'upload':False,'priorPartialReceipt':'release-readiness-e6b9630e-20261127.json','queryCorrection':{'priorFields':'identifier,name,platform,seedId','currentFields':'identifier,platform','canonicalExistingProducer':'Scripts/ProductSplit/resolve_signing_profiles.py','producerSHA256':hashlib.sha256((root/'Scripts/ProductSplit/resolve_signing_profiles.py').read_bytes()).hexdigest()},'products':[]}
def save():
 t=out.with_suffix('.tmp');t.write_text(json.dumps(data,indent=2)+'\n');t.replace(out)
try:
 assert not out.exists()
 assert data['source']=='f103996cc03d2cc5321c7e83b6cdf77c3b60e509'
 assert os.environ['APPLE_TEAM_ID']=='NA6HPWARQ2'
 team=os.environ['APPLE_TEAM_ID'];certsha='5aefaf80b344410af7da85678fcb19de9a4be6885a846644df974b1ee38eba4b'
 os.environ['ASC_KEY_P8']=base64.b64encode(pathlib.Path(os.environ['ASC_KEY_PATH']).read_bytes()).decode()
 for role,bundle,_,ent in audit.ROLES:
  if role not in ('miniapps_keyboard','miniapps_notification_content','miniapps_camera_capture'):continue
  row={'role':role,'bundleID':bundle,'entitlementsSHA256':hashlib.sha256((root/ent).read_bytes()).hexdigest(),'status':'QUERYING','examinedProfiles':[]}
  data['products'].append(row);save()
  r=audit.apple_get('/v1/bundleIds',{'filter[identifier]':bundle,'fields[bundleIds]':'identifier,platform','limit':200})
  assert not r.get('links',{}).get('next')
  exact=audit.exact_bundles(r,bundle);assert len(exact)==1,'Original bundle not unique'
  row['bundleResourceID']=exact[0]['id'];row['registration']='EXACT_ORIGINAL_BUNDLE'
  r=audit.apple_get('/v1/bundleIds/'+row['bundleResourceID']+'/bundleIdCapabilities',{'limit':200})
  assert not r.get('links',{}).get('next')
  row['capabilities']=[{'capabilityType':x.get('attributes',{}).get('capabilityType'),'settings':x.get('attributes',{}).get('settings')} for x in r.get('data',[])]
  r=audit.apple_get('/v1/bundleIds/'+row['bundleResourceID']+'/profiles',{'fields[profiles]':'profileType,profileState','limit':200})
  assert not r.get('links',{}).get('next')
  candidates=[x for x in r.get('data',[]) if x.get('attributes',{}).get('profileType')=='IOS_APP_STORE' and x.get('attributes',{}).get('profileState')=='ACTIVE']
  row['activeAppStoreProfileCount']=len(candidates)
  assert len(candidates)<=8,'More than bounded eight existing profiles'
  required=plistlib.loads((root/ent).read_bytes())
  for candidate in candidates:
   result=audit.apple_get('/v1/profiles/'+candidate['id'],{'fields[profiles]':'profileType,profileState,profileContent'})
   attr=result['data']['attributes'];assert (attr['profileType'],attr['profileState'])==('IOS_APP_STORE','ACTIVE')
   raw=base64.b64decode(attr['profileContent'],validate=True)
   with tempfile.TemporaryDirectory(prefix='hanlin-readonly-profile-') as folder:
    p=pathlib.Path(folder)/'input.mobileprovision';p.write_bytes(raw);p.chmod(0o600)
    proc=subprocess.run(['/usr/bin/security','cms','-D','-k',os.environ['APPLE_SIGNING_KEYCHAIN'],'-i',str(p)],capture_output=True,timeout=20)
    assert proc.returncode==0,'Existing portal profile CMS decode failed'
    profile=plistlib.loads(proc.stdout)
   check=audit.evaluate_profile(profile,required,bundle,team,certsha,datetime.datetime.now(datetime.timezone.utc))
   row['examinedProfiles'].append({'profileResourceID':candidate['id'],'profileSHA256':hashlib.sha256(raw).hexdigest(),'uuid':profile.get('UUID'),**check})
   save()
  row['compatibleRemoteProfileCount']=sum(x.get('status')=='READY_RESOURCE' for x in row['examinedProfiles'])
  row['status']='READY_RESOURCE' if row['compatibleRemoteProfileCount'] else 'MISSING_COMPATIBLE_REMOTE_PROFILE'
  row['queryComplete']=True;save()
 assert len(data['products'])==3
 data['status']='READ_ONLY_BUNDLE_PROFILE_READBACK_COMPLETE'
 data['compatibleRemoteRoleCount']=sum(x['status']=='READY_RESOURCE' for x in data['products'])
except Exception as e:
 data['status']='READ_ONLY_BUNDLE_PROFILE_READBACK_PARTIAL';data['errorKind']=type(e).__name__
 data['error']=str(e) if isinstance(e,(AssertionError,audit.AppleReadFailure)) else 'Sanitized read-only prerequisite failure'
finally:
 os.environ.pop('ASC_KEY_P8',None)
 data['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 print(json.dumps(data),flush=True)
if data['status']!='READ_ONLY_BUNDLE_PROFILE_READBACK_COMPLETE':raise SystemExit(1)
