import Foundation
#if canImport(FoundationModels)
import FoundationModels
#endif

@main
struct HanlinFoundationModelsAvailabilityQuery {
    static func main() throws {
        let availability: String
        #if canImport(FoundationModels)
        if #available(macOS 26.0, *) {
            switch SystemLanguageModel.default.availability {
            case .available: availability = "available"
            case .unavailable(.deviceNotEligible): availability = "deviceNotEligible"
            case .unavailable(.appleIntelligenceNotEnabled): availability = "intelligenceDisabled"
            case .unavailable(.modelNotReady): availability = "modelNotReady"
            case .unavailable: availability = "unavailable"
            @unknown default: availability = "unavailable"
            }
        } else {
            availability = "unsupportedOS"
        }
        #else
        availability = "frameworkUnavailable"
        #endif
        let result: [String: Any] = [
            "schemaVersion": 1, "query": "SystemLanguageModel.default.availability",
            "availability": availability, "platform": "macOS",
            "osVersion": ProcessInfo.processInfo.operatingSystemVersionString,
            "modelExecution": "NOT_RUN", "toolExecution": "NOT_RUN"
        ]
        let data = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(decoding: data, as: UTF8.self))
    }
}
