set -euxo pipefail
swift package --package-path "$PACKAGE_PATH" resolve \
  2>&1 | tee "$LOG_DIR/03-swift-package-resolve.log"

