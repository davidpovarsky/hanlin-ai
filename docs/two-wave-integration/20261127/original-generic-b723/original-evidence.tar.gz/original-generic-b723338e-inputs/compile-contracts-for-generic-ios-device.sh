set -euxo pipefail
rm -rf "$LOG_DIR/Phase1Device.xcresult"
build_actions=(build)
if [ "${{ inputs.force_clean_build }}" = "true" ]; then
  build_actions=(clean build)
fi
started_at="$(date +%s)"
xcodebuild \
  -scheme "$PACKAGE_XCODE_SCHEME" \
  -configuration Debug \
  -sdk iphoneos \
  -destination "generic/platform=iOS" \
  -derivedDataPath "$GITHUB_WORKSPACE/build/Phase1DeviceDerivedData" \
  -resultBundlePath "$LOG_DIR/Phase1Device.xcresult" \
  -showBuildTimingSummary \
  CODE_SIGNING_ALLOWED=NO \
  SWIFT_STRICT_CONCURRENCY=complete \
  "${build_actions[@]}" 2>&1 | tee "$LOG_DIR/08-ios-device.log"
echo "$(( $(date +%s) - started_at ))" > "$LOG_DIR/08-ios-device-duration-seconds.txt"

