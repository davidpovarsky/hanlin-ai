set -euxo pipefail
swift build --package-path "$PACKAGE_PATH" \
  2>&1 | tee "$LOG_DIR/04-swift-build.log"

