set -euxo pipefail
rm -rf "$LOG_DIR/Phase1Simulator.xcresult"
build_actions=(build)
if [ "${{ inputs.force_clean_build }}" = "true" ]; then
  build_actions=(clean build)
fi
started_at="$(date +%s)"
xcodebuild \
  -scheme "$PACKAGE_XCODE_SCHEME" \
  -configuration Debug \
  -sdk iphonesimulator \
  -destination "generic/platform=iOS Simulator" \
  -derivedDataPath "$GITHUB_WORKSPACE/build/Phase1SimulatorDerivedData" \
  -resultBundlePath "$LOG_DIR/Phase1Simulator.xcresult" \
  -showBuildTimingSummary \
  CODE_SIGNING_ALLOWED=NO \
  SWIFT_STRICT_CONCURRENCY=complete \
  "${build_actions[@]}" 2>&1 | tee "$LOG_DIR/07-ios-simulator.log"
echo "$(( $(date +%s) - started_at ))" > "$LOG_DIR/07-ios-simulator-duration-seconds.txt"

