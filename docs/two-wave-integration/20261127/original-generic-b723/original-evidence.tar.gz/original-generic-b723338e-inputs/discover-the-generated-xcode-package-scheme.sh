set -euxo pipefail
xcodebuild -list -json \
  > "$LOG_DIR/06-xcodebuild-list.json" \
  2> >(tee "$LOG_DIR/06-xcodebuild-list.stderr.log" >&2)
cat "$LOG_DIR/06-xcodebuild-list.json"
package_scheme="$(python3 - "$LOG_DIR/06-xcodebuild-list.json" <<'PY'
import json
import sys

with open(sys.argv[1], encoding="utf-8") as stream:
    document = json.load(stream)
container = document.get("workspace") or document.get("project") or {}
schemes = container.get("schemes") or []
if "HanlinPlatform-Package" in schemes:
    print("HanlinPlatform-Package")
elif len(schemes) == 1:
    print(schemes[0])
else:
    raise SystemExit(f"Expected one generated package scheme, found: {schemes}")
PY
)"
test -n "$package_scheme"
echo "PACKAGE_XCODE_SCHEME=$package_scheme" >> "$GITHUB_ENV"
echo "Selected generated package scheme: $package_scheme"

