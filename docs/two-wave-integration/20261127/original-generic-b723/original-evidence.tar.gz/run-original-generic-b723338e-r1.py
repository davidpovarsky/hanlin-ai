import pathlib,subprocess,os,json,hashlib,datetime,time,fcntl,signal,traceback,shutil
stage=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=stage/'source';package=root/'Packages/HanlinPlatform'
inputs=stage/'original-generic-b723338e-inputs';binding=json.loads((inputs/'binding.json').read_text())
source=binding['source'];proof=stage/'validation/original-generic-b723338e-r1';receipt=stage/'original-generic-b723338e-r1.json'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def free():return shutil.disk_usage(stage).free
def readcmd(args,cwd=root,timeout=20):
 p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
 assert p.returncode==0,{'argv':args,'exit':p.returncode,'stderr':p.stderr}
 return p.stdout
def source_state():
 return {'head':readcmd(['/usr/bin/git','rev-parse','HEAD']).strip(),'status':readcmd(['/usr/bin/git','status','--porcelain']),
 'packageTree':readcmd(['/usr/bin/git','rev-parse','HEAD:Packages/HanlinPlatform']).strip(),
 'sourcesTree':readcmd(['/usr/bin/git','rev-parse','HEAD:Packages/HanlinPlatform/Sources']).strip(),
 'testsTree':readcmd(['/usr/bin/git','rev-parse','HEAD:Packages/HanlinPlatform/Tests']).strip(),
 'workflowSHA256':digest(root/'.github/workflows/build-ios26-unsigned-ipa.yml'),
 'pins':{str(p.relative_to(root)):digest(p) for p in [package/'Package.resolved',root/'AI_HLY.xcodeproj/project.xcworkspace/xcshareddata/swiftpm/Package.resolved'] if p.exists()}}
data={'status':'PREPARING','source':source,'controllerPID':os.getpid(),'controllerSHA256':digest(pathlib.Path(__file__)),'startedAt':now(),'originalJobDeadlineSeconds':3600,'phases':[],'nativeCommandsStarted':0,'bindingSHA256':digest(inputs/'binding.json'),'route':'Original explicit resolve/build, original generated scheme discovery, original generic Simulator and device commands; existing603+actual79 PASS preserved without test repeat.','capacityPlan':binding['capacityPlan'],'inputQualification':binding['priorEvidenceDecision']}
env=os.environ.copy();env.update({'PATH':str(stage/'tool-bin')+':/usr/bin:/bin:/usr/sbin:/sbin:/opt/homebrew/bin','DEVELOPER_DIR':'/Applications/Xcode.app/Contents/Developer','PACKAGE_PATH':'Packages/HanlinPlatform','GITHUB_WORKSPACE':str(root),'LOG_DIR':str(proof),'GITHUB_ENV':str(proof/'github-env'),'NSUnbufferedIO':'YES'})
jobStart=time.monotonic()
def save():
 p=receipt.with_suffix('.tmp');p.write_text(json.dumps(data,indent=2)+'\n');p.replace(receipt)
def stop_owned(p,row,reason):
 row['stopReason']=reason;save()
 if p.poll() is None:
  assert os.getpgid(p.pid)==p.pid
  os.killpg(p.pid,signal.SIGINT)
  try:return p.wait(timeout=30)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:return p.wait(timeout=10)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);return p.wait()
 return p.returncode
def phase(name,script,cwd):
 assert time.monotonic()-jobStart<3600,'original overall deadline exhausted before next command'
 pth=proof/(name+'-controller.log');row={'name':name,'command':['/bin/bash',str(script)],'scriptSHA256':digest(script),'cwd':str(cwd),'startedAt':now(),'log':str(pth),'freeBefore':free()};data['phases'].append(row);save()
 with pth.open('wb') as f:
  p=subprocess.Popen(row['command'],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  row.update(pid=p.pid,pgid=os.getpgid(p.pid),status='RUNNING');data['nativeCommandsStarted']+=1;data['status']='RUNNING';save()
  try:
   while True:
    try:rc=p.wait(timeout=5);break
    except subprocess.TimeoutExpired:
     row['lastObservation']={'at':now(),'freeBytes':free(),'logBytes':pth.stat().st_size,'jobElapsedSeconds':round(time.monotonic()-jobStart,3)};save()
     if free()<750000000:rc=stop_owned(p,row,'ACTUAL_DISK_RESERVE');break
     if time.monotonic()-jobStart>=3600:rc=stop_owned(p,row,'ORIGINAL_3600_SECOND_JOB_DEADLINE');break
  except BaseException:
   stop_owned(p,row,'CONTROLLER_EXCEPTION');raise
 row.update(exitCode=rc,status='PASSED' if rc==0 and not row.get('stopReason') else 'FAILED',finishedAt=now(),logSHA256=digest(pth),freeAfter=free());save()
 assert row['status']=='PASSED',{'phase':name,'exit':rc,'stopReason':row.get('stopReason')}
lock=open('/Users/m1/caches/hanlin-two-wave-native-app.lock','a+')
maintenance=open('/Users/m1/caches/.scaleway-cache-maintenance.lock','a+')
try:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);fcntl.flock(maintenance,fcntl.LOCK_SH|fcntl.LOCK_NB)
 assert not proof.exists() and not receipt.exists(),'unique attempt already exists'
 proof.mkdir(parents=True);(proof/'github-env').write_text('')
 data['coordinationLocks']={'native':'exclusive','maintenance':'shared'}
 data['sourceBefore']=source_state()
 for k in ['packageTree','sourcesTree','testsTree','workflowSHA256']:assert data['sourceBefore'][k]==binding[k],k
 assert data['sourceBefore']['head']==source and data['sourceBefore']['status']==''
 prior=stage/'full-platform-1ee9c457-r1.json';assert digest(prior)==binding['priorFull603ReceiptSHA256']
 p603=json.loads(prior.read_text());assert p603['exitCode']==0 and p603['originalFullSuitePassed'] and p603['command']==['/usr/bin/swift','test','--package-path','Packages/HanlinPlatform','--parallel']
 assert not p603.get('stopReason')
 data['qualified603']={'actualSource':p603['source'],'command':p603['command'],'receiptSHA256':digest(prior),'sameCurrentPackageTree':True,'notRerun':True}
 data['toolchain']={'xcode':readcmd(['/usr/bin/xcodebuild','-version']),'swift':readcmd(['/usr/bin/swift','--version']),'simSDK':readcmd(['/usr/bin/xcrun','--sdk','iphonesimulator','--show-sdk-version']),'deviceSDK':readcmd(['/usr/bin/xcrun','--sdk','iphoneos','--show-sdk-version'])}
 data['psBefore']=readcmd(['/bin/ps','-axo','pid=,ppid=,pgid=,etime=,comm='],timeout=10)
 data['vmStatBefore']=readcmd(['/usr/bin/vm_stat'])
 data['freeAtAdmission']=free();plan=binding['capacityPlan'];data['requiredPhaseAllowanceBytes']=sum(plan[k] for k in ['genericOutputs','warmSwiftIncrementalAllowance','additionalSourceCacheAllowance','observedSharedGrowthAllowance','OSReserve'])
 assert data['freeAtAdmission']>=data['requiredPhaseAllowanceBytes'],{'free':data['freeAtAdmission'],'allowance':data['requiredPhaseAllowanceBytes']}
 for path in ['Phase1SimulatorDerivedData','Phase1DeviceDerivedData']:assert not (root/'build'/path).exists(),'fresh generic output root must not overwrite other owner'
 for name,expect in binding['scripts'].items():
  original=inputs/name;assert digest(original)==expect['sha256'];body=original.read_text();render=body.replace('$'+'{{ inputs.force_clean_build }}','false')
  assert '$'+'{{' not in render
  (inputs/(name+'.executed')).write_text(render)
 data['inputScripts']=[{'original':str(inputs/n),'originalSHA256':v['sha256'],'executed':str(inputs/(n+'.executed')),'executedSHA256':digest(inputs/(n+'.executed')),'onlyWorkflowExpressionResolution':n.startswith('compile-contracts')} for n,v in binding['scripts'].items()]
 save()
 for name in ['resolve-the-phase-1-swift-package.sh','compile-the-phase-1-swift-package.sh']:
  phase(name.removesuffix('.sh'),inputs/(name+'.executed'),root)
 phase('discover-generated-package-scheme',inputs/'discover-the-generated-xcode-package-scheme.sh.executed',package)
 lines=(proof/'github-env').read_text().splitlines();values=[x.partition('=')[2] for x in lines if x.startswith('PACKAGE_XCODE_SCHEME=')]
 assert len(values)==1 and values[0] and '\n' not in values[0]
 env['PACKAGE_XCODE_SCHEME']=values[0];data['originalGeneratedScheme']=values[0];save()
 for name in ['compile-contracts-for-generic-ios-simulator.sh','compile-contracts-for-generic-ios-device.sh']:
  phase(name.removesuffix('.sh'),inputs/(name+'.executed'),package)
 data['sourceAfter']=source_state();assert data['sourceAfter']==data['sourceBefore'],'source/pins changed'
 data['originalSourceAndPinsUnchanged']=True
 data['status']='PASSED'
except BaseException as e:
 data['status']='FAILED' if data['nativeCommandsStarted'] else 'NOT_RUN';data['error']=str(e);data['traceback']=traceback.format_exc()
finally:
 data['finishedAt']=now();data['freeEnd']=free();data['jobElapsedSeconds']=round(time.monotonic()-jobStart,3)
 try:save()
 finally:maintenance.close();lock.close()
