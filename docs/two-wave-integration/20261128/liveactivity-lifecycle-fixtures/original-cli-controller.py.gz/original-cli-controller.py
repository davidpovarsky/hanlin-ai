import pathlib,json,hashlib,subprocess,os,stat,time,datetime,gzip,zipfile,binascii,shutil,signal,traceback
O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("x") as f:json.dump(value,f,indent=2);f.write("\n")
a_bytes=(O/"admission.json").read_bytes()
assert sha(a_bytes)=="cbf80beac548489529cd4e17610d57bb243b9aee86bdd2f79b45c95edfedbf89"
a=json.loads(a_bytes);W=pathlib.Path(a["worktree"]);HEAD=a["head"]
def git(*args):
 p=subprocess.run(["runuser","-u","chatgpt-agent","--","git","-c","safe.directory="+str(W),"-c","gc.auto=0","-c","maintenance.auto=false","-C",str(W),*args],capture_output=True)
 assert p.returncode==0,p.stderr.decode()[-1200:]
 return p.stdout
record={"startedAt":now(),"source":HEAD,"status":"ADMISSION_IN_PROGRESS","engines":[],"commands":[],"nativeCommands":0,"scope":a["scope"],"failure":None}
source_before=None;sdk_before=None
def source_state():
 rows=[]
 for row in a["fixtureAndCLIInputs"]:
  p=W/row["path"];b=p.read_bytes()
  assert b==git("show",HEAD+":"+row["path"]) and sha(b)==row["sha256"] and len(b)==row["bytes"],row["path"]
  rows.append({"path":row["path"],"bytes":len(b),"sha256":sha(b)})
 for row in a["authoringTrees"]:assert git("rev-parse",HEAD+":"+row["path"]).decode().strip()==row["currentFc5Object"]
 return rows
def sdk_state(name):
 sdk=pathlib.Path(a["sdk"]["path"]);actual={}
 for p in sorted(sdk.rglob("*")):
  if p.is_file():
   assert p.resolve().is_relative_to(sdk.resolve()),str(p)
   b=p.read_bytes();actual[str(p.relative_to(sdk))]={"bytes":len(b),"mode":stat.S_IMODE(p.stat().st_mode),"sha256":sha(b)}
 raw=(json.dumps(actual,indent=2)+"\n").encode();packed=gzip.compress(raw,mtime=0);(O/(name+".json.gz")).write_bytes(packed)
 index=pathlib.Path(a["sdk"]["retainedPhysicalIndex"]["path"]);assert sha(index.read_bytes())==a["sdk"]["retainedPhysicalIndex"]["sha256"]
 expected=json.loads(index.read_bytes())
 save(name+"-record.json",{"files":len(actual),"jsonBytes":len(raw),"jsonSHA256":sha(raw),"gzipBytes":len(packed),"gzipSHA256":sha(packed),"equalPriorIndex":actual==expected})
 assert actual==expected,{"changedSDKPaths":[p for p in sorted(set(actual)|set(expected)) if actual.get(p)!=expected.get(p)][:20]}
 return actual
def run_phase(engine,item):
 op=item["operation"];cap=item["originalBoundSeconds"];assert (op,cap) in [("validate",300),("build",600)]
 out=O/engine;out.mkdir(exist_ok=True);project=W/"Fixtures/LiveActivityLifecycle"/engine
 argv=[a["node"]["path"] if x=="node" else x.replace("<current-qualified-SDK>",a["sdk"]["path"]).replace("<owned-output>",str(out)).replace("Fixtures/LiveActivityLifecycle/"+engine,str(project)) for x in item["commandTemplate"]]
 started=time.monotonic();cmd={"engine":engine,"operation":op,"argv":argv,"cwd":str(W),"timeoutSeconds":cap,"startedAt":now(),"stopActions":[]}
 with (out/(op+".stdout.log")).open("xb") as stdout,(out/(op+".stderr.log")).open("xb") as stderr:
  p=subprocess.Popen(argv,cwd=W,stdout=stdout,stderr=stderr,start_new_session=True)
  cmd.update({"pid":p.pid,"pgid":os.getpgid(p.pid)});assert cmd["pgid"]==p.pid;save(engine+"/"+op+"-launch.json",cmd)
  try:code=p.wait(timeout=max(0.001,cap-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:
   cmd["stopReason"]="Original command deadline"
   if p.poll() is None and os.getpgid(p.pid)==p.pid:os.killpg(p.pid,signal.SIGTERM);cmd["stopActions"].append("SIGTERM owned group")
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    if p.poll() is None and os.getpgid(p.pid)==p.pid:os.killpg(p.pid,signal.SIGKILL);cmd["stopActions"].append("SIGKILL owned group")
    code=p.wait(timeout=5)
 cmd.update({"exit":code,"finishedAt":now(),"seconds":time.monotonic()-started})
 report_path=out/(engine+"-"+op+".json")
 report=None
 if report_path.exists():
  report=json.loads(report_path.read_bytes());cmd.update({"reportSHA256":sha(report_path.read_bytes()),"succeeded":report.get("succeeded"),"compiler":report.get("sdk"),"typecheck":report.get("typecheck"),"diagnosticCount":len(report.get("diagnostics",[]))})
 record["commands"].append(cmd);save(engine+"/"+op+"-result.json",cmd)
 assert code==0 and report is not None and report["succeeded"] is True and not cmd.get("stopReason"),"Original "+engine+" "+op+" failed"
 assert report["typecheck"]["strict"] is True and report["typecheck"]["skipLibCheck"] is False and report["typecheck"]["dependencyDeclarationsChecked"] is True
 return report
def archive_reconciliation(engine,build):
 out=O/engine;generated=W/"Fixtures/LiveActivityLifecycle"/engine/".hanlin-build"
 archive=pathlib.Path(build["archivePath"]);prepared=pathlib.Path(build["preparedPackagePath"])
 assert archive.is_relative_to(out) and archive.is_file() and prepared.is_relative_to(generated) and prepared.is_dir()
 files={str(p.relative_to(prepared)):p for p in prepared.rglob("*") if p.is_file()};rows=[]
 with zipfile.ZipFile(archive) as z:
  infos=z.infolist();assert len(infos)==len({x.filename for x in infos}) and all(not x.is_dir() for x in infos)
  assert {x.filename for x in infos}==set(files)
  for info in infos:
   b=z.read(info.filename);assert b==files[info.filename].read_bytes() and len(b)==info.file_size and binascii.crc32(b)&0xffffffff==info.CRC
   rows.append({"path":info.filename,"bytes":len(b),"sha256":sha(b),"crc32":f"{info.CRC:08x}","zipMode":info.external_attr>>16,"sourceMode":stat.S_IMODE(files[info.filename].stat().st_mode)})
 value={"archive":{"path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes())},"preparedPackagePath":str(prepared),"files":rows,"allOriginalGeneratedBytesAndCRCVerified":True}
 save(engine+"/archive-reconciliation.json",value)
 return {"archive":value["archive"],"archiveMembers":len(rows)}
try:
 assert git("rev-parse","HEAD").decode().strip()==HEAD and not git("status","--porcelain=v1")
 for key in ["sourceReview","integration","originalController"]:
  assert sha(pathlib.Path(a[key]["path"]).read_bytes())==a[key]["sha256"],key
 source_before=source_state();save("source-before.json",source_before)
 node=pathlib.Path(a["node"]["path"]);assert sha(node.read_bytes())==a["node"]["sha256"]
 version=subprocess.run([str(node),"--version"],capture_output=True,text=True,timeout=10);assert version.returncode==0 and version.stdout.strip()==a["node"]["version"]
 assert not os.environ.get("HANLIN_AUTHORING_TYPESCRIPT") and not os.environ.get("NODE_OPTIONS")
 sdk=pathlib.Path(a["sdk"]["path"]);manifest=sdk/"miniapp-sdk.json";assert sha(manifest.read_bytes())==a["sdk"]["manifest"]["sha256"]
 save("environment-selection.json",{"uid":os.getuid(),"node":a["node"],"actualNodeVersion":version.stdout.strip(),"HANLIN_AUTHORING_TYPESCRIPT":os.environ.get("HANLIN_AUTHORING_TYPESCRIPT"),"NODE_OPTIONS":os.environ.get("NODE_OPTIONS"),"compilerOverrideIntroduced":False,"sdkManifestSHA256":sha(manifest.read_bytes())})
 sdk_before=sdk_state("sdk-before")
 for engine in a["engines"]:
  name=engine["engine"];result={"engine":name,"status":"RUNNING","failure":None}
  try:
   assert sha(pathlib.Path(engine["originalAuthorityPath"]).read_bytes())==engine["originalAuthoritySHA256"]
   project=W/"Fixtures/LiveActivityLifecycle"/name
   assert not (project/".hanlin-build").exists()
   assert {str(p.relative_to(W)) for p in project.rglob("*") if p.is_file()}=={r["path"] for r in a["fixtureAndCLIInputs"] if r["path"].startswith("Fixtures/LiveActivityLifecycle/"+name+"/")}
   reports={}
   for phase in engine["phases"]:reports[phase["operation"]]=run_phase(name,phase)
   result.update(archive_reconciliation(name,reports["build"]));result["status"]="PASS_ORIGINAL_PORTABLE_VALIDATE_BUILD"
  except Exception as error:
   result.update({"status":"FAIL_OR_ADMISSION_BLOCKED","failure":{"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}})
  finally:
   generated=W/"Fixtures/LiveActivityLifecycle"/name/".hanlin-build"
   if generated.exists():
    rows=[]
    for p in sorted(generated.rglob("*")):
     if p.is_file():
      b=p.read_bytes();rows.append({"path":str(p.relative_to(generated)),"bytes":len(b),"sha256":sha(b),"mode":stat.S_IMODE(p.stat().st_mode)})
    save(name+"/generated-files.json",rows);shutil.move(str(generated),str(O/name/"generated-hanlin-build"))
    result["retainedGeneratedFiles"]=len(rows)
   save(name+"/receipt.json",result);record["engines"].append(result)
 after=source_state();save("source-after.json",after);assert source_before==after
 sdk_after=sdk_state("sdk-after");assert sdk_before==sdk_after
 assert git("rev-parse","HEAD").decode().strip()==HEAD and not git("status","--porcelain=v1")
 record.update({"sourceFilesUnchanged":True,"sdkCompleteBytesModesUnchanged":True,"sdkPhysicalFiles":len(sdk_after),"worktreeClean":True})
 record["status"]="PASS_BOTH_ORIGINAL_PORTABLE_VALIDATE_BUILD" if len(record["engines"])==2 and all(x["status"]=="PASS_ORIGINAL_PORTABLE_VALIDATE_BUILD" for x in record["engines"]) else "FAIL_ONE_OR_MORE_ENGINES"
except Exception as error:
 record.update({"status":"FAIL_OR_ADMISSION_BLOCKED","failure":{"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}})
finally:
 record["finishedAt"]=now();save("receipt.json",record);print(json.dumps(record))
