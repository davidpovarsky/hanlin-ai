import pathlib,json,hashlib,subprocess,os,stat,time,datetime,gzip,zipfile,binascii,shutil,signal,traceback
O=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open("x") as f:json.dump(value,f,indent=2);f.write("\n")
a_bytes=(O/"admission.json").read_bytes()
assert sha(a_bytes)=="cbf80beac548489529cd4e17610d57bb243b9aee86bdd2f79b45c95edfedbf89"
a=json.loads(a_bytes);W=pathlib.Path(a["worktree"]);HEAD=a["head"]
def git(*args):
 p=subprocess.run(["runuser","-u","chatgpt-agent","--","git","-c","safe.directory="+str(W),"-c","gc.auto=0","-c","maintenance.auto=false","-C",str(W),*args],capture_output=True)
 assert p.returncode==0,p.stderr.decode()[-1200:]
 return p.stdout
record={"startedAt":now(),"source":HEAD,"status":"ADMISSION_IN_PROGRESS","engines":[],"commands":[],"nativeCommands":0,"scope":a["scope"],"failure":None}
source_before=None;sdk_before=None
def source_state():
 rows=[]
 for row in a["fixtureAndCLIInputs"]:
  p=W/row["path"];b=p.read_bytes()
  assert b==git("show",HEAD+":"+row["path"]) and sha(b)==row["sha256"] and len(b)==row["bytes"],row["path"]
  rows.append({"path":row["path"],"bytes":len(b),"sha256":sha(b)})
 for row in a["authoringTrees"]:assert git("rev-parse",HEAD+":"+row["path"]).decode().strip()==row["currentFc5Object"]
 return rows
def sdk_state(name):
 sdk=pathlib.Path(a["sdk"]["path"]);actual={}
 for p in sorted(sdk.rglob("*")):
  if p.is_file():
   assert p.resolve().is_relative_to(sdk.resolve()),str(p)
   b=p.read_bytes();actual[str(p.relative_to(sdk))]={"bytes":len(b),"mode":stat.S_IMODE(p.stat().st_mode),"sha256":sha(b)}
 raw=(json.dumps(actual,indent=2)+"\n").encode();packed=gzip.compress(raw,mtime=0);(O/(name+".json.gz")).write_bytes(packed)
 index=pathlib.Path(a["sdk"]["retainedPhysicalIndex"]["path"]);assert sha(index.read_bytes())==a["sdk"]["retainedPhysicalIndex"]["sha256"]
 expected=json.loads(index.read_bytes())
 save(name+"-record.json",{"files":len(actual),"jsonBytes":len(raw),"jsonSHA256":sha(raw),"gzipBytes":len(packed),"gzipSHA256":sha(packed),"equalPriorIndex":actual==expected})
 assert actual==expected,{"changedSDKPaths":[p for p in sorted(set(actual)|set(expected)) if actual.get(p)!=expected.get(p)][:20]}
 return actual
def run_phase(engine,item):
 op=item["operation"];cap=item["originalBoundSeconds"];assert (op,cap) in [("validate",300),("build",600)]
 out=O/engine;out.mkdir(exist_ok=True);project=W/"Fixtures/LiveActivityLifecycle"/engine
 argv=[a["node"]["path"] if x=="node" else x.replace("<current-qualified-SDK>",a["sdk"]["path"]).replace("<owned-output>",str(out)).replace("Fixtures/LiveActivityLifecycle/"+engine,str(project)) for x in item["commandTemplate"]]
 started=time.monotonic();cmd={"engine":engine,"operation":op,"argv":argv,"cwd":str(W),"timeoutSeconds":cap,"startedAt":now(),"stopActions":[]}
 with (out/(op+".stdout.log")).open("xb") as stdout,(out/(op+".stderr.log")).open("xb") as stderr:
  p=subprocess.Popen(argv,cwd=W,stdout=stdout,stderr=stderr,start_new_session=True)
  cmd.update({"pid":p.pid,"pgid":os.getpgid(p.pid)});assert cmd["pgid"]==p.pid;save(engine+"/"+op+"-launch.json",cmd)
  try:code=p.wait(timeout=max(0.001,cap-(time.monotonic()-started)))
  except subprocess.TimeoutExpired:
   cmd["stopReason"]="Original command deadline"
   if p.poll() is None and os.getpgid(p.pid)==p.pid:os.killpg(p.pid,signal.SIGTERM);cmd["stopActions"].append("SIGTERM owned group")
   try:code=p.wait(timeout=5)
   except subprocess.TimeoutExpired:
    if p.poll() is None and os.getpgid(p.pid)==p.pid:os.killpg(p.pid,signal.SIGKILL);cmd["stopActions"].append("SIGKILL owned group")
    code=p.wait(timeout=5)
 cmd.update({"exit":code,"finishedAt":now(),"seconds":time.monotonic()-started})
 report_path=out/(engine+"-"+op+".json")
 report=None
 if report_path.exists():
  report=json.loads(report_path.read_bytes());cmd.update({"reportSHA256":sha(report_path.read_bytes()),"succeeded":report.get("succeeded"),"compiler":report.get("sdk"),"typecheck":report.get("typecheck"),"diagnosticCount":len(report.get("diagnostics",[]))})
 record["commands"].append(cmd);save(engine+"/"+op+"-result.json",cmd)
 assert code==0 and report is not None and report["succeeded"] is True and not cmd.get("stopReason"),"Original "+engine+" "+op+" failed"
 assert report["typecheck"]==historical_ns["typecheck"] and report["sdk"]["compilerVersion"]==historical_ns["sdk"]["compilerVersion"]
 return report
def archive_reconciliation(engine,build):
 out=O/engine;generated=W/"Fixtures/LiveActivityLifecycle"/engine/".hanlin-build"
 archive=pathlib.Path(build["archivePath"]);prepared=pathlib.Path(build["preparedPackagePath"])
 assert archive.is_relative_to(out) and archive.is_file() and prepared.is_relative_to(generated) and prepared.is_dir()
 files={str(p.relative_to(prepared)):p for p in prepared.rglob("*") if p.is_file()};rows=[]
 with zipfile.ZipFile(archive) as z:
  infos=z.infolist();assert len(infos)==len({x.filename for x in infos}) and all(not x.is_dir() for x in infos)
  assert {x.filename for x in infos}==set(files)
  for info in infos:
   b=z.read(info.filename);assert b==files[info.filename].read_bytes() and len(b)==info.file_size and binascii.crc32(b)&0xffffffff==info.CRC
   rows.append({"path":info.filename,"bytes":len(b),"sha256":sha(b),"crc32":f"{info.CRC:08x}","zipMode":info.external_attr>>16,"sourceMode":stat.S_IMODE(files[info.filename].stat().st_mode)})
 value={"archive":{"path":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes())},"preparedPackagePath":str(prepared),"files":rows,"allOriginalGeneratedBytesAndCRCVerified":True}
 save(engine+"/archive-reconciliation.json",value)
 return {"archive":value["archive"],"archiveMembers":len(rows)}
P=O.parent
try:
 old_bytes=(P/"receipt.json").read_bytes()
 assert sha(old_bytes)=="638b80a13e3e80005834f233c2a468d171b7bf25c27d3b7ad5fa19a6a6367c86"
 old=json.loads(old_bytes);assert len(old["commands"])==3 and old["source"]==HEAD and old["sourceFilesUnchanged"] and old["sdkCompleteBytesModesUnchanged"] and old["worktreeClean"]
 assert not (P/"nativescript/build-launch.json").exists() and not (P/"nativescript/build-result.json").exists()
 assert [(x["engine"],x["operation"],x["exit"]) for x in old["commands"]]==[("expo","validate",0),("expo","build",0),("nativescript","validate",0)]
 H=P.parent
 original_ns=H/"native-lists-shortcuts-3634078f/portable-cli-r1/validate-report.json"
 assert sha(original_ns.read_bytes())=="a88c6a605c7e9c88f1880f00869917cf4fafee18e17808850475bf088782fdf5"
 historical_ns=json.loads(original_ns.read_bytes());actual_ns=json.loads((P/"nativescript/nativescript-validate.json").read_bytes())
 assert historical_ns["succeeded"] and actual_ns["succeeded"] and actual_ns["typecheck"]==historical_ns["typecheck"] and actual_ns["sdk"]["compilerVersion"]==historical_ns["sdk"]["compilerVersion"]=="5.9.3"
 sdk=pathlib.Path(a["sdk"]["path"]);cfg=sdk/"nativescript/tsconfig.json"
 assert sha(cfg.read_bytes())=="0618a10c5d065ed7afa8c2e45163d8a55f6f41d87f479a40d917fee25275336c"
 assert json.loads(cfg.read_bytes())["compilerOptions"]["skipLibCheck"] is True
 assert git("rev-parse","HEAD").decode().strip()==HEAD and not git("status","--porcelain=v1")
 assert sha(pathlib.Path(a["node"]["path"]).read_bytes())==a["node"]["sha256"]
 assert not os.environ.get("HANLIN_AUTHORING_TYPESCRIPT") and not os.environ.get("NODE_OPTIONS")
 assert sha((sdk/"miniapp-sdk.json").read_bytes())==a["sdk"]["manifest"]["sha256"]
 source_before=source_state();save("source-before.json",source_before)
 sdk_before=sdk_state("sdk-before")
 save("qualification-correction.json",{"previousReceiptSHA256":sha(old_bytes),"previousWrapperError":"The wrapper applied Expo declaration flags to NativeScript after its successful original validate, and stopped before any NativeScript build.","unchangedOriginalNativeScriptReportSHA256":sha(original_ns.read_bytes()),"unchangedOriginalSDKTsconfigSHA256":sha(cfg.read_bytes()),"actualNativeScriptValidation":actual_ns["typecheck"],"compilerVersion":"5.9.3","commandsRepeated":0,"commandNow":"Only the never-started original NativeScript build600","productionOrSDKChanges":0})
 engine=next(x for x in a["engines"] if x["engine"]=="nativescript");phase=next(x for x in engine["phases"] if x["operation"]=="build")
 generated=W/"Fixtures/LiveActivityLifecycle/nativescript/.hanlin-build";assert not generated.exists()
 build=run_phase("nativescript",phase)
 result={"engine":"nativescript","status":"PASS_ORIGINAL_PORTABLE_BUILD",**archive_reconciliation("nativescript",build)}
 rows=[]
 for p in sorted(generated.rglob("*")):
  if p.is_file():
   b=p.read_bytes();rows.append({"path":str(p.relative_to(generated)),"bytes":len(b),"sha256":sha(b),"mode":stat.S_IMODE(p.stat().st_mode)})
 save("nativescript/generated-files.json",rows);shutil.move(str(generated),str(O/"nativescript/generated-hanlin-build"));result["retainedGeneratedFiles"]=len(rows);record["engines"].append(result)
 after=source_state();save("source-after.json",after);assert source_before==after
 sdk_after=sdk_state("sdk-after");assert sdk_before==sdk_after
 assert git("rev-parse","HEAD").decode().strip()==HEAD and not git("status","--porcelain=v1")
 record.update({"status":"PASS_BOTH_ORIGINAL_ENGINE_RECIPES_WITH_QUALIFIED_WRAPPER_CORRECTION","previousReceiptSHA256":sha(old_bytes),"sourceFilesUnchanged":True,"sdkCompleteBytesModesUnchanged":True,"sdkPhysicalFiles":len(sdk_after),"worktreeClean":True,"commandsRepeated":0,"commandsExecutedInContinuation":1,"priorActualValidatedPhases":[{"engine":x["engine"],"operation":x["operation"],"exit":x["exit"],"reportSHA256":x["reportSHA256"]} for x in old["commands"]],"scope":"Expo original validate/build and NS original validate remain retained from prior exact attempt; only NS original build600 executes here. Actual NS strict source retains original skipLibCheck=true and TypeScript5.9.3; no SDK/compiler flag modification. Native/final shipping SDK gates separate."})
except Exception as error:
 record.update({"status":"FAIL_OR_ADMISSION_BLOCKED","failure":{"type":type(error).__name__,"message":str(error),"traceback":traceback.format_exc()}})
finally:
 record["finishedAt"]=now();save("receipt.json",record);print(json.dumps(record))
