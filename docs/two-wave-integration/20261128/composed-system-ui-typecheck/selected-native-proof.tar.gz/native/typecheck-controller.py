from __future__ import annotations
import os,sys,json,pathlib,hashlib,time,subprocess,signal,datetime,socket
P=pathlib.Path(__file__).resolve().parent
A=P/"admission.json"
EXPECTED_ADMISSION="1c2c0e386cca43949ebbba41119f36a2fe2b6f57dabadea76595dd4e49239d16"
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
 path=P/name
 with path.open("x",encoding="utf-8") as stream:json.dump(value,stream,indent=2);stream.write("\n")
def free():
 s=os.statvfs("/System/Volumes/Data");return s.f_bavail*s.f_frsize
assert digest(A)==EXPECTED_ADMISSION
admission=json.loads(A.read_bytes())
assert admission["deadlineSeconds"]==120
assert socket.gethostname()=="109bcd84-6a7a-475f-9c53-0cf427912d04"
assert P==pathlib.Path("/Users/m1/builds/hanlin-two-wave-root-20261126/composed-ai-ui-typecheck-04e33c45-r1")
source=P/"source/HanlinEntrypointSystemSurfaceUITests.swift"
assert str(source)==admission["composedSource"]["macPath"]
expected=[(source,admission["composedSource"]["sha256"],admission["composedSource"]["bytes"])]
expected += [(P/"source-authorities"/r["path"],r["sha256"],r["bytes"]) for r in admission["sourceRows"]]
def source_rows():
 out=[]
 for path,sha,size in expected:
  assert path.is_file() and not path.is_symlink()
  raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest()
  assert len(raw)==size and actual==sha,(str(path),actual)
  out.append({"path":str(path.relative_to(P)),"bytes":len(raw),"sha256":actual})
 return out
before=source_rows()
checks=[]
for cmd,expectedText in [
 (["xcodebuild","-version"],"Xcode 27.0\nBuild version 27A266a"),
 (["xcrun","--sdk","iphonesimulator","--show-sdk-path"],"/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk"),
 (["xcrun","--sdk","iphonesimulator","--show-sdk-platform-path"],"/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform")]:
 r=subprocess.run(cmd,capture_output=True,text=True,timeout=10)
 checks.append({"argv":cmd,"exit":r.returncode,"stdout":r.stdout,"stderr":r.stderr})
 assert r.returncode==0 and r.stdout.strip()==expectedText
argv=admission["command"]
assert argv[:7]==["xcrun","--sdk","iphonesimulator","swiftc","-typecheck","-module-name","AI_HLYUITests"]
assert argv[-1]==str(source)
assert argv.count("-typecheck")==1 and "build-for-testing" not in argv
save("source-before.json",before)
save("toolchain-before.json",checks)
started=time.monotonic();startedAt=datetime.datetime.now(datetime.timezone.utc).isoformat();freeBefore=free()
stop=None;actions=[]
with (P/"typecheck.stdout.log").open("xb") as stdout,(P/"typecheck.stderr.log").open("xb") as stderr:
 process=subprocess.Popen(argv,cwd=P,stdout=stdout,stderr=stderr,start_new_session=True)
 assert os.getpgid(process.pid)==process.pid
 save("launch.json",{"pid":process.pid,"pgid":process.pid,"argv":argv,"cwd":str(P),"startedAtUTC":startedAt,"deadlineSeconds":120,"sourceRows":before,"freeBytes":freeBefore,"scope":admission["scope"]})
 try:
  remaining=120-(time.monotonic()-started)
  if remaining<=0:raise subprocess.TimeoutExpired(argv,120)
  code=process.wait(timeout=remaining)
 except subprocess.TimeoutExpired:
  stop="original120SecondCommandDeadline"
  if process.poll() is None and os.getpgid(process.pid)==process.pid:
   os.killpg(process.pid,signal.SIGTERM);actions.append({"signal":"SIGTERM","ownedPGID":process.pid})
  try:code=process.wait(timeout=5)
  except subprocess.TimeoutExpired:
   if process.poll() is None and os.getpgid(process.pid)==process.pid:
    os.killpg(process.pid,signal.SIGKILL);actions.append({"signal":"SIGKILL","ownedPGID":process.pid})
   code=process.wait(timeout=5)
elapsed=time.monotonic()-started
after=source_rows()
scan=subprocess.run(["pgrep","-fl",str(source)],capture_output=True,text=True,timeout=10)
assert scan.returncode in (0,1)
save("source-after.json",after)
save("remaining-owned-source-processes.json",{"argv":["pgrep","-fl",str(source)],"exit":scan.returncode,"stdout":scan.stdout,"stderr":scan.stderr,"scope":"Attempt-unique source path only, no global process enumeration or foreign cleanup."})
noRemaining=scan.returncode==1 and not scan.stdout.strip()
record={"schema":1,"status":"TYPECHECK_PASS" if code==0 and stop is None and before==after and noRemaining else "TYPECHECK_FAILED_OR_CLEANUP_UNQUALIFIED","sourceCommit":admission["source"],"composedSourceSHA256":admission["composedSource"]["sha256"],"admissionSHA256":EXPECTED_ADMISSION,"controllerSHA256":digest(pathlib.Path(__file__)),"argv":argv,"pid":process.pid,"pgid":process.pid,"startedAtUTC":startedAt,"finishedAtUTC":datetime.datetime.now(datetime.timezone.utc).isoformat(),"commandSeconds":elapsed,"commandExit":code,"stopReason":stop,"stopActions":actions,"deadlineSeconds":120,"sourceBeforeAfterEqual":before==after,"authorityFileCount":len(before)-1,"noRemainingOwnedSourceProcesses":noRemaining,"freeBeforeBytes":freeBefore,"freeAfterBytes":free(),"stdout":{"bytes":(P/"typecheck.stdout.log").stat().st_size,"sha256":digest(P/"typecheck.stdout.log")},"stderr":{"bytes":(P/"typecheck.stderr.log").stat().st_size,"sha256":digest(P/"typecheck.stderr.log")},"scope":"Exact whole composed AI_HLYUITests file typechecked against installed Xcode27.0/SDK27.0;0 tests,no app build,no Simulator/no hosted27.2 acceptance.","nativeTestInvocations":0,"appBuild":"NOT_RUN"}
save("receipt.json",record)
print(json.dumps(record))
sys.exit(0 if record["status"]=="TYPECHECK_PASS" else 1)
