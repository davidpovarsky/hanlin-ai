import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const [sdkRoot,runRoot,authoringPath]=process.argv.slice(2);
const {runMiniAppOperation}=await import(pathToFileURL(authoringPath).href);
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const manifestPath=path.join(sdkRoot,'miniapp-sdk.json');
const manifestBefore=await fs.readFile(manifestPath);const sdk=JSON.parse(manifestBefore);
const index=JSON.parse(await fs.readFile(path.join(sdkRoot,'examples/index.json')));
if(sdk.inputSHA256!=='bf1f6d6f9ed041287aab026b5f8dcf6c0e31b3571e7af459993dbd23534e4b73'||index.projects.length!==5||process.version!=='v24.5.0')throw Error('Immutable SDK/gallery/tool identity differs');
const receipt={schemaVersion:1,sourceCommit:'9819697c1792119a6a93b492d12abad7b3330c93',inputSHA256:sdk.inputSHA256,sdkRoot,nodeVersion:process.version,startedAt:new Date().toISOString(),passed:false,scope:'Ten fresh original runMiniAppOperation validate/build operations using current SDK examples and original locked toolchain. No Apple runtime or OS acceptance.',originalContract:'succeeded=true and strict user-source typing; original NativeScript skipLibCheck=true is preserved.',sdkManifestSHA256:sha(manifestBefore),projects:[]};
const out=path.join(runRoot,'gallery-original-contract-receipt.json');
const persist=()=>fs.writeFile(out,JSON.stringify(receipt,null,2)+'\n');
await persist();
try{
 for(const item of [...index.projects].sort((a,b)=>Number(b.engine==='nativescript')-Number(a.engine==='nativescript'))){
  if(path.isAbsolute(item.directory)||item.directory.split('/').includes('..'))throw Error('Unexpected gallery directory');
  const source=path.join(sdkRoot,'examples',item.directory),project=path.join(runRoot,'projects',item.directory);
  await fs.cp(source,project,{recursive:true,errorOnExist:true,force:false});
  const result={id:item.id,engine:item.engine,source,project,reports:[]};receipt.projects.push(result);
  for(const operation of ['validate','build']){
   const started=performance.now();
   const report=await runMiniAppOperation({operation,projectRoot:project,outputDirectory:path.join(runRoot,'packages',item.directory)},{sdkRoot});
   const reportPath=path.join(runRoot,item.id+'-'+operation+'.json');await fs.writeFile(reportPath,JSON.stringify(report,null,2)+'\n');
   const accepted=report.succeeded===true&&report.typecheck?.strict===true;
   result.reports.push({operation,accepted,succeeded:report.succeeded,reusedOriginalOperation:false,reportPath,durationMilliseconds:Math.round(performance.now()-started),compilerVersion:report.sdk?.compilerVersion,packageVersions:report.sdk?.packageVersions,typecheck:report.typecheck,diagnostics:report.diagnostics,preparedPackagePath:report.preparedPackagePath});
   if(accepted&&operation==='build'){
    const prepared=report.preparedPackagePath,retained=JSON.parse(await fs.readFile(path.join(prepared,'hanlin.authoring.json')));
    if(!Object.keys(retained.sourceHashes??{}).length||!Object.keys(retained.compiledHashes??{}).length)throw Error('Missing original source/compiled hashes');
    for(const [name,hash] of Object.entries(retained.sourceHashes)){
     for(const file of [path.join(source,name),path.join(project,name),path.join(prepared,'source',name)]){
      if(sha(await fs.readFile(file))!==hash)throw Error('Source identity mismatch: '+file);
     }
    }
    for(const [name,hash] of Object.entries(retained.compiledHashes)){
     if(sha(await fs.readFile(path.join(prepared,name)))!==hash)throw Error('Compiled identity mismatch: '+name);
    }
    result.retainedSourceFiles=Object.keys(retained.sourceHashes).length;result.verifiedCompiledFiles=Object.keys(retained.compiledHashes).length;
    result.entrypoint=JSON.parse(await fs.readFile(path.join(prepared,'script.json'))).entry;
   }
   await persist();console.log(JSON.stringify({id:item.id,operation,accepted,reused:false,typecheck:report.typecheck,compilerVersion:report.sdk?.compilerVersion,diagnostics:report.diagnostics}));
   globalThis.gc?.();if(!accepted)break;
  }
 }
 if(sha(await fs.readFile(manifestPath))!==receipt.sdkManifestSHA256)throw Error('SDK manifest changed during gallery');
 receipt.passed=receipt.projects.length===5&&receipt.projects.every(p=>p.reports.length===2&&p.reports.every(r=>r.accepted&&!r.reusedOriginalOperation)&&p.retainedSourceFiles>0&&p.verifiedCompiledFiles>0);
}catch(error){receipt.error=String(error?.stack??error);throw error;}
finally{receipt.finishedAt=new Date().toISOString();await persist();console.log(JSON.stringify({passed:receipt.passed,receipt:out,projects:receipt.projects.map(p=>({id:p.id,sourceFiles:p.retainedSourceFiles,compiledFiles:p.verifiedCompiledFiles,entrypoint:p.entrypoint}))}));}
process.exitCode=receipt.passed?0:1;
