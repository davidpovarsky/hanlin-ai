import pathlib,json,subprocess,hashlib,datetime,os,zipfile,traceback,time,signal
s=pathlib.Path('/Users/m1/builds/hanlin-two-wave-root-20261126');root=s/'source';run=pathlib.Path('/Users/m1/builds/hanlin-gallery-9819697c-20261126')
host=json.loads((s/'host-preparation-9819697c-original-phases-r1.json').read_text());assert host['status']=='FRESH_HOST_AND_SDK_VERIFIED';sdk=pathlib.Path(host['sdk']['path'])
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def free():v=os.statvfs('/System/Volumes/Data');return v.f_bavail*v.f_frsize
out=run/'controller-receipt.json';proof={'source':host['source'],'startedAt':now(),'status':'PREPARING','freeBefore':free(),'expectedFreshOperations':10,'expectedProjects':5,'nativeAcceptance':False}
def save():out.write_text(json.dumps(proof,indent=2)+'\n')
try:
 assert not out.exists()
 assert proof['freeBefore']>4_823_741_824
 assert sha(sdk/'miniapp-sdk.json')==host['sdk']['manifestSHA256']
 zipPath=pathlib.Path(host['archive']['path']);assert sha(zipPath)==host['archive']['sha256']
 modules=[]
 with zipfile.ZipFile(zipPath) as z:
  for name in ['miniapp-authoring.mjs','miniapp-assistant-tools.mjs']:
   path=root/'AI_HLY/Downstream/RuntimeCore/Node/Host'/name;actual=path.read_bytes();assert actual==z.read(name)
   modules.append({'path':str(path),'archiveMember':name,'sha256':hashlib.sha256(actual).hexdigest()})
 proof.update(sdk=host['sdk'],archive=host['archive'],originalHostModules=modules,hostReceiptSHA256=sha(s/'host-preparation-9819697c-original-phases-r1.json'),scope='Fresh five original gallery validate/build pairs; no dependency installation, source/SDK writes or native job.');save()
 env=os.environ.copy();env['PATH']=str(s/'tool-bin')+':/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'
 command=[str(s/'tool-bin/node'),'--expose-gc',str(run/'gallery-original-contract-driver.mjs'),str(sdk),str(run),modules[0]['path']]
 proof['command']=command;log=run/'gallery-original-contract.log'
 with log.open('wb') as f:
  p=subprocess.Popen(command,cwd=run,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  proof.update(status='RUNNING',pid=p.pid);save();start=time.monotonic()
  while True:
   try:code=p.wait(timeout=15);break
   except subprocess.TimeoutExpired:
    proof['lastObservation']={'at':now(),'freeBytes':free(),'logBytes':log.stat().st_size};save()
    if free()<750000000 or time.monotonic()-start>1500:
     proof['stopReason']='DISK_FLOOR' if free()<750000000 else 'BOUNDED_JOB_TIMEOUT';os.killpg(p.pid,signal.SIGTERM);code=p.wait(timeout=20);break
 proof['exitCode']=code;proof['logSHA256']=sha(log)
 report=json.loads((run/'gallery-original-contract-receipt.json').read_text());assert code==0 and report['passed'] and not proof.get('stopReason')
 assert len(report['projects'])==5 and sum(len(x['reports']) for x in report['projects'])==10
 assert all(not r['reusedOriginalOperation'] for x in report['projects'] for r in x['reports'])
 for module in modules:assert sha(pathlib.Path(module['path']))==module['sha256']
 assert sha(sdk/'miniapp-sdk.json')==host['sdk']['manifestSHA256']
 proof['galleryReceiptSHA256']=sha(run/'gallery-original-contract-receipt.json');proof['status']='FIVE_CURRENT_GALLERY_PROJECTS_VALIDATED_AND_BUILT'
except Exception as e:proof.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
finally:proof['finishedAt']=now();proof['freeAfter']=free();save();print(json.dumps(proof),flush=True)
if proof['status']!='FIVE_CURRENT_GALLERY_PROJECTS_VALIDATED_AND_BUILT':raise SystemExit(1)
