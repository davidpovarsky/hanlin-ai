// swift-tools-version: 6.0
import PackageDescription
let package = Package(name: "SkillImportPresentationProof", targets: [
    .target(name: "AI_Hanlin"),
    .testTarget(name: "UIStateTests", dependencies: ["AI_Hanlin"])
], swiftLanguageModes: [.v6])
