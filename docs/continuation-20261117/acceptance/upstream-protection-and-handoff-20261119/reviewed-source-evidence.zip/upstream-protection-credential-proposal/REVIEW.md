# Separate upstream protection read credential — unapplied review packet

Source base: 884c41d039dfbf276af4c12299d84ac4c981e082.
Default-main base: cbfae6eeeaa53969fa95fed18a5ba0a5548fd2ad.
The immutable V3 baseline d6e2e3f062633fe7a55c0f44b922c5b3321aaf4a and PR15 head c80f620ba8ed28243922728e00acffcdd439cc12 are unchanged.

## Why this correction is necessary

Actual consumer44462885406 verified the trusted source and original producer lineage but GitHub rejected both the REST and exact-ref GraphQL branch-protection reads under the standard GITHUB_TOKEN. The original strict/admin-enforced/app15368 required-check gates remain closed. This packet does not claim native acceptance or recover the failed consumer.

GitHub documents Administration:read for GET branch protection:
https://docs.github.com/en/rest/branches/branch-protection#get-branch-protection
GITHUB_TOKEN does not expose that permission in workflow permissions:
https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#permissions

## Exact authorization boundary

Create only a credential scoped to repository davidpovarsky/hanlin-ai with Administration:read and the mandatory Metadata:read. Store it as HANLIN_UPSTREAM_PROTECTION_READ_TOKEN. No existing owner gh credential has been read or copied. No credential has been created by this source proposal.

The existing default-main workflow changes exactly one environment value on the existing trusted-consumer step. Checkout remains immutable and persist-credentials:false. Normal GITHUB_TOKEN, workflow permission declarations and app15368 proof publication remain unchanged.

The new read client accepts only the existing three exact acceptance bases in the owned repository and a 40-character source SHA. It fixes the host to github.com and the REST method to GET. The only REST paths are the exact base's classic protection and effective branch rules. The original GraphQL fallback accepts only the exact existing read query and exact repository/ref variables. There is no write operation or unknown-route fallback.

CI without a nonempty dedicated credential fails closed. A rejected dedicated credential never falls back to the ordinary write credential. Local authenticated read-only inspection preserves its existing gh authorization. The dedicated read credential is removed from every ordinary gh child, protected-auto-merge child, artifact download, and Python archive verification child. The consumer passes it only into the immutable checker, which narrows it to the dedicated read calls. Error sanitization retains HTTP diagnostics and removes secret bytes without retaining the original error object.

## Files and validation

Canonical source patch: separate-protection-read-credential.UNAPPLIED.patch — five files, including two new modules/tests and original preflight registration.
Default-main patch: default-main-protection-read-secret.UNAPPLIED.patch — one line, separate from canonical source ownership.
proposal.json contains exact pre/post SHA256 hashes, bases, patch hashes and command results.

Node24.22.1: 71/71 focused tests passed, including 12 new credential separation and rejection cases, complete protection projection tests, consumer policy and lineage tests. Tests use synthetic credentials and injected commands only; no network credentials or live authorization are tested. All three changed runtime modules parse; git apply --check passes against the source snapshot. Parsed YAML comparison proves the main workflow object delta is exactly the secret environment mapping.

## Activation and remaining work

After root review/publication, verify the existing conservative139 Host input closure at the new immutable source; set the existing trusted-source variable to that reviewed SHA. Apply the reviewed one-line default-main change through the existing owned activation PR path. Only after an actual least-privilege credential is securely configured should original proof_run44455722821 be dispatched once.

Current authentication is blocked because the available browser is at GitHub sign-in. No repeat of the known-failing proof run is useful before the credential exists. The full original failure-demo/server rejection/later same-head green/protected automerge/reverse-apply rollback sequence remains open. Automatic bot-to-consumer delivery is a separate source proposal and must be demonstrated before full original pipeline completion.
