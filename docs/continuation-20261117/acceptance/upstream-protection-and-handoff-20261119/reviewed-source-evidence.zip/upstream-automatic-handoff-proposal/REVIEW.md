# Automatic upstream proof handoff — unapplied review packet

This is a separate future automation repair. It does not change or relabel immutable V3 source d6e2e3f062633fe7a55c0f44b922c5b3321aaf4a, candidate c80f620ba8ed28243922728e00acffcdd439cc12 or native run44455722821.

## Observed gap

The original CI Renovate producer44448070120 created PR15 and dispatched native candidate44455722821. The candidate passed, but no automatic original consumer appeared. Owner-started original-main runs did receive workflow_run consumers. The bounded raw inventory and correlation evidence is upstream-activation/execution/v3/AUTOMATIC_CONSUMER_TRIGGER_AUDIT.json SHA7de0501279e015388f8e9ad6326ce5388b0965ebc482b61f49cb8b3a70f22f69.

The public run API does not expose a definitive suppression reason. Neither the precise event-token cause nor a nesting-limit explanation is claimed as proven. GitHub documents explicit workflow_dispatch as a supported exception to GITHUB_TOKEN event suppression:
https://docs.github.com/en/actions/concepts/security/github_token
Existing workflow_run constraints:
https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#workflow_run

## Exact source layering

Base source884c41d039dfbf276af4c12299d84ac4c981e082 plus the reviewed-later credential proposal bcd786db1184d63759dca537f136001f399621d311822fb7c0cc6d7b1ca839dd. This packet's prehashes intentionally match that proposal's posthashes.

Default-main basecbfae6eeeaa53969fa95fed18a5ba0a5548fd2ad plus one-line secret mapping de17eb910afc5051961d98584543348b063cda1c1feb2935cc470820c54e5854. The main delta is an optional proof_attempt input, its environment binding, and a description acknowledging that the producer may still be completing.

Source patch attempt-bound-automatic-proof-handoff.UNAPPLIED.patch has five files: one existing producer step/test registration, the existing consumer, a pure delivery/identity module, a small one-shot dispatch CLI and focused tests. No new event hooks, action permissions, branch patterns or required-check changes.

## Mutually exclusive automatic routes

The authenticated actor tuple id41898282/login github-actions[bot]/typeBot uses the explicit handoff. Any partial mismatch rejects. Other well-formed authenticated actors retain the existing workflow_run route. A workflow_run invocation for that exact bot origin records NOT_APPLICABLE and publishes no check; it cannot race a second automatic proof publication. Existing explicit manual proof_run recovery remains accepted for a completed producer.

The producer's new final always-step applies only to candidate/failure-demo. It runs after Host artifact retention and before original proof artifact upload, authenticates its current server run and PR, exact source SHA, workflow ref, run attempt, branch, head/base and actor, then sends one request to the existing trusted-main consumer. It has no proof-check or merge operation. An ambiguous dispatch transport error is preserved without automatic retry. The existing actions:write credential is unchanged; the separate Administration:read secret is never supplied to this producer.

Owner-started producer attempts record WORKFLOW_RUN_DELIVERY_RETAINED and do not explicitly dispatch. A rerun remains tied to its exact new run_attempt. Legacy frozen bot producers do not gain this source step; their preserved manual recovery remains explicit and is not called an automated demonstration.

## Authenticated completion wait

An explicit attempt-bound handoff may reach the consumer before the producer has uploaded its final proof. The consumer waits for completion with a monotonic90-second deadline, at most20 reads, at most10 seconds per API request and bounded intervals. Every read authenticates repository IDs, workflow ID/path, event, run ID/attempt, SHA, branch, actor and creation time. Changed identity, unknown states, a new rerun attempt, missing attempt on a pending request, deadline expiry or exhausted reads rejects.

A workflow_run event must supply its original event attempt and may not wait for a pending rerun. Local inspection does not gain a pending wait. A completed failed producer remains failed; the original consumer then publishes the original required failure check. Completion waiting never substitutes for digest, schema2, source-input, required-check or protection verification.

The source consumes only the existing reviewed immutable checker and APIs. Main must receive the attempt environment binding before activating this future source for automatic workflow_run traffic.

## Validation and limits

Node24.22.1:93/93 focused tests passed, including22 new cases. Tests cover mutually exclusive routes, actor inconsistency, foreign/moved/closed/draft candidates, exact source/attempt/environment binding, a genuinely awaited gated API read, pending-to-completed delivery, failure preservation, source drift, deadline and read-count exhaustion, malformed states and compatible completed manual recovery.

Three changed runtime modules parse. git apply --check succeeds. Parsed YAML comparison confirms exactly one producer handoff step/test registration and the narrowly described main input/env changes; hooks and permissions remain unchanged. All tests use synthetic API snapshots and clocks. Actual automatic delivery remains NOT_RUN.

## Activation needed after review

1. Apply/publish the credential correction and this future handoff source after review; verify source hashes and the original Host input closure as appropriate.
2. Merge the exact reviewed main input/env changes before selecting this source as the trusted consumer.
3. Securely configure the repository-only Administration:read credential. Existing browser authentication is currently unavailable.
4. Preserve V3 and candidatec80 throughout their original manual recovery and negative/green/merge/rollback lifecycle.
5. For a new automatic producer demonstration, review and create a new immutable explicit acceptance baseline and corresponding exact allowlist/default target change. This packet adds no fourth base itself.
6. Run the real original Renovate-to-native-to-consumer sequence with authenticated handoff/run/attempt artifacts. No manual proof_run may be presented as that automatic demonstration. Retain original required negative/server-block/later-green/protected-merge/rollback gates.

A producer that cannot reach the final handoff step (for example a checkout failure) cannot produce that receipt; its original source check still fails and blocks merge. This repair does not claim delivery despite an unavailable runner or a failed workflow bootstrap.
