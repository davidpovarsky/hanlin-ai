import Foundation
import Testing
struct Store {
    func load() throws -> String? { "value" }
    func resolve(_ handle: String, kind: String) throws -> String? { handle }
    func fetch() throws -> [String] { ["value"] }
    func asyncLoad() async throws -> String? { "value" }
}
func originalShapes(_ store: Store) async throws {
    let _ = try #require(store.load())
    let _ = try #require(store.resolve("handle", kind: "model"))
    #expect(Data(try #require(store.load()).utf8) == Data("value".utf8))
    let _ = try #require(store.fetch().first)
    let _ = try #require(await store.asyncLoad())
}
