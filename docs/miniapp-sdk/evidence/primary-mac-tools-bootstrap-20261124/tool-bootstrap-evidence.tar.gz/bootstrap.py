import datetime,hashlib,json,os,pathlib,re,signal,subprocess,sys,time,traceback
ROOT=pathlib.Path(__file__).resolve().parent
LOGS=ROOT/'logs';DOWNLOADS=ROOT/'downloads';BIN=ROOT/'bin'
for p in [LOGS,DOWNLOADS,BIN,ROOT/'cache/homebrew']:p.mkdir(parents=True,exist_ok=True)
ENV=os.environ.copy();ENV.update(HOMEBREW_NO_AUTO_UPDATE='1',HOMEBREW_NO_ANALYTICS='1',HOMEBREW_CACHE=str(ROOT/'cache/homebrew'),PATH=str(BIN)+':/opt/homebrew/bin:'+os.environ.get('PATH','/usr/bin:/bin:/usr/sbin:/sbin'))
state={'schemaVersion':1,'owner':'/root/entrypoints','nativeOwner':'/root/control_authoring','sourceCommit':'ce49e30d69466e44b0aa26582beaa57ee7a91a9b','host':'scaleway-mac','taskRoot':str(ROOT),'pid':os.getpid(),'status':'RUNNING','startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'nativeBuilds':0,'tests':0,'globalNodePythonChanges':False,'sourceCompilation':False}
def save():
 temp=ROOT/'receipt.json.tmp';temp.write_text(json.dumps(state,indent=2)+'\n');temp.replace(ROOT/'receipt.json')
def run(name,argv,timeout=60):
 start=time.monotonic();item={'name':name,'argv':argv,'startedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeoutSeconds':timeout,'stdout':'logs/'+name+'.stdout.log','stderr':'logs/'+name+'.stderr.log','status':'STARTING'};state['commands'].append(item);state['activeCommand']=name;save()
 with (ROOT/item['stdout']).open('wb') as out,(ROOT/item['stderr']).open('wb') as err:
  process=subprocess.Popen(argv,cwd=ROOT,env=ENV,stdout=out,stderr=err,start_new_session=True);item.update(pid=process.pid,status='RUNNING');save()
  try:code=process.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=2)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
   item.update(status='TIMED_OUT',exitCode=process.returncode,durationSeconds=time.monotonic()-start);save();raise RuntimeError(name+' timed out; own process group stopped')
 item.update(status='COMPLETED',exitCode=code,durationSeconds=time.monotonic()-start,completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());state['activeCommand']=None;save()
 if code:raise RuntimeError(name+' exited '+str(code)+'; see '+item['stderr'])
 return (ROOT/item['stdout']).read_text()
def fetch(name,url,destination):
 run(name,['/usr/bin/curl','--fail','--location','--connect-timeout','15','--max-time','180','--retry','1','--output',str(destination),url],195)
def verify(archive,manifest,url,manifest_url):
 matches=[]
 for line in manifest.read_text().splitlines():
  parts=line.split()
  if len(parts)==2 and parts[1].lstrip('*')==archive.name:matches.append(parts[0].lower())
 if len(matches)!=1 or not re.fullmatch('[0-9a-f]{64}',matches[0]):raise RuntimeError('Official checksum manifest has no unique valid '+archive.name)
 actual=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()
 if actual!=matches[0]:raise RuntimeError('Official checksum mismatch for '+archive.name)
 return {'archiveURL':url,'manifestURL':manifest_url,'archivePath':str(archive),'archiveBytes':archive.stat().st_size,'expectedSHA256':matches[0],'actualSHA256':actual,'officialManifestSHA256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'verified':True}
def link(name,target):
 path=BIN/name
 if path.exists() or path.is_symlink():raise RuntimeError('Task-local tool link already exists: '+str(path))
 path.symlink_to(target)
try:
 save()
 link('python3','/opt/homebrew/bin/python3.12')
 node_name='node-v24.5.0-darwin-arm64.tar.gz';base='https://nodejs.org/dist/v24.5.0/'
 node_archive=DOWNLOADS/node_name;node_manifest=DOWNLOADS/'node-SHASUMS256.txt'
 fetch('node-official-checksums',base+'SHASUMS256.txt',node_manifest)
 fetch('node-official-archive',base+node_name,node_archive)
 state['nodeIntegrity']=verify(node_archive,node_manifest,base+node_name,base+'SHASUMS256.txt');save()
 run('node-extract',['/usr/bin/tar','-xzf',str(node_archive),'-C',str(ROOT)],60)
 node_bin=ROOT/'node-v24.5.0-darwin-arm64/bin'
 for name in ['node','npm','npx']:link(name,node_bin/name)
 node_version=run('node-version',[str(BIN/'node'),'--version'],10).strip()
 if node_version!='v24.5.0':raise RuntimeError('Unexpected installed Node identity '+node_version)
 state['nodeVersion']=node_version;state['npmVersion']=run('npm-version',[str(BIN/'npm'),'--version'],15).strip();state['pythonVersion']=run('python-version',[str(BIN/'python3'),'--version'],10).strip();save()
 info=run('cmake-homebrew-metadata',['/opt/homebrew/bin/brew','info','--json=v2','cmake'],90)
 metadata=json.loads(info);formulas=[f for f in metadata.get('formulae',[]) if f.get('name')=='cmake']
 if len(formulas)!=1:raise RuntimeError('No unique genuine CMake formula metadata')
 version=formulas[0]['versions']['stable']
 if not re.fullmatch(r'\d+\.\d+\.\d+',version):raise RuntimeError('Unrecognized original CMake stable version '+str(version))
 state['cmakeMetadata']={'authority':'Existing Homebrew formula metadata; version only','version':version,'metadataSHA256':hashlib.sha256(info.encode()).hexdigest(),'buildFromSource':False};save()
 cmake_name='cmake-'+version+'-macos-universal.tar.gz';cmake_base='https://github.com/Kitware/CMake/releases/download/v'+version+'/'
 cmake_archive=DOWNLOADS/cmake_name;cmake_manifest=DOWNLOADS/('cmake-'+version+'-SHA-256.txt')
 fetch('cmake-official-checksums',cmake_base+cmake_manifest.name,cmake_manifest)
 fetch('cmake-official-archive',cmake_base+cmake_name,cmake_archive)
 state['cmakeIntegrity']=verify(cmake_archive,cmake_manifest,cmake_base+cmake_name,cmake_base+cmake_manifest.name);save()
 run('cmake-extract',['/usr/bin/tar','-xzf',str(cmake_archive),'-C',str(ROOT)],60)
 cmake_bin=ROOT/('cmake-'+version+'-macos-universal')/'CMake.app/Contents/bin'
 for name in ['cmake','ctest','cpack']:
  if not (cmake_bin/name).is_file():raise RuntimeError('Original CMake archive has no expected executable '+name)
  link(name,cmake_bin/name)
 cmake_version=run('cmake-version',[str(BIN/'cmake'),'--version'],15).strip()
 if cmake_version.splitlines()[0]!='cmake version '+version:raise RuntimeError('Unexpected original CMake binary version')
 state['cmakeVersion']=cmake_version
 state['toolBinaryTypes']=run('tool-binary-types',['/usr/bin/file',str(node_bin/'node'),str(cmake_bin/'cmake')],10).strip()
 (ROOT/'env.sh').write_text('export PATH="'+str(BIN)+':$PATH"\n')
 state.update(status='READY',pathPrefix=str(BIN),environmentScript=str(ROOT/'env.sh'),completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),boundary='Official prebuilt tools downloaded, checksum-verified, extracted and queried for versions. No app/native compilation, tests, signing or source changes. No Homebrew installation/global tool changes.')
except BaseException as error:
 state.update(status='FAILED',error=str(error),completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat());traceback.print_exc()
finally:
 state['activeCommand']=None;save()
 print(json.dumps({'status':state['status'],'taskRoot':str(ROOT),'nodeVersion':state.get('nodeVersion'),'pythonVersion':state.get('pythonVersion'),'cmakeVersion':state.get('cmakeVersion'),'error':state.get('error')},indent=2),flush=True)
 sys.exit(0 if state['status']=='READY' else 1)
