export PATH="/Users/m1/builds/hanlin-ai-ce49e30d-miniapp-complete-tools/bin:$PATH"
