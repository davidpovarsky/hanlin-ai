import assert from 'node:assert/strict';
import {promises as fs} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';

const require = createRequire(import.meta.url);
const compiler = require(process.env.HANLIN_AUTHORING_TYPESCRIPT);
const {inspectMiniAppSource} = await import(pathToFileURL(process.argv[2]).href);
const root = await fs.mkdtemp(path.join(os.tmpdir(), 'hanlin-original-intl-completion-'));
try {
  const project = path.join(root, 'project');
  const sdkRoot = path.join(root, 'sdk');
  await fs.mkdir(project);
  await fs.mkdir(path.join(sdkRoot, 'tooling'), {recursive: true});
  await fs.writeFile(path.join(sdkRoot, 'miniapp-sdk.json'), JSON.stringify({
    schemaVersion: 1, engines: {nativescript: {toolingRoot: 'tooling', packageVersions: {}}}
  }));
  await fs.writeFile(path.join(project, 'script.json'), JSON.stringify({
    name: 'Original editor Intl qualification', version: '1.0.0', hanlinRuntime: 'hanlin-nativescript'
  }));
  await fs.writeFile(path.join(project, 'hanlin.authoring.json'), JSON.stringify({
    schemaVersion: 1, engine: 'nativescript', entry: 'index.ts'
  }));
  await fs.writeFile(path.join(project, 'tsconfig.json'), JSON.stringify({
    compilerOptions: {strict: true, target: 'ES2022'}, files: ['index.ts']
  }));
  const saved = 'export const saved = true;\n';
  await fs.writeFile(path.join(project, 'index.ts'), saved);
  const source = 'const greeting: string = "שלום 世界";\ngreeting.';
  const result = await inspectMiniAppSource({
    projectRoot: project, engine: 'nativescript', file: 'index.ts', source,
    position: source.length, version: 7, completionName: 'toUpperCase'
  }, {sdkRoot, compiler});
  assert.equal(result.compilerVersion, compiler.version);
  assert.ok(result.completions.some(item => item.name === 'toUpperCase'));
  assert.match(result.display, /toUpperCase/);
  assert.equal(await fs.readFile(path.join(project, 'index.ts'), 'utf8'), saved);
  const locales = ['en', 'he', 'zh-Hans'].map(locale => {
    assert.equal(Intl.Collator.supportedLocalesOf([locale], {localeMatcher: 'lookup'}).length, 1);
    const collator = new Intl.Collator(locale, {usage: 'sort', sensitivity: 'variant', numeric: true});
    const numeric = collator.compare('item2', 'item10');
    assert.ok(numeric < 0);
    return {locale, resolved: collator.resolvedOptions(), numeric};
  });
  console.log(JSON.stringify({
    scope: 'Original compiler/host API on Linux; native NodeMobile remains NOT_RUN',
    nodeVersion: process.versions.node, icuVersion: process.versions.icu,
    compilerVersion: compiler.version, toUpperCase: true, originalSavedBytesUnchanged: true,
    display: result.display, locales
  }, null, 2));
} finally {
  await fs.rm(root, {recursive: true, force: true});
}
