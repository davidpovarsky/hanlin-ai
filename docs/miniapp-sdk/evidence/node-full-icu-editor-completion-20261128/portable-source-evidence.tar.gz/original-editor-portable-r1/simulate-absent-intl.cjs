if (typeof globalThis.Intl !== 'object') throw new Error('Control requires the original full ICU runtime');
delete globalThis.Intl;
if ('Intl' in globalThis) throw new Error('Control did not establish absent Intl');
