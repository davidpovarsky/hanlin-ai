#!/usr/bin/env python3
"""Assemble exact production authoring files beside an existing SDK export.
Release-maintainer utility only. Users of the finished kit do not need Git.
This packages files; it does not rebuild the SDK or claim runtime/test success.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import hashlib
import json
import os
import shutil
import stat
import subprocess
import zipfile

PRODUCTION_FILES = (
    "Scripts/MiniApps/miniapp.mjs",
    "AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-authoring.mjs",
)

def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", type=Path, required=True)
    parser.add_argument("--source", required=True, help="Exact production Git commit")
    parser.add_argument("--sdk-source", required=True, help="SDK producer commit from its build receipt")
    parser.add_argument("--sdk-zip", type=Path, required=True)
    parser.add_argument("--expected-sdk-sha256", required=True)
    parser.add_argument("--expected-manifest-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True, help="New, nonexistent kit directory")
    args = parser.parse_args()
    assert not args.output.exists(), "Output already exists; choose a new directory."
    assert sha256(args.sdk_zip) == args.expected_sdk_sha256, "SDK export hash differs."
    source = subprocess.check_output(
        ["git", "-C", str(args.repository), "rev-parse", args.source + "^{commit}"],
        text=True).strip()
    sdk_source = subprocess.check_output(
        ["git", "-C", str(args.repository), "rev-parse", args.sdk_source + "^{commit}"],
        text=True).strip()
    originals = []
    for relative in PRODUCTION_FILES:
        data = subprocess.check_output(
            ["git", "-C", str(args.repository), "show", source + ":" + relative])
        mode = subprocess.check_output(
            ["git", "-C", str(args.repository), "ls-tree", source, "--", relative],
            text=True).split()[0]
        assert mode in ("100644", "100755")
        originals.append((relative, data, mode))
    args.output.mkdir(parents=True)
    sdk_rows = []
    with zipfile.ZipFile(args.sdk_zip) as archive:
        for info in archive.infolist():
            relative = PurePosixPath(info.filename)
            assert relative.parts and relative.parts[0] == "MiniAppSDK"
            assert not relative.is_absolute() and ".." not in relative.parts
            assert not stat.S_ISLNK(info.external_attr >> 16)
            target = args.output / info.filename
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source_file, target.open("xb") as output_file:
                shutil.copyfileobj(source_file, output_file)
            mode = (info.external_attr >> 16) & 0o777
            if mode:
                target.chmod(mode)
            sdk_rows.append({"path": info.filename, "bytes": target.stat().st_size,
                             "sha256": sha256(target)})
    manifest = args.output / "MiniAppSDK/miniapp-sdk.json"
    assert sha256(manifest) == args.expected_manifest_sha256
    production_rows = []
    for relative, data, mode in originals:
        target = args.output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        target.chmod(int(mode, 8) & 0o777)
        production_rows.append({"path": relative, "bytes": len(data),
                                "sha256": sha256(target), "gitMode": mode})
    receipt = {
        "schema": 1,
        "status": "ASSEMBLED_NOT_VERIFIED",
        "createdAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "productionSource": source,
        "SDKProducerSourceFromBuildReceipt": sdk_source,
        "SDKArchive": {"path": str(args.sdk_zip.resolve()),
                       "bytes": args.sdk_zip.stat().st_size,
                       "sha256": sha256(args.sdk_zip)},
        "SDKManifestSHA256": sha256(manifest),
        "productionFiles": production_rows,
        "SDKFiles": sdk_rows,
        "scope": "Exact copy/export only; run the documented isolated authoring checks before publishing a future release.",
    }
    receipt_path = args.output / "toolchain-export-receipt.json"
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"output": str(args.output.resolve()),
                      "receipt": str(receipt_path.resolve()),
                      "receiptSHA256": sha256(receipt_path),
                      "productionFileCount": len(production_rows),
                      "SDKFileCount": len(sdk_rows)}))

if __name__ == "__main__":
    main()
