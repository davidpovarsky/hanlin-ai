# Standalone MiniApp authoring CLI

The developer kit includes the original production CLI and authoring module beside the exact SDK19 export. It can validate authored TypeScript and produce an Expo or NativeScript mini-app archive after one extraction. A repository checkout, npm installation and a separate compiler download are not required for these operations.

## Prerequisites and layout

Use Node 24.x version 24.3.0 or later and Python 3 available as `python3` (or `python`). The isolated Oracle verification used Node 24.22.0 on Linux arm64 and Python 3.12.3. Python supplies the standard-library ZIP writer. Native iOS execution, device testing and host-app builds are separate operations.

Run the commands below from the extracted kit root. Preserve these relative paths:

| Path | Purpose |
| --- | --- |
| [MiniAppSDK/miniapp-sdk.json](MiniAppSDK/miniapp-sdk.json) | SDK index, engine descriptors and source provenance |
| [MiniAppSDK/docs/](MiniAppSDK/docs/) | Original exported API and authoring documentation |
| [MiniAppSDK/examples/](MiniAppSDK/examples/) | Original examples and templates |
| [Scripts/MiniApps/miniapp.mjs](Scripts/MiniApps/miniapp.mjs) | Original production CLI |
| [AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-authoring.mjs](AI_HLY/Downstream/RuntimeCore/Node/Host/miniapp-authoring.mjs) | Original production authoring module imported by the CLI |

The two JavaScript files are byte-identical at production commit `d4a0b115b106d4250ea40ad66153d5156847a07c` and SDK producer commit `a2c8a1b1be746461272ba77254603304567c309d`. The SDK ZIP SHA-256 is `1bf347311b9547054725f8674419a11b3c502a4994feb6dbd9283c3af7400210`; its manifest SHA-256 is `4505c28495d8b6ecd1073254e0e395adcc898cc02dd1d40699591f51db4dee92`.

## Create working copies

Keep the SDK itself unchanged. Copy an example to a working directory:

```sh
mkdir -p workspace artifacts
cp -R MiniAppSDK/examples/expo-hello-world workspace/expo-hello-world
cp -R MiniAppSDK/examples/nativescript-hello-world workspace/nativescript-hello-world
```

These are ordinary file-copy operations; an editor or file manager can perform the same copies. Choose new working-directory names when repeating the copy.

## Validate and build

```sh
node Scripts/MiniApps/miniapp.mjs validate --sdk ./MiniAppSDK --engine expo --project ./workspace/expo-hello-world --report ./artifacts/expo-validate.json
node Scripts/MiniApps/miniapp.mjs build --sdk ./MiniAppSDK --engine expo --project ./workspace/expo-hello-world --archive ./artifacts/Expo-Hello-World.hanlinExpo --report ./artifacts/expo-build.json
node Scripts/MiniApps/miniapp.mjs validate --sdk ./MiniAppSDK --engine nativescript --project ./workspace/nativescript-hello-world --report ./artifacts/nativescript-validate.json
node Scripts/MiniApps/miniapp.mjs build --sdk ./MiniAppSDK --engine nativescript --project ./workspace/nativescript-hello-world --report ./artifacts/nativescript-build.json --archive ./artifacts/NativeScript-Hello-World.hanlinNativeScript
```

The commands deliberately select the kit's SDK with `--sdk`. Leave `HANLIN_AUTHORING_TYPESCRIPT` unset when using the bundled original compilers. Reports are written as JSON and printed to the terminal. Exit code 0 indicates success; an authored type error produces exit code 1 and a failed report. Each build archive path must be new because the original ZIP writer preserves create-only behavior.

Expo uses the original Metro/Expo build configuration and bundled TypeScript compiler 6.0.3. NativeScript uses its original compiler 5.9.3 and retains its original native-runtime package contract. Generated archives include source files, authoring metadata, compiled output and validation evidence.

## Actual standalone verification

On 2026-11-25, both engines passed validation and archive creation using this exact kit layout. Expo produced a 1,949,117-byte `.hanlinExpo` archive with 14 members; NativeScript produced a 7,817-byte `.hanlinNativeScript` archive with 16 members. Both archives passed ZIP CRC checks.

A separate NativeScript working copy contained this deliberately invalid declaration:

```ts
export const deliberateTypeError: number = "SDK08 should reject this";
```

Both `validate` and `build` rejected it, returned exit code 1, and reported:

```json
{
  "code": "TS2322",
  "category": "error",
  "message": "Type 'string' is not assignable to type 'number'.",
  "file": "index.ts",
  "line": 36,
  "column": 14,
  "endLine": 36,
  "endColumn": 33
}
```

The rejected build created neither an archive nor a build stage. The exact negative commands were:

```sh
node Scripts/MiniApps/miniapp.mjs validate --sdk ./MiniAppSDK --engine nativescript --project ./workspace/nativescript-type-error --report ./artifacts/negative-type-error-validate.json
node Scripts/MiniApps/miniapp.mjs build --sdk ./MiniAppSDK --engine nativescript --project ./workspace/nativescript-type-error --report ./artifacts/negative-type-error-build.json --archive ./artifacts/Rejected-Type-Error.hanlinNativeScript
```

Expo's original configuration used `strict: true` and `skipLibCheck: false`, including dependency declaration checks. NativeScript's original configuration used `strict: true` and `skipLibCheck: true`; authored code was checked, while dependency declaration internals were skipped. The deliberate TS2322 confirms that the NativeScript source-code diagnostic path remained active.

All 25,670 SDK files and both production JavaScript files remained byte-identical after the six invocations. Complete file/process/network traces showed no repository fallback, no successful external dependency loads and no Internet connections. Original optional ancestor package probes remained visible as failed lookups. System Node, Python and operating-system libraries were used as prerequisites.

This proof establishes standalone authoring, type diagnostics and archive creation. It does not claim that the two Oracle-generated archives were installed or executed on iOS.

## Maintainer recipe for a later SDK export

The accompanying `export-standalone-toolchain.py` copies these same production paths from an exact Git commit and extracts an existing SDK ZIP into a new kit directory. It records source, archive, manifest and per-file hashes; it does not rebuild the SDK, fetch dependencies or modify production code.

Example for this frozen snapshot:

```sh
python3 export-standalone-toolchain.py --repository /path/to/hanlin-repository --source d4a0b115b106d4250ea40ad66153d5156847a07c --sdk-source a2c8a1b1be746461272ba77254603304567c309d --sdk-zip /path/to/Hanlin-MiniApp-SDK-2026-11-25.zip --expected-sdk-sha256 1bf347311b9547054725f8674419a11b3c502a4994feb6dbd9283c3af7400210 --expected-manifest-sha256 4505c28495d8b6ecd1073254e0e395adcc898cc02dd1d40699591f51db4dee92 --output /path/to/new-kit
```

For a future release, supply that release's exact production commit, SDK producer receipt and export hashes. Recheck the CLI's import closure if production imports change, then repeat isolated Expo/NativeScript validation, build and the deliberate type-error check before publishing. The recipe is syntax-verified; this release's actual proof used the equivalent exact-copy extraction recorded in the evidence.
