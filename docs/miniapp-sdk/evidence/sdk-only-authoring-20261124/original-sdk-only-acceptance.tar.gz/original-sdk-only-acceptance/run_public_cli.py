from pathlib import Path
import datetime, hashlib, json, os, shlex, subprocess, sys, time
WORK = Path(__file__).resolve().parent
KIT = WORK.parent
SDK = KIT / 'AI_HLY/Downstream/RuntimeCore/Node/Host/MiniAppSDK'
CLI = KIT / 'Scripts/MiniApps/miniapp.mjs'
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def inventory(project):
    return [{'path': str(p.relative_to(project)), 'bytes': p.stat().st_size, 'sha256': digest(p)} for p in sorted(project.rglob('*')) if p.is_file() and not any(x.startswith('.') or x == 'node_modules' for x in p.relative_to(project).parts)]
name, operation, engine, project_name = sys.argv[1:5]
project = WORK / project_name
evidence = WORK / 'evidence' / name
evidence.mkdir(parents=True, exist_ok=False)
report = evidence / 'report.json'
command = ['/usr/local/bin/node', str(CLI), operation, '--sdk', str(SDK), '--engine', engine, '--project', str(project), '--report', str(report)]
if operation == 'build':
    archives = WORK / 'archives'
    archives.mkdir(exist_ok=True)
    suffix = '.hanlinExpo' if engine == 'expo' else '.hanlinNativeScript'
    command += ['--archive', str(archives / (project_name + suffix))]
inputs = inventory(project)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = os.statvfs(WORK)
start = time.monotonic()
env = os.environ.copy()
temp = WORK / 'temporary'
temp.mkdir(exist_ok=True)
env['TMPDIR'] = str(temp)
result = subprocess.run(command, cwd=WORK, env=env, capture_output=True)
elapsed = time.monotonic() - start
(evidence / 'stdout.txt').write_bytes(result.stdout)
(evidence / 'stderr.txt').write_bytes(result.stderr)
(evidence / 'command.txt').write_text(shlex.join(command) + '\n')
receipt = {'command': command, 'commandText': shlex.join(command), 'cwd': str(WORK), 'startedUTC': started, 'durationSeconds': round(elapsed, 4), 'exitCode': result.returncode, 'sdkRoot': str(SDK), 'sdkManifestSHA256': digest(SDK / 'miniapp-sdk.json'), 'inputFiles': inputs, 'tempDirectory': str(temp), 'diskFreeBefore': before.f_bavail * before.f_frsize, 'outputFiles': []}
for p in [evidence / 'stdout.txt', evidence / 'stderr.txt', report, evidence / 'command.txt']:
    if p.exists(): receipt['outputFiles'].append({'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)})
after = os.statvfs(WORK)
receipt['diskFreeAfter'] = after.f_bavail * after.f_frsize
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'evidence':str(evidence),'command':command,'exitCode':result.returncode,'durationSeconds':receipt['durationSeconds'],'diskFreeAfter':receipt['diskFreeAfter']}, indent=2))
if report.exists():
    value = json.loads(report.read_text())
    summary = {key: value[key] for key in ['schemaVersion', 'engine', 'operation', 'succeeded', 'diagnostics', 'sourceRoot', 'archivePath', 'preparedRoot', 'bundlePath', 'typecheck', 'build'] if key in value}
    summary['reportKeys'] = list(value)
    print(json.dumps(summary, indent=2)[:22000])
else:
    print('NO REPORT')
    print(result.stdout.decode(errors='replace')[-14000:])
    print(result.stderr.decode(errors='replace')[-14000:])
sys.exit(0)
