    private func createSystemShortcut(_ message: String) throws {
        // Onboarding and the observed expanded sidebar share the original
        // creation allowance; no navigation tap substitutes for actual creation.
        var continuedWhatsNew = false
        var hidSidebar = false
        var create = shortcuts.buttons["Create Shortcut"].firstMatch
        try require(wait(12) {
            let whatsNew = self.shortcuts.staticTexts["What’s New in Shortcuts"].firstMatch
            if whatsNew.exists {
                let next = self.shortcuts.buttons["Continue"].firstMatch
                guard !continuedWhatsNew && whatsNew.isHittable &&
                        next.exists && next.isEnabled && next.isHittable else { return false }
                continuedWhatsNew = true
                next.tap()
                return false
            }
            create = self.firstButton(self.shortcuts, ["Create Shortcut", "Add", "New Shortcut"])
            if create.exists && create.isEnabled && create.isHittable { return true }

            let newShortcut = self.shortcuts.buttons["New Shortcut"].firstMatch
            guard !hidSidebar && newShortcut.exists && newShortcut.isEnabled &&
                    !newShortcut.isHittable else { return false }
            let sidebarBars = self.shortcuts.navigationBars
                .containing(.button, identifier: "sidebar.button.edit").allElementsBoundByIndex
                .filter { $0.buttons["sidebar.button.newfolder"].firstMatch.exists }
            guard sidebarBars.count == 1 else { return false }
            let hideButtons = sidebarBars[0].buttons.matching(identifier: "Hide Sidebar")
                .allElementsBoundByIndex.filter { $0.exists && $0.isEnabled && $0.isHittable }
            guard hideButtons.count == 1 else { return false }
            hidSidebar = true
            hideButtons[0].tap()
            return false
        }, message)
        create.tap()
    }

    private func shortcutActionSearchFields() -> [XCUIElement] {
        let labels = ["Search Actions", "Search for apps and actions"]
        return shortcuts.searchFields.allElementsBoundByIndex.filter { field in
            field.exists &&
                (labels.contains(field.label) || labels.contains(field.placeholderValue ?? "")) &&
                field.isEnabled && field.isHittable
        }
    }

    private func findShortcutActionSearch(
        _ message: String, navigateFromNewShortcut: Bool = true
    ) throws -> XCUIElement {
        // The original search allowance includes only observed navigation.
        // All Shortcuts' generic Search is never an action-gallery candidate.
        var enteredEditor = false
        var openedActions = false
        var search = shortcuts.searchFields["Search Actions"].firstMatch
        try require(wait(12) {
            let fields = self.shortcutActionSearchFields()
            if fields.count == 1 {
                search = fields[0]
                return true
            }
            guard fields.isEmpty && navigateFromNewShortcut else { return false }
            if !enteredEditor {
                let editors = self.shortcuts.navigationBars.matching(identifier: "New Shortcut")
                    .buttons.matching(identifier: "Editor").allElementsBoundByIndex
                    .filter { $0.exists && $0.isEnabled && $0.isHittable }
                guard editors.count <= 1 else { return false }
                if let editor = editors.first {
                    enteredEditor = true
                    editor.tap()
                    return false
                }
            }
            if !openedActions {
                for label in ["Add Action", "Search Actions"] {
                    let buttons = self.shortcuts.buttons.matching(identifier: label)
                        .allElementsBoundByIndex.filter { $0.exists && $0.isEnabled && $0.isHittable }
                    guard buttons.count <= 1 else { return false }
                    if let button = buttons.first {
                        openedActions = true
                        button.tap()
                        return false
                    }
                }
            }
            return false
        }, message)
        search.tap()
        return search
    }

